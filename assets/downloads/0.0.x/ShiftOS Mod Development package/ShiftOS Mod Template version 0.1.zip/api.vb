﻿Module api
    Dim OutPath As String = "C:\ShiftOS\Shiftum42\Temp\DefaultModPath\ModRequest.srip" 'This must be the same as the 2nd line of config.set
    Dim InPath As String = "C:\ShiftOS\Shiftum42\Temp\DefaultModPath\In\" 'This must be the same as the 3rd line of config.set
    Dim readDelay As Integer = 2000 'This should be the same as the 4th line of config.set

    Dim sw As System.IO.StreamWriter
    Dim sr As System.IO.StreamReader
    Dim WithEvents tmrRead As Timer = New Timer

    Public Sub init()
        If Not My.Computer.FileSystem.DirectoryExists("C:\ShiftOS\Shiftum42\Temp\DefaultModPath\") Then 'This must be the same as OutPath without the file
            My.Computer.FileSystem.CreateDirectory("C:\ShiftOS\Shiftum42\Temp\DefaultModPath\")
        End If
    End Sub

    'This Module allows you to call ShiftOS functions without dealing with the ShiftOS Request/Receive* Information Protocol (SRIP) *Depends on the direction (Yes I have wierd naming conventions)
    'If you wish to do this yourself, see the documentation for information on how it works

    'The Following commands requires you to call function from with this module, insert the call where indicated
    Private Sub ReadInput() Handles tmrRead.Tick
        If My.Computer.FileSystem.DirectoryExists(InPath & "\givecolour.srip") Then
            sr = New IO.StreamReader(InPath & "\givecolour.srip")
            ' The selected colour's RGB value can be accessed through sr.readline() - do with it what you want
            sr.Close()
        End If
    End Sub
    'The following commands can be called by calling "api.functionName(required data)" - there is no need to edit
    Public Sub getColour(TitleOfColourPicker As String)
        sw = New IO.StreamWriter(OutPath)
        sw.WriteLine("getcolour.title = " & TitleOfColourPicker)
        sw.Close()
        tmrRead.Interval = readDelay
        tmrRead.Start()
    End Sub
    Public Sub makeInfoBox(title As String, message As String)
        sw = New IO.StreamWriter(OutPath)
        sw.WriteLine("infobox.title = " & title)
        sw.WriteLine("infobox.message = " & message)
        sw.Close()
    End Sub
    Public Sub addCodepoints(amount As Integer)
        sw = New IO.StreamWriter(OutPath)
        sw.WriteLine("codepoints.add = " & amount)
        sw.Close()
    End Sub
    Public Sub addBitnotes(amount As Decimal)
        sw = New IO.StreamWriter(OutPath)
        sw.WriteLine("bitnotes.add = " & amount)
        sw.Close()
    End Sub
End Module
