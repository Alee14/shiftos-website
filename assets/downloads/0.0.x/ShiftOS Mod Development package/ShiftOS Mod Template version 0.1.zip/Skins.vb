﻿Imports System.IO

Module Skins
#Region "Declarations"
    Dim savepath As String = "C:\ShiftOS\"
    Dim loadedskin As String = "C:\ShiftOS\Shiftum42\Skins\Loaded\"
    Dim firstrun As Boolean = True
    'WINDOW SETTINGS/IMAGES
    'images
    Public titlebar As Image = Nothing
    Public titlebarlayout As String = 3
    Public borderleft As Image = Nothing
    Public borderleftlayout As String = 3
    Public borderright As Image = Nothing
    Public borderrightlayout As String = 3
    Public borderbottom As Image = Nothing
    Public borderbottomlayout As String = 3
    Public closebtn As Image = Nothing
    Public closebtnlayout As String = 3
    Public closebtnhover As Image = Nothing
    Public closebtnclick As Image = Nothing
    Public rollbtn As Image = Nothing
    Public rollbtnlayout As String = 3
    Public rollbtnhover As Image = Nothing
    Public rollbtnclick As Image = Nothing
    Public minbtn As Image = Nothing
    Public minbtnlayout As String = 3
    Public minbtnhover As Image = Nothing
    Public minbtnclick As Image = Nothing
    Public rightcorner As Image = Nothing
    Public rightcornerlayout As String = 3
    Public leftcorner As Image = Nothing
    Public leftcornerlayout As String = 3
    Public bottomleftcorner As Image = Nothing
    Public bottomleftcornerlayout As String = 3
    Public bottomrightcorner As Image = Nothing
    Public bottomrightcornerlayout As String = 3
    Public bottomleftcornercolour As Color = Color.Gray
    Public bottomrightcornercolour As Color = Color.Gray
    Public enablebordercorners As Boolean = False

    ' settings
    Public closebtnsize As Size = New Size(22, 22)
    Public rollbtnsize As Size = New Size(22, 22)
    Public minbtnsize As Size = New Size(22, 22)
    Public titlebarheight As Integer = 30
    Public closebtnfromtop As Integer = 5
    Public closebtnfromside As Integer = 2
    Public rollbtnfromtop As Integer = 5
    Public rollbtnfromside As Integer = 26
    Public minbtnfromtop As Integer = 5
    Public minbtnfromside As Integer = 52
    Public borderwidth As Integer = 2
    Public enablecorners As Boolean = False
    Public titlebarcornerwidth As Integer = 5
    Public titleiconfromside As Integer = 4
    Public titleiconfromtop As Integer = 4
    'colours
    Public titlebarcolour As Color = Color.Gray
    Public borderleftcolour As Color = Color.Gray
    Public borderrightcolour As Color = Color.Gray
    Public borderbottomcolour As Color = Color.Gray
    Public closebtncolour As Color = Color.Black
    Public closebtnhovercolour As Color = Color.Black
    Public closebtnclickcolour As Color = Color.Black
    Public rollbtncolour As Color = Color.Black
    Public rollbtnhovercolour As Color = Color.Black
    Public rollbtnclickcolour As Color = Color.Black
    Public minbtncolour As Color = Color.Black
    Public minbtnhovercolour As Color = Color.Black
    Public minbtnclickcolour As Color = Color.Black
    Public rightcornercolour As Color = Color.Gray
    Public leftcornercolour As Color = Color.Gray
    ' Text
    Public titletextfontfamily As String = "Microsoft Sans Serif"
    Public titletextfontsize As Integer = 10
    Public titletextfontstyle As String = FontStyle.Bold
    Public titletextpos As String = "Left"
    Public titletextfromtop As Integer = 3
    Public titletextfromside As Integer = 24
    Public titletextcolour As Color = Color.White

    Private Function GetImage(ByVal fileName As String) As Bitmap
        Dim ret As Bitmap
        Using img As Image = Image.FromFile(fileName)
            ret = New Bitmap(img)
        End Using
        Return ret
    End Function

#End Region

    ' LOAD SKIN FROM SKN FILE
    Public Sub loadsknfile(ByVal filepath As String)
        If Directory.Exists(loadedskin) Then My.Computer.FileSystem.DeleteDirectory(savepath + "Shiftum42\Skins\Loaded", FileIO.DeleteDirectoryOption.DeleteAllContents)
        Directory.CreateDirectory(savepath + "Shiftum42\Skins\Loaded")
        System.IO.Compression.ZipFile.ExtractToDirectory(filepath, savepath + "Shiftum42\Skins\Loaded")
        loadimages()
    End Sub
    ' LOAD SKIN FROM SAVE FOLDER
    Public Sub loadimages()
        'If File.Exists(loadedskin & "titlebar") Then
        titlebar = GetImage(loadedskin & "titlebar")
        'Else : titlebar = Nothing
        'End If
        If File.Exists(loadedskin & "borderleft") Then
            borderleft = GetImage(loadedskin & "borderleft")
        Else : borderleft = Nothing
        End If
        If File.Exists(loadedskin & "borderright") Then
            borderright = GetImage(loadedskin & "borderright".Clone)
        Else : borderright = Nothing
        End If
        If File.Exists(loadedskin & "borderbottom") Then
            borderbottom = GetImage(loadedskin & "borderbottom".Clone)
        Else : borderbottom = Nothing
        End If
        If File.Exists(loadedskin & "closebtn") Then
            closebtn = GetImage(loadedskin & "closebtn".Clone)
        Else : closebtn = Nothing
        End If
        If File.Exists(loadedskin & "closebtnhover") Then
            closebtnhover = GetImage(loadedskin & "closebtnhover".Clone)
        Else : closebtnhover = Nothing
        End If
        If File.Exists(loadedskin & "closebtnclick") Then
            closebtnclick = GetImage(loadedskin & "closebtnclick".Clone)
        Else : closebtnclick = Nothing
        End If
        If File.Exists(loadedskin & "rollbtn") Then
            rollbtn = GetImage(loadedskin & "rollbtn".Clone)
        Else : rollbtn = Nothing
        End If
        If File.Exists(loadedskin & "rollbtnhover") Then
            rollbtnhover = GetImage(loadedskin & "rollbtnhover".Clone)
        Else : rollbtnhover = Nothing
        End If
        If File.Exists(loadedskin & "rollbtnclick") Then
            rollbtnclick = GetImage(loadedskin & "rollbtnclick".Clone)
        Else : rollbtnclick = Nothing
        End If
        If File.Exists(loadedskin & "minbtn") Then
            minbtn = GetImage(loadedskin & "minbtn".Clone)
        Else : minbtn = Nothing
        End If
        If File.Exists(loadedskin & "minbtnhover") Then
            minbtnhover = GetImage(loadedskin & "minbtnhover".Clone)
        Else : minbtnhover = Nothing
        End If
        If File.Exists(loadedskin & "minbtnclick") Then
            minbtnclick = GetImage(loadedskin & "minbtnclick".Clone)
        Else : minbtnclick = Nothing
        End If
        If File.Exists(loadedskin & "rightcorner") Then
            rightcorner = GetImage(loadedskin & "rightcorner".Clone)
        Else : rightcorner = Nothing
        End If
        If File.Exists(loadedskin & "leftcorner") Then
            leftcorner = GetImage(loadedskin & "leftcorner".Clone)
        Else : leftcorner = Nothing
        End If
        If File.Exists(loadedskin & "bottomleftcorner") Then
            bottomleftcorner = GetImage(loadedskin & "bottomleftcorner".Clone)
        Else : bottomleftcorner = Nothing
        End If
        If File.Exists(loadedskin & "bottomrightcorner") Then
            bottomrightcorner = GetImage(loadedskin & "bottomrightcorner".Clone)
        Else : bottomrightcorner = Nothing
        End If
        'load settings
        Dim loaddata(200) As String
        If File.Exists(loadedskin & "data.dat") Then
            Dim sr As StreamReader = New StreamReader(loadedskin & "data.dat")

            For i As Integer = 0 To 200 Step 1
                loaddata(i) = sr.ReadLine
                If i = 200 Then
                    sr.Close()
                    Exit For
                End If
            Next

            ' settings
            closebtnsize = New Size(loaddata(1), loaddata(2))
            rollbtnsize = New Size(loaddata(3), loaddata(4))
            minbtnsize = New Size(loaddata(5), loaddata(6))
            titlebarheight = loaddata(7)
            closebtnfromtop = loaddata(8)
            closebtnfromside = loaddata(9)
            rollbtnfromtop = loaddata(10)
            rollbtnfromside = loaddata(11)
            minbtnfromtop = loaddata(12)
            minbtnfromside = loaddata(13)
            borderwidth = loaddata(14)
            enablecorners = loaddata(15)
            titlebarcornerwidth = loaddata(16)
            titleiconfromside = loaddata(17)
            titleiconfromtop = loaddata(18)
            titlebarcolour = Color.FromArgb(loaddata(19))
            borderleftcolour = Color.FromArgb(loaddata(20))
            borderrightcolour = Color.FromArgb(loaddata(21))
            borderbottomcolour = Color.FromArgb(loaddata(22))
            closebtncolour = Color.FromArgb(loaddata(23))
            closebtnhovercolour = Color.FromArgb(loaddata(24))
            closebtnclickcolour = Color.FromArgb(loaddata(25))
            rollbtncolour = Color.FromArgb(loaddata(26))
            rollbtnhovercolour = Color.FromArgb(loaddata(27))
            rollbtnclickcolour = Color.FromArgb(loaddata(28))
            minbtncolour = Color.FromArgb(loaddata(29))
            minbtnhovercolour = Color.FromArgb(loaddata(30))
            minbtnclickcolour = Color.FromArgb(loaddata(31))
            rightcornercolour = Color.FromArgb(loaddata(32))
            leftcornercolour = Color.FromArgb(loaddata(33))
            bottomrightcornercolour = Color.FromArgb(loaddata(34))
            bottomleftcornercolour = Color.FromArgb(loaddata(35))
            titletextfontfamily = loaddata(36)
            titletextfontsize = loaddata(37)
            titletextfontstyle = loaddata(38)
            titletextpos = loaddata(39)
            titletextfromtop = loaddata(40)
            titletextfromside = loaddata(41)
            titletextcolour = Color.FromArgb(loaddata(42))

            'layout stuff
            titlebarlayout = loaddata(89)
            borderleftlayout = loaddata(90)
            borderrightlayout = loaddata(91)
            borderbottomlayout = loaddata(92)
            closebtnlayout = loaddata(93)
            rollbtnlayout = loaddata(94)
            minbtnlayout = loaddata(95)
            rightcornerlayout = loaddata(96)
            leftcornerlayout = loaddata(97)
            bottomleftcornerlayout = loaddata(103)
            bottomrightcornerlayout = loaddata(104)

        Else
            setupdefaults()
        End If
        applyskin()
    End Sub
    ' SET SKIN
    Public Sub applyskin()
        Form1.setupall()
    End Sub
    ' SAVE TO SKN FILE
    Public Sub saveskin(ByVal path As String)
        If Not File.Exists(path) Then
            Dim sw As StreamWriter = New StreamWriter(loadedskin & "SKN-version") 'tells skin loader which system to use when openning the file
            sw.WriteLine("Name of skinning system used to create this skn file:")
            sw.WriteLine("2.0 disposal-free skinning")
            sw.WriteLine("Skinning system created by william.1008 on December 2014, based on 1.0 system by DevX")
            sw.Close()
            saveskinfiles(False)
            Compression.ZipFile.CreateFromDirectory(loadedskin, path)
            File.Delete(loadedskin & "SKN-version")
        Else
            'DO INFO infobox.showinfo("File Exists", "That file location is already taken, please choose another.")
        End If
    End Sub
    ' SAVE TO SAVE FOLDER
    Public Sub saveskinfiles(ByVal apply As Boolean)
        If File.Exists(loadedskin) Then
            Directory.Delete(loadedskin)
        End If
        Directory.CreateDirectory(loadedskin)
        saveimage(titlebar, "titlebar")
        saveimage(borderleft, "borderleft")
        saveimage(borderright, "borderright")
        saveimage(borderbottom, "borderbottom")
        saveimage(closebtn, "closebtn")
        saveimage(closebtnhover, "closebtnhover")
        saveimage(closebtnclick, "closebtnclick")
        saveimage(rollbtn, "rollbtn")
        saveimage(rollbtnhover, "rollbtnhover")
        saveimage(rollbtnclick, "rollbtnclick")
        saveimage(minbtn, "minbtn")
        saveimage(minbtnhover, "minbtnhover")
        saveimage(minbtnclick, "minbtnclick")
        saveimage(rightcorner, "rightcorner")
        saveimage(leftcorner, "leftcorner")
        saveimage(bottomleftcorner, "bottomleftcorner")
        saveimage(bottomrightcorner, "bottomrightcorner")
        'save settings to dat file
        Dim savedata(200) As String
        ' setting and colour as saved in the order they are declared, image's are saved in sepporate preset files,
        ' image layout options are saved at the end of file
        savedata(0) = "ShiftOS skin data - Beware: Editing may result in skinning errors"
        savedata(2) = closebtnsize.Height
        savedata(1) = closebtnsize.Width
        savedata(4) = rollbtnsize.Height
        savedata(3) = rollbtnsize.Width
        savedata(6) = minbtnsize.Height
        savedata(5) = minbtnsize.Width
        savedata(7) = titlebarheight
        savedata(8) = closebtnfromtop
        savedata(9) = closebtnfromside
        savedata(10) = rollbtnfromtop
        savedata(11) = rollbtnfromside
        savedata(12) = minbtnfromtop
        savedata(13) = minbtnfromside
        savedata(14) = borderwidth
        savedata(15) = enablecorners
        savedata(16) = titlebarcornerwidth
        savedata(17) = titleiconfromside
        savedata(18) = titleiconfromtop
        savedata(19) = titlebarcolour.ToArgb
        savedata(20) = borderleftcolour.ToArgb
        savedata(21) = borderrightcolour.ToArgb
        savedata(22) = borderbottomcolour.ToArgb
        savedata(23) = closebtncolour.ToArgb
        savedata(24) = closebtnhovercolour.ToArgb
        savedata(25) = closebtnclickcolour.ToArgb
        savedata(26) = rollbtncolour.ToArgb
        savedata(27) = rollbtnhovercolour.ToArgb
        savedata(28) = rollbtnclickcolour.ToArgb
        savedata(29) = minbtncolour.ToArgb
        savedata(30) = minbtnhovercolour.ToArgb
        savedata(31) = minbtnclickcolour.ToArgb
        savedata(32) = rightcornercolour.ToArgb
        savedata(33) = leftcornercolour.ToArgb
        savedata(34) = bottomrightcornercolour.ToArgb
        savedata(35) = bottomleftcornercolour.ToArgb
        savedata(36) = titletextfontfamily
        savedata(37) = titletextfontsize
        savedata(38) = titletextfontstyle
        savedata(39) = titletextpos
        savedata(40) = titletextfromtop
        savedata(41) = titletextfromside
        savedata(42) = titletextcolour.ToArgb
        'Image layout options
        savedata(89) = titlebarlayout
        savedata(90) = borderleftlayout
        savedata(91) = borderrightlayout
        savedata(92) = borderbottomlayout
        savedata(93) = closebtnlayout
        savedata(94) = rollbtnlayout
        savedata(95) = minbtnlayout
        savedata(96) = rightcornerlayout
        savedata(97) = leftcornerlayout
        savedata(103) = bottomleftcornerlayout
        savedata(104) = bottomrightcornerlayout
        savedata(109) = enablebordercorners

        ' End of skin data text was at line 110, if adding future items, check for "End of skin data" on line 110
        savedata(200) = "End of skin data"
        File.WriteAllLines(loadedskin & "data.dat", savedata)
        If apply = True Then
            applyskin()
        End If
    End Sub
    Public Sub setupdefaults()
        titlebar = Nothing
        titlebarlayout = 3
        borderleft = Nothing
        borderleftlayout = 3
        borderright = Nothing
        borderrightlayout = 3
        borderbottom = Nothing
        borderbottomlayout = 3
        closebtn = Nothing
        closebtnlayout = 3
        closebtnhover = Nothing
        closebtnclick = Nothing
        rollbtn = Nothing
        rollbtnlayout = 3
        rollbtnhover = Nothing
        rollbtnclick = Nothing
        minbtn = Nothing
        minbtnlayout = 3
        minbtnhover = Nothing
        minbtnclick = Nothing
        rightcorner = Nothing
        rightcornerlayout = 3
        leftcorner = Nothing
        leftcornerlayout = 3
        bottomleftcorner = Nothing
        bottomleftcornerlayout = 3
        bottomrightcorner = Nothing
        bottomrightcornerlayout = 3
        bottomleftcornercolour = Color.Gray
        bottomrightcornercolour = Color.Gray
        enablebordercorners = False
        closebtnsize = New Size(22, 22)
        rollbtnsize = New Size(22, 22)
        minbtnsize = New Size(22, 22)
        titlebarheight = 30
        closebtnfromtop = 5
        closebtnfromside = 2
        rollbtnfromtop = 5
        rollbtnfromside = 26
        minbtnfromtop = 5
        minbtnfromside = 52
        borderwidth = 2
        enablecorners = False
        titlebarcornerwidth = 5
        titleiconfromside = 4
        titleiconfromtop = 4
        titlebarcolour = Color.Gray
        borderleftcolour = Color.Gray
        borderrightcolour = Color.Gray
        borderbottomcolour = Color.Gray
        closebtncolour = Color.Black
        closebtnhovercolour = Color.Black
        closebtnclickcolour = Color.Black
        rollbtncolour = Color.Black
        rollbtnhovercolour = Color.Black
        rollbtnclickcolour = Color.Black
        minbtncolour = Color.Black
        minbtnhovercolour = Color.Black
        minbtnclickcolour = Color.Black
        rightcornercolour = Color.Gray
        leftcornercolour = Color.Gray
        titletextfontfamily = "Microsoft Sans Serif"
        titletextfontsize = 10
        titletextfontstyle = FontStyle.Bold
        titletextpos = "Left"
        titletextfromtop = 3
        titletextfromside = 24
        titletextcolour = Color.White
    End Sub
    Private Sub saveimage(ByVal img As Image, ByVal name As String)
        If Not IsNothing(img) Then
            If File.Exists(loadedskin & name) Then File.Delete(loadedskin & name)
            Try
                img.Save(loadedskin & name, System.Drawing.Imaging.ImageFormat.Png)
            Catch ex As Exception
            End Try
        Else
            If File.Exists(loadedskin & name) Then File.Delete(loadedskin & name)
        End If
    End Sub
End Module
