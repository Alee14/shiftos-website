﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Shiftnet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Shiftnet))
        Me.pullside = New System.Windows.Forms.Timer(Me.components)
        Me.pullbs = New System.Windows.Forms.Timer(Me.components)
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.pullbottom = New System.Windows.Forms.Timer(Me.components)
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.pnlquickchat = New System.Windows.Forms.Panel()
        Me.pnlquickchathome = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.tbqcusers = New System.Windows.Forms.ListView()
        Me.tbqcchat = New System.Windows.Forms.TextBox()
        Me.tbqctype = New System.Windows.Forms.TextBox()
        Me.qchome = New System.Windows.Forms.Label()
        Me.pnlquickchatoffline = New System.Windows.Forms.Panel()
        Me.qcpanel = New System.Windows.Forms.Panel()
        Me.tbqcochat = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.tbqchomebtn = New System.Windows.Forms.Label()
        Me.pnlxenonh = New System.Windows.Forms.Panel()
        Me.pnlxenonhhome = New System.Windows.Forms.Panel()
        Me.tbxenonhquickchat = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.pnlpostspot = New System.Windows.Forms.Panel()
        Me.pnlpostspothome = New System.Windows.Forms.Panel()
        Me.tbxenonhurl = New System.Windows.Forms.Label()
        Me.tbpostspothomeshifterhackerlink = New System.Windows.Forms.Label()
        Me.tbpostspothomecontent = New System.Windows.Forms.Label()
        Me.tbpostspothomead = New System.Windows.Forms.Label()
        Me.tbpostspothomesubtext = New System.Windows.Forms.Label()
        Me.tbpostspothomepostspot = New System.Windows.Forms.Label()
        Me.pnlpirateboat = New System.Windows.Forms.Panel()
        Me.pnlpirateboatmain = New System.Windows.Forms.Panel()
        Me.tpbsearchresults = New System.Windows.Forms.ListView()
        Me.tpbsearch = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.tbpbfglink1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tbpbWarning = New System.Windows.Forms.Label()
        Me.tbpbMSG = New System.Windows.Forms.Label()
        Me.tbdnlfloodgate = New System.Windows.Forms.Label()
        Me.tbPirateBoat = New System.Windows.Forms.Label()
        Me.pnlpirateboatdownlaod = New System.Windows.Forms.Panel()
        Me.tpbbackbtn = New System.Windows.Forms.Button()
        Me.tpbfloodgate = New System.Windows.Forms.Button()
        Me.tpburlbox = New System.Windows.Forms.TextBox()
        Me.pnlhome = New System.Windows.Forms.Panel()
        Me.pnlhomehome = New System.Windows.Forms.Panel()
        Me.lblhomehomehistorylink = New System.Windows.Forms.Label()
        Me.lblhomehomebackuplink = New System.Windows.Forms.Label()
        Me.lblhomehomebitnotelink = New System.Windows.Forms.Label()
        Me.lblhomehomeminimatchlink = New System.Windows.Forms.Label()
        Me.lblhomehomeappscapelink = New System.Windows.Forms.Label()
        Me.lblhomehomedescription = New System.Windows.Forms.Label()
        Me.pichomehomeicon = New System.Windows.Forms.PictureBox()
        Me.tbhomehomewelcome = New System.Windows.Forms.Label()
        Me.pnlhomehistory = New System.Windows.Forms.Panel()
        Me.lbhomehistoryhistory = New System.Windows.Forms.ListView()
        Me.pnlmainsiteappscape = New System.Windows.Forms.Panel()
        Me.pnlappscapedeposit = New System.Windows.Forms.Panel()
        Me.appscapedepositestep3 = New System.Windows.Forms.Label()
        Me.appscapedepositestep2 = New System.Windows.Forms.Label()
        Me.appscapedepositestep1 = New System.Windows.Forms.Label()
        Me.picappscapedepositeinfobitnotescreenshot = New System.Windows.Forms.PictureBox()
        Me.lblappscapedepositpasteinfo = New System.Windows.Forms.Label()
        Me.txtappscapedepositeaddress = New System.Windows.Forms.TextBox()
        Me.lblappscapecopyaddressinfo = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.btnappscapedepositeback = New System.Windows.Forms.Panel()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.lbappscapepayinfohello = New System.Windows.Forms.Label()
        Me.appscapehomepage = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.btnbuymoresoftware2 = New System.Windows.Forms.Panel()
        Me.btnmoresoftware2info = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.btnbuyorcwrite = New System.Windows.Forms.Panel()
        Me.btnmoresoftware1info = New System.Windows.Forms.Panel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.btnbuycalculator = New System.Windows.Forms.Panel()
        Me.btncalculatorinfo = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.btnbuywebbrowser = New System.Windows.Forms.Panel()
        Me.btnwebbrowserinfo = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.btnbuyvideoplayer = New System.Windows.Forms.Panel()
        Me.btnvideoplayerinfo = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnbuyaudioplayer = New System.Windows.Forms.Panel()
        Me.btnaudioplayerinfo = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lbappscapehello = New System.Windows.Forms.Label()
        Me.btnappscapedeposit = New System.Windows.Forms.Panel()
        Me.pnlappscapeoprcwrite = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.btnappscapeorcwritebuy = New System.Windows.Forms.Panel()
        Me.btnappscapeorcwriteback = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.lblappscapeorcwritehellotext = New System.Windows.Forms.Label()
        Me.btnappscapeorcwritedeposit = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.appscapewebbrowserinfopage = New System.Windows.Forms.Panel()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.btnwebbrowserinfobuy = New System.Windows.Forms.Panel()
        Me.btnwebbrowserinfoback = New System.Windows.Forms.Panel()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.lbappscapewebbroswerinfohello = New System.Windows.Forms.Label()
        Me.appscapewebbrowserinfodepositbtn = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.appscapevideoplayerinfopage = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.btnvideoplayerinfobuy = New System.Windows.Forms.Panel()
        Me.btnvideoplayerinfoback = New System.Windows.Forms.Panel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.lbappscapevideoplayerinfohello = New System.Windows.Forms.Label()
        Me.appscapevideoplayerinfodepositbtn = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.appscapecalculatorinfopage = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.btncalculatorinfobuy = New System.Windows.Forms.Panel()
        Me.btncalculatorinfoback = New System.Windows.Forms.Panel()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.lbappscapecalculatorinfohello = New System.Windows.Forms.Label()
        Me.appscapecalcinfodepositbtn = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.appscapeaudioplayerinfopage = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnaudioplayerinfobuy = New System.Windows.Forms.Panel()
        Me.btnaudioplayerinfoback = New System.Windows.Forms.Panel()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.lbappscapeaudioplayerinfohello = New System.Windows.Forms.Label()
        Me.appscapeaudioplayerinfodepositbtn = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnlmainsiteminimatch = New System.Windows.Forms.Panel()
        Me.pnlminimatchlabyrinth = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.txtminimatchlabrinthaddress = New System.Windows.Forms.TextBox()
        Me.lblminimatchinfopagebuy = New System.Windows.Forms.Label()
        Me.lblminimatchlabyrinthbuyinstuct = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.pnlminimatchhomepage = New System.Windows.Forms.Panel()
        Me.lblminimatchcopyright = New System.Windows.Forms.Label()
        Me.pnlminimatchcomingsoon2 = New System.Windows.Forms.Panel()
        Me.pnlminimatchcomingsoonbuy2 = New System.Windows.Forms.Label()
        Me.pnlminimatchcomingsooninfo2 = New System.Windows.Forms.Label()
        Me.pnlminimatchcomingsoondescription2 = New System.Windows.Forms.Label()
        Me.pnlminimatchcomingsoontitle2 = New System.Windows.Forms.Label()
        Me.pnlminimatchcomingsoon = New System.Windows.Forms.Panel()
        Me.bntminimatchcomingsoonbuy = New System.Windows.Forms.Label()
        Me.bntminimatchcomingsooninfo = New System.Windows.Forms.Label()
        Me.lblminimatchcomingsoondescription = New System.Windows.Forms.Label()
        Me.lblminimatchcomingsoontitle = New System.Windows.Forms.Label()
        Me.pnlminimatchdodgepreview = New System.Windows.Forms.Panel()
        Me.bntminimatchdodgebuy = New System.Windows.Forms.Label()
        Me.bntminimatchdodgeinfo = New System.Windows.Forms.Label()
        Me.lblminimatchdodgedescription = New System.Windows.Forms.Label()
        Me.lblminimatchdodgetitle = New System.Windows.Forms.Label()
        Me.picbitnotesaccepted = New System.Windows.Forms.PictureBox()
        Me.lblminimatchmainpagewelcome = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.pnlminimatchdodgeinfopage = New System.Windows.Forms.Panel()
        Me.lblminimatchuserwelcome = New System.Windows.Forms.Label()
        Me.pnlminimatchdodgepagebuy = New System.Windows.Forms.Panel()
        Me.txtminimatchbitnoteaddress = New System.Windows.Forms.TextBox()
        Me.btnminimatchdodgepagebuy = New System.Windows.Forms.Label()
        Me.lblminimatchdodgehow2buydetails = New System.Windows.Forms.Label()
        Me.lblminimatchdodgehow2buy = New System.Windows.Forms.Label()
        Me.picminimatchdodgepreview = New System.Windows.Forms.PictureBox()
        Me.lblminimatchcopyrightdodgepage = New System.Windows.Forms.Label()
        Me.pnlminimatchdodgeinfodetails = New System.Windows.Forms.Panel()
        Me.bntminimatchdodgepageback = New System.Windows.Forms.Label()
        Me.lblminimatchaboutdetails = New System.Windows.Forms.Label()
        Me.lblminimatchdodgeabout = New System.Windows.Forms.Label()
        Me.picminimatchbtnaccepted = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.pnlshiftomizer = New System.Windows.Forms.Panel()
        Me.pnlshiftomizerhome = New System.Windows.Forms.Panel()
        Me.btnshiftomizerhomecheckout = New System.Windows.Forms.Button()
        Me.lblshiftomizerhomeskinsliderdownload = New System.Windows.Forms.Label()
        Me.picshiftomizerhomeappslidernext = New System.Windows.Forms.PictureBox()
        Me.picshiftomizerhomeappsliderback = New System.Windows.Forms.PictureBox()
        Me.lblshiftomizerhomeappdescription = New System.Windows.Forms.Label()
        Me.picshiftomizerhomeappsliderimg = New System.Windows.Forms.PictureBox()
        Me.lblshiftomizerhomeappname = New System.Windows.Forms.Label()
        Me.picshiftomizerhomeskinsliderright = New System.Windows.Forms.PictureBox()
        Me.picshiftomizerhomeskinssliderleft = New System.Windows.Forms.PictureBox()
        Me.lblshiftomizerhomeskinname = New System.Windows.Forms.Label()
        Me.lblshiftomizerhomeappdownload = New System.Windows.Forms.Label()
        Me.lblshiftomizerhomeskinsliderdescription = New System.Windows.Forms.Label()
        Me.picshiftomizerhomeskinsliderimage = New System.Windows.Forms.PictureBox()
        Me.lblshiftomizerhomedescription = New System.Windows.Forms.Label()
        Me.lblshiftomizerhometitle = New System.Windows.Forms.Label()
        Me.pnlshiftomizerpayments = New System.Windows.Forms.Panel()
        Me.lblshiftomizerpaymentsclear = New System.Windows.Forms.Label()
        Me.lblshiftomizerpaymentsback = New System.Windows.Forms.Label()
        Me.lblshiftomizerpaymentinstruct = New System.Windows.Forms.Label()
        Me.lblshiftomizerpaymentorder = New System.Windows.Forms.Label()
        Me.lblshiftomizerpaymentstitle = New System.Windows.Forms.Label()
        Me.pnlbitnotemainpage = New System.Windows.Forms.Panel()
        Me.pnlbitnotedigger = New System.Windows.Forms.Panel()
        Me.btnbitnotediggergrade5buy = New System.Windows.Forms.Button()
        Me.btnbitnotediggergrade4buy = New System.Windows.Forms.Button()
        Me.btnbitnotediggergrade3buy = New System.Windows.Forms.Button()
        Me.btnbitnotediggergrade2buy = New System.Windows.Forms.Button()
        Me.btnbitnotediggergrade1buy = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.pnlbitnotediggerfooter = New System.Windows.Forms.Panel()
        Me.lblbitnotediggerfooterhomelink = New System.Windows.Forms.Label()
        Me.lblbitnotediggerfootercopyright = New System.Windows.Forms.Label()
        Me.lblbitnotediggerfootergetlink = New System.Windows.Forms.Label()
        Me.lblbitnotediggerfooterdiggerlink = New System.Windows.Forms.Label()
        Me.lblbitnotediggerfooterwalletlink = New System.Windows.Forms.Label()
        Me.lblbitnotediggerfootergettitle = New System.Windows.Forms.Label()
        Me.lblbitnotediggerfooterdownloadstitle = New System.Windows.Forms.Label()
        Me.lblbitnotediggerfooterabouttitle = New System.Windows.Forms.Label()
        Me.pnlbitnotediggersideright = New System.Windows.Forms.Panel()
        Me.pnlbitnotediggersideleft = New System.Windows.Forms.Panel()
        Me.lblbitnotediggerdescription = New System.Windows.Forms.Label()
        Me.lblbitnotediggertitle = New System.Windows.Forms.Label()
        Me.picbitnotediggertitlelogo = New System.Windows.Forms.PictureBox()
        Me.pnlbitnotecurrencyexchange = New System.Windows.Forms.Panel()
        Me.btnbitnotecurrencyexchangebuy = New System.Windows.Forms.Button()
        Me.txtbitnotecurrencyexchangebitnoteamout = New System.Windows.Forms.TextBox()
        Me.lblbitnotecurrencyexchangeprice = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangebuytitle = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangetodaysrate = New System.Windows.Forms.Label()
        Me.pnlbitnotecurrencyexchangefooter = New System.Windows.Forms.Panel()
        Me.lblbitnotecurrencyexchangefooterhomelink = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangefootercopyright = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangefootergetlink = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangefooterdiggerlink = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangefooterwalletlink = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangefootergettitle = New System.Windows.Forms.Label()
        Me.bitnotecurrencyexchangefooterdownloadstitle = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangefooterabouttitle = New System.Windows.Forms.Label()
        Me.pnlbitnotecurrencyexchangerightside = New System.Windows.Forms.Panel()
        Me.pnlbitnotecurrencyexchangeleftside = New System.Windows.Forms.Panel()
        Me.lblbitnotecurrencyexchangedescription = New System.Windows.Forms.Label()
        Me.lblbitnotecurrencyexchangetitle = New System.Windows.Forms.Label()
        Me.picbitnotecurrencyexchangetitle = New System.Windows.Forms.PictureBox()
        Me.pnlbitnotebuywallet = New System.Windows.Forms.Panel()
        Me.picbitnotewalletdownloadbtn = New System.Windows.Forms.PictureBox()
        Me.lblbitnotewalletdescription2 = New System.Windows.Forms.Label()
        Me.lblbitnotewalletdescription1 = New System.Windows.Forms.Label()
        Me.picbitnotewalletpagescreenshot = New System.Windows.Forms.PictureBox()
        Me.pnlbitnotewalletfooter = New System.Windows.Forms.Panel()
        Me.lblbitnotewalletpagefooterhomelink = New System.Windows.Forms.Label()
        Me.lblbitnotewalletcopyrighttitle = New System.Windows.Forms.Label()
        Me.lblbitnotewalletfootergetlink = New System.Windows.Forms.Label()
        Me.lblbitnotewalletdiggerdownloadlink = New System.Windows.Forms.Label()
        Me.lblbitnotewalletwalletdownloadlink = New System.Windows.Forms.Label()
        Me.lblbitnotewalletpagegettitle = New System.Windows.Forms.Label()
        Me.lblbitnotewalletpagedownloadstitle = New System.Windows.Forms.Label()
        Me.lblbitnotewalletpageabouttitle = New System.Windows.Forms.Label()
        Me.pnlbitnotewalletpagerightside = New System.Windows.Forms.Panel()
        Me.pnlbitnotewalletpageleftside = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.picbitnotewalletpagelogo = New System.Windows.Forms.PictureBox()
        Me.pnlbitnotehome = New System.Windows.Forms.Panel()
        Me.pnlbitnotehomefooter = New System.Windows.Forms.Panel()
        Me.lblbitnotehomehomebtn = New System.Windows.Forms.Label()
        Me.lblbitnotehomecopyright = New System.Windows.Forms.Label()
        Me.lblbitnotehomefootergetlink = New System.Windows.Forms.Label()
        Me.lblbitnotehomediggerlink = New System.Windows.Forms.Label()
        Me.lblbitnotehomewalletlink = New System.Windows.Forms.Label()
        Me.lblbitnotehomefootergettitle = New System.Windows.Forms.Label()
        Me.lblbitnotehomedownloadlink = New System.Windows.Forms.Label()
        Me.lblbitnotehomeaboutlink = New System.Windows.Forms.Label()
        Me.pnlbitnotesideright = New System.Windows.Forms.Panel()
        Me.pnlbitnotesideleft = New System.Windows.Forms.Panel()
        Me.lblbitnotehowgettxt = New System.Windows.Forms.Label()
        Me.lblbitnotehowgettitle = New System.Windows.Forms.Label()
        Me.lblbitnoteabouttxt = New System.Windows.Forms.Label()
        Me.lblbitnoteabouttitle = New System.Windows.Forms.Label()
        Me.picbitnotewebsitetitle = New System.Windows.Forms.PictureBox()
        Me.pnlshifterhacker = New System.Windows.Forms.Panel()
        Me.pnlshifterhackerhome = New System.Windows.Forms.Panel()
        Me.tbshifterhackerhomefloodgatelink1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.tbshifterhackerhomeblogpost1 = New System.Windows.Forms.Label()
        Me.tbshifterhackerhomefloodgatead = New System.Windows.Forms.Label()
        Me.tbshifterhackerhomepostspotwatermark = New System.Windows.Forms.Label()
        Me.tbshifterhackerhomeh1 = New System.Windows.Forms.Label()
        Me.pnlutilsweb = New System.Windows.Forms.Panel()
        Me.pnlutilswebhome = New System.Windows.Forms.Panel()
        Me.utilswebhomewip = New System.Windows.Forms.Label()
        Me.utilswebvirusscanner = New System.Windows.Forms.Label()
        Me.utilswebbackuputil = New System.Windows.Forms.Label()
        Me.pnlutilswebbackuputility = New System.Windows.Forms.Panel()
        Me.lbl_backuputility_soon = New System.Windows.Forms.Label()
        Me.pnlutilswebvirusscan = New System.Windows.Forms.Panel()
        Me.pnlnotfound = New System.Windows.Forms.Panel()
        Me.pnlnotfoundsite = New System.Windows.Forms.Panel()
        Me.tbnotfound = New System.Windows.Forms.Label()
        Me.pnlshiftnet = New System.Windows.Forms.Panel()
        Me.pnlshiftnethome = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.homenetsite = New System.Windows.Forms.Label()
        Me.homedefaultpage = New System.Windows.Forms.Label()
        Me.hometitle = New System.Windows.Forms.Label()
        Me.pnl404 = New System.Windows.Forms.Panel()
        Me.pnl404home = New System.Windows.Forms.Panel()
        Me.tb404homenotfound = New System.Windows.Forms.Label()
        Me.tb404home404 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnhome = New System.Windows.Forms.Button()
        Me.txtlocation = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lbldevdockingwarning = New System.Windows.Forms.Label()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.tmrloadsite = New System.Windows.Forms.Timer(Me.components)
        Me.AllLinksMustHaveATooltipForTheirUrl = New System.Windows.Forms.ToolTip(Me.components)
        Me.tmrshiftomizerwaitinglist = New System.Windows.Forms.Timer(Me.components)
        Me.qctext = New System.Windows.Forms.Timer(Me.components)
        Me.pgright.SuspendLayout()
        Me.pgcontents.SuspendLayout()
        Me.pnlquickchat.SuspendLayout()
        Me.pnlquickchathome.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.pnlquickchatoffline.SuspendLayout()
        Me.qcpanel.SuspendLayout()
        Me.pnlxenonh.SuspendLayout()
        Me.pnlxenonhhome.SuspendLayout()
        Me.pnlpostspot.SuspendLayout()
        Me.pnlpostspothome.SuspendLayout()
        Me.pnlpirateboat.SuspendLayout()
        Me.pnlpirateboatmain.SuspendLayout()
        Me.pnlpirateboatdownlaod.SuspendLayout()
        Me.pnlhome.SuspendLayout()
        Me.pnlhomehome.SuspendLayout()
        CType(Me.pichomehomeicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlhomehistory.SuspendLayout()
        Me.pnlmainsiteappscape.SuspendLayout()
        Me.pnlappscapedeposit.SuspendLayout()
        CType(Me.picappscapedepositeinfobitnotescreenshot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel46.SuspendLayout()
        Me.Panel47.SuspendLayout()
        Me.appscapehomepage.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.pnlappscapeoprcwrite.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.appscapewebbrowserinfopage.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.appscapevideoplayerinfopage.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.appscapecalculatorinfopage.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel35.SuspendLayout()
        Me.appscapeaudioplayerinfopage.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.pnlmainsiteminimatch.SuspendLayout()
        Me.pnlminimatchlabyrinth.SuspendLayout()
        Me.Panel10.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel12.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlminimatchhomepage.SuspendLayout()
        Me.pnlminimatchcomingsoon2.SuspendLayout()
        Me.pnlminimatchcomingsoon.SuspendLayout()
        Me.pnlminimatchdodgepreview.SuspendLayout()
        CType(Me.picbitnotesaccepted, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlminimatchdodgeinfopage.SuspendLayout()
        Me.pnlminimatchdodgepagebuy.SuspendLayout()
        CType(Me.picminimatchdodgepreview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlminimatchdodgeinfodetails.SuspendLayout()
        CType(Me.picminimatchbtnaccepted, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlshiftomizer.SuspendLayout()
        Me.pnlshiftomizerhome.SuspendLayout()
        CType(Me.picshiftomizerhomeappslidernext, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picshiftomizerhomeappsliderback, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picshiftomizerhomeappsliderimg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picshiftomizerhomeskinsliderright, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picshiftomizerhomeskinssliderleft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picshiftomizerhomeskinsliderimage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlshiftomizerpayments.SuspendLayout()
        Me.pnlbitnotemainpage.SuspendLayout()
        Me.pnlbitnotedigger.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlbitnotediggerfooter.SuspendLayout()
        CType(Me.picbitnotediggertitlelogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlbitnotecurrencyexchange.SuspendLayout()
        Me.pnlbitnotecurrencyexchangefooter.SuspendLayout()
        CType(Me.picbitnotecurrencyexchangetitle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlbitnotebuywallet.SuspendLayout()
        CType(Me.picbitnotewalletdownloadbtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbitnotewalletpagescreenshot, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlbitnotewalletfooter.SuspendLayout()
        CType(Me.picbitnotewalletpagelogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlbitnotehome.SuspendLayout()
        Me.pnlbitnotehomefooter.SuspendLayout()
        CType(Me.picbitnotewebsitetitle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlshifterhacker.SuspendLayout()
        Me.pnlshifterhackerhome.SuspendLayout()
        Me.pnlutilsweb.SuspendLayout()
        Me.pnlutilswebhome.SuspendLayout()
        Me.pnlutilswebbackuputility.SuspendLayout()
        Me.pnlnotfound.SuspendLayout()
        Me.pnlnotfoundsite.SuspendLayout()
        Me.pnlshiftnet.SuspendLayout()
        Me.pnlshiftnethome.SuspendLayout()
        Me.pnl404.SuspendLayout()
        Me.pnl404home.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pgleft.SuspendLayout()
        Me.titlebar.SuspendLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pullside
        '
        Me.pullside.Interval = 1
        '
        'pullbs
        '
        Me.pullbs.Interval = 1
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 598)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(816, 2)
        Me.pgbottom.TabIndex = 23
        '
        'pullbottom
        '
        Me.pullbottom.Interval = 1
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(246, 5)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 24
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(274, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 568)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(818, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 570)
        Me.pgright.TabIndex = 22
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(302, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(65, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Shiftnet"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(818, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 568)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgcontents
        '
        Me.pgcontents.BackColor = System.Drawing.Color.White
        Me.pgcontents.Controls.Add(Me.pnlquickchat)
        Me.pgcontents.Controls.Add(Me.pnlxenonh)
        Me.pgcontents.Controls.Add(Me.pnlpostspot)
        Me.pgcontents.Controls.Add(Me.pnlpirateboat)
        Me.pgcontents.Controls.Add(Me.pnlhome)
        Me.pgcontents.Controls.Add(Me.pnlmainsiteappscape)
        Me.pgcontents.Controls.Add(Me.pnlmainsiteminimatch)
        Me.pgcontents.Controls.Add(Me.pnlshiftomizer)
        Me.pgcontents.Controls.Add(Me.pnlbitnotemainpage)
        Me.pgcontents.Controls.Add(Me.pnlshifterhacker)
        Me.pgcontents.Controls.Add(Me.pnlutilsweb)
        Me.pgcontents.Controls.Add(Me.pnlnotfound)
        Me.pgcontents.Controls.Add(Me.pnlshiftnet)
        Me.pgcontents.Controls.Add(Me.pnl404)
        Me.pgcontents.Controls.Add(Me.Panel1)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(816, 568)
        Me.pgcontents.TabIndex = 20
        '
        'pnlquickchat
        '
        Me.pnlquickchat.AutoScroll = True
        Me.pnlquickchat.BackColor = System.Drawing.Color.White
        Me.pnlquickchat.Controls.Add(Me.pnlquickchathome)
        Me.pnlquickchat.Controls.Add(Me.pnlquickchatoffline)
        Me.pnlquickchat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlquickchat.Location = New System.Drawing.Point(0, 35)
        Me.pnlquickchat.Name = "pnlquickchat"
        Me.pnlquickchat.Size = New System.Drawing.Size(816, 533)
        Me.pnlquickchat.TabIndex = 21
        Me.pnlquickchat.Visible = False
        '
        'pnlquickchathome
        '
        Me.pnlquickchathome.Controls.Add(Me.Panel7)
        Me.pnlquickchathome.Controls.Add(Me.qchome)
        Me.pnlquickchathome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlquickchathome.Location = New System.Drawing.Point(0, 0)
        Me.pnlquickchathome.Name = "pnlquickchathome"
        Me.pnlquickchathome.Size = New System.Drawing.Size(816, 533)
        Me.pnlquickchathome.TabIndex = 4
        '
        'Panel7
        '
        Me.Panel7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.tbqcusers)
        Me.Panel7.Controls.Add(Me.tbqcchat)
        Me.Panel7.Controls.Add(Me.tbqctype)
        Me.Panel7.Location = New System.Drawing.Point(10, 61)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(796, 463)
        Me.Panel7.TabIndex = 2
        '
        'tbqcusers
        '
        Me.tbqcusers.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tbqcusers.Location = New System.Drawing.Point(643, 10)
        Me.tbqcusers.Name = "tbqcusers"
        Me.tbqcusers.Size = New System.Drawing.Size(145, 419)
        Me.tbqcusers.TabIndex = 3
        Me.tbqcusers.UseCompatibleStateImageBehavior = False
        '
        'tbqcchat
        '
        Me.tbqcchat.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbqcchat.BackColor = System.Drawing.Color.White
        Me.tbqcchat.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tbqcchat.Location = New System.Drawing.Point(5, 9)
        Me.tbqcchat.Multiline = True
        Me.tbqcchat.Name = "tbqcchat"
        Me.tbqcchat.ReadOnly = True
        Me.tbqcchat.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbqcchat.Size = New System.Drawing.Size(629, 420)
        Me.tbqcchat.TabIndex = 2
        '
        'tbqctype
        '
        Me.tbqctype.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbqctype.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbqctype.Enabled = False
        Me.tbqctype.Location = New System.Drawing.Point(5, 436)
        Me.tbqctype.Name = "tbqctype"
        Me.tbqctype.Size = New System.Drawing.Size(783, 20)
        Me.tbqctype.TabIndex = 1
        '
        'qchome
        '
        Me.qchome.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.qchome.AutoSize = True
        Me.qchome.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.qchome.ForeColor = System.Drawing.Color.Gray
        Me.qchome.Location = New System.Drawing.Point(321, 10)
        Me.qchome.Name = "qchome"
        Me.qchome.Size = New System.Drawing.Size(167, 37)
        Me.qchome.TabIndex = 1
        Me.qchome.Text = "QuickChat"
        '
        'pnlquickchatoffline
        '
        Me.pnlquickchatoffline.Controls.Add(Me.qcpanel)
        Me.pnlquickchatoffline.Controls.Add(Me.tbqchomebtn)
        Me.pnlquickchatoffline.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlquickchatoffline.Location = New System.Drawing.Point(0, 0)
        Me.pnlquickchatoffline.Name = "pnlquickchatoffline"
        Me.pnlquickchatoffline.Size = New System.Drawing.Size(816, 533)
        Me.pnlquickchatoffline.TabIndex = 5
        '
        'qcpanel
        '
        Me.qcpanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.qcpanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.qcpanel.Controls.Add(Me.tbqcochat)
        Me.qcpanel.Controls.Add(Me.Label24)
        Me.qcpanel.Location = New System.Drawing.Point(10, 60)
        Me.qcpanel.Name = "qcpanel"
        Me.qcpanel.Size = New System.Drawing.Size(796, 463)
        Me.qcpanel.TabIndex = 1
        '
        'tbqcochat
        '
        Me.tbqcochat.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbqcochat.Enabled = False
        Me.tbqcochat.Location = New System.Drawing.Point(5, 436)
        Me.tbqcochat.Name = "tbqcochat"
        Me.tbqcochat.Size = New System.Drawing.Size(783, 20)
        Me.tbqcochat.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(5, 10)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(115, 13)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "This chatroom is empty"
        '
        'tbqchomebtn
        '
        Me.tbqchomebtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbqchomebtn.AutoSize = True
        Me.tbqchomebtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbqchomebtn.ForeColor = System.Drawing.Color.Gray
        Me.tbqchomebtn.Location = New System.Drawing.Point(330, 13)
        Me.tbqchomebtn.Name = "tbqchomebtn"
        Me.tbqchomebtn.Size = New System.Drawing.Size(167, 37)
        Me.tbqchomebtn.TabIndex = 0
        Me.tbqchomebtn.Text = "QuickChat"
        '
        'pnlxenonh
        '
        Me.pnlxenonh.AutoScroll = True
        Me.pnlxenonh.BackColor = System.Drawing.Color.White
        Me.pnlxenonh.Controls.Add(Me.pnlxenonhhome)
        Me.pnlxenonh.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlxenonh.Location = New System.Drawing.Point(0, 35)
        Me.pnlxenonh.Name = "pnlxenonh"
        Me.pnlxenonh.Size = New System.Drawing.Size(816, 533)
        Me.pnlxenonh.TabIndex = 20
        Me.pnlxenonh.Visible = False
        '
        'pnlxenonhhome
        '
        Me.pnlxenonhhome.Controls.Add(Me.tbxenonhquickchat)
        Me.pnlxenonhhome.Controls.Add(Me.Label10)
        Me.pnlxenonhhome.Controls.Add(Me.Label3)
        Me.pnlxenonhhome.Controls.Add(Me.Label7)
        Me.pnlxenonhhome.Controls.Add(Me.Label19)
        Me.pnlxenonhhome.Controls.Add(Me.Label18)
        Me.pnlxenonhhome.Controls.Add(Me.Label17)
        Me.pnlxenonhhome.Controls.Add(Me.Label16)
        Me.pnlxenonhhome.Controls.Add(Me.Label15)
        Me.pnlxenonhhome.Controls.Add(Me.Label14)
        Me.pnlxenonhhome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlxenonhhome.Location = New System.Drawing.Point(0, 0)
        Me.pnlxenonhhome.Name = "pnlxenonhhome"
        Me.pnlxenonhhome.Size = New System.Drawing.Size(816, 533)
        Me.pnlxenonhhome.TabIndex = 4
        '
        'tbxenonhquickchat
        '
        Me.tbxenonhquickchat.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbxenonhquickchat.AutoSize = True
        Me.tbxenonhquickchat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxenonhquickchat.Location = New System.Drawing.Point(360, 238)
        Me.tbxenonhquickchat.Name = "tbxenonhquickchat"
        Me.tbxenonhquickchat.Size = New System.Drawing.Size(57, 13)
        Me.tbxenonhquickchat.TabIndex = 9
        Me.tbxenonhquickchat.Text = "QuickChat"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.tbxenonhquickchat, "shiftnet.quickchat/user/xenonh.rnp")
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(278, 238)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(83, 13)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Chat with me on"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(289, 179)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(377, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "- Save shiftnet and Web Browser websites to .URL or .URLS files to open later" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(250, 179)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(39, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = ".URLS"
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(297, 164)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(382, 13)
        Me.Label19.TabIndex = 5
        Me.Label19.Text = "- Currently only converts TRM to SSA, but may convert much more in the future!"
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(249, 164)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 13)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "Convert It"
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(298, 150)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(304, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "- A useful dock addon for ShiftOS (Front paged on shiftomizer!!)"
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(249, 150)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(54, 13)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "ShiftDock"
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(433, 57)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(108, 13)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "powered by PostSpot"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(190, 22)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(450, 37)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Xenon H's Customization Blog"
        '
        'pnlpostspot
        '
        Me.pnlpostspot.AutoScroll = True
        Me.pnlpostspot.BackColor = System.Drawing.Color.White
        Me.pnlpostspot.Controls.Add(Me.pnlpostspothome)
        Me.pnlpostspot.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlpostspot.Location = New System.Drawing.Point(0, 35)
        Me.pnlpostspot.Name = "pnlpostspot"
        Me.pnlpostspot.Size = New System.Drawing.Size(816, 533)
        Me.pnlpostspot.TabIndex = 19
        Me.pnlpostspot.Visible = False
        '
        'pnlpostspothome
        '
        Me.pnlpostspothome.Controls.Add(Me.tbxenonhurl)
        Me.pnlpostspothome.Controls.Add(Me.tbpostspothomeshifterhackerlink)
        Me.pnlpostspothome.Controls.Add(Me.tbpostspothomecontent)
        Me.pnlpostspothome.Controls.Add(Me.tbpostspothomead)
        Me.pnlpostspothome.Controls.Add(Me.tbpostspothomesubtext)
        Me.pnlpostspothome.Controls.Add(Me.tbpostspothomepostspot)
        Me.pnlpostspothome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlpostspothome.Location = New System.Drawing.Point(0, 0)
        Me.pnlpostspothome.Name = "pnlpostspothome"
        Me.pnlpostspothome.Size = New System.Drawing.Size(816, 533)
        Me.pnlpostspothome.TabIndex = 4
        '
        'tbxenonhurl
        '
        Me.tbxenonhurl.AutoSize = True
        Me.tbxenonhurl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxenonhurl.Location = New System.Drawing.Point(24, 198)
        Me.tbxenonhurl.Name = "tbxenonhurl"
        Me.tbxenonhurl.Size = New System.Drawing.Size(145, 13)
        Me.tbxenonhurl.TabIndex = 11
        Me.tbxenonhurl.Text = "XenonH's Customization Blog"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.tbxenonhurl, "shiftnet.main.xenonh/home.rnp")
        '
        'tbpostspothomeshifterhackerlink
        '
        Me.tbpostspothomeshifterhackerlink.AutoSize = True
        Me.tbpostspothomeshifterhackerlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbpostspothomeshifterhackerlink.Location = New System.Drawing.Point(24, 179)
        Me.tbpostspothomeshifterhackerlink.Name = "tbpostspothomeshifterhackerlink"
        Me.tbpostspothomeshifterhackerlink.Size = New System.Drawing.Size(103, 13)
        Me.tbpostspothomeshifterhackerlink.TabIndex = 10
        Me.tbpostspothomeshifterhackerlink.Text = "ShifterHacker's Blog"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.tbpostspothomeshifterhackerlink, "shiftnet.shifterhacker/home.rnp")
        '
        'tbpostspothomecontent
        '
        Me.tbpostspothomecontent.AutoSize = True
        Me.tbpostspothomecontent.Location = New System.Drawing.Point(24, 75)
        Me.tbpostspothomecontent.Name = "tbpostspothomecontent"
        Me.tbpostspothomecontent.Size = New System.Drawing.Size(252, 91)
        Me.tbpostspothomecontent.TabIndex = 8
        Me.tbpostspothomecontent.Text = "Customize your website however you want." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Include:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ShiftLinks NetAds" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Comment Wi" & _
    "gets" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "And much more when customizing your website." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Below are some blogs that " & _
    "other people have made:"
        '
        'tbpostspothomead
        '
        Me.tbpostspothomead.AutoSize = True
        Me.tbpostspothomead.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.tbpostspothomead.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbpostspothomead.Location = New System.Drawing.Point(0, 507)
        Me.tbpostspothomead.Name = "tbpostspothomead"
        Me.tbpostspothomead.Size = New System.Drawing.Size(328, 26)
        Me.tbpostspothomead.TabIndex = 7
        Me.tbpostspothomead.Text = "Install FloodgateManager: The best flood downloader on the shiftnet" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ShiftLinks N" & _
    "etAds"
        '
        'tbpostspothomesubtext
        '
        Me.tbpostspothomesubtext.AutoSize = True
        Me.tbpostspothomesubtext.BackColor = System.Drawing.Color.White
        Me.tbpostspothomesubtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbpostspothomesubtext.ForeColor = System.Drawing.Color.Black
        Me.tbpostspothomesubtext.Location = New System.Drawing.Point(172, 48)
        Me.tbpostspothomesubtext.Name = "tbpostspothomesubtext"
        Me.tbpostspothomesubtext.Size = New System.Drawing.Size(157, 13)
        Me.tbpostspothomesubtext.TabIndex = 6
        Me.tbpostspothomesubtext.Text = "The best blogger on the shiftnet"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.tbpostspothomesubtext, "shiftnet.main.floodgate/filetrans.dwnld?file=FloodGate.stp")
        '
        'tbpostspothomepostspot
        '
        Me.tbpostspothomepostspot.AutoSize = True
        Me.tbpostspothomepostspot.BackColor = System.Drawing.Color.Transparent
        Me.tbpostspothomepostspot.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbpostspothomepostspot.Location = New System.Drawing.Point(116, 17)
        Me.tbpostspothomepostspot.Name = "tbpostspothomepostspot"
        Me.tbpostspothomepostspot.Size = New System.Drawing.Size(147, 37)
        Me.tbpostspothomepostspot.TabIndex = 5
        Me.tbpostspothomepostspot.Text = "PostSpot"
        '
        'pnlpirateboat
        '
        Me.pnlpirateboat.AutoScroll = True
        Me.pnlpirateboat.BackColor = System.Drawing.Color.White
        Me.pnlpirateboat.Controls.Add(Me.pnlpirateboatmain)
        Me.pnlpirateboat.Controls.Add(Me.pnlpirateboatdownlaod)
        Me.pnlpirateboat.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlpirateboat.Location = New System.Drawing.Point(0, 35)
        Me.pnlpirateboat.Name = "pnlpirateboat"
        Me.pnlpirateboat.Size = New System.Drawing.Size(816, 533)
        Me.pnlpirateboat.TabIndex = 17
        Me.pnlpirateboat.Visible = False
        '
        'pnlpirateboatmain
        '
        Me.pnlpirateboatmain.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pnlpirateboatmain.Controls.Add(Me.tpbsearchresults)
        Me.pnlpirateboatmain.Controls.Add(Me.tpbsearch)
        Me.pnlpirateboatmain.Controls.Add(Me.TextBox4)
        Me.pnlpirateboatmain.Controls.Add(Me.TextBox3)
        Me.pnlpirateboatmain.Controls.Add(Me.Label23)
        Me.pnlpirateboatmain.Controls.Add(Me.Label22)
        Me.pnlpirateboatmain.Controls.Add(Me.TextBox2)
        Me.pnlpirateboatmain.Controls.Add(Me.tbpbfglink1)
        Me.pnlpirateboatmain.Controls.Add(Me.Label13)
        Me.pnlpirateboatmain.Controls.Add(Me.tbpbWarning)
        Me.pnlpirateboatmain.Controls.Add(Me.tbpbMSG)
        Me.pnlpirateboatmain.Controls.Add(Me.tbdnlfloodgate)
        Me.pnlpirateboatmain.Controls.Add(Me.tbPirateBoat)
        Me.pnlpirateboatmain.Location = New System.Drawing.Point(0, 0)
        Me.pnlpirateboatmain.Name = "pnlpirateboatmain"
        Me.pnlpirateboatmain.Size = New System.Drawing.Size(816, 533)
        Me.pnlpirateboatmain.TabIndex = 4
        '
        'tpbsearchresults
        '
        Me.tpbsearchresults.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tpbsearchresults.Location = New System.Drawing.Point(226, 223)
        Me.tpbsearchresults.Name = "tpbsearchresults"
        Me.tpbsearchresults.Size = New System.Drawing.Size(329, 269)
        Me.tpbsearchresults.TabIndex = 17
        Me.tpbsearchresults.UseCompatibleStateImageBehavior = False
        '
        'tpbsearch
        '
        Me.tpbsearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tpbsearch.Location = New System.Drawing.Point(219, 503)
        Me.tpbsearch.Name = "tpbsearch"
        Me.tpbsearch.Size = New System.Drawing.Size(350, 20)
        Me.tpbsearch.TabIndex = 12
        '
        'TextBox4
        '
        Me.TextBox4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox4.BackColor = System.Drawing.Color.White
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.Location = New System.Drawing.Point(244, 201)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(209, 13)
        Me.TextBox4.TabIndex = 16
        Me.TextBox4.Text = "shiftnet.pirate.piratebay/floods/virusscanner" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.TextBox3.BackColor = System.Drawing.Color.White
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.Location = New System.Drawing.Point(244, 184)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(178, 13)
        Me.TextBox3.TabIndex = 15
        Me.TextBox3.Text = "shiftnet.pirate.piratebay/floods/dodge"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(455, 201)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(73, 13)
        Me.Label23.TabIndex = 14
        Me.Label23.Text = "Floodgate link"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(241, 202)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(0, 13)
        Me.Label22.TabIndex = 13
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(219, 503)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(350, 20)
        Me.TextBox2.TabIndex = 12
        '
        'tbpbfglink1
        '
        Me.tbpbfglink1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbpbfglink1.AutoSize = True
        Me.tbpbfglink1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbpbfglink1.Location = New System.Drawing.Point(437, 185)
        Me.tbpbfglink1.Name = "tbpbfglink1"
        Me.tbpbfglink1.Size = New System.Drawing.Size(73, 13)
        Me.tbpbfglink1.TabIndex = 11
        Me.tbpbfglink1.Text = "Floodgate link"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(283, 140)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(191, 29)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "Featured Pirates"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.Label13, "floodgate--""shiftnet.pirate.piratebay/floods/dodge""")
        '
        'tbpbWarning
        '
        Me.tbpbWarning.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbpbWarning.AutoSize = True
        Me.tbpbWarning.Location = New System.Drawing.Point(189, 114)
        Me.tbpbWarning.Name = "tbpbWarning"
        Me.tbpbWarning.Size = New System.Drawing.Size(478, 13)
        Me.tbpbWarning.TabIndex = 8
        Me.tbpbWarning.Text = "Most pirates are submitted by users, they may contain malware/viruses.  USE AT YO" & _
    "UR OWN RISK"
        '
        'tbpbMSG
        '
        Me.tbpbMSG.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbpbMSG.AutoSize = True
        Me.tbpbMSG.Location = New System.Drawing.Point(229, 71)
        Me.tbpbMSG.Name = "tbpbMSG"
        Me.tbpbMSG.Size = New System.Drawing.Size(365, 26)
        Me.tbpbMSG.TabIndex = 7
        Me.tbpbMSG.Text = "FloodGate is REQUIRED (or any other program that can install .flood files) to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "do" & _
    "wnload anything on this page."
        '
        'tbdnlfloodgate
        '
        Me.tbdnlfloodgate.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbdnlfloodgate.AutoSize = True
        Me.tbdnlfloodgate.BackColor = System.Drawing.Color.White
        Me.tbdnlfloodgate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbdnlfloodgate.ForeColor = System.Drawing.Color.Gray
        Me.tbdnlfloodgate.Location = New System.Drawing.Point(229, 54)
        Me.tbdnlfloodgate.Name = "tbdnlfloodgate"
        Me.tbdnlfloodgate.Size = New System.Drawing.Size(107, 13)
        Me.tbdnlfloodgate.TabIndex = 6
        Me.tbdnlfloodgate.Text = "Download FloodGate"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.tbdnlfloodgate, "shiftnet.main.floodgate/filetrans.dwnld?file=FloodGate.stp")
        '
        'tbPirateBoat
        '
        Me.tbPirateBoat.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbPirateBoat.AutoSize = True
        Me.tbPirateBoat.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPirateBoat.Location = New System.Drawing.Point(222, 13)
        Me.tbPirateBoat.Name = "tbPirateBoat"
        Me.tbPirateBoat.Size = New System.Drawing.Size(400, 37)
        Me.tbPirateBoat.TabIndex = 5
        Me.tbPirateBoat.Text = "Welcome to the pirate boat"
        '
        'pnlpirateboatdownlaod
        '
        Me.pnlpirateboatdownlaod.Controls.Add(Me.tpbbackbtn)
        Me.pnlpirateboatdownlaod.Controls.Add(Me.tpbfloodgate)
        Me.pnlpirateboatdownlaod.Controls.Add(Me.tpburlbox)
        Me.pnlpirateboatdownlaod.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlpirateboatdownlaod.Location = New System.Drawing.Point(0, 0)
        Me.pnlpirateboatdownlaod.Name = "pnlpirateboatdownlaod"
        Me.pnlpirateboatdownlaod.Size = New System.Drawing.Size(816, 533)
        Me.pnlpirateboatdownlaod.TabIndex = 18
        '
        'tpbbackbtn
        '
        Me.tpbbackbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.tpbbackbtn.Location = New System.Drawing.Point(0, 35)
        Me.tpbbackbtn.Name = "tpbbackbtn"
        Me.tpbbackbtn.Size = New System.Drawing.Size(75, 23)
        Me.tpbbackbtn.TabIndex = 2
        Me.tpbbackbtn.Text = "Back"
        Me.tpbbackbtn.UseVisualStyleBackColor = True
        '
        'tpbfloodgate
        '
        Me.tpbfloodgate.Dock = System.Windows.Forms.DockStyle.Top
        Me.tpbfloodgate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.tpbfloodgate.Location = New System.Drawing.Point(0, 13)
        Me.tpbfloodgate.Name = "tpbfloodgate"
        Me.tpbfloodgate.Size = New System.Drawing.Size(816, 23)
        Me.tpbfloodgate.TabIndex = 1
        Me.tpbfloodgate.Text = "Download with FloodGate"
        Me.tpbfloodgate.UseVisualStyleBackColor = True
        '
        'tpburlbox
        '
        Me.tpburlbox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tpburlbox.Dock = System.Windows.Forms.DockStyle.Top
        Me.tpburlbox.Location = New System.Drawing.Point(0, 0)
        Me.tpburlbox.Name = "tpburlbox"
        Me.tpburlbox.Size = New System.Drawing.Size(816, 13)
        Me.tpburlbox.TabIndex = 0
        '
        'pnlhome
        '
        Me.pnlhome.AutoScroll = True
        Me.pnlhome.BackColor = System.Drawing.Color.White
        Me.pnlhome.Controls.Add(Me.pnlhomehome)
        Me.pnlhome.Controls.Add(Me.pnlhomehistory)
        Me.pnlhome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlhome.Location = New System.Drawing.Point(0, 35)
        Me.pnlhome.Name = "pnlhome"
        Me.pnlhome.Size = New System.Drawing.Size(816, 533)
        Me.pnlhome.TabIndex = 12
        Me.pnlhome.Visible = False
        '
        'pnlhomehome
        '
        Me.pnlhomehome.Controls.Add(Me.lblhomehomehistorylink)
        Me.pnlhomehome.Controls.Add(Me.lblhomehomebackuplink)
        Me.pnlhomehome.Controls.Add(Me.lblhomehomebitnotelink)
        Me.pnlhomehome.Controls.Add(Me.lblhomehomeminimatchlink)
        Me.pnlhomehome.Controls.Add(Me.lblhomehomeappscapelink)
        Me.pnlhomehome.Controls.Add(Me.lblhomehomedescription)
        Me.pnlhomehome.Controls.Add(Me.pichomehomeicon)
        Me.pnlhomehome.Controls.Add(Me.tbhomehomewelcome)
        Me.pnlhomehome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlhomehome.Location = New System.Drawing.Point(0, 0)
        Me.pnlhomehome.Name = "pnlhomehome"
        Me.pnlhomehome.Size = New System.Drawing.Size(816, 533)
        Me.pnlhomehome.TabIndex = 4
        '
        'lblhomehomehistorylink
        '
        Me.lblhomehomehistorylink.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblhomehomehistorylink.AutoSize = True
        Me.lblhomehomehistorylink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhomehomehistorylink.Location = New System.Drawing.Point(24, 323)
        Me.lblhomehomehistorylink.Name = "lblhomehomehistorylink"
        Me.lblhomehomehistorylink.Size = New System.Drawing.Size(345, 13)
        Me.lblhomehomehistorylink.TabIndex = 10
        Me.lblhomehomehistorylink.Text = "history:shiftnet - any websites you visit will be added to your history here."
        '
        'lblhomehomebackuplink
        '
        Me.lblhomehomebackuplink.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblhomehomebackuplink.AutoSize = True
        Me.lblhomehomebackuplink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhomehomebackuplink.Location = New System.Drawing.Point(24, 300)
        Me.lblhomehomebackuplink.Name = "lblhomehomebackuplink"
        Me.lblhomehomebackuplink.Size = New System.Drawing.Size(484, 13)
        Me.lblhomehomebackuplink.TabIndex = 9
        Me.lblhomehomebackuplink.Text = "shiftnet.main.shiftomizer/home.rnp - a site allowing you to download skins and cu" & _
    "stomization programs"
        '
        'lblhomehomebitnotelink
        '
        Me.lblhomehomebitnotelink.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblhomehomebitnotelink.AutoSize = True
        Me.lblhomehomebitnotelink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhomehomebitnotelink.Location = New System.Drawing.Point(24, 276)
        Me.lblhomehomebitnotelink.Name = "lblhomehomebitnotelink"
        Me.lblhomehomebitnotelink.Size = New System.Drawing.Size(429, 13)
        Me.lblhomehomebitnotelink.TabIndex = 8
        Me.lblhomehomebitnotelink.Text = "shiftnet.main.bitnote/home.rnp - a site allowing you to trade in Bitnotes, an onl" & _
    "ine currency"
        '
        'lblhomehomeminimatchlink
        '
        Me.lblhomehomeminimatchlink.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblhomehomeminimatchlink.AutoSize = True
        Me.lblhomehomeminimatchlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhomehomeminimatchlink.Location = New System.Drawing.Point(24, 253)
        Me.lblhomehomeminimatchlink.Name = "lblhomehomeminimatchlink"
        Me.lblhomehomeminimatchlink.Size = New System.Drawing.Size(409, 13)
        Me.lblhomehomeminimatchlink.TabIndex = 7
        Me.lblhomehomeminimatchlink.Text = "shiftnet.main.minimatch/home.rnp - a site selling games that can earn you code po" & _
    "ints"
        '
        'lblhomehomeappscapelink
        '
        Me.lblhomehomeappscapelink.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblhomehomeappscapelink.AutoSize = True
        Me.lblhomehomeappscapelink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhomehomeappscapelink.Location = New System.Drawing.Point(24, 231)
        Me.lblhomehomeappscapelink.Name = "lblhomehomeappscapelink"
        Me.lblhomehomeappscapelink.Size = New System.Drawing.Size(361, 13)
        Me.lblhomehomeappscapelink.TabIndex = 6
        Me.lblhomehomeappscapelink.Text = "shiftnet.main.appscape/home.rnp - a site to buy useful programs for your pc"
        '
        'lblhomehomedescription
        '
        Me.lblhomehomedescription.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblhomehomedescription.Location = New System.Drawing.Point(24, 86)
        Me.lblhomehomedescription.Name = "lblhomehomedescription"
        Me.lblhomehomedescription.Size = New System.Drawing.Size(767, 140)
        Me.lblhomehomedescription.TabIndex = 5
        Me.lblhomehomedescription.Text = resources.GetString("lblhomehomedescription.Text")
        '
        'pichomehomeicon
        '
        Me.pichomehomeicon.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pichomehomeicon.Image = Global.ShiftOS.My.Resources.Resources.iconShiftnet
        Me.pichomehomeicon.Location = New System.Drawing.Point(537, 31)
        Me.pichomehomeicon.Name = "pichomehomeicon"
        Me.pichomehomeicon.Size = New System.Drawing.Size(16, 16)
        Me.pichomehomeicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pichomehomeicon.TabIndex = 4
        Me.pichomehomeicon.TabStop = False
        '
        'tbhomehomewelcome
        '
        Me.tbhomehomewelcome.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.tbhomehomewelcome.AutoSize = True
        Me.tbhomehomewelcome.BackColor = System.Drawing.Color.Transparent
        Me.tbhomehomewelcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbhomehomewelcome.Location = New System.Drawing.Point(244, 37)
        Me.tbhomehomewelcome.Name = "tbhomehomewelcome"
        Me.tbhomehomewelcome.Size = New System.Drawing.Size(303, 37)
        Me.tbhomehomewelcome.TabIndex = 3
        Me.tbhomehomewelcome.Text = "Welcome to Shiftnet"
        '
        'pnlhomehistory
        '
        Me.pnlhomehistory.Controls.Add(Me.lbhomehistoryhistory)
        Me.pnlhomehistory.Location = New System.Drawing.Point(344, 323)
        Me.pnlhomehistory.Name = "pnlhomehistory"
        Me.pnlhomehistory.Size = New System.Drawing.Size(156, 136)
        Me.pnlhomehistory.TabIndex = 11
        '
        'lbhomehistoryhistory
        '
        Me.lbhomehistoryhistory.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbhomehistoryhistory.Location = New System.Drawing.Point(0, 0)
        Me.lbhomehistoryhistory.Name = "lbhomehistoryhistory"
        Me.lbhomehistoryhistory.Size = New System.Drawing.Size(156, 136)
        Me.lbhomehistoryhistory.TabIndex = 1
        Me.lbhomehistoryhistory.UseCompatibleStateImageBehavior = False
        '
        'pnlmainsiteappscape
        '
        Me.pnlmainsiteappscape.BackColor = System.Drawing.Color.White
        Me.pnlmainsiteappscape.Controls.Add(Me.pnlappscapedeposit)
        Me.pnlmainsiteappscape.Controls.Add(Me.appscapehomepage)
        Me.pnlmainsiteappscape.Controls.Add(Me.pnlappscapeoprcwrite)
        Me.pnlmainsiteappscape.Controls.Add(Me.appscapewebbrowserinfopage)
        Me.pnlmainsiteappscape.Controls.Add(Me.appscapevideoplayerinfopage)
        Me.pnlmainsiteappscape.Controls.Add(Me.appscapecalculatorinfopage)
        Me.pnlmainsiteappscape.Controls.Add(Me.appscapeaudioplayerinfopage)
        Me.pnlmainsiteappscape.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlmainsiteappscape.Location = New System.Drawing.Point(0, 35)
        Me.pnlmainsiteappscape.Name = "pnlmainsiteappscape"
        Me.pnlmainsiteappscape.Size = New System.Drawing.Size(816, 533)
        Me.pnlmainsiteappscape.TabIndex = 2
        Me.pnlmainsiteappscape.Visible = False
        '
        'pnlappscapedeposit
        '
        Me.pnlappscapedeposit.AutoScroll = True
        Me.pnlappscapedeposit.BackColor = System.Drawing.Color.White
        Me.pnlappscapedeposit.Controls.Add(Me.appscapedepositestep3)
        Me.pnlappscapedeposit.Controls.Add(Me.appscapedepositestep2)
        Me.pnlappscapedeposit.Controls.Add(Me.appscapedepositestep1)
        Me.pnlappscapedeposit.Controls.Add(Me.picappscapedepositeinfobitnotescreenshot)
        Me.pnlappscapedeposit.Controls.Add(Me.lblappscapedepositpasteinfo)
        Me.pnlappscapedeposit.Controls.Add(Me.txtappscapedepositeaddress)
        Me.pnlappscapedeposit.Controls.Add(Me.lblappscapecopyaddressinfo)
        Me.pnlappscapedeposit.Controls.Add(Me.Label9)
        Me.pnlappscapedeposit.Controls.Add(Me.Panel46)
        Me.pnlappscapedeposit.Controls.Add(Me.Panel47)
        Me.pnlappscapedeposit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlappscapedeposit.Location = New System.Drawing.Point(0, 0)
        Me.pnlappscapedeposit.Name = "pnlappscapedeposit"
        Me.pnlappscapedeposit.Size = New System.Drawing.Size(816, 533)
        Me.pnlappscapedeposit.TabIndex = 8
        Me.pnlappscapedeposit.Visible = False
        '
        'appscapedepositestep3
        '
        Me.appscapedepositestep3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.appscapedepositestep3.AutoSize = True
        Me.appscapedepositestep3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.appscapedepositestep3.Location = New System.Drawing.Point(247, 472)
        Me.appscapedepositestep3.Name = "appscapedepositestep3"
        Me.appscapedepositestep3.Size = New System.Drawing.Size(510, 25)
        Me.appscapedepositestep3.TabIndex = 13
        Me.appscapedepositestep3.Text = "...Select the desired amount and press ""Send."" "
        '
        'appscapedepositestep2
        '
        Me.appscapedepositestep2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.appscapedepositestep2.AutoSize = True
        Me.appscapedepositestep2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.appscapedepositestep2.Location = New System.Drawing.Point(247, 189)
        Me.appscapedepositestep2.Name = "appscapedepositestep2"
        Me.appscapedepositestep2.Size = New System.Drawing.Size(426, 25)
        Me.appscapedepositestep2.TabIndex = 12
        Me.appscapedepositestep2.Text = "...And paste it into your bitnote wallet..."
        '
        'appscapedepositestep1
        '
        Me.appscapedepositestep1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.appscapedepositestep1.AutoSize = True
        Me.appscapedepositestep1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.appscapedepositestep1.Location = New System.Drawing.Point(243, 119)
        Me.appscapedepositestep1.Name = "appscapedepositestep1"
        Me.appscapedepositestep1.Size = New System.Drawing.Size(367, 25)
        Me.appscapedepositestep1.TabIndex = 11
        Me.appscapedepositestep1.Text = "Copy the Bitnote address below..."
        '
        'picappscapedepositeinfobitnotescreenshot
        '
        Me.picappscapedepositeinfobitnotescreenshot.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picappscapedepositeinfobitnotescreenshot.Image = Global.ShiftOS.My.Resources.Resources.appscapedepositbitnotewalletscreenshot
        Me.picappscapedepositeinfobitnotescreenshot.Location = New System.Drawing.Point(248, 227)
        Me.picappscapedepositeinfobitnotescreenshot.Name = "picappscapedepositeinfobitnotescreenshot"
        Me.picappscapedepositeinfobitnotescreenshot.Size = New System.Drawing.Size(451, 226)
        Me.picappscapedepositeinfobitnotescreenshot.TabIndex = 10
        Me.picappscapedepositeinfobitnotescreenshot.TabStop = False
        '
        'lblappscapedepositpasteinfo
        '
        Me.lblappscapedepositpasteinfo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblappscapedepositpasteinfo.BackColor = System.Drawing.Color.Transparent
        Me.lblappscapedepositpasteinfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblappscapedepositpasteinfo.Location = New System.Drawing.Point(1576, 190)
        Me.lblappscapedepositpasteinfo.Name = "lblappscapedepositpasteinfo"
        Me.lblappscapedepositpasteinfo.Size = New System.Drawing.Size(545, 57)
        Me.lblappscapedepositpasteinfo.TabIndex = 9
        Me.lblappscapedepositpasteinfo.Text = "...And paste it into your Bitnote wallet. Choose the desired amount and click sen" & _
    "d!"
        Me.lblappscapedepositpasteinfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtappscapedepositeaddress
        '
        Me.txtappscapedepositeaddress.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtappscapedepositeaddress.Location = New System.Drawing.Point(244, 149)
        Me.txtappscapedepositeaddress.Name = "txtappscapedepositeaddress"
        Me.txtappscapedepositeaddress.Size = New System.Drawing.Size(541, 20)
        Me.txtappscapedepositeaddress.TabIndex = 8
        Me.txtappscapedepositeaddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblappscapecopyaddressinfo
        '
        Me.lblappscapecopyaddressinfo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblappscapecopyaddressinfo.BackColor = System.Drawing.Color.Transparent
        Me.lblappscapecopyaddressinfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblappscapecopyaddressinfo.Location = New System.Drawing.Point(1576, 124)
        Me.lblappscapecopyaddressinfo.Name = "lblappscapecopyaddressinfo"
        Me.lblappscapecopyaddressinfo.Size = New System.Drawing.Size(432, 23)
        Me.lblappscapecopyaddressinfo.TabIndex = 7
        Me.lblappscapecopyaddressinfo.Text = "Copy the following Bitnote address:"
        Me.lblappscapecopyaddressinfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(1351, 511)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(768, 23)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "© Copyright Aiden Nirh - Do Not Reproduce"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel46
        '
        Me.Panel46.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel46.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapedepositinfo
        Me.Panel46.Controls.Add(Me.btnappscapedepositeback)
        Me.Panel46.Location = New System.Drawing.Point(10, 98)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(202, 407)
        Me.Panel46.TabIndex = 1
        '
        'btnappscapedepositeback
        '
        Me.btnappscapedepositeback.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobackbutton
        Me.btnappscapedepositeback.Location = New System.Drawing.Point(41, 361)
        Me.btnappscapedepositeback.Name = "btnappscapedepositeback"
        Me.btnappscapedepositeback.Size = New System.Drawing.Size(100, 35)
        Me.btnappscapedepositeback.TabIndex = 0
        '
        'Panel47
        '
        Me.Panel47.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel47.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapetitlebanner
        Me.Panel47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel47.Controls.Add(Me.lbappscapepayinfohello)
        Me.Panel47.Location = New System.Drawing.Point(10, 6)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(770, 88)
        Me.Panel47.TabIndex = 0
        '
        'lbappscapepayinfohello
        '
        Me.lbappscapepayinfohello.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbappscapepayinfohello.BackColor = System.Drawing.Color.Transparent
        Me.lbappscapepayinfohello.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbappscapepayinfohello.Location = New System.Drawing.Point(335, 5)
        Me.lbappscapepayinfohello.Name = "lbappscapepayinfohello"
        Me.lbappscapepayinfohello.Size = New System.Drawing.Size(432, 23)
        Me.lbappscapepayinfohello.TabIndex = 6
        Me.lbappscapepayinfohello.Text = " Hello CherryBlue - Your Wallet Contains 2.53542 BTN"
        Me.lbappscapepayinfohello.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'appscapehomepage
        '
        Me.appscapehomepage.AutoScroll = True
        Me.appscapehomepage.BackColor = System.Drawing.Color.White
        Me.appscapehomepage.Controls.Add(Me.Label1)
        Me.appscapehomepage.Controls.Add(Me.Panel20)
        Me.appscapehomepage.Controls.Add(Me.Panel17)
        Me.appscapehomepage.Controls.Add(Me.Panel14)
        Me.appscapehomepage.Controls.Add(Me.Panel11)
        Me.appscapehomepage.Controls.Add(Me.Panel8)
        Me.appscapehomepage.Controls.Add(Me.Panel5)
        Me.appscapehomepage.Controls.Add(Me.Panel4)
        Me.appscapehomepage.Controls.Add(Me.Panel3)
        Me.appscapehomepage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.appscapehomepage.Location = New System.Drawing.Point(0, 0)
        Me.appscapehomepage.Name = "appscapehomepage"
        Me.appscapehomepage.Size = New System.Drawing.Size(816, 533)
        Me.appscapehomepage.TabIndex = 3
        Me.appscapehomepage.Visible = False
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 511)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(768, 23)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "© Copyright Aiden Nirh - Do Not Reproduce"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel20
        '
        Me.Panel20.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel20.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapemoresoftware
        Me.Panel20.Controls.Add(Me.btnbuymoresoftware2)
        Me.Panel20.Controls.Add(Me.btnmoresoftware2info)
        Me.Panel20.Location = New System.Drawing.Point(610, 308)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(182, 200)
        Me.Panel20.TabIndex = 3
        '
        'btnbuymoresoftware2
        '
        Me.btnbuymoresoftware2.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeundefinedprice
        Me.btnbuymoresoftware2.Location = New System.Drawing.Point(73, 161)
        Me.btnbuymoresoftware2.Name = "btnbuymoresoftware2"
        Me.btnbuymoresoftware2.Size = New System.Drawing.Size(102, 30)
        Me.btnbuymoresoftware2.TabIndex = 1
        '
        'btnmoresoftware2info
        '
        Me.btnmoresoftware2info.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobutton
        Me.btnmoresoftware2info.Location = New System.Drawing.Point(10, 161)
        Me.btnmoresoftware2info.Name = "btnmoresoftware2info"
        Me.btnmoresoftware2info.Size = New System.Drawing.Size(57, 30)
        Me.btnmoresoftware2info.TabIndex = 0
        '
        'Panel17
        '
        Me.Panel17.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel17.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeorcwrite
        Me.Panel17.Controls.Add(Me.btnbuyorcwrite)
        Me.Panel17.Controls.Add(Me.btnmoresoftware1info)
        Me.Panel17.Location = New System.Drawing.Point(421, 308)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(182, 200)
        Me.Panel17.TabIndex = 4
        '
        'btnbuyorcwrite
        '
        Me.btnbuyorcwrite.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapevideoplayerprice
        Me.btnbuyorcwrite.Location = New System.Drawing.Point(73, 161)
        Me.btnbuyorcwrite.Name = "btnbuyorcwrite"
        Me.btnbuyorcwrite.Size = New System.Drawing.Size(102, 30)
        Me.btnbuyorcwrite.TabIndex = 1
        '
        'btnmoresoftware1info
        '
        Me.btnmoresoftware1info.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobutton
        Me.btnmoresoftware1info.Location = New System.Drawing.Point(10, 161)
        Me.btnmoresoftware1info.Name = "btnmoresoftware1info"
        Me.btnmoresoftware1info.Size = New System.Drawing.Size(57, 30)
        Me.btnmoresoftware1info.TabIndex = 0
        '
        'Panel14
        '
        Me.Panel14.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel14.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapecalculator
        Me.Panel14.Controls.Add(Me.btnbuycalculator)
        Me.Panel14.Controls.Add(Me.btncalculatorinfo)
        Me.Panel14.Location = New System.Drawing.Point(232, 308)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(182, 200)
        Me.Panel14.TabIndex = 3
        '
        'btnbuycalculator
        '
        Me.btnbuycalculator.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapecalculatorprice
        Me.btnbuycalculator.Location = New System.Drawing.Point(73, 161)
        Me.btnbuycalculator.Name = "btnbuycalculator"
        Me.btnbuycalculator.Size = New System.Drawing.Size(102, 30)
        Me.btnbuycalculator.TabIndex = 1
        '
        'btncalculatorinfo
        '
        Me.btncalculatorinfo.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobutton
        Me.btncalculatorinfo.Location = New System.Drawing.Point(10, 161)
        Me.btncalculatorinfo.Name = "btncalculatorinfo"
        Me.btncalculatorinfo.Size = New System.Drawing.Size(57, 30)
        Me.btncalculatorinfo.TabIndex = 0
        '
        'Panel11
        '
        Me.Panel11.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel11.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapewebbrowser
        Me.Panel11.Controls.Add(Me.btnbuywebbrowser)
        Me.Panel11.Controls.Add(Me.btnwebbrowserinfo)
        Me.Panel11.Location = New System.Drawing.Point(610, 101)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(182, 200)
        Me.Panel11.TabIndex = 3
        '
        'btnbuywebbrowser
        '
        Me.btnbuywebbrowser.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapewebbrowserprice
        Me.btnbuywebbrowser.Location = New System.Drawing.Point(73, 161)
        Me.btnbuywebbrowser.Name = "btnbuywebbrowser"
        Me.btnbuywebbrowser.Size = New System.Drawing.Size(102, 30)
        Me.btnbuywebbrowser.TabIndex = 1
        '
        'btnwebbrowserinfo
        '
        Me.btnwebbrowserinfo.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobutton
        Me.btnwebbrowserinfo.Location = New System.Drawing.Point(10, 161)
        Me.btnwebbrowserinfo.Name = "btnwebbrowserinfo"
        Me.btnwebbrowserinfo.Size = New System.Drawing.Size(57, 30)
        Me.btnwebbrowserinfo.TabIndex = 0
        '
        'Panel8
        '
        Me.Panel8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel8.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapevideoplayer
        Me.Panel8.Controls.Add(Me.btnbuyvideoplayer)
        Me.Panel8.Controls.Add(Me.btnvideoplayerinfo)
        Me.Panel8.Location = New System.Drawing.Point(421, 101)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(182, 200)
        Me.Panel8.TabIndex = 3
        '
        'btnbuyvideoplayer
        '
        Me.btnbuyvideoplayer.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapevideoplayerprice
        Me.btnbuyvideoplayer.Location = New System.Drawing.Point(73, 161)
        Me.btnbuyvideoplayer.Name = "btnbuyvideoplayer"
        Me.btnbuyvideoplayer.Size = New System.Drawing.Size(102, 30)
        Me.btnbuyvideoplayer.TabIndex = 1
        '
        'btnvideoplayerinfo
        '
        Me.btnvideoplayerinfo.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobutton
        Me.btnvideoplayerinfo.Location = New System.Drawing.Point(10, 161)
        Me.btnvideoplayerinfo.Name = "btnvideoplayerinfo"
        Me.btnvideoplayerinfo.Size = New System.Drawing.Size(57, 30)
        Me.btnvideoplayerinfo.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel5.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeaudioplayerbox
        Me.Panel5.Controls.Add(Me.btnbuyaudioplayer)
        Me.Panel5.Controls.Add(Me.btnaudioplayerinfo)
        Me.Panel5.Location = New System.Drawing.Point(232, 101)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(182, 200)
        Me.Panel5.TabIndex = 2
        '
        'btnbuyaudioplayer
        '
        Me.btnbuyaudioplayer.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeaudioplayerprice
        Me.btnbuyaudioplayer.Location = New System.Drawing.Point(73, 161)
        Me.btnbuyaudioplayer.Name = "btnbuyaudioplayer"
        Me.btnbuyaudioplayer.Size = New System.Drawing.Size(102, 30)
        Me.btnbuyaudioplayer.TabIndex = 1
        '
        'btnaudioplayerinfo
        '
        Me.btnaudioplayerinfo.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobutton
        Me.btnaudioplayerinfo.Location = New System.Drawing.Point(10, 161)
        Me.btnaudioplayerinfo.Name = "btnaudioplayerinfo"
        Me.btnaudioplayerinfo.Size = New System.Drawing.Size(57, 30)
        Me.btnaudioplayerinfo.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel4.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapewelcometoappscape
        Me.Panel4.Location = New System.Drawing.Point(23, 101)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(202, 407)
        Me.Panel4.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel3.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapetitlebanner
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel3.Controls.Add(Me.lbappscapehello)
        Me.Panel3.Controls.Add(Me.btnappscapedeposit)
        Me.Panel3.Location = New System.Drawing.Point(23, 5)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(770, 88)
        Me.Panel3.TabIndex = 0
        '
        'lbappscapehello
        '
        Me.lbappscapehello.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbappscapehello.BackColor = System.Drawing.Color.Transparent
        Me.lbappscapehello.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbappscapehello.Location = New System.Drawing.Point(335, 5)
        Me.lbappscapehello.Name = "lbappscapehello"
        Me.lbappscapehello.Size = New System.Drawing.Size(432, 23)
        Me.lbappscapehello.TabIndex = 6
        Me.lbappscapehello.Text = " Hello CherryBlue - Your Wallet Contains 2.53542 BTN"
        Me.lbappscapehello.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnappscapedeposit
        '
        Me.btnappscapedeposit.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnappscapedeposit.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapedepositnowbutton
        Me.btnappscapedeposit.Location = New System.Drawing.Point(678, 33)
        Me.btnappscapedeposit.Name = "btnappscapedeposit"
        Me.btnappscapedeposit.Size = New System.Drawing.Size(82, 47)
        Me.btnappscapedeposit.TabIndex = 0
        '
        'pnlappscapeoprcwrite
        '
        Me.pnlappscapeoprcwrite.AutoScroll = True
        Me.pnlappscapeoprcwrite.BackColor = System.Drawing.Color.White
        Me.pnlappscapeoprcwrite.Controls.Add(Me.Panel16)
        Me.pnlappscapeoprcwrite.Controls.Add(Me.Panel22)
        Me.pnlappscapeoprcwrite.Controls.Add(Me.Panel23)
        Me.pnlappscapeoprcwrite.Controls.Add(Me.Label5)
        Me.pnlappscapeoprcwrite.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlappscapeoprcwrite.Location = New System.Drawing.Point(0, 0)
        Me.pnlappscapeoprcwrite.Name = "pnlappscapeoprcwrite"
        Me.pnlappscapeoprcwrite.Size = New System.Drawing.Size(816, 533)
        Me.pnlappscapeoprcwrite.TabIndex = 9
        Me.pnlappscapeoprcwrite.Visible = False
        '
        'Panel16
        '
        Me.Panel16.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel16.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfoorcwritevisualpreview
        Me.Panel16.Controls.Add(Me.btnappscapeorcwritebuy)
        Me.Panel16.Controls.Add(Me.btnappscapeorcwriteback)
        Me.Panel16.Location = New System.Drawing.Point(224, 99)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(561, 414)
        Me.Panel16.TabIndex = 2
        '
        'btnappscapeorcwritebuy
        '
        Me.btnappscapeorcwritebuy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnappscapeorcwritebuy.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobuybutton
        Me.btnappscapeorcwritebuy.Location = New System.Drawing.Point(439, 366)
        Me.btnappscapeorcwritebuy.Name = "btnappscapeorcwritebuy"
        Me.btnappscapeorcwritebuy.Size = New System.Drawing.Size(102, 37)
        Me.btnappscapeorcwritebuy.TabIndex = 2
        '
        'btnappscapeorcwriteback
        '
        Me.btnappscapeorcwriteback.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnappscapeorcwriteback.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobackbutton
        Me.btnappscapeorcwriteback.Location = New System.Drawing.Point(20, 366)
        Me.btnappscapeorcwriteback.Name = "btnappscapeorcwriteback"
        Me.btnappscapeorcwriteback.Size = New System.Drawing.Size(102, 37)
        Me.btnappscapeorcwriteback.TabIndex = 1
        '
        'Panel22
        '
        Me.Panel22.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel22.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfoorcwritetext
        Me.Panel22.Location = New System.Drawing.Point(15, 99)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(202, 414)
        Me.Panel22.TabIndex = 1
        '
        'Panel23
        '
        Me.Panel23.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel23.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapetitlebanner
        Me.Panel23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel23.Controls.Add(Me.lblappscapeorcwritehellotext)
        Me.Panel23.Controls.Add(Me.btnappscapeorcwritedeposit)
        Me.Panel23.Location = New System.Drawing.Point(15, 5)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(770, 88)
        Me.Panel23.TabIndex = 0
        '
        'lblappscapeorcwritehellotext
        '
        Me.lblappscapeorcwritehellotext.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblappscapeorcwritehellotext.BackColor = System.Drawing.Color.Transparent
        Me.lblappscapeorcwritehellotext.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblappscapeorcwritehellotext.Location = New System.Drawing.Point(335, 5)
        Me.lblappscapeorcwritehellotext.Name = "lblappscapeorcwritehellotext"
        Me.lblappscapeorcwritehellotext.Size = New System.Drawing.Size(432, 23)
        Me.lblappscapeorcwritehellotext.TabIndex = 6
        Me.lblappscapeorcwritehellotext.Text = " Hello CherryBlue - Your Wallet Contains 2.53542 BTN"
        Me.lblappscapeorcwritehellotext.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnappscapeorcwritedeposit
        '
        Me.btnappscapeorcwritedeposit.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnappscapeorcwritedeposit.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapedepositnowbutton
        Me.btnappscapeorcwritedeposit.Location = New System.Drawing.Point(678, 33)
        Me.btnappscapeorcwritedeposit.Name = "btnappscapeorcwritedeposit"
        Me.btnappscapeorcwritedeposit.Size = New System.Drawing.Size(82, 47)
        Me.btnappscapeorcwritedeposit.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 511)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(768, 23)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "© Copyright Aiden Nirh - Do Not Reproduce"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'appscapewebbrowserinfopage
        '
        Me.appscapewebbrowserinfopage.AutoScroll = True
        Me.appscapewebbrowserinfopage.BackColor = System.Drawing.Color.White
        Me.appscapewebbrowserinfopage.Controls.Add(Me.Panel19)
        Me.appscapewebbrowserinfopage.Controls.Add(Me.Panel24)
        Me.appscapewebbrowserinfopage.Controls.Add(Me.Panel25)
        Me.appscapewebbrowserinfopage.Controls.Add(Me.Label6)
        Me.appscapewebbrowserinfopage.Location = New System.Drawing.Point(483, 241)
        Me.appscapewebbrowserinfopage.Name = "appscapewebbrowserinfopage"
        Me.appscapewebbrowserinfopage.Size = New System.Drawing.Size(333, 292)
        Me.appscapewebbrowserinfopage.TabIndex = 6
        Me.appscapewebbrowserinfopage.Visible = False
        '
        'Panel19
        '
        Me.Panel19.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel19.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfowebbrowservisualpreview
        Me.Panel19.Controls.Add(Me.btnwebbrowserinfobuy)
        Me.Panel19.Controls.Add(Me.btnwebbrowserinfoback)
        Me.Panel19.Location = New System.Drawing.Point(-9, 99)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(561, 414)
        Me.Panel19.TabIndex = 2
        '
        'btnwebbrowserinfobuy
        '
        Me.btnwebbrowserinfobuy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnwebbrowserinfobuy.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobuybutton
        Me.btnwebbrowserinfobuy.Location = New System.Drawing.Point(439, 366)
        Me.btnwebbrowserinfobuy.Name = "btnwebbrowserinfobuy"
        Me.btnwebbrowserinfobuy.Size = New System.Drawing.Size(102, 37)
        Me.btnwebbrowserinfobuy.TabIndex = 2
        '
        'btnwebbrowserinfoback
        '
        Me.btnwebbrowserinfoback.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnwebbrowserinfoback.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobackbutton
        Me.btnwebbrowserinfoback.Location = New System.Drawing.Point(20, 366)
        Me.btnwebbrowserinfoback.Name = "btnwebbrowserinfoback"
        Me.btnwebbrowserinfoback.Size = New System.Drawing.Size(102, 37)
        Me.btnwebbrowserinfoback.TabIndex = 1
        '
        'Panel24
        '
        Me.Panel24.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel24.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfowebbrowsertext
        Me.Panel24.Location = New System.Drawing.Point(-218, 99)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(202, 414)
        Me.Panel24.TabIndex = 1
        '
        'Panel25
        '
        Me.Panel25.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel25.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapetitlebanner
        Me.Panel25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel25.Controls.Add(Me.lbappscapewebbroswerinfohello)
        Me.Panel25.Controls.Add(Me.appscapewebbrowserinfodepositbtn)
        Me.Panel25.Location = New System.Drawing.Point(-218, 5)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(770, 88)
        Me.Panel25.TabIndex = 0
        '
        'lbappscapewebbroswerinfohello
        '
        Me.lbappscapewebbroswerinfohello.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbappscapewebbroswerinfohello.BackColor = System.Drawing.Color.Transparent
        Me.lbappscapewebbroswerinfohello.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbappscapewebbroswerinfohello.Location = New System.Drawing.Point(335, 5)
        Me.lbappscapewebbroswerinfohello.Name = "lbappscapewebbroswerinfohello"
        Me.lbappscapewebbroswerinfohello.Size = New System.Drawing.Size(432, 23)
        Me.lbappscapewebbroswerinfohello.TabIndex = 6
        Me.lbappscapewebbroswerinfohello.Text = " Hello CherryBlue - Your Wallet Contains 2.53542 BTN"
        Me.lbappscapewebbroswerinfohello.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'appscapewebbrowserinfodepositbtn
        '
        Me.appscapewebbrowserinfodepositbtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.appscapewebbrowserinfodepositbtn.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapedepositnowbutton
        Me.appscapewebbrowserinfodepositbtn.Location = New System.Drawing.Point(678, 33)
        Me.appscapewebbrowserinfodepositbtn.Name = "appscapewebbrowserinfodepositbtn"
        Me.appscapewebbrowserinfodepositbtn.Size = New System.Drawing.Size(82, 47)
        Me.appscapewebbrowserinfodepositbtn.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(-221, 511)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(768, 23)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "© Copyright Aiden Nirh - Do Not Reproduce"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'appscapevideoplayerinfopage
        '
        Me.appscapevideoplayerinfopage.AutoScroll = True
        Me.appscapevideoplayerinfopage.BackColor = System.Drawing.Color.White
        Me.appscapevideoplayerinfopage.Controls.Add(Me.Panel9)
        Me.appscapevideoplayerinfopage.Controls.Add(Me.Panel13)
        Me.appscapevideoplayerinfopage.Controls.Add(Me.Panel15)
        Me.appscapevideoplayerinfopage.Controls.Add(Me.Label4)
        Me.appscapevideoplayerinfopage.Location = New System.Drawing.Point(347, 125)
        Me.appscapevideoplayerinfopage.Name = "appscapevideoplayerinfopage"
        Me.appscapevideoplayerinfopage.Size = New System.Drawing.Size(469, 408)
        Me.appscapevideoplayerinfopage.TabIndex = 5
        Me.appscapevideoplayerinfopage.Visible = False
        '
        'Panel9
        '
        Me.Panel9.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel9.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfovideoplayervisualpreview
        Me.Panel9.Controls.Add(Me.btnvideoplayerinfobuy)
        Me.Panel9.Controls.Add(Me.btnvideoplayerinfoback)
        Me.Panel9.Location = New System.Drawing.Point(59, 99)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(561, 414)
        Me.Panel9.TabIndex = 2
        '
        'btnvideoplayerinfobuy
        '
        Me.btnvideoplayerinfobuy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnvideoplayerinfobuy.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobuybutton
        Me.btnvideoplayerinfobuy.Location = New System.Drawing.Point(439, 366)
        Me.btnvideoplayerinfobuy.Name = "btnvideoplayerinfobuy"
        Me.btnvideoplayerinfobuy.Size = New System.Drawing.Size(102, 37)
        Me.btnvideoplayerinfobuy.TabIndex = 2
        '
        'btnvideoplayerinfoback
        '
        Me.btnvideoplayerinfoback.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnvideoplayerinfoback.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobackbutton
        Me.btnvideoplayerinfoback.Location = New System.Drawing.Point(20, 366)
        Me.btnvideoplayerinfoback.Name = "btnvideoplayerinfoback"
        Me.btnvideoplayerinfoback.Size = New System.Drawing.Size(102, 37)
        Me.btnvideoplayerinfoback.TabIndex = 1
        '
        'Panel13
        '
        Me.Panel13.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel13.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfovideoplayertext
        Me.Panel13.Location = New System.Drawing.Point(-150, 99)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(202, 414)
        Me.Panel13.TabIndex = 1
        '
        'Panel15
        '
        Me.Panel15.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel15.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapetitlebanner
        Me.Panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel15.Controls.Add(Me.lbappscapevideoplayerinfohello)
        Me.Panel15.Controls.Add(Me.appscapevideoplayerinfodepositbtn)
        Me.Panel15.Location = New System.Drawing.Point(-150, 5)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(770, 88)
        Me.Panel15.TabIndex = 0
        '
        'lbappscapevideoplayerinfohello
        '
        Me.lbappscapevideoplayerinfohello.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbappscapevideoplayerinfohello.BackColor = System.Drawing.Color.Transparent
        Me.lbappscapevideoplayerinfohello.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbappscapevideoplayerinfohello.Location = New System.Drawing.Point(335, 5)
        Me.lbappscapevideoplayerinfohello.Name = "lbappscapevideoplayerinfohello"
        Me.lbappscapevideoplayerinfohello.Size = New System.Drawing.Size(432, 23)
        Me.lbappscapevideoplayerinfohello.TabIndex = 6
        Me.lbappscapevideoplayerinfohello.Text = " Hello CherryBlue - Your Wallet Contains 2.53542 BTN"
        Me.lbappscapevideoplayerinfohello.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'appscapevideoplayerinfodepositbtn
        '
        Me.appscapevideoplayerinfodepositbtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.appscapevideoplayerinfodepositbtn.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapedepositnowbutton
        Me.appscapevideoplayerinfodepositbtn.Location = New System.Drawing.Point(678, 33)
        Me.appscapevideoplayerinfodepositbtn.Name = "appscapevideoplayerinfodepositbtn"
        Me.appscapevideoplayerinfodepositbtn.Size = New System.Drawing.Size(82, 47)
        Me.appscapevideoplayerinfodepositbtn.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(-153, 511)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(768, 23)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "© Copyright Aiden Nirh - Do Not Reproduce"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'appscapecalculatorinfopage
        '
        Me.appscapecalculatorinfopage.AutoScroll = True
        Me.appscapecalculatorinfopage.BackColor = System.Drawing.Color.White
        Me.appscapecalculatorinfopage.Controls.Add(Me.Panel28)
        Me.appscapecalculatorinfopage.Controls.Add(Me.Panel34)
        Me.appscapecalculatorinfopage.Controls.Add(Me.Panel35)
        Me.appscapecalculatorinfopage.Controls.Add(Me.Label8)
        Me.appscapecalculatorinfopage.Location = New System.Drawing.Point(279, 86)
        Me.appscapecalculatorinfopage.Name = "appscapecalculatorinfopage"
        Me.appscapecalculatorinfopage.Size = New System.Drawing.Size(537, 447)
        Me.appscapecalculatorinfopage.TabIndex = 7
        Me.appscapecalculatorinfopage.Visible = False
        '
        'Panel28
        '
        Me.Panel28.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel28.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfocalculatorvisualpreview
        Me.Panel28.Controls.Add(Me.btncalculatorinfobuy)
        Me.Panel28.Controls.Add(Me.btncalculatorinfoback)
        Me.Panel28.Location = New System.Drawing.Point(93, 99)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(561, 414)
        Me.Panel28.TabIndex = 2
        '
        'btncalculatorinfobuy
        '
        Me.btncalculatorinfobuy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btncalculatorinfobuy.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobuybutton
        Me.btncalculatorinfobuy.Location = New System.Drawing.Point(439, 366)
        Me.btncalculatorinfobuy.Name = "btncalculatorinfobuy"
        Me.btncalculatorinfobuy.Size = New System.Drawing.Size(102, 37)
        Me.btncalculatorinfobuy.TabIndex = 2
        '
        'btncalculatorinfoback
        '
        Me.btncalculatorinfoback.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btncalculatorinfoback.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobackbutton
        Me.btncalculatorinfoback.Location = New System.Drawing.Point(20, 366)
        Me.btncalculatorinfoback.Name = "btncalculatorinfoback"
        Me.btncalculatorinfoback.Size = New System.Drawing.Size(102, 37)
        Me.btncalculatorinfoback.TabIndex = 1
        '
        'Panel34
        '
        Me.Panel34.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel34.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfocalculatortext
        Me.Panel34.Location = New System.Drawing.Point(-116, 99)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(202, 414)
        Me.Panel34.TabIndex = 1
        '
        'Panel35
        '
        Me.Panel35.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel35.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapetitlebanner
        Me.Panel35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel35.Controls.Add(Me.lbappscapecalculatorinfohello)
        Me.Panel35.Controls.Add(Me.appscapecalcinfodepositbtn)
        Me.Panel35.Location = New System.Drawing.Point(-116, 5)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(770, 88)
        Me.Panel35.TabIndex = 0
        '
        'lbappscapecalculatorinfohello
        '
        Me.lbappscapecalculatorinfohello.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbappscapecalculatorinfohello.BackColor = System.Drawing.Color.Transparent
        Me.lbappscapecalculatorinfohello.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbappscapecalculatorinfohello.Location = New System.Drawing.Point(335, 5)
        Me.lbappscapecalculatorinfohello.Name = "lbappscapecalculatorinfohello"
        Me.lbappscapecalculatorinfohello.Size = New System.Drawing.Size(432, 23)
        Me.lbappscapecalculatorinfohello.TabIndex = 6
        Me.lbappscapecalculatorinfohello.Text = " Hello CherryBlue - Your Wallet Contains 2.53542 BTN"
        Me.lbappscapecalculatorinfohello.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'appscapecalcinfodepositbtn
        '
        Me.appscapecalcinfodepositbtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.appscapecalcinfodepositbtn.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapedepositnowbutton
        Me.appscapecalcinfodepositbtn.Location = New System.Drawing.Point(678, 33)
        Me.appscapecalcinfodepositbtn.Name = "appscapecalcinfodepositbtn"
        Me.appscapecalcinfodepositbtn.Size = New System.Drawing.Size(82, 47)
        Me.appscapecalcinfodepositbtn.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(-119, 511)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(768, 23)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "© Copyright Aiden Nirh - Do Not Reproduce"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'appscapeaudioplayerinfopage
        '
        Me.appscapeaudioplayerinfopage.AutoScroll = True
        Me.appscapeaudioplayerinfopage.BackColor = System.Drawing.Color.White
        Me.appscapeaudioplayerinfopage.Controls.Add(Me.Panel6)
        Me.appscapeaudioplayerinfopage.Controls.Add(Me.Panel31)
        Me.appscapeaudioplayerinfopage.Controls.Add(Me.Panel32)
        Me.appscapeaudioplayerinfopage.Controls.Add(Me.Label2)
        Me.appscapeaudioplayerinfopage.Location = New System.Drawing.Point(80, 452)
        Me.appscapeaudioplayerinfopage.Name = "appscapeaudioplayerinfopage"
        Me.appscapeaudioplayerinfopage.Size = New System.Drawing.Size(111, 66)
        Me.appscapeaudioplayerinfopage.TabIndex = 4
        Me.appscapeaudioplayerinfopage.Visible = False
        '
        'Panel6
        '
        Me.Panel6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel6.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfoaudioplayervisualpreview
        Me.Panel6.Controls.Add(Me.btnaudioplayerinfobuy)
        Me.Panel6.Controls.Add(Me.btnaudioplayerinfoback)
        Me.Panel6.Location = New System.Drawing.Point(-120, 99)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(561, 414)
        Me.Panel6.TabIndex = 2
        '
        'btnaudioplayerinfobuy
        '
        Me.btnaudioplayerinfobuy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnaudioplayerinfobuy.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobuybutton
        Me.btnaudioplayerinfobuy.Location = New System.Drawing.Point(439, 366)
        Me.btnaudioplayerinfobuy.Name = "btnaudioplayerinfobuy"
        Me.btnaudioplayerinfobuy.Size = New System.Drawing.Size(102, 37)
        Me.btnaudioplayerinfobuy.TabIndex = 2
        '
        'btnaudioplayerinfoback
        '
        Me.btnaudioplayerinfoback.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnaudioplayerinfoback.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfobackbutton
        Me.btnaudioplayerinfoback.Location = New System.Drawing.Point(20, 366)
        Me.btnaudioplayerinfoback.Name = "btnaudioplayerinfoback"
        Me.btnaudioplayerinfoback.Size = New System.Drawing.Size(102, 37)
        Me.btnaudioplayerinfoback.TabIndex = 1
        '
        'Panel31
        '
        Me.Panel31.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel31.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapeinfoaudioplayertext
        Me.Panel31.Location = New System.Drawing.Point(-329, 99)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(202, 414)
        Me.Panel31.TabIndex = 1
        '
        'Panel32
        '
        Me.Panel32.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel32.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapetitlebanner
        Me.Panel32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel32.Controls.Add(Me.lbappscapeaudioplayerinfohello)
        Me.Panel32.Controls.Add(Me.appscapeaudioplayerinfodepositbtn)
        Me.Panel32.Location = New System.Drawing.Point(-329, 5)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(770, 88)
        Me.Panel32.TabIndex = 0
        '
        'lbappscapeaudioplayerinfohello
        '
        Me.lbappscapeaudioplayerinfohello.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbappscapeaudioplayerinfohello.BackColor = System.Drawing.Color.Transparent
        Me.lbappscapeaudioplayerinfohello.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbappscapeaudioplayerinfohello.Location = New System.Drawing.Point(335, 5)
        Me.lbappscapeaudioplayerinfohello.Name = "lbappscapeaudioplayerinfohello"
        Me.lbappscapeaudioplayerinfohello.Size = New System.Drawing.Size(432, 23)
        Me.lbappscapeaudioplayerinfohello.TabIndex = 6
        Me.lbappscapeaudioplayerinfohello.Text = " Hello CherryBlue - Your Wallet Contains 2.53542 BTN"
        Me.lbappscapeaudioplayerinfohello.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'appscapeaudioplayerinfodepositbtn
        '
        Me.appscapeaudioplayerinfodepositbtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.appscapeaudioplayerinfodepositbtn.BackgroundImage = Global.ShiftOS.My.Resources.Resources.appscapedepositnowbutton
        Me.appscapeaudioplayerinfodepositbtn.Location = New System.Drawing.Point(678, 33)
        Me.appscapeaudioplayerinfodepositbtn.Name = "appscapeaudioplayerinfodepositbtn"
        Me.appscapeaudioplayerinfodepositbtn.Size = New System.Drawing.Size(82, 47)
        Me.appscapeaudioplayerinfodepositbtn.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(-333, 511)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(768, 23)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "© Copyright Aiden Nirh - Do Not Reproduce"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlmainsiteminimatch
        '
        Me.pnlmainsiteminimatch.AutoScroll = True
        Me.pnlmainsiteminimatch.BackColor = System.Drawing.Color.White
        Me.pnlmainsiteminimatch.Controls.Add(Me.pnlminimatchlabyrinth)
        Me.pnlmainsiteminimatch.Controls.Add(Me.pnlminimatchhomepage)
        Me.pnlmainsiteminimatch.Controls.Add(Me.pnlminimatchdodgeinfopage)
        Me.pnlmainsiteminimatch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlmainsiteminimatch.Location = New System.Drawing.Point(0, 35)
        Me.pnlmainsiteminimatch.Name = "pnlmainsiteminimatch"
        Me.pnlmainsiteminimatch.Size = New System.Drawing.Size(816, 533)
        Me.pnlmainsiteminimatch.TabIndex = 9
        Me.pnlmainsiteminimatch.Visible = False
        '
        'pnlminimatchlabyrinth
        '
        Me.pnlminimatchlabyrinth.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlminimatchlabyrinth.Controls.Add(Me.Label20)
        Me.pnlminimatchlabyrinth.Controls.Add(Me.Panel10)
        Me.pnlminimatchlabyrinth.Controls.Add(Me.PictureBox2)
        Me.pnlminimatchlabyrinth.Controls.Add(Me.Label27)
        Me.pnlminimatchlabyrinth.Controls.Add(Me.Panel12)
        Me.pnlminimatchlabyrinth.Controls.Add(Me.PictureBox3)
        Me.pnlminimatchlabyrinth.Controls.Add(Me.PictureBox6)
        Me.pnlminimatchlabyrinth.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlminimatchlabyrinth.Location = New System.Drawing.Point(0, 0)
        Me.pnlminimatchlabyrinth.Name = "pnlminimatchlabyrinth"
        Me.pnlminimatchlabyrinth.Size = New System.Drawing.Size(816, 533)
        Me.pnlminimatchlabyrinth.TabIndex = 2
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(13, 10)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(197, 47)
        Me.Label20.TabIndex = 7
        Me.Label20.Text = "Welcome William," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Your balance is 1.65BTN"
        '
        'Panel10
        '
        Me.Panel10.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel10.BackColor = System.Drawing.Color.LightGray
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel10.Controls.Add(Me.txtminimatchlabrinthaddress)
        Me.Panel10.Controls.Add(Me.lblminimatchinfopagebuy)
        Me.Panel10.Controls.Add(Me.lblminimatchlabyrinthbuyinstuct)
        Me.Panel10.Controls.Add(Me.Label26)
        Me.Panel10.Location = New System.Drawing.Point(561, 167)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(242, 338)
        Me.Panel10.TabIndex = 6
        '
        'txtminimatchlabrinthaddress
        '
        Me.txtminimatchlabrinthaddress.Location = New System.Drawing.Point(22, 262)
        Me.txtminimatchlabrinthaddress.Name = "txtminimatchlabrinthaddress"
        Me.txtminimatchlabrinthaddress.Size = New System.Drawing.Size(204, 20)
        Me.txtminimatchlabrinthaddress.TabIndex = 4
        '
        'lblminimatchinfopagebuy
        '
        Me.lblminimatchinfopagebuy.BackColor = System.Drawing.Color.Gray
        Me.lblminimatchinfopagebuy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblminimatchinfopagebuy.ForeColor = System.Drawing.Color.White
        Me.lblminimatchinfopagebuy.Location = New System.Drawing.Point(5, 310)
        Me.lblminimatchinfopagebuy.Name = "lblminimatchinfopagebuy"
        Me.lblminimatchinfopagebuy.Size = New System.Drawing.Size(232, 21)
        Me.lblminimatchinfopagebuy.TabIndex = 3
        Me.lblminimatchinfopagebuy.Text = "Buy for 1.32 BNT"
        Me.lblminimatchinfopagebuy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblminimatchlabyrinthbuyinstuct
        '
        Me.lblminimatchlabyrinthbuyinstuct.Location = New System.Drawing.Point(23, 62)
        Me.lblminimatchlabyrinthbuyinstuct.Name = "lblminimatchlabyrinthbuyinstuct"
        Me.lblminimatchlabyrinthbuyinstuct.Size = New System.Drawing.Size(203, 193)
        Me.lblminimatchlabyrinthbuyinstuct.TabIndex = 1
        Me.lblminimatchlabyrinthbuyinstuct.Text = resources.GetString("lblminimatchlabyrinthbuyinstuct.Text")
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(36, 20)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(169, 31)
        Me.Label26.TabIndex = 0
        Me.Label26.Text = "How to buy:"
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox2.Image = Global.ShiftOS.My.Resources.Resources.minimatchlabyrinthpreview
        Me.PictureBox2.Location = New System.Drawing.Point(277, 167)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(253, 338)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(309, 511)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(168, 13)
        Me.Label27.TabIndex = 4
        Me.Label27.Text = "Copyright © - Minimatch CO. 2014"
        '
        'Panel12
        '
        Me.Panel12.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Panel12.BackColor = System.Drawing.Color.LightGray
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel12.Controls.Add(Me.Label28)
        Me.Panel12.Controls.Add(Me.Label29)
        Me.Panel12.Controls.Add(Me.Label30)
        Me.Panel12.Location = New System.Drawing.Point(10, 167)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(242, 338)
        Me.Panel12.TabIndex = 1
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.Gray
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(5, 310)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(232, 21)
        Me.Label28.TabIndex = 4
        Me.Label28.Text = "<- Back"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(19, 61)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(203, 244)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = resources.GetString("Label29.Text")
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(11, 17)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(219, 31)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "About Labyrinth"
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox3.Image = Global.ShiftOS.My.Resources.Resources.BitnotesAcceptedHereLogo
        Me.PictureBox3.Location = New System.Drawing.Point(16, 71)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(200, 44)
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox6.BackgroundImage = Global.ShiftOS.My.Resources.Resources.Minimatchbackground
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox6.Location = New System.Drawing.Point(5, 6)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(806, 524)
        Me.PictureBox6.TabIndex = 8
        Me.PictureBox6.TabStop = False
        '
        'pnlminimatchhomepage
        '
        Me.pnlminimatchhomepage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pnlminimatchhomepage.Controls.Add(Me.lblminimatchcopyright)
        Me.pnlminimatchhomepage.Controls.Add(Me.pnlminimatchcomingsoon2)
        Me.pnlminimatchhomepage.Controls.Add(Me.pnlminimatchcomingsoon)
        Me.pnlminimatchhomepage.Controls.Add(Me.pnlminimatchdodgepreview)
        Me.pnlminimatchhomepage.Controls.Add(Me.picbitnotesaccepted)
        Me.pnlminimatchhomepage.Controls.Add(Me.lblminimatchmainpagewelcome)
        Me.pnlminimatchhomepage.Controls.Add(Me.PictureBox5)
        Me.pnlminimatchhomepage.Location = New System.Drawing.Point(79, 288)
        Me.pnlminimatchhomepage.Name = "pnlminimatchhomepage"
        Me.pnlminimatchhomepage.Size = New System.Drawing.Size(271, 197)
        Me.pnlminimatchhomepage.TabIndex = 0
        '
        'lblminimatchcopyright
        '
        Me.lblminimatchcopyright.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblminimatchcopyright.AutoSize = True
        Me.lblminimatchcopyright.Location = New System.Drawing.Point(36, 512)
        Me.lblminimatchcopyright.Name = "lblminimatchcopyright"
        Me.lblminimatchcopyright.Size = New System.Drawing.Size(168, 13)
        Me.lblminimatchcopyright.TabIndex = 4
        Me.lblminimatchcopyright.Text = "Copyright © - Minimatch CO. 2014"
        '
        'pnlminimatchcomingsoon2
        '
        Me.pnlminimatchcomingsoon2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pnlminimatchcomingsoon2.BackColor = System.Drawing.Color.LightGray
        Me.pnlminimatchcomingsoon2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlminimatchcomingsoon2.Controls.Add(Me.pnlminimatchcomingsoonbuy2)
        Me.pnlminimatchcomingsoon2.Controls.Add(Me.pnlminimatchcomingsooninfo2)
        Me.pnlminimatchcomingsoon2.Controls.Add(Me.pnlminimatchcomingsoondescription2)
        Me.pnlminimatchcomingsoon2.Controls.Add(Me.pnlminimatchcomingsoontitle2)
        Me.pnlminimatchcomingsoon2.Location = New System.Drawing.Point(271, 223)
        Me.pnlminimatchcomingsoon2.Name = "pnlminimatchcomingsoon2"
        Me.pnlminimatchcomingsoon2.Size = New System.Drawing.Size(254, 289)
        Me.pnlminimatchcomingsoon2.TabIndex = 3
        '
        'pnlminimatchcomingsoonbuy2
        '
        Me.pnlminimatchcomingsoonbuy2.BackColor = System.Drawing.Color.Gray
        Me.pnlminimatchcomingsoonbuy2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlminimatchcomingsoonbuy2.ForeColor = System.Drawing.Color.White
        Me.pnlminimatchcomingsoonbuy2.Location = New System.Drawing.Point(126, 122)
        Me.pnlminimatchcomingsoonbuy2.Name = "pnlminimatchcomingsoonbuy2"
        Me.pnlminimatchcomingsoonbuy2.Size = New System.Drawing.Size(100, 21)
        Me.pnlminimatchcomingsoonbuy2.TabIndex = 3
        Me.pnlminimatchcomingsoonbuy2.Text = "----"
        Me.pnlminimatchcomingsoonbuy2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlminimatchcomingsooninfo2
        '
        Me.pnlminimatchcomingsooninfo2.BackColor = System.Drawing.Color.Gray
        Me.pnlminimatchcomingsooninfo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlminimatchcomingsooninfo2.ForeColor = System.Drawing.Color.White
        Me.pnlminimatchcomingsooninfo2.Location = New System.Drawing.Point(20, 122)
        Me.pnlminimatchcomingsooninfo2.Name = "pnlminimatchcomingsooninfo2"
        Me.pnlminimatchcomingsooninfo2.Size = New System.Drawing.Size(100, 21)
        Me.pnlminimatchcomingsooninfo2.TabIndex = 2
        Me.pnlminimatchcomingsooninfo2.Text = "----"
        Me.pnlminimatchcomingsooninfo2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlminimatchcomingsoondescription2
        '
        Me.pnlminimatchcomingsoondescription2.Location = New System.Drawing.Point(23, 62)
        Me.pnlminimatchcomingsoondescription2.Name = "pnlminimatchcomingsoondescription2"
        Me.pnlminimatchcomingsoondescription2.Size = New System.Drawing.Size(203, 41)
        Me.pnlminimatchcomingsoondescription2.TabIndex = 1
        Me.pnlminimatchcomingsoondescription2.Text = "Minimatch is constantly adding new software to it's store. Make sure you check ba" & _
    "ck for more..."
        '
        'pnlminimatchcomingsoontitle2
        '
        Me.pnlminimatchcomingsoontitle2.AutoSize = True
        Me.pnlminimatchcomingsoontitle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnlminimatchcomingsoontitle2.Location = New System.Drawing.Point(20, 18)
        Me.pnlminimatchcomingsoontitle2.Name = "pnlminimatchcomingsoontitle2"
        Me.pnlminimatchcomingsoontitle2.Size = New System.Drawing.Size(106, 31)
        Me.pnlminimatchcomingsoontitle2.TabIndex = 0
        Me.pnlminimatchcomingsoontitle2.Text = "More..."
        '
        'pnlminimatchcomingsoon
        '
        Me.pnlminimatchcomingsoon.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pnlminimatchcomingsoon.BackColor = System.Drawing.Color.LightGray
        Me.pnlminimatchcomingsoon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlminimatchcomingsoon.Controls.Add(Me.bntminimatchcomingsoonbuy)
        Me.pnlminimatchcomingsoon.Controls.Add(Me.bntminimatchcomingsooninfo)
        Me.pnlminimatchcomingsoon.Controls.Add(Me.lblminimatchcomingsoondescription)
        Me.pnlminimatchcomingsoon.Controls.Add(Me.lblminimatchcomingsoontitle)
        Me.pnlminimatchcomingsoon.Location = New System.Drawing.Point(9, 223)
        Me.pnlminimatchcomingsoon.Name = "pnlminimatchcomingsoon"
        Me.pnlminimatchcomingsoon.Size = New System.Drawing.Size(250, 289)
        Me.pnlminimatchcomingsoon.TabIndex = 2
        '
        'bntminimatchcomingsoonbuy
        '
        Me.bntminimatchcomingsoonbuy.BackColor = System.Drawing.Color.Gray
        Me.bntminimatchcomingsoonbuy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.bntminimatchcomingsoonbuy.ForeColor = System.Drawing.Color.White
        Me.bntminimatchcomingsoonbuy.Location = New System.Drawing.Point(126, 122)
        Me.bntminimatchcomingsoonbuy.Name = "bntminimatchcomingsoonbuy"
        Me.bntminimatchcomingsoonbuy.Size = New System.Drawing.Size(100, 21)
        Me.bntminimatchcomingsoonbuy.TabIndex = 3
        Me.bntminimatchcomingsoonbuy.Text = "1 BNT"
        Me.bntminimatchcomingsoonbuy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'bntminimatchcomingsooninfo
        '
        Me.bntminimatchcomingsooninfo.BackColor = System.Drawing.Color.Gray
        Me.bntminimatchcomingsooninfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.bntminimatchcomingsooninfo.ForeColor = System.Drawing.Color.White
        Me.bntminimatchcomingsooninfo.Location = New System.Drawing.Point(20, 122)
        Me.bntminimatchcomingsooninfo.Name = "bntminimatchcomingsooninfo"
        Me.bntminimatchcomingsooninfo.Size = New System.Drawing.Size(100, 21)
        Me.bntminimatchcomingsooninfo.TabIndex = 2
        Me.bntminimatchcomingsooninfo.Text = "INFO"
        Me.bntminimatchcomingsooninfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblminimatchcomingsoondescription
        '
        Me.lblminimatchcomingsoondescription.Location = New System.Drawing.Point(23, 62)
        Me.lblminimatchcomingsoondescription.Name = "lblminimatchcomingsoondescription"
        Me.lblminimatchcomingsoondescription.Size = New System.Drawing.Size(203, 41)
        Me.lblminimatchcomingsoondescription.TabIndex = 1
        Me.lblminimatchcomingsoondescription.Text = "Run through a maze as fast as you can without touching walls. Every time you win," & _
    " you get some codepoints"
        '
        'lblminimatchcomingsoontitle
        '
        Me.lblminimatchcomingsoontitle.AutoSize = True
        Me.lblminimatchcomingsoontitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblminimatchcomingsoontitle.Location = New System.Drawing.Point(20, 18)
        Me.lblminimatchcomingsoontitle.Name = "lblminimatchcomingsoontitle"
        Me.lblminimatchcomingsoontitle.Size = New System.Drawing.Size(135, 31)
        Me.lblminimatchcomingsoontitle.TabIndex = 0
        Me.lblminimatchcomingsoontitle.Text = "Labyrinth"
        '
        'pnlminimatchdodgepreview
        '
        Me.pnlminimatchdodgepreview.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pnlminimatchdodgepreview.BackColor = System.Drawing.Color.LightGray
        Me.pnlminimatchdodgepreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlminimatchdodgepreview.Controls.Add(Me.bntminimatchdodgebuy)
        Me.pnlminimatchdodgepreview.Controls.Add(Me.bntminimatchdodgeinfo)
        Me.pnlminimatchdodgepreview.Controls.Add(Me.lblminimatchdodgedescription)
        Me.pnlminimatchdodgepreview.Controls.Add(Me.lblminimatchdodgetitle)
        Me.pnlminimatchdodgepreview.Location = New System.Drawing.Point(-255, 223)
        Me.pnlminimatchdodgepreview.Name = "pnlminimatchdodgepreview"
        Me.pnlminimatchdodgepreview.Size = New System.Drawing.Size(253, 289)
        Me.pnlminimatchdodgepreview.TabIndex = 1
        '
        'bntminimatchdodgebuy
        '
        Me.bntminimatchdodgebuy.BackColor = System.Drawing.Color.Gray
        Me.bntminimatchdodgebuy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.bntminimatchdodgebuy.ForeColor = System.Drawing.Color.White
        Me.bntminimatchdodgebuy.Location = New System.Drawing.Point(126, 122)
        Me.bntminimatchdodgebuy.Name = "bntminimatchdodgebuy"
        Me.bntminimatchdodgebuy.Size = New System.Drawing.Size(100, 21)
        Me.bntminimatchdodgebuy.TabIndex = 3
        Me.bntminimatchdodgebuy.Text = "1.32 BNT"
        Me.bntminimatchdodgebuy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'bntminimatchdodgeinfo
        '
        Me.bntminimatchdodgeinfo.BackColor = System.Drawing.Color.Gray
        Me.bntminimatchdodgeinfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.bntminimatchdodgeinfo.ForeColor = System.Drawing.Color.White
        Me.bntminimatchdodgeinfo.Location = New System.Drawing.Point(20, 122)
        Me.bntminimatchdodgeinfo.Name = "bntminimatchdodgeinfo"
        Me.bntminimatchdodgeinfo.Size = New System.Drawing.Size(100, 21)
        Me.bntminimatchdodgeinfo.TabIndex = 2
        Me.bntminimatchdodgeinfo.Text = "INFO"
        Me.bntminimatchdodgeinfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblminimatchdodgedescription
        '
        Me.lblminimatchdodgedescription.Location = New System.Drawing.Point(23, 62)
        Me.lblminimatchdodgedescription.Name = "lblminimatchdodgedescription"
        Me.lblminimatchdodgedescription.Size = New System.Drawing.Size(203, 41)
        Me.lblminimatchdodgedescription.TabIndex = 1
        Me.lblminimatchdodgedescription.Text = "Dodge falling objects and stay alive as long as you can. Play this fun and exciti" & _
    "ng game while earning code points!"
        '
        'lblminimatchdodgetitle
        '
        Me.lblminimatchdodgetitle.AutoSize = True
        Me.lblminimatchdodgetitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblminimatchdodgetitle.Location = New System.Drawing.Point(65, 18)
        Me.lblminimatchdodgetitle.Name = "lblminimatchdodgetitle"
        Me.lblminimatchdodgetitle.Size = New System.Drawing.Size(99, 31)
        Me.lblminimatchdodgetitle.TabIndex = 0
        Me.lblminimatchdodgetitle.Text = "Dodge"
        '
        'picbitnotesaccepted
        '
        Me.picbitnotesaccepted.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picbitnotesaccepted.BackColor = System.Drawing.Color.Transparent
        Me.picbitnotesaccepted.Image = Global.ShiftOS.My.Resources.Resources.BitnotesAcceptedHereLogo
        Me.picbitnotesaccepted.Location = New System.Drawing.Point(-246, 88)
        Me.picbitnotesaccepted.Name = "picbitnotesaccepted"
        Me.picbitnotesaccepted.Size = New System.Drawing.Size(209, 50)
        Me.picbitnotesaccepted.TabIndex = 0
        Me.picbitnotesaccepted.TabStop = False
        '
        'lblminimatchmainpagewelcome
        '
        Me.lblminimatchmainpagewelcome.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblminimatchmainpagewelcome.BackColor = System.Drawing.Color.Transparent
        Me.lblminimatchmainpagewelcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblminimatchmainpagewelcome.Location = New System.Drawing.Point(-249, 26)
        Me.lblminimatchmainpagewelcome.Name = "lblminimatchmainpagewelcome"
        Me.lblminimatchmainpagewelcome.Size = New System.Drawing.Size(239, 58)
        Me.lblminimatchmainpagewelcome.TabIndex = 8
        Me.lblminimatchmainpagewelcome.Text = "Welcome William," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Your balance is 1.65BTN"
        '
        'PictureBox5
        '
        Me.PictureBox5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox5.BackgroundImage = Global.ShiftOS.My.Resources.Resources.Minimatchbackground
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Location = New System.Drawing.Point(-267, 5)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(804, 524)
        Me.PictureBox5.TabIndex = 9
        Me.PictureBox5.TabStop = False
        '
        'pnlminimatchdodgeinfopage
        '
        Me.pnlminimatchdodgeinfopage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlminimatchdodgeinfopage.Controls.Add(Me.lblminimatchuserwelcome)
        Me.pnlminimatchdodgeinfopage.Controls.Add(Me.pnlminimatchdodgepagebuy)
        Me.pnlminimatchdodgeinfopage.Controls.Add(Me.picminimatchdodgepreview)
        Me.pnlminimatchdodgeinfopage.Controls.Add(Me.lblminimatchcopyrightdodgepage)
        Me.pnlminimatchdodgeinfopage.Controls.Add(Me.pnlminimatchdodgeinfodetails)
        Me.pnlminimatchdodgeinfopage.Controls.Add(Me.picminimatchbtnaccepted)
        Me.pnlminimatchdodgeinfopage.Controls.Add(Me.PictureBox4)
        Me.pnlminimatchdodgeinfopage.Location = New System.Drawing.Point(79, 124)
        Me.pnlminimatchdodgeinfopage.Name = "pnlminimatchdodgeinfopage"
        Me.pnlminimatchdodgeinfopage.Size = New System.Drawing.Size(187, 105)
        Me.pnlminimatchdodgeinfopage.TabIndex = 1
        '
        'lblminimatchuserwelcome
        '
        Me.lblminimatchuserwelcome.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblminimatchuserwelcome.BackColor = System.Drawing.Color.Transparent
        Me.lblminimatchuserwelcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblminimatchuserwelcome.Location = New System.Drawing.Point(-302, 10)
        Me.lblminimatchuserwelcome.Name = "lblminimatchuserwelcome"
        Me.lblminimatchuserwelcome.Size = New System.Drawing.Size(197, 47)
        Me.lblminimatchuserwelcome.TabIndex = 7
        Me.lblminimatchuserwelcome.Text = "Welcome William," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Your balance is 1.65BTN"
        '
        'pnlminimatchdodgepagebuy
        '
        Me.pnlminimatchdodgepagebuy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pnlminimatchdodgepagebuy.BackColor = System.Drawing.Color.LightGray
        Me.pnlminimatchdodgepagebuy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlminimatchdodgepagebuy.Controls.Add(Me.txtminimatchbitnoteaddress)
        Me.pnlminimatchdodgepagebuy.Controls.Add(Me.btnminimatchdodgepagebuy)
        Me.pnlminimatchdodgepagebuy.Controls.Add(Me.lblminimatchdodgehow2buydetails)
        Me.pnlminimatchdodgepagebuy.Controls.Add(Me.lblminimatchdodgehow2buy)
        Me.pnlminimatchdodgepagebuy.Location = New System.Drawing.Point(246, 167)
        Me.pnlminimatchdodgepagebuy.Name = "pnlminimatchdodgepagebuy"
        Me.pnlminimatchdodgepagebuy.Size = New System.Drawing.Size(242, 338)
        Me.pnlminimatchdodgepagebuy.TabIndex = 6
        '
        'txtminimatchbitnoteaddress
        '
        Me.txtminimatchbitnoteaddress.Location = New System.Drawing.Point(22, 262)
        Me.txtminimatchbitnoteaddress.Name = "txtminimatchbitnoteaddress"
        Me.txtminimatchbitnoteaddress.Size = New System.Drawing.Size(204, 20)
        Me.txtminimatchbitnoteaddress.TabIndex = 4
        '
        'btnminimatchdodgepagebuy
        '
        Me.btnminimatchdodgepagebuy.BackColor = System.Drawing.Color.Gray
        Me.btnminimatchdodgepagebuy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.btnminimatchdodgepagebuy.ForeColor = System.Drawing.Color.White
        Me.btnminimatchdodgepagebuy.Location = New System.Drawing.Point(5, 310)
        Me.btnminimatchdodgepagebuy.Name = "btnminimatchdodgepagebuy"
        Me.btnminimatchdodgepagebuy.Size = New System.Drawing.Size(232, 21)
        Me.btnminimatchdodgepagebuy.TabIndex = 3
        Me.btnminimatchdodgepagebuy.Text = "Buy for 1.32 BNT"
        Me.btnminimatchdodgepagebuy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblminimatchdodgehow2buydetails
        '
        Me.lblminimatchdodgehow2buydetails.Location = New System.Drawing.Point(23, 62)
        Me.lblminimatchdodgehow2buydetails.Name = "lblminimatchdodgehow2buydetails"
        Me.lblminimatchdodgehow2buydetails.Size = New System.Drawing.Size(203, 193)
        Me.lblminimatchdodgehow2buydetails.TabIndex = 1
        Me.lblminimatchdodgehow2buydetails.Text = resources.GetString("lblminimatchdodgehow2buydetails.Text")
        '
        'lblminimatchdodgehow2buy
        '
        Me.lblminimatchdodgehow2buy.AutoSize = True
        Me.lblminimatchdodgehow2buy.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblminimatchdodgehow2buy.Location = New System.Drawing.Point(36, 20)
        Me.lblminimatchdodgehow2buy.Name = "lblminimatchdodgehow2buy"
        Me.lblminimatchdodgehow2buy.Size = New System.Drawing.Size(169, 31)
        Me.lblminimatchdodgehow2buy.TabIndex = 0
        Me.lblminimatchdodgehow2buy.Text = "How to buy:"
        '
        'picminimatchdodgepreview
        '
        Me.picminimatchdodgepreview.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picminimatchdodgepreview.Image = Global.ShiftOS.My.Resources.Resources.minimatchdodgepreviewimage
        Me.picminimatchdodgepreview.Location = New System.Drawing.Point(-38, 167)
        Me.picminimatchdodgepreview.Name = "picminimatchdodgepreview"
        Me.picminimatchdodgepreview.Size = New System.Drawing.Size(253, 338)
        Me.picminimatchdodgepreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picminimatchdodgepreview.TabIndex = 5
        Me.picminimatchdodgepreview.TabStop = False
        '
        'lblminimatchcopyrightdodgepage
        '
        Me.lblminimatchcopyrightdodgepage.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblminimatchcopyrightdodgepage.AutoSize = True
        Me.lblminimatchcopyrightdodgepage.Location = New System.Drawing.Point(-6, 511)
        Me.lblminimatchcopyrightdodgepage.Name = "lblminimatchcopyrightdodgepage"
        Me.lblminimatchcopyrightdodgepage.Size = New System.Drawing.Size(168, 13)
        Me.lblminimatchcopyrightdodgepage.TabIndex = 4
        Me.lblminimatchcopyrightdodgepage.Text = "Copyright © - Minimatch CO. 2014"
        '
        'pnlminimatchdodgeinfodetails
        '
        Me.pnlminimatchdodgeinfodetails.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pnlminimatchdodgeinfodetails.BackColor = System.Drawing.Color.LightGray
        Me.pnlminimatchdodgeinfodetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlminimatchdodgeinfodetails.Controls.Add(Me.bntminimatchdodgepageback)
        Me.pnlminimatchdodgeinfodetails.Controls.Add(Me.lblminimatchaboutdetails)
        Me.pnlminimatchdodgeinfodetails.Controls.Add(Me.lblminimatchdodgeabout)
        Me.pnlminimatchdodgeinfodetails.Location = New System.Drawing.Point(-305, 167)
        Me.pnlminimatchdodgeinfodetails.Name = "pnlminimatchdodgeinfodetails"
        Me.pnlminimatchdodgeinfodetails.Size = New System.Drawing.Size(242, 338)
        Me.pnlminimatchdodgeinfodetails.TabIndex = 1
        '
        'bntminimatchdodgepageback
        '
        Me.bntminimatchdodgepageback.BackColor = System.Drawing.Color.Gray
        Me.bntminimatchdodgepageback.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.bntminimatchdodgepageback.ForeColor = System.Drawing.Color.White
        Me.bntminimatchdodgepageback.Location = New System.Drawing.Point(5, 310)
        Me.bntminimatchdodgepageback.Name = "bntminimatchdodgepageback"
        Me.bntminimatchdodgepageback.Size = New System.Drawing.Size(232, 21)
        Me.bntminimatchdodgepageback.TabIndex = 4
        Me.bntminimatchdodgepageback.Text = "<- Back"
        Me.bntminimatchdodgepageback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblminimatchaboutdetails
        '
        Me.lblminimatchaboutdetails.Location = New System.Drawing.Point(19, 61)
        Me.lblminimatchaboutdetails.Name = "lblminimatchaboutdetails"
        Me.lblminimatchaboutdetails.Size = New System.Drawing.Size(203, 244)
        Me.lblminimatchaboutdetails.TabIndex = 1
        Me.lblminimatchaboutdetails.Text = resources.GetString("lblminimatchaboutdetails.Text")
        '
        'lblminimatchdodgeabout
        '
        Me.lblminimatchdodgeabout.AutoSize = True
        Me.lblminimatchdodgeabout.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblminimatchdodgeabout.Location = New System.Drawing.Point(24, 17)
        Me.lblminimatchdodgeabout.Name = "lblminimatchdodgeabout"
        Me.lblminimatchdodgeabout.Size = New System.Drawing.Size(192, 31)
        Me.lblminimatchdodgeabout.TabIndex = 0
        Me.lblminimatchdodgeabout.Text = "About Dodge:"
        '
        'picminimatchbtnaccepted
        '
        Me.picminimatchbtnaccepted.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picminimatchbtnaccepted.Image = Global.ShiftOS.My.Resources.Resources.BitnotesAcceptedHereLogo
        Me.picminimatchbtnaccepted.Location = New System.Drawing.Point(-299, 71)
        Me.picminimatchbtnaccepted.Name = "picminimatchbtnaccepted"
        Me.picminimatchbtnaccepted.Size = New System.Drawing.Size(200, 44)
        Me.picminimatchbtnaccepted.TabIndex = 0
        Me.picminimatchbtnaccepted.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox4.BackgroundImage = Global.ShiftOS.My.Resources.Resources.Minimatchbackground
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(-309, 6)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(806, 523)
        Me.PictureBox4.TabIndex = 8
        Me.PictureBox4.TabStop = False
        '
        'pnlshiftomizer
        '
        Me.pnlshiftomizer.Controls.Add(Me.pnlshiftomizerhome)
        Me.pnlshiftomizer.Controls.Add(Me.pnlshiftomizerpayments)
        Me.pnlshiftomizer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlshiftomizer.Location = New System.Drawing.Point(0, 35)
        Me.pnlshiftomizer.Name = "pnlshiftomizer"
        Me.pnlshiftomizer.Size = New System.Drawing.Size(816, 533)
        Me.pnlshiftomizer.TabIndex = 8
        '
        'pnlshiftomizerhome
        '
        Me.pnlshiftomizerhome.Controls.Add(Me.btnshiftomizerhomecheckout)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhomeskinsliderdownload)
        Me.pnlshiftomizerhome.Controls.Add(Me.picshiftomizerhomeappslidernext)
        Me.pnlshiftomizerhome.Controls.Add(Me.picshiftomizerhomeappsliderback)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhomeappdescription)
        Me.pnlshiftomizerhome.Controls.Add(Me.picshiftomizerhomeappsliderimg)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhomeappname)
        Me.pnlshiftomizerhome.Controls.Add(Me.picshiftomizerhomeskinsliderright)
        Me.pnlshiftomizerhome.Controls.Add(Me.picshiftomizerhomeskinssliderleft)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhomeskinname)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhomeappdownload)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhomeskinsliderdescription)
        Me.pnlshiftomizerhome.Controls.Add(Me.picshiftomizerhomeskinsliderimage)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhomedescription)
        Me.pnlshiftomizerhome.Controls.Add(Me.lblshiftomizerhometitle)
        Me.pnlshiftomizerhome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlshiftomizerhome.Location = New System.Drawing.Point(0, 0)
        Me.pnlshiftomizerhome.Name = "pnlshiftomizerhome"
        Me.pnlshiftomizerhome.Size = New System.Drawing.Size(816, 533)
        Me.pnlshiftomizerhome.TabIndex = 9
        '
        'btnshiftomizerhomecheckout
        '
        Me.btnshiftomizerhomecheckout.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnshiftomizerhomecheckout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnshiftomizerhomecheckout.Location = New System.Drawing.Point(731, 6)
        Me.btnshiftomizerhomecheckout.Name = "btnshiftomizerhomecheckout"
        Me.btnshiftomizerhomecheckout.Size = New System.Drawing.Size(75, 23)
        Me.btnshiftomizerhomecheckout.TabIndex = 31
        Me.btnshiftomizerhomecheckout.Text = "Checkout (0) items"
        Me.btnshiftomizerhomecheckout.UseVisualStyleBackColor = True
        '
        'lblshiftomizerhomeskinsliderdownload
        '
        Me.lblshiftomizerhomeskinsliderdownload.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhomeskinsliderdownload.AutoSize = True
        Me.lblshiftomizerhomeskinsliderdownload.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerhomeskinsliderdownload.Location = New System.Drawing.Point(347, 291)
        Me.lblshiftomizerhomeskinsliderdownload.Name = "lblshiftomizerhomeskinsliderdownload"
        Me.lblshiftomizerhomeskinsliderdownload.Size = New System.Drawing.Size(137, 13)
        Me.lblshiftomizerhomeskinsliderdownload.TabIndex = 30
        Me.lblshiftomizerhomeskinsliderdownload.Text = "Download <program name>"
        '
        'picshiftomizerhomeappslidernext
        '
        Me.picshiftomizerhomeappslidernext.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picshiftomizerhomeappslidernext.Image = Global.ShiftOS.My.Resources.Resources.shiftomizersliderrightarrow
        Me.picshiftomizerhomeappslidernext.Location = New System.Drawing.Point(612, 343)
        Me.picshiftomizerhomeappslidernext.Name = "picshiftomizerhomeappslidernext"
        Me.picshiftomizerhomeappslidernext.Size = New System.Drawing.Size(33, 118)
        Me.picshiftomizerhomeappslidernext.TabIndex = 29
        Me.picshiftomizerhomeappslidernext.TabStop = False
        '
        'picshiftomizerhomeappsliderback
        '
        Me.picshiftomizerhomeappsliderback.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picshiftomizerhomeappsliderback.Image = Global.ShiftOS.My.Resources.Resources.shiftomizersliderleftarrow
        Me.picshiftomizerhomeappsliderback.Location = New System.Drawing.Point(171, 343)
        Me.picshiftomizerhomeappsliderback.Name = "picshiftomizerhomeappsliderback"
        Me.picshiftomizerhomeappsliderback.Size = New System.Drawing.Size(33, 118)
        Me.picshiftomizerhomeappsliderback.TabIndex = 28
        Me.picshiftomizerhomeappsliderback.TabStop = False
        '
        'lblshiftomizerhomeappdescription
        '
        Me.lblshiftomizerhomeappdescription.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhomeappdescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerhomeappdescription.Location = New System.Drawing.Point(216, 464)
        Me.lblshiftomizerhomeappdescription.Name = "lblshiftomizerhomeappdescription"
        Me.lblshiftomizerhomeappdescription.Size = New System.Drawing.Size(393, 36)
        Me.lblshiftomizerhomeappdescription.TabIndex = 27
        Me.lblshiftomizerhomeappdescription.Text = "Skin description - changed by code"
        '
        'picshiftomizerhomeappsliderimg
        '
        Me.picshiftomizerhomeappsliderimg.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picshiftomizerhomeappsliderimg.Location = New System.Drawing.Point(213, 343)
        Me.picshiftomizerhomeappsliderimg.Name = "picshiftomizerhomeappsliderimg"
        Me.picshiftomizerhomeappsliderimg.Size = New System.Drawing.Size(393, 118)
        Me.picshiftomizerhomeappsliderimg.TabIndex = 26
        Me.picshiftomizerhomeappsliderimg.TabStop = False
        '
        'lblshiftomizerhomeappname
        '
        Me.lblshiftomizerhomeappname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhomeappname.AutoSize = True
        Me.lblshiftomizerhomeappname.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerhomeappname.Location = New System.Drawing.Point(211, 315)
        Me.lblshiftomizerhomeappname.Name = "lblshiftomizerhomeappname"
        Me.lblshiftomizerhomeappname.Size = New System.Drawing.Size(310, 25)
        Me.lblshiftomizerhomeappname.TabIndex = 25
        Me.lblshiftomizerhomeappname.Text = "Programs - <program name>"
        '
        'picshiftomizerhomeskinsliderright
        '
        Me.picshiftomizerhomeskinsliderright.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picshiftomizerhomeskinsliderright.Image = Global.ShiftOS.My.Resources.Resources.shiftomizersliderrightarrow
        Me.picshiftomizerhomeskinsliderright.Location = New System.Drawing.Point(612, 122)
        Me.picshiftomizerhomeskinsliderright.Name = "picshiftomizerhomeskinsliderright"
        Me.picshiftomizerhomeskinsliderright.Size = New System.Drawing.Size(33, 118)
        Me.picshiftomizerhomeskinsliderright.TabIndex = 24
        Me.picshiftomizerhomeskinsliderright.TabStop = False
        '
        'picshiftomizerhomeskinssliderleft
        '
        Me.picshiftomizerhomeskinssliderleft.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picshiftomizerhomeskinssliderleft.Image = Global.ShiftOS.My.Resources.Resources.shiftomizersliderleftarrow
        Me.picshiftomizerhomeskinssliderleft.Location = New System.Drawing.Point(173, 122)
        Me.picshiftomizerhomeskinssliderleft.Name = "picshiftomizerhomeskinssliderleft"
        Me.picshiftomizerhomeskinssliderleft.Size = New System.Drawing.Size(33, 118)
        Me.picshiftomizerhomeskinssliderleft.TabIndex = 23
        Me.picshiftomizerhomeskinssliderleft.TabStop = False
        '
        'lblshiftomizerhomeskinname
        '
        Me.lblshiftomizerhomeskinname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhomeskinname.AutoSize = True
        Me.lblshiftomizerhomeskinname.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerhomeskinname.Location = New System.Drawing.Point(211, 97)
        Me.lblshiftomizerhomeskinname.Name = "lblshiftomizerhomeskinname"
        Me.lblshiftomizerhomeskinname.Size = New System.Drawing.Size(231, 25)
        Me.lblshiftomizerhomeskinname.TabIndex = 22
        Me.lblshiftomizerhomeskinname.Text = "Skins - <Skin Name>"
        '
        'lblshiftomizerhomeappdownload
        '
        Me.lblshiftomizerhomeappdownload.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhomeappdownload.AutoSize = True
        Me.lblshiftomizerhomeappdownload.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerhomeappdownload.Location = New System.Drawing.Point(347, 506)
        Me.lblshiftomizerhomeappdownload.Name = "lblshiftomizerhomeappdownload"
        Me.lblshiftomizerhomeappdownload.Size = New System.Drawing.Size(137, 13)
        Me.lblshiftomizerhomeappdownload.TabIndex = 21
        Me.lblshiftomizerhomeappdownload.Text = "Download <program name>"
        '
        'lblshiftomizerhomeskinsliderdescription
        '
        Me.lblshiftomizerhomeskinsliderdescription.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhomeskinsliderdescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerhomeskinsliderdescription.Location = New System.Drawing.Point(213, 244)
        Me.lblshiftomizerhomeskinsliderdescription.Name = "lblshiftomizerhomeskinsliderdescription"
        Me.lblshiftomizerhomeskinsliderdescription.Size = New System.Drawing.Size(393, 36)
        Me.lblshiftomizerhomeskinsliderdescription.TabIndex = 20
        Me.lblshiftomizerhomeskinsliderdescription.Text = "Skin description - changed by code"
        '
        'picshiftomizerhomeskinsliderimage
        '
        Me.picshiftomizerhomeskinsliderimage.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picshiftomizerhomeskinsliderimage.Image = Global.ShiftOS.My.Resources.Resources.shiftomizerlinuxmintskinpreview
        Me.picshiftomizerhomeskinsliderimage.Location = New System.Drawing.Point(212, 122)
        Me.picshiftomizerhomeskinsliderimage.Name = "picshiftomizerhomeskinsliderimage"
        Me.picshiftomizerhomeskinsliderimage.Size = New System.Drawing.Size(393, 118)
        Me.picshiftomizerhomeskinsliderimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picshiftomizerhomeskinsliderimage.TabIndex = 19
        Me.picshiftomizerhomeskinsliderimage.TabStop = False
        '
        'lblshiftomizerhomedescription
        '
        Me.lblshiftomizerhomedescription.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhomedescription.AutoSize = True
        Me.lblshiftomizerhomedescription.Location = New System.Drawing.Point(209, 58)
        Me.lblshiftomizerhomedescription.Name = "lblshiftomizerhomedescription"
        Me.lblshiftomizerhomedescription.Size = New System.Drawing.Size(334, 26)
        Me.lblshiftomizerhomedescription.TabIndex = 18
        Me.lblshiftomizerhomedescription.Text = "Here you can find epic skins, and some modifications to your ShiftOS." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "You can se" & _
    "e some of our best skins below"
        '
        'lblshiftomizerhometitle
        '
        Me.lblshiftomizerhometitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerhometitle.AutoSize = True
        Me.lblshiftomizerhometitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerhometitle.Location = New System.Drawing.Point(209, 13)
        Me.lblshiftomizerhometitle.Name = "lblshiftomizerhometitle"
        Me.lblshiftomizerhometitle.Size = New System.Drawing.Size(408, 37)
        Me.lblshiftomizerhometitle.TabIndex = 17
        Me.lblshiftomizerhometitle.Text = "Welcome to the Shiftomizer"
        '
        'pnlshiftomizerpayments
        '
        Me.pnlshiftomizerpayments.Controls.Add(Me.lblshiftomizerpaymentsclear)
        Me.pnlshiftomizerpayments.Controls.Add(Me.lblshiftomizerpaymentsback)
        Me.pnlshiftomizerpayments.Controls.Add(Me.lblshiftomizerpaymentinstruct)
        Me.pnlshiftomizerpayments.Controls.Add(Me.lblshiftomizerpaymentorder)
        Me.pnlshiftomizerpayments.Controls.Add(Me.lblshiftomizerpaymentstitle)
        Me.pnlshiftomizerpayments.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlshiftomizerpayments.Location = New System.Drawing.Point(0, 0)
        Me.pnlshiftomizerpayments.Name = "pnlshiftomizerpayments"
        Me.pnlshiftomizerpayments.Size = New System.Drawing.Size(816, 533)
        Me.pnlshiftomizerpayments.TabIndex = 10
        '
        'lblshiftomizerpaymentsclear
        '
        Me.lblshiftomizerpaymentsclear.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerpaymentsclear.AutoSize = True
        Me.lblshiftomizerpaymentsclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerpaymentsclear.Location = New System.Drawing.Point(373, 507)
        Me.lblshiftomizerpaymentsclear.Name = "lblshiftomizerpaymentsclear"
        Me.lblshiftomizerpaymentsclear.Size = New System.Drawing.Size(96, 13)
        Me.lblshiftomizerpaymentsclear.TabIndex = 21
        Me.lblshiftomizerpaymentsclear.Text = "Clear all purchases"
        '
        'lblshiftomizerpaymentsback
        '
        Me.lblshiftomizerpaymentsback.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerpaymentsback.AutoSize = True
        Me.lblshiftomizerpaymentsback.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerpaymentsback.Location = New System.Drawing.Point(224, 506)
        Me.lblshiftomizerpaymentsback.Name = "lblshiftomizerpaymentsback"
        Me.lblshiftomizerpaymentsback.Size = New System.Drawing.Size(41, 13)
        Me.lblshiftomizerpaymentsback.TabIndex = 20
        Me.lblshiftomizerpaymentsback.Text = "< Back"
        '
        'lblshiftomizerpaymentinstruct
        '
        Me.lblshiftomizerpaymentinstruct.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerpaymentinstruct.Location = New System.Drawing.Point(226, 370)
        Me.lblshiftomizerpaymentinstruct.Name = "lblshiftomizerpaymentinstruct"
        Me.lblshiftomizerpaymentinstruct.Size = New System.Drawing.Size(318, 122)
        Me.lblshiftomizerpaymentinstruct.TabIndex = 19
        Me.lblshiftomizerpaymentinstruct.Text = resources.GetString("lblshiftomizerpaymentinstruct.Text")
        '
        'lblshiftomizerpaymentorder
        '
        Me.lblshiftomizerpaymentorder.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerpaymentorder.AutoSize = True
        Me.lblshiftomizerpaymentorder.Location = New System.Drawing.Point(224, 56)
        Me.lblshiftomizerpaymentorder.Name = "lblshiftomizerpaymentorder"
        Me.lblshiftomizerpaymentorder.Size = New System.Drawing.Size(150, 78)
        Me.lblshiftomizerpaymentorder.TabIndex = 18
        Me.lblshiftomizerpaymentorder.Text = "Order details:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "1x   Icon Manager   2 BTN" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "1x   Name Changer    1.5 BTN" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Tota" & _
    "l: 3.5 BTN"
        '
        'lblshiftomizerpaymentstitle
        '
        Me.lblshiftomizerpaymentstitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblshiftomizerpaymentstitle.AutoSize = True
        Me.lblshiftomizerpaymentstitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftomizerpaymentstitle.Location = New System.Drawing.Point(224, 11)
        Me.lblshiftomizerpaymentstitle.Name = "lblshiftomizerpaymentstitle"
        Me.lblshiftomizerpaymentstitle.Size = New System.Drawing.Size(327, 37)
        Me.lblshiftomizerpaymentstitle.TabIndex = 17
        Me.lblshiftomizerpaymentstitle.Text = "Shiftomizer Payments"
        '
        'pnlbitnotemainpage
        '
        Me.pnlbitnotemainpage.AutoScroll = True
        Me.pnlbitnotemainpage.BackColor = System.Drawing.Color.White
        Me.pnlbitnotemainpage.Controls.Add(Me.pnlbitnotedigger)
        Me.pnlbitnotemainpage.Controls.Add(Me.pnlbitnotecurrencyexchange)
        Me.pnlbitnotemainpage.Controls.Add(Me.pnlbitnotebuywallet)
        Me.pnlbitnotemainpage.Controls.Add(Me.pnlbitnotehome)
        Me.pnlbitnotemainpage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlbitnotemainpage.Location = New System.Drawing.Point(0, 35)
        Me.pnlbitnotemainpage.Name = "pnlbitnotemainpage"
        Me.pnlbitnotemainpage.Size = New System.Drawing.Size(816, 533)
        Me.pnlbitnotemainpage.TabIndex = 10
        Me.pnlbitnotemainpage.Visible = False
        '
        'pnlbitnotedigger
        '
        Me.pnlbitnotedigger.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.pnlbitnotedigger.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlbitnotedigger.Controls.Add(Me.btnbitnotediggergrade5buy)
        Me.pnlbitnotedigger.Controls.Add(Me.btnbitnotediggergrade4buy)
        Me.pnlbitnotedigger.Controls.Add(Me.btnbitnotediggergrade3buy)
        Me.pnlbitnotedigger.Controls.Add(Me.btnbitnotediggergrade2buy)
        Me.pnlbitnotedigger.Controls.Add(Me.btnbitnotediggergrade1buy)
        Me.pnlbitnotedigger.Controls.Add(Me.PictureBox1)
        Me.pnlbitnotedigger.Controls.Add(Me.pnlbitnotediggerfooter)
        Me.pnlbitnotedigger.Controls.Add(Me.pnlbitnotediggersideright)
        Me.pnlbitnotedigger.Controls.Add(Me.pnlbitnotediggersideleft)
        Me.pnlbitnotedigger.Controls.Add(Me.lblbitnotediggerdescription)
        Me.pnlbitnotedigger.Controls.Add(Me.lblbitnotediggertitle)
        Me.pnlbitnotedigger.Controls.Add(Me.picbitnotediggertitlelogo)
        Me.pnlbitnotedigger.Location = New System.Drawing.Point(0, 0)
        Me.pnlbitnotedigger.Name = "pnlbitnotedigger"
        Me.pnlbitnotedigger.Size = New System.Drawing.Size(816, 533)
        Me.pnlbitnotedigger.TabIndex = 3
        '
        'btnbitnotediggergrade5buy
        '
        Me.btnbitnotediggergrade5buy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnbitnotediggergrade5buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbitnotediggergrade5buy.Location = New System.Drawing.Point(586, 427)
        Me.btnbitnotediggergrade5buy.Name = "btnbitnotediggergrade5buy"
        Me.btnbitnotediggergrade5buy.Size = New System.Drawing.Size(75, 23)
        Me.btnbitnotediggergrade5buy.TabIndex = 13
        Me.btnbitnotediggergrade5buy.Text = "35 BTN"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.btnbitnotediggergrade5buy, "app://bitnotedigger:setgrade5")
        Me.btnbitnotediggergrade5buy.UseVisualStyleBackColor = True
        '
        'btnbitnotediggergrade4buy
        '
        Me.btnbitnotediggergrade4buy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnbitnotediggergrade4buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbitnotediggergrade4buy.Location = New System.Drawing.Point(470, 427)
        Me.btnbitnotediggergrade4buy.Name = "btnbitnotediggergrade4buy"
        Me.btnbitnotediggergrade4buy.Size = New System.Drawing.Size(75, 23)
        Me.btnbitnotediggergrade4buy.TabIndex = 12
        Me.btnbitnotediggergrade4buy.Text = "20 BTN"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.btnbitnotediggergrade4buy, "app://bitnotedigger:setgrade4")
        Me.btnbitnotediggergrade4buy.UseVisualStyleBackColor = True
        '
        'btnbitnotediggergrade3buy
        '
        Me.btnbitnotediggergrade3buy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnbitnotediggergrade3buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbitnotediggergrade3buy.Location = New System.Drawing.Point(363, 427)
        Me.btnbitnotediggergrade3buy.Name = "btnbitnotediggergrade3buy"
        Me.btnbitnotediggergrade3buy.Size = New System.Drawing.Size(75, 23)
        Me.btnbitnotediggergrade3buy.TabIndex = 11
        Me.btnbitnotediggergrade3buy.Text = "10 BTN"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.btnbitnotediggergrade3buy, "app://bitnotedigger:setgrade3")
        Me.btnbitnotediggergrade3buy.UseVisualStyleBackColor = True
        '
        'btnbitnotediggergrade2buy
        '
        Me.btnbitnotediggergrade2buy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnbitnotediggergrade2buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbitnotediggergrade2buy.Location = New System.Drawing.Point(254, 427)
        Me.btnbitnotediggergrade2buy.Name = "btnbitnotediggergrade2buy"
        Me.btnbitnotediggergrade2buy.Size = New System.Drawing.Size(75, 23)
        Me.btnbitnotediggergrade2buy.TabIndex = 10
        Me.btnbitnotediggergrade2buy.Text = "5 BTN"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.btnbitnotediggergrade2buy, "app://bitnotedigger:setgrade2")
        Me.btnbitnotediggergrade2buy.UseVisualStyleBackColor = True
        '
        'btnbitnotediggergrade1buy
        '
        Me.btnbitnotediggergrade1buy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnbitnotediggergrade1buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbitnotediggergrade1buy.Location = New System.Drawing.Point(139, 427)
        Me.btnbitnotediggergrade1buy.Name = "btnbitnotediggergrade1buy"
        Me.btnbitnotediggergrade1buy.Size = New System.Drawing.Size(75, 23)
        Me.btnbitnotediggergrade1buy.TabIndex = 9
        Me.btnbitnotediggergrade1buy.Text = "Free"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.btnbitnotediggergrade1buy, "shiftnet.main.bitnote/filetrans.dwnld?file=BitnoteDigger.stp")
        Me.btnbitnotediggergrade1buy.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox1.Image = Global.ShiftOS.My.Resources.Resources.bitnotediggergradetable
        Me.PictureBox1.Location = New System.Drawing.Point(126, 238)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(554, 190)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'pnlbitnotediggerfooter
        '
        Me.pnlbitnotediggerfooter.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotediggerfooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfooterhomelink)
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfootercopyright)
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfootergetlink)
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfooterdiggerlink)
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfooterwalletlink)
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfootergettitle)
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfooterdownloadstitle)
        Me.pnlbitnotediggerfooter.Controls.Add(Me.lblbitnotediggerfooterabouttitle)
        Me.pnlbitnotediggerfooter.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlbitnotediggerfooter.Location = New System.Drawing.Point(100, 453)
        Me.pnlbitnotediggerfooter.Name = "pnlbitnotediggerfooter"
        Me.pnlbitnotediggerfooter.Size = New System.Drawing.Size(616, 80)
        Me.pnlbitnotediggerfooter.TabIndex = 7
        '
        'lblbitnotediggerfooterhomelink
        '
        Me.lblbitnotediggerfooterhomelink.AutoSize = True
        Me.lblbitnotediggerfooterhomelink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfooterhomelink.Location = New System.Drawing.Point(29, 27)
        Me.lblbitnotediggerfooterhomelink.Name = "lblbitnotediggerfooterhomelink"
        Me.lblbitnotediggerfooterhomelink.Size = New System.Drawing.Size(35, 13)
        Me.lblbitnotediggerfooterhomelink.TabIndex = 7
        Me.lblbitnotediggerfooterhomelink.Text = "Home"
        '
        'lblbitnotediggerfootercopyright
        '
        Me.lblbitnotediggerfootercopyright.AutoSize = True
        Me.lblbitnotediggerfootercopyright.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfootercopyright.Location = New System.Drawing.Point(438, 60)
        Me.lblbitnotediggerfootercopyright.Name = "lblbitnotediggerfootercopyright"
        Me.lblbitnotediggerfootercopyright.Size = New System.Drawing.Size(174, 16)
        Me.lblbitnotediggerfootercopyright.TabIndex = 6
        Me.lblbitnotediggerfootercopyright.Text = "Copyright © Bitnote inc. 2014"
        '
        'lblbitnotediggerfootergetlink
        '
        Me.lblbitnotediggerfootergetlink.AutoSize = True
        Me.lblbitnotediggerfootergetlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfootergetlink.Location = New System.Drawing.Point(337, 28)
        Me.lblbitnotediggerfootergetlink.Name = "lblbitnotediggerfootergetlink"
        Me.lblbitnotediggerfootergetlink.Size = New System.Drawing.Size(100, 13)
        Me.lblbitnotediggerfootergetlink.TabIndex = 5
        Me.lblbitnotediggerfootergetlink.Text = "Currency Exchange"
        '
        'lblbitnotediggerfooterdiggerlink
        '
        Me.lblbitnotediggerfooterdiggerlink.AutoSize = True
        Me.lblbitnotediggerfooterdiggerlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfooterdiggerlink.Location = New System.Drawing.Point(168, 52)
        Me.lblbitnotediggerfooterdiggerlink.Name = "lblbitnotediggerfooterdiggerlink"
        Me.lblbitnotediggerfooterdiggerlink.Size = New System.Drawing.Size(38, 13)
        Me.lblbitnotediggerfooterdiggerlink.TabIndex = 4
        Me.lblbitnotediggerfooterdiggerlink.Text = "Digger"
        '
        'lblbitnotediggerfooterwalletlink
        '
        Me.lblbitnotediggerfooterwalletlink.AutoSize = True
        Me.lblbitnotediggerfooterwalletlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfooterwalletlink.Location = New System.Drawing.Point(168, 30)
        Me.lblbitnotediggerfooterwalletlink.Name = "lblbitnotediggerfooterwalletlink"
        Me.lblbitnotediggerfooterwalletlink.Size = New System.Drawing.Size(37, 13)
        Me.lblbitnotediggerfooterwalletlink.TabIndex = 3
        Me.lblbitnotediggerfooterwalletlink.Text = "Wallet"
        '
        'lblbitnotediggerfootergettitle
        '
        Me.lblbitnotediggerfootergettitle.AutoSize = True
        Me.lblbitnotediggerfootergettitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfootergettitle.Location = New System.Drawing.Point(314, 5)
        Me.lblbitnotediggerfootergettitle.Name = "lblbitnotediggerfootergettitle"
        Me.lblbitnotediggerfootergettitle.Size = New System.Drawing.Size(89, 13)
        Me.lblbitnotediggerfootergettitle.TabIndex = 2
        Me.lblbitnotediggerfootergettitle.Text = "GET BITNOTES:"
        '
        'lblbitnotediggerfooterdownloadstitle
        '
        Me.lblbitnotediggerfooterdownloadstitle.AutoSize = True
        Me.lblbitnotediggerfooterdownloadstitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfooterdownloadstitle.Location = New System.Drawing.Point(151, 7)
        Me.lblbitnotediggerfooterdownloadstitle.Name = "lblbitnotediggerfooterdownloadstitle"
        Me.lblbitnotediggerfooterdownloadstitle.Size = New System.Drawing.Size(81, 13)
        Me.lblbitnotediggerfooterdownloadstitle.TabIndex = 1
        Me.lblbitnotediggerfooterdownloadstitle.Text = "DOWNLOADS:"
        '
        'lblbitnotediggerfooterabouttitle
        '
        Me.lblbitnotediggerfooterabouttitle.AutoSize = True
        Me.lblbitnotediggerfooterabouttitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggerfooterabouttitle.Location = New System.Drawing.Point(22, 7)
        Me.lblbitnotediggerfooterabouttitle.Name = "lblbitnotediggerfooterabouttitle"
        Me.lblbitnotediggerfooterabouttitle.Size = New System.Drawing.Size(44, 13)
        Me.lblbitnotediggerfooterabouttitle.TabIndex = 0
        Me.lblbitnotediggerfooterabouttitle.Text = "ABOUT"
        '
        'pnlbitnotediggersideright
        '
        Me.pnlbitnotediggersideright.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotediggersideright.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotediggersideright.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotediggersideright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlbitnotediggersideright.Location = New System.Drawing.Point(716, 0)
        Me.pnlbitnotediggersideright.Name = "pnlbitnotediggersideright"
        Me.pnlbitnotediggersideright.Size = New System.Drawing.Size(100, 533)
        Me.pnlbitnotediggersideright.TabIndex = 6
        '
        'pnlbitnotediggersideleft
        '
        Me.pnlbitnotediggersideleft.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotediggersideleft.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotediggersideleft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotediggersideleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlbitnotediggersideleft.Location = New System.Drawing.Point(0, 0)
        Me.pnlbitnotediggersideleft.Name = "pnlbitnotediggersideleft"
        Me.pnlbitnotediggersideleft.Size = New System.Drawing.Size(100, 533)
        Me.pnlbitnotediggersideleft.TabIndex = 5
        '
        'lblbitnotediggerdescription
        '
        Me.lblbitnotediggerdescription.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotediggerdescription.Location = New System.Drawing.Point(119, 195)
        Me.lblbitnotediggerdescription.Name = "lblbitnotediggerdescription"
        Me.lblbitnotediggerdescription.Size = New System.Drawing.Size(575, 43)
        Me.lblbitnotediggerdescription.TabIndex = 2
        Me.lblbitnotediggerdescription.Text = resources.GetString("lblbitnotediggerdescription.Text")
        '
        'lblbitnotediggertitle
        '
        Me.lblbitnotediggertitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotediggertitle.AutoSize = True
        Me.lblbitnotediggertitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotediggertitle.Location = New System.Drawing.Point(250, 168)
        Me.lblbitnotediggertitle.Name = "lblbitnotediggertitle"
        Me.lblbitnotediggertitle.Size = New System.Drawing.Size(291, 29)
        Me.lblbitnotediggertitle.TabIndex = 1
        Me.lblbitnotediggertitle.Text = "THE BITNOTE DIGGER"
        '
        'picbitnotediggertitlelogo
        '
        Me.picbitnotediggertitlelogo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picbitnotediggertitlelogo.Image = Global.ShiftOS.My.Resources.Resources.bitnotewebsitetitle
        Me.picbitnotediggertitlelogo.Location = New System.Drawing.Point(108, 15)
        Me.picbitnotediggertitlelogo.Name = "picbitnotediggertitlelogo"
        Me.picbitnotediggertitlelogo.Size = New System.Drawing.Size(600, 150)
        Me.picbitnotediggertitlelogo.TabIndex = 0
        Me.picbitnotediggertitlelogo.TabStop = False
        '
        'pnlbitnotecurrencyexchange
        '
        Me.pnlbitnotecurrencyexchange.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.btnbitnotecurrencyexchangebuy)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.txtbitnotecurrencyexchangebitnoteamout)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.lblbitnotecurrencyexchangeprice)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.lblbitnotecurrencyexchangebuytitle)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.lblbitnotecurrencyexchangetodaysrate)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.pnlbitnotecurrencyexchangefooter)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.pnlbitnotecurrencyexchangerightside)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.pnlbitnotecurrencyexchangeleftside)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.lblbitnotecurrencyexchangedescription)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.lblbitnotecurrencyexchangetitle)
        Me.pnlbitnotecurrencyexchange.Controls.Add(Me.picbitnotecurrencyexchangetitle)
        Me.pnlbitnotecurrencyexchange.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlbitnotecurrencyexchange.Location = New System.Drawing.Point(0, 0)
        Me.pnlbitnotecurrencyexchange.Name = "pnlbitnotecurrencyexchange"
        Me.pnlbitnotecurrencyexchange.Size = New System.Drawing.Size(816, 533)
        Me.pnlbitnotecurrencyexchange.TabIndex = 4
        '
        'btnbitnotecurrencyexchangebuy
        '
        Me.btnbitnotecurrencyexchangebuy.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnbitnotecurrencyexchangebuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbitnotecurrencyexchangebuy.Location = New System.Drawing.Point(292, 342)
        Me.btnbitnotecurrencyexchangebuy.Name = "btnbitnotecurrencyexchangebuy"
        Me.btnbitnotecurrencyexchangebuy.Size = New System.Drawing.Size(202, 23)
        Me.btnbitnotecurrencyexchangebuy.TabIndex = 12
        Me.btnbitnotecurrencyexchangebuy.Text = "Purchase"
        Me.btnbitnotecurrencyexchangebuy.UseVisualStyleBackColor = True
        '
        'txtbitnotecurrencyexchangebitnoteamout
        '
        Me.txtbitnotecurrencyexchangebitnoteamout.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtbitnotecurrencyexchangebitnoteamout.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbitnotecurrencyexchangebitnoteamout.Location = New System.Drawing.Point(318, 317)
        Me.txtbitnotecurrencyexchangebitnoteamout.Name = "txtbitnotecurrencyexchangebitnoteamout"
        Me.txtbitnotecurrencyexchangebitnoteamout.Size = New System.Drawing.Size(100, 20)
        Me.txtbitnotecurrencyexchangebitnoteamout.TabIndex = 11
        Me.txtbitnotecurrencyexchangebitnoteamout.Text = "1"
        Me.txtbitnotecurrencyexchangebitnoteamout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblbitnotecurrencyexchangeprice
        '
        Me.lblbitnotecurrencyexchangeprice.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotecurrencyexchangeprice.AutoSize = True
        Me.lblbitnotecurrencyexchangeprice.Location = New System.Drawing.Point(421, 320)
        Me.lblbitnotecurrencyexchangeprice.Name = "lblbitnotecurrencyexchangeprice"
        Me.lblbitnotecurrencyexchangeprice.Size = New System.Drawing.Size(76, 13)
        Me.lblbitnotecurrencyexchangeprice.TabIndex = 10
        Me.lblbitnotecurrencyexchangeprice.Text = "BTN for 22 CP"
        '
        'lblbitnotecurrencyexchangebuytitle
        '
        Me.lblbitnotecurrencyexchangebuytitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotecurrencyexchangebuytitle.AutoSize = True
        Me.lblbitnotecurrencyexchangebuytitle.Location = New System.Drawing.Point(289, 320)
        Me.lblbitnotecurrencyexchangebuytitle.Name = "lblbitnotecurrencyexchangebuytitle"
        Me.lblbitnotecurrencyexchangebuytitle.Size = New System.Drawing.Size(25, 13)
        Me.lblbitnotecurrencyexchangebuytitle.TabIndex = 9
        Me.lblbitnotecurrencyexchangebuytitle.Text = "Buy"
        '
        'lblbitnotecurrencyexchangetodaysrate
        '
        Me.lblbitnotecurrencyexchangetodaysrate.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotecurrencyexchangetodaysrate.AutoSize = True
        Me.lblbitnotecurrencyexchangetodaysrate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangetodaysrate.Location = New System.Drawing.Point(271, 269)
        Me.lblbitnotecurrencyexchangetodaysrate.Name = "lblbitnotecurrencyexchangetodaysrate"
        Me.lblbitnotecurrencyexchangetodaysrate.Size = New System.Drawing.Size(257, 13)
        Me.lblbitnotecurrencyexchangetodaysrate.TabIndex = 8
        Me.lblbitnotecurrencyexchangetodaysrate.Text = "Exchange rate for 21st Nov - 1 BTN : 22 CP"
        '
        'pnlbitnotecurrencyexchangefooter
        '
        Me.pnlbitnotecurrencyexchangefooter.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotecurrencyexchangefooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.lblbitnotecurrencyexchangefooterhomelink)
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.lblbitnotecurrencyexchangefootercopyright)
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.lblbitnotecurrencyexchangefootergetlink)
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.lblbitnotecurrencyexchangefooterdiggerlink)
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.lblbitnotecurrencyexchangefooterwalletlink)
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.lblbitnotecurrencyexchangefootergettitle)
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.bitnotecurrencyexchangefooterdownloadstitle)
        Me.pnlbitnotecurrencyexchangefooter.Controls.Add(Me.lblbitnotecurrencyexchangefooterabouttitle)
        Me.pnlbitnotecurrencyexchangefooter.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlbitnotecurrencyexchangefooter.Location = New System.Drawing.Point(100, 453)
        Me.pnlbitnotecurrencyexchangefooter.Name = "pnlbitnotecurrencyexchangefooter"
        Me.pnlbitnotecurrencyexchangefooter.Size = New System.Drawing.Size(616, 80)
        Me.pnlbitnotecurrencyexchangefooter.TabIndex = 7
        '
        'lblbitnotecurrencyexchangefooterhomelink
        '
        Me.lblbitnotecurrencyexchangefooterhomelink.AutoSize = True
        Me.lblbitnotecurrencyexchangefooterhomelink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangefooterhomelink.Location = New System.Drawing.Point(29, 27)
        Me.lblbitnotecurrencyexchangefooterhomelink.Name = "lblbitnotecurrencyexchangefooterhomelink"
        Me.lblbitnotecurrencyexchangefooterhomelink.Size = New System.Drawing.Size(35, 13)
        Me.lblbitnotecurrencyexchangefooterhomelink.TabIndex = 7
        Me.lblbitnotecurrencyexchangefooterhomelink.Text = "Home"
        '
        'lblbitnotecurrencyexchangefootercopyright
        '
        Me.lblbitnotecurrencyexchangefootercopyright.AutoSize = True
        Me.lblbitnotecurrencyexchangefootercopyright.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangefootercopyright.Location = New System.Drawing.Point(438, 60)
        Me.lblbitnotecurrencyexchangefootercopyright.Name = "lblbitnotecurrencyexchangefootercopyright"
        Me.lblbitnotecurrencyexchangefootercopyright.Size = New System.Drawing.Size(174, 16)
        Me.lblbitnotecurrencyexchangefootercopyright.TabIndex = 6
        Me.lblbitnotecurrencyexchangefootercopyright.Text = "Copyright © Bitnote inc. 2014"
        '
        'lblbitnotecurrencyexchangefootergetlink
        '
        Me.lblbitnotecurrencyexchangefootergetlink.AutoSize = True
        Me.lblbitnotecurrencyexchangefootergetlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangefootergetlink.Location = New System.Drawing.Point(337, 28)
        Me.lblbitnotecurrencyexchangefootergetlink.Name = "lblbitnotecurrencyexchangefootergetlink"
        Me.lblbitnotecurrencyexchangefootergetlink.Size = New System.Drawing.Size(100, 13)
        Me.lblbitnotecurrencyexchangefootergetlink.TabIndex = 5
        Me.lblbitnotecurrencyexchangefootergetlink.Text = "Currency Exchange"
        '
        'lblbitnotecurrencyexchangefooterdiggerlink
        '
        Me.lblbitnotecurrencyexchangefooterdiggerlink.AutoSize = True
        Me.lblbitnotecurrencyexchangefooterdiggerlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangefooterdiggerlink.Location = New System.Drawing.Point(168, 52)
        Me.lblbitnotecurrencyexchangefooterdiggerlink.Name = "lblbitnotecurrencyexchangefooterdiggerlink"
        Me.lblbitnotecurrencyexchangefooterdiggerlink.Size = New System.Drawing.Size(38, 13)
        Me.lblbitnotecurrencyexchangefooterdiggerlink.TabIndex = 4
        Me.lblbitnotecurrencyexchangefooterdiggerlink.Text = "Digger"
        '
        'lblbitnotecurrencyexchangefooterwalletlink
        '
        Me.lblbitnotecurrencyexchangefooterwalletlink.AutoSize = True
        Me.lblbitnotecurrencyexchangefooterwalletlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangefooterwalletlink.Location = New System.Drawing.Point(168, 30)
        Me.lblbitnotecurrencyexchangefooterwalletlink.Name = "lblbitnotecurrencyexchangefooterwalletlink"
        Me.lblbitnotecurrencyexchangefooterwalletlink.Size = New System.Drawing.Size(37, 13)
        Me.lblbitnotecurrencyexchangefooterwalletlink.TabIndex = 3
        Me.lblbitnotecurrencyexchangefooterwalletlink.Text = "Wallet"
        '
        'lblbitnotecurrencyexchangefootergettitle
        '
        Me.lblbitnotecurrencyexchangefootergettitle.AutoSize = True
        Me.lblbitnotecurrencyexchangefootergettitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangefootergettitle.Location = New System.Drawing.Point(314, 5)
        Me.lblbitnotecurrencyexchangefootergettitle.Name = "lblbitnotecurrencyexchangefootergettitle"
        Me.lblbitnotecurrencyexchangefootergettitle.Size = New System.Drawing.Size(89, 13)
        Me.lblbitnotecurrencyexchangefootergettitle.TabIndex = 2
        Me.lblbitnotecurrencyexchangefootergettitle.Text = "GET BITNOTES:"
        '
        'bitnotecurrencyexchangefooterdownloadstitle
        '
        Me.bitnotecurrencyexchangefooterdownloadstitle.AutoSize = True
        Me.bitnotecurrencyexchangefooterdownloadstitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bitnotecurrencyexchangefooterdownloadstitle.Location = New System.Drawing.Point(151, 7)
        Me.bitnotecurrencyexchangefooterdownloadstitle.Name = "bitnotecurrencyexchangefooterdownloadstitle"
        Me.bitnotecurrencyexchangefooterdownloadstitle.Size = New System.Drawing.Size(81, 13)
        Me.bitnotecurrencyexchangefooterdownloadstitle.TabIndex = 1
        Me.bitnotecurrencyexchangefooterdownloadstitle.Text = "DOWNLOADS:"
        '
        'lblbitnotecurrencyexchangefooterabouttitle
        '
        Me.lblbitnotecurrencyexchangefooterabouttitle.AutoSize = True
        Me.lblbitnotecurrencyexchangefooterabouttitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangefooterabouttitle.Location = New System.Drawing.Point(22, 7)
        Me.lblbitnotecurrencyexchangefooterabouttitle.Name = "lblbitnotecurrencyexchangefooterabouttitle"
        Me.lblbitnotecurrencyexchangefooterabouttitle.Size = New System.Drawing.Size(44, 13)
        Me.lblbitnotecurrencyexchangefooterabouttitle.TabIndex = 0
        Me.lblbitnotecurrencyexchangefooterabouttitle.Text = "ABOUT"
        '
        'pnlbitnotecurrencyexchangerightside
        '
        Me.pnlbitnotecurrencyexchangerightside.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotecurrencyexchangerightside.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotecurrencyexchangerightside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotecurrencyexchangerightside.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlbitnotecurrencyexchangerightside.Location = New System.Drawing.Point(716, 0)
        Me.pnlbitnotecurrencyexchangerightside.Name = "pnlbitnotecurrencyexchangerightside"
        Me.pnlbitnotecurrencyexchangerightside.Size = New System.Drawing.Size(100, 533)
        Me.pnlbitnotecurrencyexchangerightside.TabIndex = 6
        '
        'pnlbitnotecurrencyexchangeleftside
        '
        Me.pnlbitnotecurrencyexchangeleftside.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotecurrencyexchangeleftside.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotecurrencyexchangeleftside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotecurrencyexchangeleftside.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlbitnotecurrencyexchangeleftside.Location = New System.Drawing.Point(0, 0)
        Me.pnlbitnotecurrencyexchangeleftside.Name = "pnlbitnotecurrencyexchangeleftside"
        Me.pnlbitnotecurrencyexchangeleftside.Size = New System.Drawing.Size(100, 533)
        Me.pnlbitnotecurrencyexchangeleftside.TabIndex = 5
        '
        'lblbitnotecurrencyexchangedescription
        '
        Me.lblbitnotecurrencyexchangedescription.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotecurrencyexchangedescription.Location = New System.Drawing.Point(119, 215)
        Me.lblbitnotecurrencyexchangedescription.Name = "lblbitnotecurrencyexchangedescription"
        Me.lblbitnotecurrencyexchangedescription.Size = New System.Drawing.Size(575, 43)
        Me.lblbitnotecurrencyexchangedescription.TabIndex = 2
        Me.lblbitnotecurrencyexchangedescription.Text = resources.GetString("lblbitnotecurrencyexchangedescription.Text")
        '
        'lblbitnotecurrencyexchangetitle
        '
        Me.lblbitnotecurrencyexchangetitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotecurrencyexchangetitle.AutoSize = True
        Me.lblbitnotecurrencyexchangetitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotecurrencyexchangetitle.Location = New System.Drawing.Point(250, 178)
        Me.lblbitnotecurrencyexchangetitle.Name = "lblbitnotecurrencyexchangetitle"
        Me.lblbitnotecurrencyexchangetitle.Size = New System.Drawing.Size(305, 29)
        Me.lblbitnotecurrencyexchangetitle.TabIndex = 1
        Me.lblbitnotecurrencyexchangetitle.Text = "CURRENCY EXCHANGE"
        '
        'picbitnotecurrencyexchangetitle
        '
        Me.picbitnotecurrencyexchangetitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picbitnotecurrencyexchangetitle.Image = Global.ShiftOS.My.Resources.Resources.bitnotewebsitetitle
        Me.picbitnotecurrencyexchangetitle.Location = New System.Drawing.Point(108, 15)
        Me.picbitnotecurrencyexchangetitle.Name = "picbitnotecurrencyexchangetitle"
        Me.picbitnotecurrencyexchangetitle.Size = New System.Drawing.Size(600, 150)
        Me.picbitnotecurrencyexchangetitle.TabIndex = 0
        Me.picbitnotecurrencyexchangetitle.TabStop = False
        '
        'pnlbitnotebuywallet
        '
        Me.pnlbitnotebuywallet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlbitnotebuywallet.Controls.Add(Me.picbitnotewalletdownloadbtn)
        Me.pnlbitnotebuywallet.Controls.Add(Me.lblbitnotewalletdescription2)
        Me.pnlbitnotebuywallet.Controls.Add(Me.lblbitnotewalletdescription1)
        Me.pnlbitnotebuywallet.Controls.Add(Me.picbitnotewalletpagescreenshot)
        Me.pnlbitnotebuywallet.Controls.Add(Me.pnlbitnotewalletfooter)
        Me.pnlbitnotebuywallet.Controls.Add(Me.pnlbitnotewalletpagerightside)
        Me.pnlbitnotebuywallet.Controls.Add(Me.pnlbitnotewalletpageleftside)
        Me.pnlbitnotebuywallet.Controls.Add(Me.Label21)
        Me.pnlbitnotebuywallet.Controls.Add(Me.picbitnotewalletpagelogo)
        Me.pnlbitnotebuywallet.Location = New System.Drawing.Point(10, 32)
        Me.pnlbitnotebuywallet.Name = "pnlbitnotebuywallet"
        Me.pnlbitnotebuywallet.Size = New System.Drawing.Size(270, 185)
        Me.pnlbitnotebuywallet.TabIndex = 2
        '
        'picbitnotewalletdownloadbtn
        '
        Me.picbitnotewalletdownloadbtn.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picbitnotewalletdownloadbtn.Image = Global.ShiftOS.My.Resources.Resources.bitnotewalletdownload
        Me.picbitnotewalletdownloadbtn.Location = New System.Drawing.Point(17, 374)
        Me.picbitnotewalletdownloadbtn.Name = "picbitnotewalletdownloadbtn"
        Me.picbitnotewalletdownloadbtn.Size = New System.Drawing.Size(200, 50)
        Me.picbitnotewalletdownloadbtn.TabIndex = 11
        Me.picbitnotewalletdownloadbtn.TabStop = False
        '
        'lblbitnotewalletdescription2
        '
        Me.lblbitnotewalletdescription2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotewalletdescription2.Location = New System.Drawing.Point(-166, 335)
        Me.lblbitnotewalletdescription2.Name = "lblbitnotewalletdescription2"
        Me.lblbitnotewalletdescription2.Size = New System.Drawing.Size(603, 36)
        Me.lblbitnotewalletdescription2.TabIndex = 10
        Me.lblbitnotewalletdescription2.Text = "service. You can easily transfer money to family and friends, what's more, it's a" & _
    "bsolutely FREE, download it now and it won't cost you a cent."
        '
        'lblbitnotewalletdescription1
        '
        Me.lblbitnotewalletdescription1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotewalletdescription1.Location = New System.Drawing.Point(266, 222)
        Me.lblbitnotewalletdescription1.Name = "lblbitnotewalletdescription1"
        Me.lblbitnotewalletdescription1.Size = New System.Drawing.Size(170, 107)
        Me.lblbitnotewalletdescription1.TabIndex = 9
        Me.lblbitnotewalletdescription1.Text = resources.GetString("lblbitnotewalletdescription1.Text")
        '
        'picbitnotewalletpagescreenshot
        '
        Me.picbitnotewalletpagescreenshot.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picbitnotewalletpagescreenshot.Image = Global.ShiftOS.My.Resources.Resources.bitnotewalletpreviewscreenshot
        Me.picbitnotewalletpagescreenshot.Location = New System.Drawing.Point(-163, 220)
        Me.picbitnotewalletpagescreenshot.Name = "picbitnotewalletpagescreenshot"
        Me.picbitnotewalletpagescreenshot.Size = New System.Drawing.Size(419, 109)
        Me.picbitnotewalletpagescreenshot.TabIndex = 8
        Me.picbitnotewalletpagescreenshot.TabStop = False
        '
        'pnlbitnotewalletfooter
        '
        Me.pnlbitnotewalletfooter.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotewalletfooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletpagefooterhomelink)
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletcopyrighttitle)
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletfootergetlink)
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletdiggerdownloadlink)
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletwalletdownloadlink)
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletpagegettitle)
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletpagedownloadstitle)
        Me.pnlbitnotewalletfooter.Controls.Add(Me.lblbitnotewalletpageabouttitle)
        Me.pnlbitnotewalletfooter.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlbitnotewalletfooter.Location = New System.Drawing.Point(100, 100)
        Me.pnlbitnotewalletfooter.Name = "pnlbitnotewalletfooter"
        Me.pnlbitnotewalletfooter.Size = New System.Drawing.Size(70, 85)
        Me.pnlbitnotewalletfooter.TabIndex = 7
        '
        'lblbitnotewalletpagefooterhomelink
        '
        Me.lblbitnotewalletpagefooterhomelink.AutoSize = True
        Me.lblbitnotewalletpagefooterhomelink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletpagefooterhomelink.Location = New System.Drawing.Point(35, 27)
        Me.lblbitnotewalletpagefooterhomelink.Name = "lblbitnotewalletpagefooterhomelink"
        Me.lblbitnotewalletpagefooterhomelink.Size = New System.Drawing.Size(35, 13)
        Me.lblbitnotewalletpagefooterhomelink.TabIndex = 7
        Me.lblbitnotewalletpagefooterhomelink.Text = "Home"
        '
        'lblbitnotewalletcopyrighttitle
        '
        Me.lblbitnotewalletcopyrighttitle.AutoSize = True
        Me.lblbitnotewalletcopyrighttitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletcopyrighttitle.Location = New System.Drawing.Point(438, 65)
        Me.lblbitnotewalletcopyrighttitle.Name = "lblbitnotewalletcopyrighttitle"
        Me.lblbitnotewalletcopyrighttitle.Size = New System.Drawing.Size(174, 16)
        Me.lblbitnotewalletcopyrighttitle.TabIndex = 6
        Me.lblbitnotewalletcopyrighttitle.Text = "Copyright © Bitnote inc. 2014"
        '
        'lblbitnotewalletfootergetlink
        '
        Me.lblbitnotewalletfootergetlink.AutoSize = True
        Me.lblbitnotewalletfootergetlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletfootergetlink.Location = New System.Drawing.Point(337, 28)
        Me.lblbitnotewalletfootergetlink.Name = "lblbitnotewalletfootergetlink"
        Me.lblbitnotewalletfootergetlink.Size = New System.Drawing.Size(100, 13)
        Me.lblbitnotewalletfootergetlink.TabIndex = 5
        Me.lblbitnotewalletfootergetlink.Text = "Currency Exchange"
        '
        'lblbitnotewalletdiggerdownloadlink
        '
        Me.lblbitnotewalletdiggerdownloadlink.AutoSize = True
        Me.lblbitnotewalletdiggerdownloadlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletdiggerdownloadlink.Location = New System.Drawing.Point(168, 52)
        Me.lblbitnotewalletdiggerdownloadlink.Name = "lblbitnotewalletdiggerdownloadlink"
        Me.lblbitnotewalletdiggerdownloadlink.Size = New System.Drawing.Size(38, 13)
        Me.lblbitnotewalletdiggerdownloadlink.TabIndex = 4
        Me.lblbitnotewalletdiggerdownloadlink.Text = "Digger"
        '
        'lblbitnotewalletwalletdownloadlink
        '
        Me.lblbitnotewalletwalletdownloadlink.AutoSize = True
        Me.lblbitnotewalletwalletdownloadlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletwalletdownloadlink.Location = New System.Drawing.Point(168, 30)
        Me.lblbitnotewalletwalletdownloadlink.Name = "lblbitnotewalletwalletdownloadlink"
        Me.lblbitnotewalletwalletdownloadlink.Size = New System.Drawing.Size(37, 13)
        Me.lblbitnotewalletwalletdownloadlink.TabIndex = 3
        Me.lblbitnotewalletwalletdownloadlink.Text = "Wallet"
        '
        'lblbitnotewalletpagegettitle
        '
        Me.lblbitnotewalletpagegettitle.AutoSize = True
        Me.lblbitnotewalletpagegettitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletpagegettitle.Location = New System.Drawing.Point(314, 5)
        Me.lblbitnotewalletpagegettitle.Name = "lblbitnotewalletpagegettitle"
        Me.lblbitnotewalletpagegettitle.Size = New System.Drawing.Size(89, 13)
        Me.lblbitnotewalletpagegettitle.TabIndex = 2
        Me.lblbitnotewalletpagegettitle.Text = "GET BITNOTES:"
        '
        'lblbitnotewalletpagedownloadstitle
        '
        Me.lblbitnotewalletpagedownloadstitle.AutoSize = True
        Me.lblbitnotewalletpagedownloadstitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletpagedownloadstitle.Location = New System.Drawing.Point(151, 7)
        Me.lblbitnotewalletpagedownloadstitle.Name = "lblbitnotewalletpagedownloadstitle"
        Me.lblbitnotewalletpagedownloadstitle.Size = New System.Drawing.Size(81, 13)
        Me.lblbitnotewalletpagedownloadstitle.TabIndex = 1
        Me.lblbitnotewalletpagedownloadstitle.Text = "DOWNLOADS:"
        '
        'lblbitnotewalletpageabouttitle
        '
        Me.lblbitnotewalletpageabouttitle.AutoSize = True
        Me.lblbitnotewalletpageabouttitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewalletpageabouttitle.Location = New System.Drawing.Point(22, 7)
        Me.lblbitnotewalletpageabouttitle.Name = "lblbitnotewalletpageabouttitle"
        Me.lblbitnotewalletpageabouttitle.Size = New System.Drawing.Size(44, 13)
        Me.lblbitnotewalletpageabouttitle.TabIndex = 0
        Me.lblbitnotewalletpageabouttitle.Text = "ABOUT"
        '
        'pnlbitnotewalletpagerightside
        '
        Me.pnlbitnotewalletpagerightside.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotewalletpagerightside.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotewalletpagerightside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotewalletpagerightside.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlbitnotewalletpagerightside.Location = New System.Drawing.Point(170, 0)
        Me.pnlbitnotewalletpagerightside.Name = "pnlbitnotewalletpagerightside"
        Me.pnlbitnotewalletpagerightside.Size = New System.Drawing.Size(100, 185)
        Me.pnlbitnotewalletpagerightside.TabIndex = 6
        '
        'pnlbitnotewalletpageleftside
        '
        Me.pnlbitnotewalletpageleftside.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotewalletpageleftside.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotewalletpageleftside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotewalletpageleftside.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlbitnotewalletpageleftside.Location = New System.Drawing.Point(0, 0)
        Me.pnlbitnotewalletpageleftside.Name = "pnlbitnotewalletpageleftside"
        Me.pnlbitnotewalletpageleftside.Size = New System.Drawing.Size(100, 185)
        Me.pnlbitnotewalletpageleftside.TabIndex = 5
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(-37, 184)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(294, 29)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "THE BITNOTE WALLET"
        '
        'picbitnotewalletpagelogo
        '
        Me.picbitnotewalletpagelogo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picbitnotewalletpagelogo.Image = Global.ShiftOS.My.Resources.Resources.bitnotewebsitetitle
        Me.picbitnotewalletpagelogo.Location = New System.Drawing.Point(-163, 17)
        Me.picbitnotewalletpagelogo.Name = "picbitnotewalletpagelogo"
        Me.picbitnotewalletpagelogo.Size = New System.Drawing.Size(600, 150)
        Me.picbitnotewalletpagelogo.TabIndex = 0
        Me.picbitnotewalletpagelogo.TabStop = False
        '
        'pnlbitnotehome
        '
        Me.pnlbitnotehome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlbitnotehome.Controls.Add(Me.pnlbitnotehomefooter)
        Me.pnlbitnotehome.Controls.Add(Me.pnlbitnotesideright)
        Me.pnlbitnotehome.Controls.Add(Me.pnlbitnotesideleft)
        Me.pnlbitnotehome.Controls.Add(Me.lblbitnotehowgettxt)
        Me.pnlbitnotehome.Controls.Add(Me.lblbitnotehowgettitle)
        Me.pnlbitnotehome.Controls.Add(Me.lblbitnoteabouttxt)
        Me.pnlbitnotehome.Controls.Add(Me.lblbitnoteabouttitle)
        Me.pnlbitnotehome.Controls.Add(Me.picbitnotewebsitetitle)
        Me.pnlbitnotehome.Location = New System.Drawing.Point(380, 17)
        Me.pnlbitnotehome.Name = "pnlbitnotehome"
        Me.pnlbitnotehome.Size = New System.Drawing.Size(324, 164)
        Me.pnlbitnotehome.TabIndex = 1
        '
        'pnlbitnotehomefooter
        '
        Me.pnlbitnotehomefooter.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotehomefooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomehomebtn)
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomecopyright)
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomefootergetlink)
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomediggerlink)
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomewalletlink)
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomefootergettitle)
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomedownloadlink)
        Me.pnlbitnotehomefooter.Controls.Add(Me.lblbitnotehomeaboutlink)
        Me.pnlbitnotehomefooter.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlbitnotehomefooter.Location = New System.Drawing.Point(100, 79)
        Me.pnlbitnotehomefooter.Name = "pnlbitnotehomefooter"
        Me.pnlbitnotehomefooter.Size = New System.Drawing.Size(124, 85)
        Me.pnlbitnotehomefooter.TabIndex = 7
        '
        'lblbitnotehomehomebtn
        '
        Me.lblbitnotehomehomebtn.AutoSize = True
        Me.lblbitnotehomehomebtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomehomebtn.Location = New System.Drawing.Point(29, 27)
        Me.lblbitnotehomehomebtn.Name = "lblbitnotehomehomebtn"
        Me.lblbitnotehomehomebtn.Size = New System.Drawing.Size(35, 13)
        Me.lblbitnotehomehomebtn.TabIndex = 7
        Me.lblbitnotehomehomebtn.Text = "Home"
        '
        'lblbitnotehomecopyright
        '
        Me.lblbitnotehomecopyright.AutoSize = True
        Me.lblbitnotehomecopyright.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomecopyright.Location = New System.Drawing.Point(438, 65)
        Me.lblbitnotehomecopyright.Name = "lblbitnotehomecopyright"
        Me.lblbitnotehomecopyright.Size = New System.Drawing.Size(174, 16)
        Me.lblbitnotehomecopyright.TabIndex = 6
        Me.lblbitnotehomecopyright.Text = "Copyright © Bitnote inc. 2014"
        '
        'lblbitnotehomefootergetlink
        '
        Me.lblbitnotehomefootergetlink.AutoSize = True
        Me.lblbitnotehomefootergetlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomefootergetlink.Location = New System.Drawing.Point(337, 28)
        Me.lblbitnotehomefootergetlink.Name = "lblbitnotehomefootergetlink"
        Me.lblbitnotehomefootergetlink.Size = New System.Drawing.Size(100, 13)
        Me.lblbitnotehomefootergetlink.TabIndex = 5
        Me.lblbitnotehomefootergetlink.Text = "Currency Exchange"
        '
        'lblbitnotehomediggerlink
        '
        Me.lblbitnotehomediggerlink.AutoSize = True
        Me.lblbitnotehomediggerlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomediggerlink.Location = New System.Drawing.Point(168, 52)
        Me.lblbitnotehomediggerlink.Name = "lblbitnotehomediggerlink"
        Me.lblbitnotehomediggerlink.Size = New System.Drawing.Size(38, 13)
        Me.lblbitnotehomediggerlink.TabIndex = 4
        Me.lblbitnotehomediggerlink.Text = "Digger"
        '
        'lblbitnotehomewalletlink
        '
        Me.lblbitnotehomewalletlink.AutoSize = True
        Me.lblbitnotehomewalletlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomewalletlink.Location = New System.Drawing.Point(168, 30)
        Me.lblbitnotehomewalletlink.Name = "lblbitnotehomewalletlink"
        Me.lblbitnotehomewalletlink.Size = New System.Drawing.Size(37, 13)
        Me.lblbitnotehomewalletlink.TabIndex = 3
        Me.lblbitnotehomewalletlink.Text = "Wallet"
        '
        'lblbitnotehomefootergettitle
        '
        Me.lblbitnotehomefootergettitle.AutoSize = True
        Me.lblbitnotehomefootergettitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomefootergettitle.Location = New System.Drawing.Point(314, 5)
        Me.lblbitnotehomefootergettitle.Name = "lblbitnotehomefootergettitle"
        Me.lblbitnotehomefootergettitle.Size = New System.Drawing.Size(89, 13)
        Me.lblbitnotehomefootergettitle.TabIndex = 2
        Me.lblbitnotehomefootergettitle.Text = "GET BITNOTES:"
        '
        'lblbitnotehomedownloadlink
        '
        Me.lblbitnotehomedownloadlink.AutoSize = True
        Me.lblbitnotehomedownloadlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomedownloadlink.Location = New System.Drawing.Point(151, 7)
        Me.lblbitnotehomedownloadlink.Name = "lblbitnotehomedownloadlink"
        Me.lblbitnotehomedownloadlink.Size = New System.Drawing.Size(81, 13)
        Me.lblbitnotehomedownloadlink.TabIndex = 1
        Me.lblbitnotehomedownloadlink.Text = "DOWNLOADS:"
        '
        'lblbitnotehomeaboutlink
        '
        Me.lblbitnotehomeaboutlink.AutoSize = True
        Me.lblbitnotehomeaboutlink.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehomeaboutlink.Location = New System.Drawing.Point(22, 7)
        Me.lblbitnotehomeaboutlink.Name = "lblbitnotehomeaboutlink"
        Me.lblbitnotehomeaboutlink.Size = New System.Drawing.Size(44, 13)
        Me.lblbitnotehomeaboutlink.TabIndex = 0
        Me.lblbitnotehomeaboutlink.Text = "ABOUT"
        '
        'pnlbitnotesideright
        '
        Me.pnlbitnotesideright.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotesideright.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotesideright.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotesideright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlbitnotesideright.Location = New System.Drawing.Point(224, 0)
        Me.pnlbitnotesideright.Name = "pnlbitnotesideright"
        Me.pnlbitnotesideright.Size = New System.Drawing.Size(100, 164)
        Me.pnlbitnotesideright.TabIndex = 6
        '
        'pnlbitnotesideleft
        '
        Me.pnlbitnotesideleft.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.pnlbitnotesideleft.BackgroundImage = Global.ShiftOS.My.Resources.Resources.bitnoteswebsidepnl
        Me.pnlbitnotesideleft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbitnotesideleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlbitnotesideleft.Location = New System.Drawing.Point(0, 0)
        Me.pnlbitnotesideleft.Name = "pnlbitnotesideleft"
        Me.pnlbitnotesideleft.Size = New System.Drawing.Size(100, 164)
        Me.pnlbitnotesideleft.TabIndex = 5
        '
        'lblbitnotehowgettxt
        '
        Me.lblbitnotehowgettxt.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotehowgettxt.Location = New System.Drawing.Point(-126, 348)
        Me.lblbitnotehowgettxt.Name = "lblbitnotehowgettxt"
        Me.lblbitnotehowgettxt.Size = New System.Drawing.Size(579, 78)
        Me.lblbitnotehowgettxt.TabIndex = 4
        Me.lblbitnotehowgettxt.Text = resources.GetString("lblbitnotehowgettxt.Text")
        '
        'lblbitnotehowgettitle
        '
        Me.lblbitnotehowgettitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnotehowgettitle.AutoSize = True
        Me.lblbitnotehowgettitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotehowgettitle.Location = New System.Drawing.Point(-28, 313)
        Me.lblbitnotehowgettitle.Name = "lblbitnotehowgettitle"
        Me.lblbitnotehowgettitle.Size = New System.Drawing.Size(344, 29)
        Me.lblbitnotehowgettitle.TabIndex = 3
        Me.lblbitnotehowgettitle.Text = "HOW DO I GET BITNOTES?"
        '
        'lblbitnoteabouttxt
        '
        Me.lblbitnoteabouttxt.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnoteabouttxt.Location = New System.Drawing.Point(-127, 234)
        Me.lblbitnoteabouttxt.Name = "lblbitnoteabouttxt"
        Me.lblbitnoteabouttxt.Size = New System.Drawing.Size(575, 53)
        Me.lblbitnoteabouttxt.TabIndex = 2
        Me.lblbitnoteabouttxt.Text = resources.GetString("lblbitnoteabouttxt.Text")
        '
        'lblbitnoteabouttitle
        '
        Me.lblbitnoteabouttitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lblbitnoteabouttitle.AutoSize = True
        Me.lblbitnoteabouttitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnoteabouttitle.Location = New System.Drawing.Point(4, 196)
        Me.lblbitnoteabouttitle.Name = "lblbitnoteabouttitle"
        Me.lblbitnoteabouttitle.Size = New System.Drawing.Size(275, 29)
        Me.lblbitnoteabouttitle.TabIndex = 1
        Me.lblbitnoteabouttitle.Text = "WHAT IS A BITNOTE?"
        '
        'picbitnotewebsitetitle
        '
        Me.picbitnotewebsitetitle.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.picbitnotewebsitetitle.Image = Global.ShiftOS.My.Resources.Resources.bitnotewebsitetitle
        Me.picbitnotewebsitetitle.Location = New System.Drawing.Point(-138, 15)
        Me.picbitnotewebsitetitle.Name = "picbitnotewebsitetitle"
        Me.picbitnotewebsitetitle.Size = New System.Drawing.Size(600, 150)
        Me.picbitnotewebsitetitle.TabIndex = 0
        Me.picbitnotewebsitetitle.TabStop = False
        '
        'pnlshifterhacker
        '
        Me.pnlshifterhacker.AutoScroll = True
        Me.pnlshifterhacker.BackColor = System.Drawing.Color.White
        Me.pnlshifterhacker.Controls.Add(Me.pnlshifterhackerhome)
        Me.pnlshifterhacker.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlshifterhacker.Location = New System.Drawing.Point(0, 35)
        Me.pnlshifterhacker.Name = "pnlshifterhacker"
        Me.pnlshifterhacker.Size = New System.Drawing.Size(816, 533)
        Me.pnlshifterhacker.TabIndex = 18
        Me.pnlshifterhacker.Visible = False
        '
        'pnlshifterhackerhome
        '
        Me.pnlshifterhackerhome.Controls.Add(Me.tbshifterhackerhomefloodgatelink1)
        Me.pnlshifterhackerhome.Controls.Add(Me.TextBox1)
        Me.pnlshifterhackerhome.Controls.Add(Me.tbshifterhackerhomeblogpost1)
        Me.pnlshifterhackerhome.Controls.Add(Me.tbshifterhackerhomefloodgatead)
        Me.pnlshifterhackerhome.Controls.Add(Me.tbshifterhackerhomepostspotwatermark)
        Me.pnlshifterhackerhome.Controls.Add(Me.tbshifterhackerhomeh1)
        Me.pnlshifterhackerhome.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlshifterhackerhome.Location = New System.Drawing.Point(0, 0)
        Me.pnlshifterhackerhome.Name = "pnlshifterhackerhome"
        Me.pnlshifterhackerhome.Size = New System.Drawing.Size(816, 533)
        Me.pnlshifterhackerhome.TabIndex = 4
        '
        'tbshifterhackerhomefloodgatelink1
        '
        Me.tbshifterhackerhomefloodgatelink1.AutoSize = True
        Me.tbshifterhackerhomefloodgatelink1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbshifterhackerhomefloodgatelink1.Location = New System.Drawing.Point(262, 127)
        Me.tbshifterhackerhomefloodgatelink1.Name = "tbshifterhackerhomefloodgatelink1"
        Me.tbshifterhackerhomefloodgatelink1.Size = New System.Drawing.Size(75, 13)
        Me.tbshifterhackerhomefloodgatelink1.TabIndex = 10
        Me.tbshifterhackerhomefloodgatelink1.Text = "FloodGate link"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.tbshifterhackerhomefloodgatelink1, "fgmlink--shiftnet.shifterhacker/hacks/codepointhack.flood")
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Location = New System.Drawing.Point(27, 127)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(239, 13)
        Me.TextBox1.TabIndex = 9
        Me.TextBox1.Text = "shiftnet.shifterhacker/hacks/codepointhack.flood"
        '
        'tbshifterhackerhomeblogpost1
        '
        Me.tbshifterhackerhomeblogpost1.AutoSize = True
        Me.tbshifterhackerhomeblogpost1.Location = New System.Drawing.Point(24, 75)
        Me.tbshifterhackerhomeblogpost1.Name = "tbshifterhackerhomeblogpost1"
        Me.tbshifterhackerhomeblogpost1.Size = New System.Drawing.Size(343, 52)
        Me.tbshifterhackerhomeblogpost1.TabIndex = 8
        Me.tbshifterhackerhomeblogpost1.Text = "10/24/2013" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "First hack released: The bitnote hack." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "This hack will give you 5 bit" & _
    "notes." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Download it by pasting the link below into your preferred flood manager:" & _
    ""
        '
        'tbshifterhackerhomefloodgatead
        '
        Me.tbshifterhackerhomefloodgatead.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbshifterhackerhomefloodgatead.AutoSize = True
        Me.tbshifterhackerhomefloodgatead.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbshifterhackerhomefloodgatead.Location = New System.Drawing.Point(470, 9)
        Me.tbshifterhackerhomefloodgatead.Name = "tbshifterhackerhomefloodgatead"
        Me.tbshifterhackerhomefloodgatead.Size = New System.Drawing.Size(328, 26)
        Me.tbshifterhackerhomefloodgatead.TabIndex = 7
        Me.tbshifterhackerhomefloodgatead.Text = "Install FloodgateManager: The best flood downloader on the shiftnet" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ShiftLinks N" & _
    "etAds"
        '
        'tbshifterhackerhomepostspotwatermark
        '
        Me.tbshifterhackerhomepostspotwatermark.AutoSize = True
        Me.tbshifterhackerhomepostspotwatermark.BackColor = System.Drawing.Color.White
        Me.tbshifterhackerhomepostspotwatermark.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbshifterhackerhomepostspotwatermark.ForeColor = System.Drawing.Color.Gray
        Me.tbshifterhackerhomepostspotwatermark.Location = New System.Drawing.Point(205, 2)
        Me.tbshifterhackerhomepostspotwatermark.Name = "tbshifterhackerhomepostspotwatermark"
        Me.tbshifterhackerhomepostspotwatermark.Size = New System.Drawing.Size(109, 13)
        Me.tbshifterhackerhomepostspotwatermark.TabIndex = 6
        Me.tbshifterhackerhomepostspotwatermark.Text = "Powered by PostSpot"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.tbshifterhackerhomepostspotwatermark, "shiftnet.main.floodgate/filetrans.dwnld?file=FloodGate.stp")
        '
        'tbshifterhackerhomeh1
        '
        Me.tbshifterhackerhomeh1.AutoSize = True
        Me.tbshifterhackerhomeh1.BackColor = System.Drawing.Color.Transparent
        Me.tbshifterhackerhomeh1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbshifterhackerhomeh1.Location = New System.Drawing.Point(20, 11)
        Me.tbshifterhackerhomeh1.Name = "tbshifterhackerhomeh1"
        Me.tbshifterhackerhomeh1.Size = New System.Drawing.Size(291, 37)
        Me.tbshifterhackerhomeh1.TabIndex = 5
        Me.tbshifterhackerhomeh1.Text = "ShifterHacker's site"
        '
        'pnlutilsweb
        '
        Me.pnlutilsweb.Controls.Add(Me.pnlutilswebhome)
        Me.pnlutilsweb.Controls.Add(Me.pnlutilswebbackuputility)
        Me.pnlutilsweb.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlutilsweb.Location = New System.Drawing.Point(0, 35)
        Me.pnlutilsweb.Name = "pnlutilsweb"
        Me.pnlutilsweb.Size = New System.Drawing.Size(816, 533)
        Me.pnlutilsweb.TabIndex = 15
        '
        'pnlutilswebhome
        '
        Me.pnlutilswebhome.Controls.Add(Me.utilswebhomewip)
        Me.pnlutilswebhome.Controls.Add(Me.utilswebvirusscanner)
        Me.pnlutilswebhome.Controls.Add(Me.utilswebbackuputil)
        Me.pnlutilswebhome.Location = New System.Drawing.Point(0, 425)
        Me.pnlutilswebhome.Name = "pnlutilswebhome"
        Me.pnlutilswebhome.Size = New System.Drawing.Size(816, 108)
        Me.pnlutilswebhome.TabIndex = 1
        '
        'utilswebhomewip
        '
        Me.utilswebhomewip.AutoSize = True
        Me.utilswebhomewip.Location = New System.Drawing.Point(276, 49)
        Me.utilswebhomewip.Name = "utilswebhomewip"
        Me.utilswebhomewip.Size = New System.Drawing.Size(90, 13)
        Me.utilswebhomewip.TabIndex = 2
        Me.utilswebhomewip.Text = "Work in progress!"
        '
        'utilswebvirusscanner
        '
        Me.utilswebvirusscanner.AutoSize = True
        Me.utilswebvirusscanner.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.utilswebvirusscanner.Location = New System.Drawing.Point(277, 93)
        Me.utilswebvirusscanner.Name = "utilswebvirusscanner"
        Me.utilswebvirusscanner.Size = New System.Drawing.Size(73, 13)
        Me.utilswebvirusscanner.TabIndex = 1
        Me.utilswebvirusscanner.Text = "Virus Scanner"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.utilswebvirusscanner, "shiftnet.main.utilsweb/virusutil.rnp")
        '
        'utilswebbackuputil
        '
        Me.utilswebbackuputil.AutoSize = True
        Me.utilswebbackuputil.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.utilswebbackuputil.Location = New System.Drawing.Point(277, 70)
        Me.utilswebbackuputil.Name = "utilswebbackuputil"
        Me.utilswebbackuputil.Size = New System.Drawing.Size(72, 13)
        Me.utilswebbackuputil.TabIndex = 0
        Me.utilswebbackuputil.Text = "Backup Utility"
        Me.AllLinksMustHaveATooltipForTheirUrl.SetToolTip(Me.utilswebbackuputil, "shiftnet.main.utilsweb/backuputility.rnp")
        '
        'pnlutilswebbackuputility
        '
        Me.pnlutilswebbackuputility.Controls.Add(Me.lbl_backuputility_soon)
        Me.pnlutilswebbackuputility.Controls.Add(Me.pnlutilswebvirusscan)
        Me.pnlutilswebbackuputility.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlutilswebbackuputility.Location = New System.Drawing.Point(0, 0)
        Me.pnlutilswebbackuputility.Name = "pnlutilswebbackuputility"
        Me.pnlutilswebbackuputility.Size = New System.Drawing.Size(816, 533)
        Me.pnlutilswebbackuputility.TabIndex = 0
        '
        'lbl_backuputility_soon
        '
        Me.lbl_backuputility_soon.AutoSize = True
        Me.lbl_backuputility_soon.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_backuputility_soon.Location = New System.Drawing.Point(313, 93)
        Me.lbl_backuputility_soon.Name = "lbl_backuputility_soon"
        Me.lbl_backuputility_soon.Size = New System.Drawing.Size(106, 16)
        Me.lbl_backuputility_soon.TabIndex = 0
        Me.lbl_backuputility_soon.Text = "COMING SOON!"
        '
        'pnlutilswebvirusscan
        '
        Me.pnlutilswebvirusscan.Location = New System.Drawing.Point(591, 72)
        Me.pnlutilswebvirusscan.Name = "pnlutilswebvirusscan"
        Me.pnlutilswebvirusscan.Size = New System.Drawing.Size(200, 100)
        Me.pnlutilswebvirusscan.TabIndex = 18
        '
        'pnlnotfound
        '
        Me.pnlnotfound.AutoScroll = True
        Me.pnlnotfound.BackColor = System.Drawing.Color.White
        Me.pnlnotfound.Controls.Add(Me.pnlnotfoundsite)
        Me.pnlnotfound.Location = New System.Drawing.Point(282, 55)
        Me.pnlnotfound.Name = "pnlnotfound"
        Me.pnlnotfound.Size = New System.Drawing.Size(139, 122)
        Me.pnlnotfound.TabIndex = 13
        Me.pnlnotfound.Visible = False
        '
        'pnlnotfoundsite
        '
        Me.pnlnotfoundsite.Controls.Add(Me.tbnotfound)
        Me.pnlnotfoundsite.Location = New System.Drawing.Point(27, 67)
        Me.pnlnotfoundsite.Name = "pnlnotfoundsite"
        Me.pnlnotfoundsite.Size = New System.Drawing.Size(789, 466)
        Me.pnlnotfoundsite.TabIndex = 4
        '
        'tbnotfound
        '
        Me.tbnotfound.AutoSize = True
        Me.tbnotfound.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbnotfound.Location = New System.Drawing.Point(4, 3)
        Me.tbnotfound.Name = "tbnotfound"
        Me.tbnotfound.Size = New System.Drawing.Size(420, 37)
        Me.tbnotfound.TabIndex = 3
        Me.tbnotfound.Text = "You should not ever see this"
        '
        'pnlshiftnet
        '
        Me.pnlshiftnet.AutoScroll = True
        Me.pnlshiftnet.BackColor = System.Drawing.Color.White
        Me.pnlshiftnet.Controls.Add(Me.pnlshiftnethome)
        Me.pnlshiftnet.Location = New System.Drawing.Point(27, 358)
        Me.pnlshiftnet.Name = "pnlshiftnet"
        Me.pnlshiftnet.Size = New System.Drawing.Size(135, 91)
        Me.pnlshiftnet.TabIndex = 14
        Me.pnlshiftnet.Visible = False
        '
        'pnlshiftnethome
        '
        Me.pnlshiftnethome.Controls.Add(Me.Label11)
        Me.pnlshiftnethome.Controls.Add(Me.homenetsite)
        Me.pnlshiftnethome.Controls.Add(Me.homedefaultpage)
        Me.pnlshiftnethome.Controls.Add(Me.hometitle)
        Me.pnlshiftnethome.Location = New System.Drawing.Point(27, 35)
        Me.pnlshiftnethome.Name = "pnlshiftnethome"
        Me.pnlshiftnethome.Size = New System.Drawing.Size(789, 498)
        Me.pnlshiftnethome.TabIndex = 4
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(11, 67)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(64, 13)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "ShiftSite 4.2"
        '
        'homenetsite
        '
        Me.homenetsite.AutoSize = True
        Me.homenetsite.Location = New System.Drawing.Point(11, 50)
        Me.homenetsite.Name = "homenetsite"
        Me.homenetsite.Size = New System.Drawing.Size(347, 13)
        Me.homenetsite.TabIndex = 2
        Me.homenetsite.Text = "The web server software is running but no content has been added, yet."
        '
        'homedefaultpage
        '
        Me.homedefaultpage.AutoSize = True
        Me.homedefaultpage.Location = New System.Drawing.Point(10, 37)
        Me.homedefaultpage.Name = "homedefaultpage"
        Me.homedefaultpage.Size = New System.Drawing.Size(205, 13)
        Me.homedefaultpage.TabIndex = 1
        Me.homedefaultpage.Text = "This is the default web page for the server"
        '
        'hometitle
        '
        Me.hometitle.AutoSize = True
        Me.hometitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hometitle.Location = New System.Drawing.Point(3, 2)
        Me.hometitle.Name = "hometitle"
        Me.hometitle.Size = New System.Drawing.Size(136, 37)
        Me.hometitle.TabIndex = 0
        Me.hometitle.Text = "It works!"
        '
        'pnl404
        '
        Me.pnl404.AutoScroll = True
        Me.pnl404.BackColor = System.Drawing.Color.White
        Me.pnl404.Controls.Add(Me.pnl404home)
        Me.pnl404.Location = New System.Drawing.Point(654, 432)
        Me.pnl404.Name = "pnl404"
        Me.pnl404.Size = New System.Drawing.Size(162, 136)
        Me.pnl404.TabIndex = 16
        Me.pnl404.Visible = False
        '
        'pnl404home
        '
        Me.pnl404home.Controls.Add(Me.tb404homenotfound)
        Me.pnl404home.Controls.Add(Me.tb404home404)
        Me.pnl404home.Location = New System.Drawing.Point(44, 14)
        Me.pnl404home.Name = "pnl404home"
        Me.pnl404home.Size = New System.Drawing.Size(772, 519)
        Me.pnl404home.TabIndex = 4
        '
        'tb404homenotfound
        '
        Me.tb404homenotfound.AutoSize = True
        Me.tb404homenotfound.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb404homenotfound.Location = New System.Drawing.Point(8, 35)
        Me.tb404homenotfound.Name = "tb404homenotfound"
        Me.tb404homenotfound.Size = New System.Drawing.Size(509, 15)
        Me.tb404homenotfound.TabIndex = 4
        Me.tb404homenotfound.Text = "The requested page /XYZ.rnp can not be found on our server. Make sure you typed i" & _
    "t correctly" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'tb404home404
        '
        Me.tb404home404.AutoSize = True
        Me.tb404home404.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb404home404.Location = New System.Drawing.Point(4, 3)
        Me.tb404home404.Name = "tb404home404"
        Me.tb404home404.Size = New System.Drawing.Size(71, 37)
        Me.tb404home404.TabIndex = 3
        Me.tb404home404.Text = "404" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.btnhome)
        Me.Panel1.Controls.Add(Me.txtlocation)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(816, 35)
        Me.Panel1.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(23, 6)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(736, 20)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Use the document outline instead of undocking everything (View > Other Windows > " & _
    "Document Outline)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label12.Visible = False
        '
        'btnhome
        '
        Me.btnhome.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnhome.BackColor = System.Drawing.Color.White
        Me.btnhome.BackgroundImage = Global.ShiftOS.My.Resources.Resources.webhome
        Me.btnhome.FlatAppearance.BorderSize = 0
        Me.btnhome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnhome.Location = New System.Drawing.Point(781, 5)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(30, 25)
        Me.btnhome.TabIndex = 10
        Me.btnhome.UseVisualStyleBackColor = False
        '
        'txtlocation
        '
        Me.txtlocation.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtlocation.BackColor = System.Drawing.Color.White
        Me.txtlocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtlocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlocation.Location = New System.Drawing.Point(5, 5)
        Me.txtlocation.Multiline = True
        Me.txtlocation.Name = "txtlocation"
        Me.txtlocation.Size = New System.Drawing.Size(772, 25)
        Me.txtlocation.TabIndex = 9
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Black
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 34)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(816, 1)
        Me.Panel2.TabIndex = 6
        '
        'lbldevdockingwarning
        '
        Me.lbldevdockingwarning.AutoSize = True
        Me.lbldevdockingwarning.Location = New System.Drawing.Point(327, 9)
        Me.lbldevdockingwarning.Name = "lbldevdockingwarning"
        Me.lbldevdockingwarning.Size = New System.Drawing.Size(490, 13)
        Me.lbldevdockingwarning.TabIndex = 18
        Me.lbldevdockingwarning.Text = "Dock all sites inside pgcontants. Don't dock sites inside other sites (this warni" & _
    "ng has visible set to false)"
        Me.lbldevdockingwarning.Visible = False
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 570)
        Me.pgleft.TabIndex = 21
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.lbldevdockingwarning)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(820, 30)
        Me.titlebar.TabIndex = 19
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconTextPad
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'tmrloadsite
        '
        Me.tmrloadsite.Enabled = True
        '
        'tmrshiftomizerwaitinglist
        '
        Me.tmrshiftomizerwaitinglist.Interval = 1000
        '
        'qctext
        '
        '
        'Shiftnet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(1, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(820, 600)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Shiftnet"
        Me.Text = "Shiftnet"
        Me.TopMost = True
        Me.pgright.ResumeLayout(False)
        Me.pgcontents.ResumeLayout(False)
        Me.pnlquickchat.ResumeLayout(False)
        Me.pnlquickchathome.ResumeLayout(False)
        Me.pnlquickchathome.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.pnlquickchatoffline.ResumeLayout(False)
        Me.pnlquickchatoffline.PerformLayout()
        Me.qcpanel.ResumeLayout(False)
        Me.qcpanel.PerformLayout()
        Me.pnlxenonh.ResumeLayout(False)
        Me.pnlxenonhhome.ResumeLayout(False)
        Me.pnlxenonhhome.PerformLayout()
        Me.pnlpostspot.ResumeLayout(False)
        Me.pnlpostspothome.ResumeLayout(False)
        Me.pnlpostspothome.PerformLayout()
        Me.pnlpirateboat.ResumeLayout(False)
        Me.pnlpirateboatmain.ResumeLayout(False)
        Me.pnlpirateboatmain.PerformLayout()
        Me.pnlpirateboatdownlaod.ResumeLayout(False)
        Me.pnlpirateboatdownlaod.PerformLayout()
        Me.pnlhome.ResumeLayout(False)
        Me.pnlhomehome.ResumeLayout(False)
        Me.pnlhomehome.PerformLayout()
        CType(Me.pichomehomeicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlhomehistory.ResumeLayout(False)
        Me.pnlmainsiteappscape.ResumeLayout(False)
        Me.pnlappscapedeposit.ResumeLayout(False)
        Me.pnlappscapedeposit.PerformLayout()
        CType(Me.picappscapedepositeinfobitnotescreenshot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel46.ResumeLayout(False)
        Me.Panel47.ResumeLayout(False)
        Me.appscapehomepage.ResumeLayout(False)
        Me.Panel20.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.pnlappscapeoprcwrite.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel23.ResumeLayout(False)
        Me.appscapewebbrowserinfopage.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel25.ResumeLayout(False)
        Me.appscapevideoplayerinfopage.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.appscapecalculatorinfopage.ResumeLayout(False)
        Me.Panel28.ResumeLayout(False)
        Me.Panel35.ResumeLayout(False)
        Me.appscapeaudioplayerinfopage.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel32.ResumeLayout(False)
        Me.pnlmainsiteminimatch.ResumeLayout(False)
        Me.pnlminimatchlabyrinth.ResumeLayout(False)
        Me.pnlminimatchlabyrinth.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlminimatchhomepage.ResumeLayout(False)
        Me.pnlminimatchhomepage.PerformLayout()
        Me.pnlminimatchcomingsoon2.ResumeLayout(False)
        Me.pnlminimatchcomingsoon2.PerformLayout()
        Me.pnlminimatchcomingsoon.ResumeLayout(False)
        Me.pnlminimatchcomingsoon.PerformLayout()
        Me.pnlminimatchdodgepreview.ResumeLayout(False)
        Me.pnlminimatchdodgepreview.PerformLayout()
        CType(Me.picbitnotesaccepted, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlminimatchdodgeinfopage.ResumeLayout(False)
        Me.pnlminimatchdodgeinfopage.PerformLayout()
        Me.pnlminimatchdodgepagebuy.ResumeLayout(False)
        Me.pnlminimatchdodgepagebuy.PerformLayout()
        CType(Me.picminimatchdodgepreview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlminimatchdodgeinfodetails.ResumeLayout(False)
        Me.pnlminimatchdodgeinfodetails.PerformLayout()
        CType(Me.picminimatchbtnaccepted, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlshiftomizer.ResumeLayout(False)
        Me.pnlshiftomizerhome.ResumeLayout(False)
        Me.pnlshiftomizerhome.PerformLayout()
        CType(Me.picshiftomizerhomeappslidernext, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picshiftomizerhomeappsliderback, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picshiftomizerhomeappsliderimg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picshiftomizerhomeskinsliderright, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picshiftomizerhomeskinssliderleft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picshiftomizerhomeskinsliderimage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlshiftomizerpayments.ResumeLayout(False)
        Me.pnlshiftomizerpayments.PerformLayout()
        Me.pnlbitnotemainpage.ResumeLayout(False)
        Me.pnlbitnotedigger.ResumeLayout(False)
        Me.pnlbitnotedigger.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlbitnotediggerfooter.ResumeLayout(False)
        Me.pnlbitnotediggerfooter.PerformLayout()
        CType(Me.picbitnotediggertitlelogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlbitnotecurrencyexchange.ResumeLayout(False)
        Me.pnlbitnotecurrencyexchange.PerformLayout()
        Me.pnlbitnotecurrencyexchangefooter.ResumeLayout(False)
        Me.pnlbitnotecurrencyexchangefooter.PerformLayout()
        CType(Me.picbitnotecurrencyexchangetitle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlbitnotebuywallet.ResumeLayout(False)
        Me.pnlbitnotebuywallet.PerformLayout()
        CType(Me.picbitnotewalletdownloadbtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbitnotewalletpagescreenshot, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlbitnotewalletfooter.ResumeLayout(False)
        Me.pnlbitnotewalletfooter.PerformLayout()
        CType(Me.picbitnotewalletpagelogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlbitnotehome.ResumeLayout(False)
        Me.pnlbitnotehome.PerformLayout()
        Me.pnlbitnotehomefooter.ResumeLayout(False)
        Me.pnlbitnotehomefooter.PerformLayout()
        CType(Me.picbitnotewebsitetitle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlshifterhacker.ResumeLayout(False)
        Me.pnlshifterhackerhome.ResumeLayout(False)
        Me.pnlshifterhackerhome.PerformLayout()
        Me.pnlutilsweb.ResumeLayout(False)
        Me.pnlutilswebhome.ResumeLayout(False)
        Me.pnlutilswebhome.PerformLayout()
        Me.pnlutilswebbackuputility.ResumeLayout(False)
        Me.pnlutilswebbackuputility.PerformLayout()
        Me.pnlnotfound.ResumeLayout(False)
        Me.pnlnotfoundsite.ResumeLayout(False)
        Me.pnlnotfoundsite.PerformLayout()
        Me.pnlshiftnet.ResumeLayout(False)
        Me.pnlshiftnethome.ResumeLayout(False)
        Me.pnlshiftnethome.PerformLayout()
        Me.pnl404.ResumeLayout(False)
        Me.pnl404home.ResumeLayout(False)
        Me.pnl404home.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pgleft.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pullside As System.Windows.Forms.Timer
    Friend WithEvents pullbs As System.Windows.Forms.Timer
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents pullbottom As System.Windows.Forms.Timer
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnhome As System.Windows.Forms.Button
    Friend WithEvents txtlocation As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents pnlmainsiteappscape As System.Windows.Forms.Panel
    Friend WithEvents appscapehomepage As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents btnaudioplayerinfo As System.Windows.Forms.Panel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents btnbuywebbrowser As System.Windows.Forms.Panel
    Friend WithEvents btnwebbrowserinfo As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents btnbuyvideoplayer As System.Windows.Forms.Panel
    Friend WithEvents btnvideoplayerinfo As System.Windows.Forms.Panel
    Friend WithEvents btnbuyaudioplayer As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents btnbuymoresoftware2 As System.Windows.Forms.Panel
    Friend WithEvents btnmoresoftware2info As System.Windows.Forms.Panel
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents btnbuyorcwrite As System.Windows.Forms.Panel
    Friend WithEvents btnmoresoftware1info As System.Windows.Forms.Panel
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents btnbuycalculator As System.Windows.Forms.Panel
    Friend WithEvents btncalculatorinfo As System.Windows.Forms.Panel
    Friend WithEvents lbappscapehello As System.Windows.Forms.Label
    Friend WithEvents btnappscapedeposit As System.Windows.Forms.Panel
    Friend WithEvents tmrloadsite As System.Windows.Forms.Timer
    Friend WithEvents appscapecalculatorinfopage As System.Windows.Forms.Panel
    Friend WithEvents Panel28 As System.Windows.Forms.Panel
    Friend WithEvents btncalculatorinfobuy As System.Windows.Forms.Panel
    Friend WithEvents btncalculatorinfoback As System.Windows.Forms.Panel
    Friend WithEvents Panel34 As System.Windows.Forms.Panel
    Friend WithEvents Panel35 As System.Windows.Forms.Panel
    Friend WithEvents lbappscapecalculatorinfohello As System.Windows.Forms.Label
    Friend WithEvents appscapecalcinfodepositbtn As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents appscapewebbrowserinfopage As System.Windows.Forms.Panel
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents btnwebbrowserinfobuy As System.Windows.Forms.Panel
    Friend WithEvents btnwebbrowserinfoback As System.Windows.Forms.Panel
    Friend WithEvents Panel24 As System.Windows.Forms.Panel
    Friend WithEvents Panel25 As System.Windows.Forms.Panel
    Friend WithEvents lbappscapewebbroswerinfohello As System.Windows.Forms.Label
    Friend WithEvents appscapewebbrowserinfodepositbtn As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents appscapevideoplayerinfopage As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents btnvideoplayerinfobuy As System.Windows.Forms.Panel
    Friend WithEvents btnvideoplayerinfoback As System.Windows.Forms.Panel
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents lbappscapevideoplayerinfohello As System.Windows.Forms.Label
    Friend WithEvents appscapevideoplayerinfodepositbtn As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents appscapeaudioplayerinfopage As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents btnaudioplayerinfobuy As System.Windows.Forms.Panel
    Friend WithEvents btnaudioplayerinfoback As System.Windows.Forms.Panel
    Friend WithEvents Panel31 As System.Windows.Forms.Panel
    Friend WithEvents Panel32 As System.Windows.Forms.Panel
    Friend WithEvents lbappscapeaudioplayerinfohello As System.Windows.Forms.Label
    Friend WithEvents appscapeaudioplayerinfodepositbtn As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents pnlmainsiteminimatch As System.Windows.Forms.Panel
    Friend WithEvents pnlminimatchhomepage As System.Windows.Forms.Panel
    Friend WithEvents picbitnotesaccepted As System.Windows.Forms.PictureBox
    Friend WithEvents lblminimatchcopyright As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchcomingsoon2 As System.Windows.Forms.Panel
    Friend WithEvents pnlminimatchcomingsoonbuy2 As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchcomingsooninfo2 As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchcomingsoondescription2 As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchcomingsoontitle2 As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchcomingsoon As System.Windows.Forms.Panel
    Friend WithEvents bntminimatchcomingsoonbuy As System.Windows.Forms.Label
    Friend WithEvents bntminimatchcomingsooninfo As System.Windows.Forms.Label
    Friend WithEvents lblminimatchcomingsoondescription As System.Windows.Forms.Label
    Friend WithEvents lblminimatchcomingsoontitle As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchdodgepreview As System.Windows.Forms.Panel
    Friend WithEvents bntminimatchdodgebuy As System.Windows.Forms.Label
    Friend WithEvents bntminimatchdodgeinfo As System.Windows.Forms.Label
    Friend WithEvents lblminimatchdodgedescription As System.Windows.Forms.Label
    Friend WithEvents lblminimatchdodgetitle As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchdodgeinfopage As System.Windows.Forms.Panel
    Friend WithEvents lblminimatchcopyrightdodgepage As System.Windows.Forms.Label
    Friend WithEvents pnlminimatchdodgeinfodetails As System.Windows.Forms.Panel
    Friend WithEvents lblminimatchaboutdetails As System.Windows.Forms.Label
    Friend WithEvents lblminimatchdodgeabout As System.Windows.Forms.Label
    Friend WithEvents picminimatchbtnaccepted As System.Windows.Forms.PictureBox
    Friend WithEvents picminimatchdodgepreview As System.Windows.Forms.PictureBox
    Friend WithEvents pnlminimatchdodgepagebuy As System.Windows.Forms.Panel
    Friend WithEvents btnminimatchdodgepagebuy As System.Windows.Forms.Label
    Friend WithEvents lblminimatchdodgehow2buydetails As System.Windows.Forms.Label
    Friend WithEvents lblminimatchdodgehow2buy As System.Windows.Forms.Label
    Friend WithEvents bntminimatchdodgepageback As System.Windows.Forms.Label
    Friend WithEvents lblminimatchuserwelcome As System.Windows.Forms.Label
    Friend WithEvents lblminimatchmainpagewelcome As System.Windows.Forms.Label
    Friend WithEvents txtminimatchbitnoteaddress As System.Windows.Forms.TextBox
    Friend WithEvents pnlappscapedeposit As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel46 As System.Windows.Forms.Panel
    Friend WithEvents Panel47 As System.Windows.Forms.Panel
    Friend WithEvents lbappscapepayinfohello As System.Windows.Forms.Label
    Friend WithEvents txtappscapedepositeaddress As System.Windows.Forms.TextBox
    Friend WithEvents lblappscapecopyaddressinfo As System.Windows.Forms.Label
    Friend WithEvents picappscapedepositeinfobitnotescreenshot As System.Windows.Forms.PictureBox
    Friend WithEvents lblappscapedepositpasteinfo As System.Windows.Forms.Label
    Friend WithEvents appscapedepositestep3 As System.Windows.Forms.Label
    Friend WithEvents appscapedepositestep2 As System.Windows.Forms.Label
    Friend WithEvents appscapedepositestep1 As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotemainpage As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotehome As System.Windows.Forms.Panel
    Friend WithEvents picbitnotewebsitetitle As System.Windows.Forms.PictureBox
    Friend WithEvents lblbitnotehowgettxt As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehowgettitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnoteabouttxt As System.Windows.Forms.Label
    Friend WithEvents lblbitnoteabouttitle As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotesideright As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotesideleft As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotehomefooter As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotehomefootergettitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehomedownloadlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehomeaboutlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehomecopyright As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehomefootergetlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehomediggerlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehomewalletlink As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotebuywallet As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotewalletfooter As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotewalletcopyrighttitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotewalletfootergetlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotewalletdiggerdownloadlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotewalletwalletdownloadlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotewalletpagegettitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotewalletpagedownloadstitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotewalletpageabouttitle As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotewalletpagerightside As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotewalletpageleftside As System.Windows.Forms.Panel
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents picbitnotewalletpagelogo As System.Windows.Forms.PictureBox
    Friend WithEvents picbitnotewalletpagescreenshot As System.Windows.Forms.PictureBox
    Friend WithEvents lblbitnotewalletdescription2 As System.Windows.Forms.Label
    Friend WithEvents lblbitnotewalletdescription1 As System.Windows.Forms.Label
    Friend WithEvents picbitnotewalletdownloadbtn As System.Windows.Forms.PictureBox
    Friend WithEvents lblbitnotewalletpagefooterhomelink As System.Windows.Forms.Label
    Friend WithEvents pnlhome As System.Windows.Forms.Panel
    Friend WithEvents pnlhomehome As System.Windows.Forms.Panel
    Friend WithEvents tbhomehomewelcome As System.Windows.Forms.Label
    Friend WithEvents pnlnotfound As System.Windows.Forms.Panel
    Friend WithEvents pnlnotfoundsite As System.Windows.Forms.Panel
    Friend WithEvents tbnotfound As System.Windows.Forms.Label
    Friend WithEvents lblbitnotehomehomebtn As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotedigger As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotediggerfooter As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotediggerfooterhomelink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggerfootercopyright As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggerfootergetlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggerfooterdiggerlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggerfooterwalletlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggerfootergettitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggerfooterdownloadstitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggerfooterabouttitle As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotediggersideright As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotediggersideleft As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotediggerdescription As System.Windows.Forms.Label
    Friend WithEvents lblbitnotediggertitle As System.Windows.Forms.Label
    Friend WithEvents picbitnotediggertitlelogo As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnbitnotediggergrade5buy As System.Windows.Forms.Button
    Friend WithEvents btnbitnotediggergrade4buy As System.Windows.Forms.Button
    Friend WithEvents btnbitnotediggergrade3buy As System.Windows.Forms.Button
    Friend WithEvents btnbitnotediggergrade2buy As System.Windows.Forms.Button
    Friend WithEvents btnbitnotediggergrade1buy As System.Windows.Forms.Button
    Friend WithEvents pnlutilsweb As System.Windows.Forms.Panel
    Friend WithEvents pnlutilswebbackuputility As System.Windows.Forms.Panel
    Friend WithEvents lbl_backuputility_soon As System.Windows.Forms.Label
    Friend WithEvents pnl404 As System.Windows.Forms.Panel
    Friend WithEvents pnl404home As System.Windows.Forms.Panel
    Friend WithEvents tb404homenotfound As System.Windows.Forms.Label
    Friend WithEvents tb404home404 As System.Windows.Forms.Label
    Friend WithEvents pnlshiftnet As System.Windows.Forms.Panel
    Friend WithEvents pnlshiftnethome As System.Windows.Forms.Panel
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents homenetsite As System.Windows.Forms.Label
    Friend WithEvents homedefaultpage As System.Windows.Forms.Label
    Friend WithEvents hometitle As System.Windows.Forms.Label
    Friend WithEvents pnlpirateboat As System.Windows.Forms.Panel
    Friend WithEvents pnlpirateboatmain As System.Windows.Forms.Panel
    Friend WithEvents tbpbMSG As System.Windows.Forms.Label
    Friend WithEvents tbdnlfloodgate As System.Windows.Forms.Label
    Friend WithEvents tbPirateBoat As System.Windows.Forms.Label
    Friend WithEvents lbldevdockingwarning As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotecurrencyexchange As System.Windows.Forms.Panel
    Friend WithEvents btnbitnotecurrencyexchangebuy As System.Windows.Forms.Button
    Friend WithEvents txtbitnotecurrencyexchangebitnoteamout As System.Windows.Forms.TextBox
    Friend WithEvents lblbitnotecurrencyexchangeprice As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangebuytitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangetodaysrate As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotecurrencyexchangefooter As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotecurrencyexchangefooterhomelink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangefootercopyright As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangefootergetlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangefooterdiggerlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangefooterwalletlink As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangefootergettitle As System.Windows.Forms.Label
    Friend WithEvents bitnotecurrencyexchangefooterdownloadstitle As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangefooterabouttitle As System.Windows.Forms.Label
    Friend WithEvents pnlbitnotecurrencyexchangerightside As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotecurrencyexchangeleftside As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotecurrencyexchangedescription As System.Windows.Forms.Label
    Friend WithEvents lblbitnotecurrencyexchangetitle As System.Windows.Forms.Label
    Friend WithEvents picbitnotecurrencyexchangetitle As System.Windows.Forms.PictureBox
    Friend WithEvents pichomehomeicon As System.Windows.Forms.PictureBox
    Friend WithEvents lblhomehomedescription As System.Windows.Forms.Label
    Friend WithEvents lblhomehomebitnotelink As System.Windows.Forms.Label
    Friend WithEvents lblhomehomeminimatchlink As System.Windows.Forms.Label
    Friend WithEvents lblhomehomeappscapelink As System.Windows.Forms.Label
    Friend WithEvents lblhomehomebackuplink As System.Windows.Forms.Label
    Friend WithEvents lblhomehomehistorylink As System.Windows.Forms.Label
    Friend WithEvents pnlhomehistory As System.Windows.Forms.Panel
    Friend WithEvents lbhomehistoryhistory As System.Windows.Forms.ListView
    Friend WithEvents AllLinksMustHaveATooltipForTheirUrl As System.Windows.Forms.ToolTip
    Friend WithEvents pnlutilswebhome As System.Windows.Forms.Panel
    Friend WithEvents pnlutilswebvirusscan As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents utilswebhomewip As System.Windows.Forms.Label
    Friend WithEvents utilswebvirusscanner As System.Windows.Forms.Label
    Friend WithEvents utilswebbackuputil As System.Windows.Forms.Label
    Friend WithEvents pnlshiftomizer As System.Windows.Forms.Panel
    Friend WithEvents pnlshiftomizerhome As System.Windows.Forms.Panel
    Friend WithEvents lblshiftomizerhomeskinsliderdownload As System.Windows.Forms.Label
    Friend WithEvents picshiftomizerhomeappslidernext As System.Windows.Forms.PictureBox
    Friend WithEvents picshiftomizerhomeappsliderback As System.Windows.Forms.PictureBox
    Friend WithEvents lblshiftomizerhomeappdescription As System.Windows.Forms.Label
    Friend WithEvents picshiftomizerhomeappsliderimg As System.Windows.Forms.PictureBox
    Friend WithEvents lblshiftomizerhomeappname As System.Windows.Forms.Label
    Friend WithEvents picshiftomizerhomeskinsliderright As System.Windows.Forms.PictureBox
    Friend WithEvents picshiftomizerhomeskinssliderleft As System.Windows.Forms.PictureBox
    Friend WithEvents lblshiftomizerhomeskinname As System.Windows.Forms.Label
    Friend WithEvents lblshiftomizerhomeappdownload As System.Windows.Forms.Label
    Friend WithEvents lblshiftomizerhomeskinsliderdescription As System.Windows.Forms.Label
    Friend WithEvents picshiftomizerhomeskinsliderimage As System.Windows.Forms.PictureBox
    Friend WithEvents lblshiftomizerhomedescription As System.Windows.Forms.Label
    Friend WithEvents lblshiftomizerhometitle As System.Windows.Forms.Label
    Friend WithEvents pnlshifterhacker As System.Windows.Forms.Panel
    Friend WithEvents pnlshifterhackerhome As System.Windows.Forms.Panel
    Friend WithEvents tbshifterhackerhomefloodgatead As System.Windows.Forms.Label
    Friend WithEvents tbshifterhackerhomepostspotwatermark As System.Windows.Forms.Label
    Friend WithEvents tbshifterhackerhomeh1 As System.Windows.Forms.Label
    Friend WithEvents tbshifterhackerhomeblogpost1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents tbshifterhackerhomefloodgatelink1 As System.Windows.Forms.Label
    Friend WithEvents pnlpostspot As System.Windows.Forms.Panel
    Friend WithEvents pnlpostspothome As System.Windows.Forms.Panel
    Friend WithEvents tbpostspothomeshifterhackerlink As System.Windows.Forms.Label
    Friend WithEvents tbpostspothomecontent As System.Windows.Forms.Label
    Friend WithEvents tbpostspothomead As System.Windows.Forms.Label
    Friend WithEvents tbpostspothomesubtext As System.Windows.Forms.Label
    Friend WithEvents tbpostspothomepostspot As System.Windows.Forms.Label
    Friend WithEvents pnlxenonh As System.Windows.Forms.Panel
    Friend WithEvents pnlxenonhhome As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tbpbWarning As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents tbpbfglink1 As System.Windows.Forms.Label
    Friend WithEvents tpbsearch As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox

    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents pnlshiftomizerpayments As System.Windows.Forms.Panel
    Friend WithEvents lblshiftomizerpaymentorder As System.Windows.Forms.Label
    Friend WithEvents lblshiftomizerpaymentstitle As System.Windows.Forms.Label
    Friend WithEvents lblshiftomizerpaymentinstruct As System.Windows.Forms.Label
    Friend WithEvents btnshiftomizerhomecheckout As System.Windows.Forms.Button
    '<<<<< HEAD
    Friend WithEvents pnlminimatchlabyrinth As System.Windows.Forms.Panel
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents txtminimatchlabrinthaddress As System.Windows.Forms.TextBox
    Friend WithEvents lblminimatchinfopagebuy As System.Windows.Forms.Label
    Friend WithEvents lblminimatchlabyrinthbuyinstuct As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    '======
    Friend WithEvents tpbsearchresults As System.Windows.Forms.ListView
    Friend WithEvents pnlpirateboatdownlaod As System.Windows.Forms.Panel
    Friend WithEvents tpburlbox As System.Windows.Forms.TextBox
    Friend WithEvents tpbfloodgate As System.Windows.Forms.Button
    Friend WithEvents tpbbackbtn As System.Windows.Forms.Button
    Friend WithEvents tmrshiftomizerwaitinglist As System.Windows.Forms.Timer
    Friend WithEvents lblshiftomizerpaymentsback As System.Windows.Forms.Label
    Friend WithEvents lblshiftomizerpaymentsclear As System.Windows.Forms.Label
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents pnlappscapeoprcwrite As System.Windows.Forms.Panel
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents btnappscapeorcwritebuy As System.Windows.Forms.Panel
    Friend WithEvents btnappscapeorcwriteback As System.Windows.Forms.Panel
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents Panel23 As System.Windows.Forms.Panel
    Friend WithEvents lblappscapeorcwritehellotext As System.Windows.Forms.Label
    Friend WithEvents btnappscapeorcwritedeposit As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnappscapedepositeback As System.Windows.Forms.Panel
    Friend WithEvents tbxenonhurl As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tbxenonhquickchat As System.Windows.Forms.Label
    Friend WithEvents pnlquickchat As System.Windows.Forms.Panel
    Friend WithEvents pnlquickchathome As System.Windows.Forms.Panel
    Friend WithEvents pnlquickchatoffline As System.Windows.Forms.Panel
    Friend WithEvents tbqchomebtn As System.Windows.Forms.Label
    Friend WithEvents qcpanel As System.Windows.Forms.Panel
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents tbqcochat As System.Windows.Forms.TextBox
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents tbqctype As System.Windows.Forms.TextBox
    Friend WithEvents qchome As System.Windows.Forms.Label
    Friend WithEvents tbqcchat As System.Windows.Forms.TextBox
    Friend WithEvents tbqcusers As System.Windows.Forms.ListView
    Friend WithEvents qctext As System.Windows.Forms.Timer
    '>>>>> ce0a6a37176ae3b3ae83961966eacc02ee9487c1
End Class
