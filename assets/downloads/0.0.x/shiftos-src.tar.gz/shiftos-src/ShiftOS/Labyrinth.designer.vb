﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Labyrinth
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Labyrinth))
        Me.pullside = New System.Windows.Forms.Timer(Me.components)
        Me.pullbs = New System.Windows.Forms.Timer(Me.components)
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.pullbottom = New System.Windows.Forms.Timer(Me.components)
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.pnllevelholder = New System.Windows.Forms.Panel()
        Me.pnlintro = New System.Windows.Forms.Panel()
        Me.beginbtn = New System.Windows.Forms.Button()
        Me.lblwelcometxt = New System.Windows.Forms.Label()
        Me.pnllvl3 = New System.Windows.Forms.Panel()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnllvl1 = New System.Windows.Forms.Panel()
        Me.pnlplayer = New System.Windows.Forms.Panel()
        Me.lbllvl1exit = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.pnllvl2 = New System.Windows.Forms.Panel()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pnlfooter = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbltime = New System.Windows.Forms.Label()
        Me.btncashout = New System.Windows.Forms.Button()
        Me.lbllevel = New System.Windows.Forms.Label()
        Me.lbltitle = New System.Windows.Forms.Label()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.tmrtimeleft = New System.Windows.Forms.Timer(Me.components)
        Me.tmrgametick = New System.Windows.Forms.Timer(Me.components)
        Me.pnllvl4 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.Panel41 = New System.Windows.Forms.Panel()
        Me.pnllvl5 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel42 = New System.Windows.Forms.Panel()
        Me.Panel43 = New System.Windows.Forms.Panel()
        Me.Panel44 = New System.Windows.Forms.Panel()
        Me.Panel45 = New System.Windows.Forms.Panel()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.Panel48 = New System.Windows.Forms.Panel()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pgright.SuspendLayout()
        Me.pgcontents.SuspendLayout()
        Me.pnllevelholder.SuspendLayout()
        Me.pnlintro.SuspendLayout()
        Me.pnllvl3.SuspendLayout()
        Me.pnllvl1.SuspendLayout()
        Me.pnllvl2.SuspendLayout()
        Me.pnlfooter.SuspendLayout()
        Me.pgleft.SuspendLayout()
        Me.titlebar.SuspendLayout()
        Me.pnllvl4.SuspendLayout()
        Me.pnllvl5.SuspendLayout()
        Me.SuspendLayout()
        '
        'pullside
        '
        Me.pullside.Interval = 1
        '
        'pullbs
        '
        Me.pullbs.Interval = 1
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 298)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(496, 2)
        Me.pgbottom.TabIndex = 31
        '
        'pullbottom
        '
        Me.pullbottom.Interval = 1
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(246, 5)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 24
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconTextPad
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(274, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 268)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(498, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 270)
        Me.pgright.TabIndex = 30
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(302, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(77, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Template"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(498, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 268)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgcontents
        '
        Me.pgcontents.BackColor = System.Drawing.Color.White
        Me.pgcontents.Controls.Add(Me.pnllevelholder)
        Me.pgcontents.Controls.Add(Me.pnlfooter)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(498, 270)
        Me.pgcontents.TabIndex = 28
        '
        'pnllevelholder
        '
        Me.pnllevelholder.Controls.Add(Me.pnllvl5)
        Me.pnllevelholder.Controls.Add(Me.pnllvl4)
        Me.pnllevelholder.Controls.Add(Me.pnlintro)
        Me.pnllevelholder.Controls.Add(Me.pnllvl3)
        Me.pnllevelholder.Controls.Add(Me.pnllvl1)
        Me.pnllevelholder.Controls.Add(Me.pnllvl2)
        Me.pnllevelholder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnllevelholder.Location = New System.Drawing.Point(0, 0)
        Me.pnllevelholder.Name = "pnllevelholder"
        Me.pnllevelholder.Size = New System.Drawing.Size(498, 218)
        Me.pnllevelholder.TabIndex = 1
        '
        'pnlintro
        '
        Me.pnlintro.Controls.Add(Me.beginbtn)
        Me.pnlintro.Controls.Add(Me.lblwelcometxt)
        Me.pnlintro.Location = New System.Drawing.Point(10, 181)
        Me.pnlintro.Name = "pnlintro"
        Me.pnlintro.Size = New System.Drawing.Size(78, 34)
        Me.pnlintro.TabIndex = 3
        '
        'beginbtn
        '
        Me.beginbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.beginbtn.Location = New System.Drawing.Point(205, 153)
        Me.beginbtn.Name = "beginbtn"
        Me.beginbtn.Size = New System.Drawing.Size(75, 23)
        Me.beginbtn.TabIndex = 1
        Me.beginbtn.Text = "Begin"
        Me.beginbtn.UseVisualStyleBackColor = True
        '
        'lblwelcometxt
        '
        Me.lblwelcometxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblwelcometxt.Location = New System.Drawing.Point(30, 64)
        Me.lblwelcometxt.Name = "lblwelcometxt"
        Me.lblwelcometxt.Size = New System.Drawing.Size(445, 117)
        Me.lblwelcometxt.TabIndex = 0
        Me.lblwelcometxt.Text = resources.GetString("lblwelcometxt.Text")
        '
        'pnllvl3
        '
        Me.pnllvl3.Controls.Add(Me.Panel31)
        Me.pnllvl3.Controls.Add(Me.Panel30)
        Me.pnllvl3.Controls.Add(Me.Panel29)
        Me.pnllvl3.Controls.Add(Me.Panel28)
        Me.pnllvl3.Controls.Add(Me.Panel27)
        Me.pnllvl3.Controls.Add(Me.Panel26)
        Me.pnllvl3.Controls.Add(Me.Label2)
        Me.pnllvl3.Location = New System.Drawing.Point(190, 3)
        Me.pnllvl3.Name = "pnllvl3"
        Me.pnllvl3.Size = New System.Drawing.Size(88, 37)
        Me.pnllvl3.TabIndex = 2
        '
        'Panel31
        '
        Me.Panel31.BackColor = System.Drawing.Color.Black
        Me.Panel31.Location = New System.Drawing.Point(27, 156)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(333, 62)
        Me.Panel31.TabIndex = 17
        '
        'Panel30
        '
        Me.Panel30.BackColor = System.Drawing.Color.Black
        Me.Panel30.Location = New System.Drawing.Point(385, 133)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(26, 58)
        Me.Panel30.TabIndex = 16
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.Color.Black
        Me.Panel29.Location = New System.Drawing.Point(27, 105)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(414, 28)
        Me.Panel29.TabIndex = 15
        '
        'Panel28
        '
        Me.Panel28.BackColor = System.Drawing.Color.Black
        Me.Panel28.Location = New System.Drawing.Point(441, 156)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(23, 62)
        Me.Panel28.TabIndex = 14
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.Black
        Me.Panel27.Location = New System.Drawing.Point(441, 0)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(23, 134)
        Me.Panel27.TabIndex = 13
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.Black
        Me.Panel26.Location = New System.Drawing.Point(0, 41)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(414, 28)
        Me.Panel26.TabIndex = 12
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(476, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(14, 104)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = ">" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "X" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ">"
        '
        'pnllvl1
        '
        Me.pnllvl1.Controls.Add(Me.pnlplayer)
        Me.pnllvl1.Controls.Add(Me.lbllvl1exit)
        Me.pnllvl1.Controls.Add(Me.Panel11)
        Me.pnllvl1.Controls.Add(Me.Panel10)
        Me.pnllvl1.Controls.Add(Me.Panel9)
        Me.pnllvl1.Controls.Add(Me.Panel8)
        Me.pnllvl1.Controls.Add(Me.Panel7)
        Me.pnllvl1.Controls.Add(Me.Panel6)
        Me.pnllvl1.Controls.Add(Me.Panel5)
        Me.pnllvl1.Controls.Add(Me.Panel4)
        Me.pnllvl1.Controls.Add(Me.Panel3)
        Me.pnllvl1.Controls.Add(Me.Panel2)
        Me.pnllvl1.Controls.Add(Me.Panel1)
        Me.pnllvl1.Location = New System.Drawing.Point(0, 0)
        Me.pnllvl1.Name = "pnllvl1"
        Me.pnllvl1.Size = New System.Drawing.Size(84, 40)
        Me.pnllvl1.TabIndex = 0
        '
        'pnlplayer
        '
        Me.pnlplayer.BackColor = System.Drawing.Color.Gray
        Me.pnlplayer.Location = New System.Drawing.Point(8, 10)
        Me.pnlplayer.Name = "pnlplayer"
        Me.pnlplayer.Size = New System.Drawing.Size(13, 13)
        Me.pnlplayer.TabIndex = 12
        '
        'lbllvl1exit
        '
        Me.lbllvl1exit.AutoSize = True
        Me.lbllvl1exit.Location = New System.Drawing.Point(476, 60)
        Me.lbllvl1exit.Name = "lbllvl1exit"
        Me.lbllvl1exit.Size = New System.Drawing.Size(14, 104)
        Me.lbllvl1exit.TabIndex = 11
        Me.lbllvl1exit.Text = ">" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "X" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ">"
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.Black
        Me.Panel11.Location = New System.Drawing.Point(420, 0)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(23, 158)
        Me.Panel11.TabIndex = 10
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Black
        Me.Panel10.Location = New System.Drawing.Point(355, 60)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(23, 158)
        Me.Panel10.TabIndex = 9
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Black
        Me.Panel9.Location = New System.Drawing.Point(152, 0)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(168, 34)
        Me.Panel9.TabIndex = 8
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Black
        Me.Panel8.Location = New System.Drawing.Point(296, 114)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(24, 44)
        Me.Panel8.TabIndex = 7
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Black
        Me.Panel7.Location = New System.Drawing.Point(242, 114)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(24, 44)
        Me.Panel7.TabIndex = 6
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Black
        Me.Panel6.Location = New System.Drawing.Point(190, 114)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(24, 44)
        Me.Panel6.TabIndex = 5
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Black
        Me.Panel5.Location = New System.Drawing.Point(152, 184)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(168, 34)
        Me.Panel5.TabIndex = 4
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Black
        Me.Panel4.Location = New System.Drawing.Point(152, 60)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(168, 28)
        Me.Panel4.TabIndex = 3
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Black
        Me.Panel3.Location = New System.Drawing.Point(130, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(23, 158)
        Me.Panel3.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Black
        Me.Panel2.Location = New System.Drawing.Point(78, 60)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(23, 158)
        Me.Panel2.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(27, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(23, 158)
        Me.Panel1.TabIndex = 0
        '
        'pnllvl2
        '
        Me.pnllvl2.Controls.Add(Me.Panel25)
        Me.pnllvl2.Controls.Add(Me.Panel24)
        Me.pnllvl2.Controls.Add(Me.Panel23)
        Me.pnllvl2.Controls.Add(Me.Panel22)
        Me.pnllvl2.Controls.Add(Me.Panel21)
        Me.pnllvl2.Controls.Add(Me.Panel20)
        Me.pnllvl2.Controls.Add(Me.Panel19)
        Me.pnllvl2.Controls.Add(Me.Panel18)
        Me.pnllvl2.Controls.Add(Me.Panel17)
        Me.pnllvl2.Controls.Add(Me.Panel16)
        Me.pnllvl2.Controls.Add(Me.Panel15)
        Me.pnllvl2.Controls.Add(Me.Panel14)
        Me.pnllvl2.Controls.Add(Me.Panel13)
        Me.pnllvl2.Controls.Add(Me.Panel12)
        Me.pnllvl2.Controls.Add(Me.Label3)
        Me.pnllvl2.Location = New System.Drawing.Point(90, 3)
        Me.pnllvl2.Name = "pnllvl2"
        Me.pnllvl2.Size = New System.Drawing.Size(88, 37)
        Me.pnllvl2.TabIndex = 1
        '
        'Panel25
        '
        Me.Panel25.BackColor = System.Drawing.Color.Black
        Me.Panel25.Location = New System.Drawing.Point(264, 111)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(86, 24)
        Me.Panel25.TabIndex = 25
        '
        'Panel24
        '
        Me.Panel24.BackColor = System.Drawing.Color.Black
        Me.Panel24.Location = New System.Drawing.Point(296, 164)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(86, 24)
        Me.Panel24.TabIndex = 24
        '
        'Panel23
        '
        Me.Panel23.BackColor = System.Drawing.Color.Black
        Me.Panel23.Location = New System.Drawing.Point(382, 87)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(24, 101)
        Me.Panel23.TabIndex = 23
        '
        'Panel22
        '
        Me.Panel22.BackColor = System.Drawing.Color.Black
        Me.Panel22.Location = New System.Drawing.Point(264, 60)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(142, 28)
        Me.Panel22.TabIndex = 22
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.Black
        Me.Panel21.Location = New System.Drawing.Point(242, 111)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(24, 107)
        Me.Panel21.TabIndex = 21
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.Black
        Me.Panel20.Location = New System.Drawing.Point(242, 0)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(24, 88)
        Me.Panel20.TabIndex = 20
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.Black
        Me.Panel19.Location = New System.Drawing.Point(152, 89)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(20, 69)
        Me.Panel19.TabIndex = 19
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.Black
        Me.Panel18.Location = New System.Drawing.Point(114, 164)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(100, 24)
        Me.Panel18.TabIndex = 18
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.Black
        Me.Panel17.Location = New System.Drawing.Point(114, 61)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(100, 24)
        Me.Panel17.TabIndex = 17
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.Black
        Me.Panel16.Location = New System.Drawing.Point(78, 184)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(20, 34)
        Me.Panel16.TabIndex = 16
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.Black
        Me.Panel15.Location = New System.Drawing.Point(31, 137)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(19, 81)
        Me.Panel15.TabIndex = 15
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.Black
        Me.Panel14.Location = New System.Drawing.Point(78, -2)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(19, 56)
        Me.Panel14.TabIndex = 14
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.Black
        Me.Panel13.Location = New System.Drawing.Point(78, 89)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(19, 75)
        Me.Panel13.TabIndex = 13
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.Black
        Me.Panel12.Location = New System.Drawing.Point(30, -2)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(20, 109)
        Me.Panel12.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(476, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 104)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = ">" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "X" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ">"
        '
        'pnlfooter
        '
        Me.pnlfooter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlfooter.Controls.Add(Me.Label1)
        Me.pnlfooter.Controls.Add(Me.lbltime)
        Me.pnlfooter.Controls.Add(Me.btncashout)
        Me.pnlfooter.Controls.Add(Me.lbllevel)
        Me.pnlfooter.Controls.Add(Me.lbltitle)
        Me.pnlfooter.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlfooter.Location = New System.Drawing.Point(0, 218)
        Me.pnlfooter.Name = "pnlfooter"
        Me.pnlfooter.Size = New System.Drawing.Size(498, 52)
        Me.pnlfooter.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(392, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Time left:"
        '
        'lbltime
        '
        Me.lbltime.AutoSize = True
        Me.lbltime.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltime.Location = New System.Drawing.Point(448, 13)
        Me.lbltime.Name = "lbltime"
        Me.lbltime.Size = New System.Drawing.Size(38, 25)
        Me.lbltime.TabIndex = 3
        Me.lbltime.Text = "59"
        '
        'btncashout
        '
        Me.btncashout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncashout.Location = New System.Drawing.Point(220, 12)
        Me.btncashout.Name = "btncashout"
        Me.btncashout.Size = New System.Drawing.Size(99, 23)
        Me.btncashout.TabIndex = 2
        Me.btncashout.Text = "Cashout 0 CP"
        Me.btncashout.UseVisualStyleBackColor = True
        '
        'lbllevel
        '
        Me.lbllevel.AutoSize = True
        Me.lbllevel.Location = New System.Drawing.Point(110, 22)
        Me.lbllevel.Name = "lbllevel"
        Me.lbllevel.Size = New System.Drawing.Size(42, 13)
        Me.lbllevel.TabIndex = 1
        Me.lbllevel.Text = "Level 1"
        '
        'lbltitle
        '
        Me.lbltitle.AutoSize = True
        Me.lbltitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitle.Location = New System.Drawing.Point(10, 13)
        Me.lbltitle.Name = "lbltitle"
        Me.lbltitle.Size = New System.Drawing.Size(101, 25)
        Me.lbltitle.TabIndex = 0
        Me.lbltitle.Text = "Labyrinth"
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 270)
        Me.pgleft.TabIndex = 29
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(500, 30)
        Me.titlebar.TabIndex = 27
        '
        'tmrtimeleft
        '
        Me.tmrtimeleft.Interval = 1000
        '
        'tmrgametick
        '
        Me.tmrgametick.Interval = 1
        '
        'pnllvl4
        '
        Me.pnllvl4.Controls.Add(Me.Panel41)
        Me.pnllvl4.Controls.Add(Me.Panel40)
        Me.pnllvl4.Controls.Add(Me.Panel39)
        Me.pnllvl4.Controls.Add(Me.Panel38)
        Me.pnllvl4.Controls.Add(Me.Panel37)
        Me.pnllvl4.Controls.Add(Me.Panel36)
        Me.pnllvl4.Controls.Add(Me.Panel35)
        Me.pnllvl4.Controls.Add(Me.Panel34)
        Me.pnllvl4.Controls.Add(Me.Panel33)
        Me.pnllvl4.Controls.Add(Me.Panel32)
        Me.pnllvl4.Controls.Add(Me.Label5)
        Me.pnllvl4.Location = New System.Drawing.Point(290, 3)
        Me.pnllvl4.Name = "pnllvl4"
        Me.pnllvl4.Size = New System.Drawing.Size(88, 37)
        Me.pnllvl4.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(476, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(14, 104)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = ">" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "X" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ">"
        '
        'Panel32
        '
        Me.Panel32.BackColor = System.Drawing.Color.Black
        Me.Panel32.Location = New System.Drawing.Point(38, 22)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(50, 50)
        Me.Panel32.TabIndex = 12
        '
        'Panel33
        '
        Me.Panel33.BackColor = System.Drawing.Color.Black
        Me.Panel33.Location = New System.Drawing.Point(112, 60)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(50, 50)
        Me.Panel33.TabIndex = 13
        '
        'Panel34
        '
        Me.Panel34.BackColor = System.Drawing.Color.Black
        Me.Panel34.Location = New System.Drawing.Point(204, 35)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(50, 50)
        Me.Panel34.TabIndex = 14
        '
        'Panel35
        '
        Me.Panel35.BackColor = System.Drawing.Color.Black
        Me.Panel35.Location = New System.Drawing.Point(155, 136)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(50, 50)
        Me.Panel35.TabIndex = 15
        '
        'Panel36
        '
        Me.Panel36.BackColor = System.Drawing.Color.Black
        Me.Panel36.Location = New System.Drawing.Point(296, 128)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(50, 50)
        Me.Panel36.TabIndex = 16
        '
        'Panel37
        '
        Me.Panel37.BackColor = System.Drawing.Color.Black
        Me.Panel37.Location = New System.Drawing.Point(325, 35)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(50, 50)
        Me.Panel37.TabIndex = 17
        '
        'Panel38
        '
        Me.Panel38.BackColor = System.Drawing.Color.Black
        Me.Panel38.Location = New System.Drawing.Point(34, 144)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(50, 50)
        Me.Panel38.TabIndex = 18
        '
        'Panel39
        '
        Me.Panel39.BackColor = System.Drawing.Color.Black
        Me.Panel39.Location = New System.Drawing.Point(389, 142)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(50, 50)
        Me.Panel39.TabIndex = 19
        '
        'Panel40
        '
        Me.Panel40.BackColor = System.Drawing.Color.Black
        Me.Panel40.Location = New System.Drawing.Point(420, 10)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(50, 50)
        Me.Panel40.TabIndex = 20
        '
        'Panel41
        '
        Me.Panel41.BackColor = System.Drawing.Color.Black
        Me.Panel41.Location = New System.Drawing.Point(228, 108)
        Me.Panel41.Name = "Panel41"
        Me.Panel41.Size = New System.Drawing.Size(50, 50)
        Me.Panel41.TabIndex = 21
        '
        'pnllvl5
        '
        Me.pnllvl5.Controls.Add(Me.Panel48)
        Me.pnllvl5.Controls.Add(Me.Panel47)
        Me.pnllvl5.Controls.Add(Me.Panel46)
        Me.pnllvl5.Controls.Add(Me.Panel45)
        Me.pnllvl5.Controls.Add(Me.Panel44)
        Me.pnllvl5.Controls.Add(Me.Panel43)
        Me.pnllvl5.Controls.Add(Me.Panel42)
        Me.pnllvl5.Controls.Add(Me.Label6)
        Me.pnllvl5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnllvl5.Location = New System.Drawing.Point(0, 0)
        Me.pnllvl5.Name = "pnllvl5"
        Me.pnllvl5.Size = New System.Drawing.Size(498, 218)
        Me.pnllvl5.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(476, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(14, 104)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = ">" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "X" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "T" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & ">"
        '
        'Panel42
        '
        Me.Panel42.BackColor = System.Drawing.Color.Black
        Me.Panel42.Location = New System.Drawing.Point(-1, 40)
        Me.Panel42.Name = "Panel42"
        Me.Panel42.Size = New System.Drawing.Size(172, 32)
        Me.Panel42.TabIndex = 12
        '
        'Panel43
        '
        Me.Panel43.BackColor = System.Drawing.Color.Black
        Me.Panel43.Location = New System.Drawing.Point(193, 40)
        Me.Panel43.Name = "Panel43"
        Me.Panel43.Size = New System.Drawing.Size(172, 32)
        Me.Panel43.TabIndex = 13
        '
        'Panel44
        '
        Me.Panel44.BackColor = System.Drawing.Color.Black
        Me.Panel44.Location = New System.Drawing.Point(408, 0)
        Me.Panel44.Name = "Panel44"
        Me.Panel44.Size = New System.Drawing.Size(31, 186)
        Me.Panel44.TabIndex = 14
        '
        'Panel45
        '
        Me.Panel45.BackColor = System.Drawing.Color.Black
        Me.Panel45.Location = New System.Drawing.Point(330, 70)
        Me.Panel45.Name = "Panel45"
        Me.Panel45.Size = New System.Drawing.Size(35, 116)
        Me.Panel45.TabIndex = 15
        '
        'Panel46
        '
        Me.Panel46.BackColor = System.Drawing.Color.Black
        Me.Panel46.Location = New System.Drawing.Point(-2, 109)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(172, 32)
        Me.Panel46.TabIndex = 16
        '
        'Panel47
        '
        Me.Panel47.BackColor = System.Drawing.Color.Black
        Me.Panel47.Location = New System.Drawing.Point(-2, 167)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(172, 32)
        Me.Panel47.TabIndex = 17
        '
        'Panel48
        '
        Me.Panel48.BackColor = System.Drawing.Color.Black
        Me.Panel48.Location = New System.Drawing.Point(193, 115)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(142, 32)
        Me.Panel48.TabIndex = 18
        '
        'Labyrinth
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(500, 300)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "Labyrinth"
        Me.Text = "Labyrinth"
        Me.TopMost = True
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pgright.ResumeLayout(False)
        Me.pgcontents.ResumeLayout(False)
        Me.pnllevelholder.ResumeLayout(False)
        Me.pnlintro.ResumeLayout(False)
        Me.pnllvl3.ResumeLayout(False)
        Me.pnllvl3.PerformLayout()
        Me.pnllvl1.ResumeLayout(False)
        Me.pnllvl1.PerformLayout()
        Me.pnllvl2.ResumeLayout(False)
        Me.pnllvl2.PerformLayout()
        Me.pnlfooter.ResumeLayout(False)
        Me.pnlfooter.PerformLayout()
        Me.pgleft.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        Me.pnllvl4.ResumeLayout(False)
        Me.pnllvl4.PerformLayout()
        Me.pnllvl5.ResumeLayout(False)
        Me.pnllvl5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pullside As System.Windows.Forms.Timer
    Friend WithEvents pullbs As System.Windows.Forms.Timer
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents pullbottom As System.Windows.Forms.Timer
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents pnllevelholder As System.Windows.Forms.Panel
    Friend WithEvents pnllvl1 As System.Windows.Forms.Panel
    Friend WithEvents pnlfooter As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbltime As System.Windows.Forms.Label
    Friend WithEvents btncashout As System.Windows.Forms.Button
    Friend WithEvents lbllevel As System.Windows.Forms.Label
    Friend WithEvents lbltitle As System.Windows.Forms.Label
    Friend WithEvents tmrtimeleft As System.Windows.Forms.Timer
    Friend WithEvents pnlplayer As System.Windows.Forms.Panel
    Friend WithEvents lbllvl1exit As System.Windows.Forms.Label
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents tmrgametick As System.Windows.Forms.Timer
    Friend WithEvents pnllvl2 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel25 As System.Windows.Forms.Panel
    Friend WithEvents Panel24 As System.Windows.Forms.Panel
    Friend WithEvents Panel23 As System.Windows.Forms.Panel
    Friend WithEvents Panel22 As System.Windows.Forms.Panel
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents pnllvl3 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel31 As System.Windows.Forms.Panel
    Friend WithEvents Panel30 As System.Windows.Forms.Panel
    Friend WithEvents Panel29 As System.Windows.Forms.Panel
    Friend WithEvents Panel28 As System.Windows.Forms.Panel
    Friend WithEvents Panel27 As System.Windows.Forms.Panel
    Friend WithEvents Panel26 As System.Windows.Forms.Panel
    Friend WithEvents pnlintro As System.Windows.Forms.Panel
    Friend WithEvents lblwelcometxt As System.Windows.Forms.Label
    Friend WithEvents beginbtn As System.Windows.Forms.Button
    Friend WithEvents pnllvl4 As System.Windows.Forms.Panel
    Friend WithEvents Panel41 As System.Windows.Forms.Panel
    Friend WithEvents Panel40 As System.Windows.Forms.Panel
    Friend WithEvents Panel39 As System.Windows.Forms.Panel
    Friend WithEvents Panel38 As System.Windows.Forms.Panel
    Friend WithEvents Panel37 As System.Windows.Forms.Panel
    Friend WithEvents Panel36 As System.Windows.Forms.Panel
    Friend WithEvents Panel35 As System.Windows.Forms.Panel
    Friend WithEvents Panel34 As System.Windows.Forms.Panel
    Friend WithEvents Panel33 As System.Windows.Forms.Panel
    Friend WithEvents Panel32 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents pnllvl5 As System.Windows.Forms.Panel
    Friend WithEvents Panel42 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel48 As System.Windows.Forms.Panel
    Friend WithEvents Panel47 As System.Windows.Forms.Panel
    Friend WithEvents Panel46 As System.Windows.Forms.Panel
    Friend WithEvents Panel45 As System.Windows.Forms.Panel
    Friend WithEvents Panel44 As System.Windows.Forms.Panel
    Friend WithEvents Panel43 As System.Windows.Forms.Panel

End Class
