﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Colour_Picker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.pnlpinkcolours = New System.Windows.Forms.Panel()
        Me.pnlpinkoptions = New System.Windows.Forms.Panel()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtpinksgreen = New System.Windows.Forms.TextBox()
        Me.txtpinksred = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.txtpinksblue = New System.Windows.Forms.TextBox()
        Me.pnlpinkcustomcolour = New System.Windows.Forms.Panel()
        Me.pnlpink16 = New System.Windows.Forms.Panel()
        Me.pnlpink12 = New System.Windows.Forms.Panel()
        Me.pnlpink14 = New System.Windows.Forms.Panel()
        Me.pnlpink10 = New System.Windows.Forms.Panel()
        Me.pnlpink8 = New System.Windows.Forms.Panel()
        Me.pnlpink4 = New System.Windows.Forms.Panel()
        Me.pnlpink6 = New System.Windows.Forms.Panel()
        Me.pnlpink15 = New System.Windows.Forms.Panel()
        Me.pnlpink2 = New System.Windows.Forms.Panel()
        Me.pnlpink13 = New System.Windows.Forms.Panel()
        Me.pnlpink11 = New System.Windows.Forms.Panel()
        Me.pnlpink7 = New System.Windows.Forms.Panel()
        Me.pnlpink9 = New System.Windows.Forms.Panel()
        Me.pnlpink5 = New System.Windows.Forms.Panel()
        Me.pnlpink3 = New System.Windows.Forms.Panel()
        Me.pnlpink1 = New System.Windows.Forms.Panel()
        Me.lblpinklevel = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.pnlredcolours = New System.Windows.Forms.Panel()
        Me.pnlredoptions = New System.Windows.Forms.Panel()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtredsblue = New System.Windows.Forms.TextBox()
        Me.txtredsred = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtredsgreen = New System.Windows.Forms.TextBox()
        Me.pnlredcustomcolour = New System.Windows.Forms.Panel()
        Me.pnlred16 = New System.Windows.Forms.Panel()
        Me.pnlred12 = New System.Windows.Forms.Panel()
        Me.pnlred14 = New System.Windows.Forms.Panel()
        Me.pnlred10 = New System.Windows.Forms.Panel()
        Me.pnlred8 = New System.Windows.Forms.Panel()
        Me.pnlred4 = New System.Windows.Forms.Panel()
        Me.pnlred6 = New System.Windows.Forms.Panel()
        Me.pnlred15 = New System.Windows.Forms.Panel()
        Me.pnlred2 = New System.Windows.Forms.Panel()
        Me.pnlred13 = New System.Windows.Forms.Panel()
        Me.pnlred11 = New System.Windows.Forms.Panel()
        Me.pnlred7 = New System.Windows.Forms.Panel()
        Me.pnlred9 = New System.Windows.Forms.Panel()
        Me.pnlred5 = New System.Windows.Forms.Panel()
        Me.pnlred3 = New System.Windows.Forms.Panel()
        Me.pnlred1 = New System.Windows.Forms.Panel()
        Me.lblredlevel = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.pnlbrowncolours = New System.Windows.Forms.Panel()
        Me.pnlbrownoptions = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtbrownsblue = New System.Windows.Forms.TextBox()
        Me.txtbrownsred = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtbrownsgreen = New System.Windows.Forms.TextBox()
        Me.pnlbrowncustomcolour = New System.Windows.Forms.Panel()
        Me.pnlbrown16 = New System.Windows.Forms.Panel()
        Me.pnlbrown12 = New System.Windows.Forms.Panel()
        Me.pnlbrown14 = New System.Windows.Forms.Panel()
        Me.pnlbrown10 = New System.Windows.Forms.Panel()
        Me.pnlbrown8 = New System.Windows.Forms.Panel()
        Me.pnlbrown4 = New System.Windows.Forms.Panel()
        Me.pnlbrown6 = New System.Windows.Forms.Panel()
        Me.pnlbrown15 = New System.Windows.Forms.Panel()
        Me.pnlbrown2 = New System.Windows.Forms.Panel()
        Me.pnlbrown13 = New System.Windows.Forms.Panel()
        Me.pnlbrown11 = New System.Windows.Forms.Panel()
        Me.pnlbrown7 = New System.Windows.Forms.Panel()
        Me.pnlbrown9 = New System.Windows.Forms.Panel()
        Me.pnlbrown5 = New System.Windows.Forms.Panel()
        Me.pnlbrown3 = New System.Windows.Forms.Panel()
        Me.pnlbrown1 = New System.Windows.Forms.Panel()
        Me.lblbrownlevel = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.pnlorangecolours = New System.Windows.Forms.Panel()
        Me.pnlorangeoptions = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtorangesblue = New System.Windows.Forms.TextBox()
        Me.txtorangesred = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtorangesgreen = New System.Windows.Forms.TextBox()
        Me.pnlorangecustomcolour = New System.Windows.Forms.Panel()
        Me.pnlorange16 = New System.Windows.Forms.Panel()
        Me.pnlorange12 = New System.Windows.Forms.Panel()
        Me.pnlorange14 = New System.Windows.Forms.Panel()
        Me.pnlorange10 = New System.Windows.Forms.Panel()
        Me.pnlorange8 = New System.Windows.Forms.Panel()
        Me.pnlorange4 = New System.Windows.Forms.Panel()
        Me.pnlorange6 = New System.Windows.Forms.Panel()
        Me.pnlorange15 = New System.Windows.Forms.Panel()
        Me.pnlorange2 = New System.Windows.Forms.Panel()
        Me.pnlorange13 = New System.Windows.Forms.Panel()
        Me.pnlorange11 = New System.Windows.Forms.Panel()
        Me.pnlorange7 = New System.Windows.Forms.Panel()
        Me.pnlorange9 = New System.Windows.Forms.Panel()
        Me.pnlorange5 = New System.Windows.Forms.Panel()
        Me.pnlorange3 = New System.Windows.Forms.Panel()
        Me.pnlorange1 = New System.Windows.Forms.Panel()
        Me.lblorangelevel = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.pnlyellowcolours = New System.Windows.Forms.Panel()
        Me.pnlyellowoptions = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtyellowsblue = New System.Windows.Forms.TextBox()
        Me.txtyellowsred = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtyellowsgreen = New System.Windows.Forms.TextBox()
        Me.pnlyellowcustomcolour = New System.Windows.Forms.Panel()
        Me.pnlyellow16 = New System.Windows.Forms.Panel()
        Me.pnlyellow12 = New System.Windows.Forms.Panel()
        Me.pnlyellow14 = New System.Windows.Forms.Panel()
        Me.pnlyellow10 = New System.Windows.Forms.Panel()
        Me.pnlyellow8 = New System.Windows.Forms.Panel()
        Me.pnlyellow4 = New System.Windows.Forms.Panel()
        Me.pnlyellow6 = New System.Windows.Forms.Panel()
        Me.pnlyellow15 = New System.Windows.Forms.Panel()
        Me.pnlyellow2 = New System.Windows.Forms.Panel()
        Me.pnlyellow13 = New System.Windows.Forms.Panel()
        Me.pnlyellow11 = New System.Windows.Forms.Panel()
        Me.pnlyellow7 = New System.Windows.Forms.Panel()
        Me.pnlyellow9 = New System.Windows.Forms.Panel()
        Me.pnlyellow5 = New System.Windows.Forms.Panel()
        Me.pnlyellow3 = New System.Windows.Forms.Panel()
        Me.pnlyellow1 = New System.Windows.Forms.Panel()
        Me.lblyellowlevel = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.pnlgreencolours = New System.Windows.Forms.Panel()
        Me.pnlgreenoptions = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtgreensred = New System.Windows.Forms.TextBox()
        Me.txtgreensgreen = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtgreensblue = New System.Windows.Forms.TextBox()
        Me.pnlgreencustomcolour = New System.Windows.Forms.Panel()
        Me.pnlgreen16 = New System.Windows.Forms.Panel()
        Me.pnlgreen12 = New System.Windows.Forms.Panel()
        Me.pnlgreen14 = New System.Windows.Forms.Panel()
        Me.pnlgreen10 = New System.Windows.Forms.Panel()
        Me.pnlgreen8 = New System.Windows.Forms.Panel()
        Me.pnlgreen4 = New System.Windows.Forms.Panel()
        Me.pnlgreen6 = New System.Windows.Forms.Panel()
        Me.pnlgreen15 = New System.Windows.Forms.Panel()
        Me.pnlgreen2 = New System.Windows.Forms.Panel()
        Me.pnlgreen13 = New System.Windows.Forms.Panel()
        Me.pnlgreen11 = New System.Windows.Forms.Panel()
        Me.pnlgreen7 = New System.Windows.Forms.Panel()
        Me.pnlgreen9 = New System.Windows.Forms.Panel()
        Me.pnlgreen5 = New System.Windows.Forms.Panel()
        Me.pnlgreen3 = New System.Windows.Forms.Panel()
        Me.pnlgreen1 = New System.Windows.Forms.Panel()
        Me.lblgreenlevel = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.pnlbluecolours = New System.Windows.Forms.Panel()
        Me.pnlblueoptions = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtbluesred = New System.Windows.Forms.TextBox()
        Me.txtbluesblue = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtbluesgreen = New System.Windows.Forms.TextBox()
        Me.pnlbluecustomcolour = New System.Windows.Forms.Panel()
        Me.pnlblue16 = New System.Windows.Forms.Panel()
        Me.pnlblue12 = New System.Windows.Forms.Panel()
        Me.pnlblue14 = New System.Windows.Forms.Panel()
        Me.pnlblue10 = New System.Windows.Forms.Panel()
        Me.pnlblue8 = New System.Windows.Forms.Panel()
        Me.pnlblue4 = New System.Windows.Forms.Panel()
        Me.pnlblue6 = New System.Windows.Forms.Panel()
        Me.pnlblue15 = New System.Windows.Forms.Panel()
        Me.pnlblue2 = New System.Windows.Forms.Panel()
        Me.pnlblue13 = New System.Windows.Forms.Panel()
        Me.pnlblue11 = New System.Windows.Forms.Panel()
        Me.pnlblue7 = New System.Windows.Forms.Panel()
        Me.pnlblue9 = New System.Windows.Forms.Panel()
        Me.pnlblue5 = New System.Windows.Forms.Panel()
        Me.pnlblue3 = New System.Windows.Forms.Panel()
        Me.pnlblue1 = New System.Windows.Forms.Panel()
        Me.lblbluelevel = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.pnlpurplecolours = New System.Windows.Forms.Panel()
        Me.pnlpurpleoptions = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtpurplesgreen = New System.Windows.Forms.TextBox()
        Me.txtpurplesblue = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtpurplesred = New System.Windows.Forms.TextBox()
        Me.pnlpurplecustomcolour = New System.Windows.Forms.Panel()
        Me.pnlpurple16 = New System.Windows.Forms.Panel()
        Me.pnlpurple12 = New System.Windows.Forms.Panel()
        Me.pnlpurple14 = New System.Windows.Forms.Panel()
        Me.pnlpurple10 = New System.Windows.Forms.Panel()
        Me.pnlpurple8 = New System.Windows.Forms.Panel()
        Me.pnlpurple4 = New System.Windows.Forms.Panel()
        Me.pnlpurple6 = New System.Windows.Forms.Panel()
        Me.pnlpurple15 = New System.Windows.Forms.Panel()
        Me.pnlpurple2 = New System.Windows.Forms.Panel()
        Me.pnlpurple13 = New System.Windows.Forms.Panel()
        Me.pnlpurple11 = New System.Windows.Forms.Panel()
        Me.pnlpurple7 = New System.Windows.Forms.Panel()
        Me.pnlpurple9 = New System.Windows.Forms.Panel()
        Me.pnlpurple5 = New System.Windows.Forms.Panel()
        Me.pnlpurple3 = New System.Windows.Forms.Panel()
        Me.pnlpurple1 = New System.Windows.Forms.Panel()
        Me.lblpurplelevel = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pnlgraycolours = New System.Windows.Forms.Panel()
        Me.lblcustomshadetut = New System.Windows.Forms.Label()
        Me.txtcustomgrayshade = New System.Windows.Forms.TextBox()
        Me.pnlgraycustomcolour = New System.Windows.Forms.Panel()
        Me.pnlgray16 = New System.Windows.Forms.Panel()
        Me.pnlgray12 = New System.Windows.Forms.Panel()
        Me.pnlgray14 = New System.Windows.Forms.Panel()
        Me.pnlgray10 = New System.Windows.Forms.Panel()
        Me.pnlgray8 = New System.Windows.Forms.Panel()
        Me.pnlgray4 = New System.Windows.Forms.Panel()
        Me.pnlgray6 = New System.Windows.Forms.Panel()
        Me.pnlgray15 = New System.Windows.Forms.Panel()
        Me.pnlgray2 = New System.Windows.Forms.Panel()
        Me.pnlgray13 = New System.Windows.Forms.Panel()
        Me.pnlgray11 = New System.Windows.Forms.Panel()
        Me.pnlgray7 = New System.Windows.Forms.Panel()
        Me.pnlgray9 = New System.Windows.Forms.Panel()
        Me.pnlgray5 = New System.Windows.Forms.Panel()
        Me.pnlgray3 = New System.Windows.Forms.Panel()
        Me.pnlgray1 = New System.Windows.Forms.Panel()
        Me.lblgraylevel = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pnlanycolours = New System.Windows.Forms.Panel()
        Me.pnlanyoptions = New System.Windows.Forms.Panel()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtanysgreen = New System.Windows.Forms.TextBox()
        Me.txtanysred = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtanysblue = New System.Windows.Forms.TextBox()
        Me.pnlanycustomcolour = New System.Windows.Forms.Panel()
        Me.pnlany16 = New System.Windows.Forms.Panel()
        Me.pnlany12 = New System.Windows.Forms.Panel()
        Me.pnlany14 = New System.Windows.Forms.Panel()
        Me.pnlany10 = New System.Windows.Forms.Panel()
        Me.pnlany8 = New System.Windows.Forms.Panel()
        Me.pnlany4 = New System.Windows.Forms.Panel()
        Me.pnlany6 = New System.Windows.Forms.Panel()
        Me.pnlany15 = New System.Windows.Forms.Panel()
        Me.pnlany2 = New System.Windows.Forms.Panel()
        Me.pnlany13 = New System.Windows.Forms.Panel()
        Me.pnlany11 = New System.Windows.Forms.Panel()
        Me.pnlany7 = New System.Windows.Forms.Panel()
        Me.pnlany9 = New System.Windows.Forms.Panel()
        Me.pnlany5 = New System.Windows.Forms.Panel()
        Me.pnlany3 = New System.Windows.Forms.Panel()
        Me.pnlany1 = New System.Windows.Forms.Panel()
        Me.lblanylevel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblnewcolourrgb = New System.Windows.Forms.Label()
        Me.lblnewcolourname = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lbloldcolourrgb = New System.Windows.Forms.Label()
        Me.lbloldcolourname = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.pnlnewcolour = New System.Windows.Forms.Panel()
        Me.pnloldcolour = New System.Windows.Forms.Panel()
        Me.lblobjecttocolour = New System.Windows.Forms.Label()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.pgcontents.SuspendLayout()
        Me.pnlpinkcolours.SuspendLayout()
        Me.pnlpinkoptions.SuspendLayout()
        Me.pnlredcolours.SuspendLayout()
        Me.pnlredoptions.SuspendLayout()
        Me.pnlbrowncolours.SuspendLayout()
        Me.pnlbrownoptions.SuspendLayout()
        Me.pnlorangecolours.SuspendLayout()
        Me.pnlorangeoptions.SuspendLayout()
        Me.pnlyellowcolours.SuspendLayout()
        Me.pnlyellowoptions.SuspendLayout()
        Me.pnlgreencolours.SuspendLayout()
        Me.pnlgreenoptions.SuspendLayout()
        Me.pnlbluecolours.SuspendLayout()
        Me.pnlblueoptions.SuspendLayout()
        Me.pnlpurplecolours.SuspendLayout()
        Me.pnlpurpleoptions.SuspendLayout()
        Me.pnlgraycolours.SuspendLayout()
        Me.pnlanycolours.SuspendLayout()
        Me.pnlanyoptions.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pgleft.SuspendLayout()
        Me.pgright.SuspendLayout()
        Me.titlebar.SuspendLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pgcontents
        '
        Me.pgcontents.Controls.Add(Me.pnlpinkcolours)
        Me.pgcontents.Controls.Add(Me.pnlredcolours)
        Me.pgcontents.Controls.Add(Me.pnlbrowncolours)
        Me.pgcontents.Controls.Add(Me.pnlorangecolours)
        Me.pgcontents.Controls.Add(Me.pnlyellowcolours)
        Me.pgcontents.Controls.Add(Me.pnlgreencolours)
        Me.pgcontents.Controls.Add(Me.pnlbluecolours)
        Me.pgcontents.Controls.Add(Me.pnlpurplecolours)
        Me.pgcontents.Controls.Add(Me.pnlgraycolours)
        Me.pgcontents.Controls.Add(Me.pnlanycolours)
        Me.pgcontents.Controls.Add(Me.Panel1)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(443, 568)
        Me.pgcontents.TabIndex = 20
        '
        'pnlpinkcolours
        '
        Me.pnlpinkcolours.BackColor = System.Drawing.Color.White
        Me.pnlpinkcolours.Controls.Add(Me.pnlpinkoptions)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpinkcustomcolour)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink16)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink12)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink14)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink10)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink8)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink4)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink6)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink15)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink2)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink13)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink11)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink7)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink9)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink5)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink3)
        Me.pnlpinkcolours.Controls.Add(Me.pnlpink1)
        Me.pnlpinkcolours.Controls.Add(Me.lblpinklevel)
        Me.pnlpinkcolours.Controls.Add(Me.Label23)
        Me.pnlpinkcolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlpinkcolours.Location = New System.Drawing.Point(0, 521)
        Me.pnlpinkcolours.Name = "pnlpinkcolours"
        Me.pnlpinkcolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlpinkcolours.TabIndex = 11
        Me.pnlpinkcolours.Visible = False
        '
        'pnlpinkoptions
        '
        Me.pnlpinkoptions.Controls.Add(Me.Label35)
        Me.pnlpinkoptions.Controls.Add(Me.txtpinksgreen)
        Me.pnlpinkoptions.Controls.Add(Me.txtpinksred)
        Me.pnlpinkoptions.Controls.Add(Me.Label36)
        Me.pnlpinkoptions.Controls.Add(Me.Label37)
        Me.pnlpinkoptions.Controls.Add(Me.txtpinksblue)
        Me.pnlpinkoptions.Location = New System.Drawing.Point(282, 2)
        Me.pnlpinkoptions.Name = "pnlpinkoptions"
        Me.pnlpinkoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlpinkoptions.TabIndex = 33
        Me.pnlpinkoptions.Visible = False
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Location = New System.Drawing.Point(56, 24)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 13)
        Me.Label35.TabIndex = 26
        Me.Label35.Text = "Green:"
        '
        'txtpinksgreen
        '
        Me.txtpinksgreen.BackColor = System.Drawing.Color.White
        Me.txtpinksgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpinksgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpinksgreen.Location = New System.Drawing.Point(95, 22)
        Me.txtpinksgreen.Multiline = True
        Me.txtpinksgreen.Name = "txtpinksgreen"
        Me.txtpinksgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtpinksgreen.TabIndex = 25
        Me.txtpinksgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtpinksred
        '
        Me.txtpinksred.BackColor = System.Drawing.Color.White
        Me.txtpinksred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpinksred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpinksred.Location = New System.Drawing.Point(64, 2)
        Me.txtpinksred.Multiline = True
        Me.txtpinksred.Name = "txtpinksred"
        Me.txtpinksred.Size = New System.Drawing.Size(23, 17)
        Me.txtpinksred.TabIndex = 21
        Me.txtpinksred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.Location = New System.Drawing.Point(1, 23)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(31, 13)
        Me.Label36.TabIndex = 24
        Me.Label36.Text = "Blue:"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.Location = New System.Drawing.Point(33, 4)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(30, 13)
        Me.Label37.TabIndex = 22
        Me.Label37.Text = "Red:"
        '
        'txtpinksblue
        '
        Me.txtpinksblue.BackColor = System.Drawing.Color.White
        Me.txtpinksblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpinksblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpinksblue.Location = New System.Drawing.Point(32, 22)
        Me.txtpinksblue.Multiline = True
        Me.txtpinksblue.Name = "txtpinksblue"
        Me.txtpinksblue.Size = New System.Drawing.Size(23, 17)
        Me.txtpinksblue.TabIndex = 23
        Me.txtpinksblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlpinkcustomcolour
        '
        Me.pnlpinkcustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpinkcustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlpinkcustomcolour.Name = "pnlpinkcustomcolour"
        Me.pnlpinkcustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlpinkcustomcolour.TabIndex = 18
        Me.pnlpinkcustomcolour.Visible = False
        '
        'pnlpink16
        '
        Me.pnlpink16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink16.Location = New System.Drawing.Point(259, 25)
        Me.pnlpink16.Name = "pnlpink16"
        Me.pnlpink16.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink16.TabIndex = 17
        Me.pnlpink16.Visible = False
        '
        'pnlpink12
        '
        Me.pnlpink12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink12.Location = New System.Drawing.Point(155, 25)
        Me.pnlpink12.Name = "pnlpink12"
        Me.pnlpink12.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink12.TabIndex = 9
        Me.pnlpink12.Visible = False
        '
        'pnlpink14
        '
        Me.pnlpink14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink14.Location = New System.Drawing.Point(207, 25)
        Me.pnlpink14.Name = "pnlpink14"
        Me.pnlpink14.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink14.TabIndex = 13
        Me.pnlpink14.Visible = False
        '
        'pnlpink10
        '
        Me.pnlpink10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink10.Location = New System.Drawing.Point(103, 25)
        Me.pnlpink10.Name = "pnlpink10"
        Me.pnlpink10.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink10.TabIndex = 5
        Me.pnlpink10.Visible = False
        '
        'pnlpink8
        '
        Me.pnlpink8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink8.Location = New System.Drawing.Point(259, 8)
        Me.pnlpink8.Name = "pnlpink8"
        Me.pnlpink8.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink8.TabIndex = 16
        Me.pnlpink8.Visible = False
        '
        'pnlpink4
        '
        Me.pnlpink4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink4.Location = New System.Drawing.Point(155, 8)
        Me.pnlpink4.Name = "pnlpink4"
        Me.pnlpink4.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink4.TabIndex = 8
        Me.pnlpink4.Visible = False
        '
        'pnlpink6
        '
        Me.pnlpink6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink6.Location = New System.Drawing.Point(207, 8)
        Me.pnlpink6.Name = "pnlpink6"
        Me.pnlpink6.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink6.TabIndex = 12
        Me.pnlpink6.Visible = False
        '
        'pnlpink15
        '
        Me.pnlpink15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink15.Location = New System.Drawing.Point(233, 25)
        Me.pnlpink15.Name = "pnlpink15"
        Me.pnlpink15.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink15.TabIndex = 15
        Me.pnlpink15.Visible = False
        '
        'pnlpink2
        '
        Me.pnlpink2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink2.Location = New System.Drawing.Point(103, 8)
        Me.pnlpink2.Name = "pnlpink2"
        Me.pnlpink2.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink2.TabIndex = 4
        Me.pnlpink2.Visible = False
        '
        'pnlpink13
        '
        Me.pnlpink13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink13.Location = New System.Drawing.Point(181, 25)
        Me.pnlpink13.Name = "pnlpink13"
        Me.pnlpink13.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink13.TabIndex = 11
        Me.pnlpink13.Visible = False
        '
        'pnlpink11
        '
        Me.pnlpink11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink11.Location = New System.Drawing.Point(129, 25)
        Me.pnlpink11.Name = "pnlpink11"
        Me.pnlpink11.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink11.TabIndex = 7
        Me.pnlpink11.Visible = False
        '
        'pnlpink7
        '
        Me.pnlpink7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink7.Location = New System.Drawing.Point(233, 8)
        Me.pnlpink7.Name = "pnlpink7"
        Me.pnlpink7.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink7.TabIndex = 14
        Me.pnlpink7.Visible = False
        '
        'pnlpink9
        '
        Me.pnlpink9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink9.Location = New System.Drawing.Point(77, 25)
        Me.pnlpink9.Name = "pnlpink9"
        Me.pnlpink9.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink9.TabIndex = 3
        Me.pnlpink9.Visible = False
        '
        'pnlpink5
        '
        Me.pnlpink5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink5.Location = New System.Drawing.Point(181, 8)
        Me.pnlpink5.Name = "pnlpink5"
        Me.pnlpink5.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink5.TabIndex = 10
        Me.pnlpink5.Visible = False
        '
        'pnlpink3
        '
        Me.pnlpink3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink3.Location = New System.Drawing.Point(129, 8)
        Me.pnlpink3.Name = "pnlpink3"
        Me.pnlpink3.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink3.TabIndex = 6
        Me.pnlpink3.Visible = False
        '
        'pnlpink1
        '
        Me.pnlpink1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpink1.Location = New System.Drawing.Point(77, 8)
        Me.pnlpink1.Name = "pnlpink1"
        Me.pnlpink1.Size = New System.Drawing.Size(20, 13)
        Me.pnlpink1.TabIndex = 2
        Me.pnlpink1.Visible = False
        '
        'lblpinklevel
        '
        Me.lblpinklevel.AutoSize = True
        Me.lblpinklevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpinklevel.Location = New System.Drawing.Point(5, 25)
        Me.lblpinklevel.Name = "lblpinklevel"
        Me.lblpinklevel.Size = New System.Drawing.Size(49, 15)
        Me.lblpinklevel.TabIndex = 1
        Me.lblpinklevel.Text = "Level: 4"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(3, 2)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(48, 23)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Pink"
        '
        'pnlredcolours
        '
        Me.pnlredcolours.BackColor = System.Drawing.Color.White
        Me.pnlredcolours.Controls.Add(Me.pnlredoptions)
        Me.pnlredcolours.Controls.Add(Me.pnlredcustomcolour)
        Me.pnlredcolours.Controls.Add(Me.pnlred16)
        Me.pnlredcolours.Controls.Add(Me.pnlred12)
        Me.pnlredcolours.Controls.Add(Me.pnlred14)
        Me.pnlredcolours.Controls.Add(Me.pnlred10)
        Me.pnlredcolours.Controls.Add(Me.pnlred8)
        Me.pnlredcolours.Controls.Add(Me.pnlred4)
        Me.pnlredcolours.Controls.Add(Me.pnlred6)
        Me.pnlredcolours.Controls.Add(Me.pnlred15)
        Me.pnlredcolours.Controls.Add(Me.pnlred2)
        Me.pnlredcolours.Controls.Add(Me.pnlred13)
        Me.pnlredcolours.Controls.Add(Me.pnlred11)
        Me.pnlredcolours.Controls.Add(Me.pnlred7)
        Me.pnlredcolours.Controls.Add(Me.pnlred9)
        Me.pnlredcolours.Controls.Add(Me.pnlred5)
        Me.pnlredcolours.Controls.Add(Me.pnlred3)
        Me.pnlredcolours.Controls.Add(Me.pnlred1)
        Me.pnlredcolours.Controls.Add(Me.lblredlevel)
        Me.pnlredcolours.Controls.Add(Me.Label21)
        Me.pnlredcolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlredcolours.Location = New System.Drawing.Point(0, 475)
        Me.pnlredcolours.Name = "pnlredcolours"
        Me.pnlredcolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlredcolours.TabIndex = 10
        Me.pnlredcolours.Visible = False
        '
        'pnlredoptions
        '
        Me.pnlredoptions.Controls.Add(Me.Label32)
        Me.pnlredoptions.Controls.Add(Me.txtredsblue)
        Me.pnlredoptions.Controls.Add(Me.txtredsred)
        Me.pnlredoptions.Controls.Add(Me.Label33)
        Me.pnlredoptions.Controls.Add(Me.Label34)
        Me.pnlredoptions.Controls.Add(Me.txtredsgreen)
        Me.pnlredoptions.Location = New System.Drawing.Point(282, 2)
        Me.pnlredoptions.Name = "pnlredoptions"
        Me.pnlredoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlredoptions.TabIndex = 32
        Me.pnlredoptions.Visible = False
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Location = New System.Drawing.Point(64, 24)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(31, 13)
        Me.Label32.TabIndex = 26
        Me.Label32.Text = "Blue:"
        '
        'txtredsblue
        '
        Me.txtredsblue.BackColor = System.Drawing.Color.White
        Me.txtredsblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtredsblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtredsblue.Location = New System.Drawing.Point(95, 22)
        Me.txtredsblue.Multiline = True
        Me.txtredsblue.Name = "txtredsblue"
        Me.txtredsblue.Size = New System.Drawing.Size(23, 17)
        Me.txtredsblue.TabIndex = 25
        Me.txtredsblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtredsred
        '
        Me.txtredsred.BackColor = System.Drawing.Color.White
        Me.txtredsred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtredsred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtredsred.Location = New System.Drawing.Point(64, 2)
        Me.txtredsred.Multiline = True
        Me.txtredsred.Name = "txtredsred"
        Me.txtredsred.Size = New System.Drawing.Size(23, 17)
        Me.txtredsred.TabIndex = 21
        Me.txtredsred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Location = New System.Drawing.Point(1, 23)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(39, 13)
        Me.Label33.TabIndex = 24
        Me.Label33.Text = "Green:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Location = New System.Drawing.Point(33, 4)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(30, 13)
        Me.Label34.TabIndex = 22
        Me.Label34.Text = "Red:"
        '
        'txtredsgreen
        '
        Me.txtredsgreen.BackColor = System.Drawing.Color.White
        Me.txtredsgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtredsgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtredsgreen.Location = New System.Drawing.Point(40, 22)
        Me.txtredsgreen.Multiline = True
        Me.txtredsgreen.Name = "txtredsgreen"
        Me.txtredsgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtredsgreen.TabIndex = 23
        Me.txtredsgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlredcustomcolour
        '
        Me.pnlredcustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlredcustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlredcustomcolour.Name = "pnlredcustomcolour"
        Me.pnlredcustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlredcustomcolour.TabIndex = 18
        Me.pnlredcustomcolour.Visible = False
        '
        'pnlred16
        '
        Me.pnlred16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred16.Location = New System.Drawing.Point(259, 25)
        Me.pnlred16.Name = "pnlred16"
        Me.pnlred16.Size = New System.Drawing.Size(20, 13)
        Me.pnlred16.TabIndex = 17
        Me.pnlred16.Visible = False
        '
        'pnlred12
        '
        Me.pnlred12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred12.Location = New System.Drawing.Point(155, 25)
        Me.pnlred12.Name = "pnlred12"
        Me.pnlred12.Size = New System.Drawing.Size(20, 13)
        Me.pnlred12.TabIndex = 9
        Me.pnlred12.Visible = False
        '
        'pnlred14
        '
        Me.pnlred14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred14.Location = New System.Drawing.Point(207, 25)
        Me.pnlred14.Name = "pnlred14"
        Me.pnlred14.Size = New System.Drawing.Size(20, 13)
        Me.pnlred14.TabIndex = 13
        Me.pnlred14.Visible = False
        '
        'pnlred10
        '
        Me.pnlred10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred10.Location = New System.Drawing.Point(103, 25)
        Me.pnlred10.Name = "pnlred10"
        Me.pnlred10.Size = New System.Drawing.Size(20, 13)
        Me.pnlred10.TabIndex = 5
        Me.pnlred10.Visible = False
        '
        'pnlred8
        '
        Me.pnlred8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred8.Location = New System.Drawing.Point(259, 8)
        Me.pnlred8.Name = "pnlred8"
        Me.pnlred8.Size = New System.Drawing.Size(20, 13)
        Me.pnlred8.TabIndex = 16
        Me.pnlred8.Visible = False
        '
        'pnlred4
        '
        Me.pnlred4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred4.Location = New System.Drawing.Point(155, 8)
        Me.pnlred4.Name = "pnlred4"
        Me.pnlred4.Size = New System.Drawing.Size(20, 13)
        Me.pnlred4.TabIndex = 8
        Me.pnlred4.Visible = False
        '
        'pnlred6
        '
        Me.pnlred6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred6.Location = New System.Drawing.Point(207, 8)
        Me.pnlred6.Name = "pnlred6"
        Me.pnlred6.Size = New System.Drawing.Size(20, 13)
        Me.pnlred6.TabIndex = 12
        Me.pnlred6.Visible = False
        '
        'pnlred15
        '
        Me.pnlred15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred15.Location = New System.Drawing.Point(233, 25)
        Me.pnlred15.Name = "pnlred15"
        Me.pnlred15.Size = New System.Drawing.Size(20, 13)
        Me.pnlred15.TabIndex = 15
        Me.pnlred15.Visible = False
        '
        'pnlred2
        '
        Me.pnlred2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred2.Location = New System.Drawing.Point(103, 8)
        Me.pnlred2.Name = "pnlred2"
        Me.pnlred2.Size = New System.Drawing.Size(20, 13)
        Me.pnlred2.TabIndex = 4
        Me.pnlred2.Visible = False
        '
        'pnlred13
        '
        Me.pnlred13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred13.Location = New System.Drawing.Point(181, 25)
        Me.pnlred13.Name = "pnlred13"
        Me.pnlred13.Size = New System.Drawing.Size(20, 13)
        Me.pnlred13.TabIndex = 11
        Me.pnlred13.Visible = False
        '
        'pnlred11
        '
        Me.pnlred11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred11.Location = New System.Drawing.Point(129, 25)
        Me.pnlred11.Name = "pnlred11"
        Me.pnlred11.Size = New System.Drawing.Size(20, 13)
        Me.pnlred11.TabIndex = 7
        Me.pnlred11.Visible = False
        '
        'pnlred7
        '
        Me.pnlred7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred7.Location = New System.Drawing.Point(233, 8)
        Me.pnlred7.Name = "pnlred7"
        Me.pnlred7.Size = New System.Drawing.Size(20, 13)
        Me.pnlred7.TabIndex = 14
        Me.pnlred7.Visible = False
        '
        'pnlred9
        '
        Me.pnlred9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred9.Location = New System.Drawing.Point(77, 25)
        Me.pnlred9.Name = "pnlred9"
        Me.pnlred9.Size = New System.Drawing.Size(20, 13)
        Me.pnlred9.TabIndex = 3
        Me.pnlred9.Visible = False
        '
        'pnlred5
        '
        Me.pnlred5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred5.Location = New System.Drawing.Point(181, 8)
        Me.pnlred5.Name = "pnlred5"
        Me.pnlred5.Size = New System.Drawing.Size(20, 13)
        Me.pnlred5.TabIndex = 10
        Me.pnlred5.Visible = False
        '
        'pnlred3
        '
        Me.pnlred3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred3.Location = New System.Drawing.Point(129, 8)
        Me.pnlred3.Name = "pnlred3"
        Me.pnlred3.Size = New System.Drawing.Size(20, 13)
        Me.pnlred3.TabIndex = 6
        Me.pnlred3.Visible = False
        '
        'pnlred1
        '
        Me.pnlred1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlred1.Location = New System.Drawing.Point(77, 8)
        Me.pnlred1.Name = "pnlred1"
        Me.pnlred1.Size = New System.Drawing.Size(20, 13)
        Me.pnlred1.TabIndex = 2
        Me.pnlred1.Visible = False
        '
        'lblredlevel
        '
        Me.lblredlevel.AutoSize = True
        Me.lblredlevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblredlevel.Location = New System.Drawing.Point(5, 25)
        Me.lblredlevel.Name = "lblredlevel"
        Me.lblredlevel.Size = New System.Drawing.Size(49, 15)
        Me.lblredlevel.TabIndex = 1
        Me.lblredlevel.Text = "Level: 4"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(3, 2)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(42, 23)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Red"
        '
        'pnlbrowncolours
        '
        Me.pnlbrowncolours.BackColor = System.Drawing.Color.White
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrownoptions)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrowncustomcolour)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown16)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown12)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown14)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown10)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown8)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown4)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown6)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown15)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown2)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown13)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown11)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown7)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown9)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown5)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown3)
        Me.pnlbrowncolours.Controls.Add(Me.pnlbrown1)
        Me.pnlbrowncolours.Controls.Add(Me.lblbrownlevel)
        Me.pnlbrowncolours.Controls.Add(Me.Label19)
        Me.pnlbrowncolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlbrowncolours.Location = New System.Drawing.Point(0, 429)
        Me.pnlbrowncolours.Name = "pnlbrowncolours"
        Me.pnlbrowncolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlbrowncolours.TabIndex = 8
        Me.pnlbrowncolours.Visible = False
        '
        'pnlbrownoptions
        '
        Me.pnlbrownoptions.Controls.Add(Me.Label29)
        Me.pnlbrownoptions.Controls.Add(Me.txtbrownsblue)
        Me.pnlbrownoptions.Controls.Add(Me.txtbrownsred)
        Me.pnlbrownoptions.Controls.Add(Me.Label30)
        Me.pnlbrownoptions.Controls.Add(Me.Label31)
        Me.pnlbrownoptions.Controls.Add(Me.txtbrownsgreen)
        Me.pnlbrownoptions.Location = New System.Drawing.Point(282, 3)
        Me.pnlbrownoptions.Name = "pnlbrownoptions"
        Me.pnlbrownoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlbrownoptions.TabIndex = 31
        Me.pnlbrownoptions.Visible = False
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Location = New System.Drawing.Point(64, 24)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(31, 13)
        Me.Label29.TabIndex = 26
        Me.Label29.Text = "Blue:"
        '
        'txtbrownsblue
        '
        Me.txtbrownsblue.BackColor = System.Drawing.Color.White
        Me.txtbrownsblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbrownsblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbrownsblue.Location = New System.Drawing.Point(95, 22)
        Me.txtbrownsblue.Multiline = True
        Me.txtbrownsblue.Name = "txtbrownsblue"
        Me.txtbrownsblue.Size = New System.Drawing.Size(23, 17)
        Me.txtbrownsblue.TabIndex = 25
        Me.txtbrownsblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbrownsred
        '
        Me.txtbrownsred.BackColor = System.Drawing.Color.White
        Me.txtbrownsred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbrownsred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbrownsred.Location = New System.Drawing.Point(64, 2)
        Me.txtbrownsred.Multiline = True
        Me.txtbrownsred.Name = "txtbrownsred"
        Me.txtbrownsred.Size = New System.Drawing.Size(23, 17)
        Me.txtbrownsred.TabIndex = 21
        Me.txtbrownsred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Location = New System.Drawing.Point(1, 23)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(39, 13)
        Me.Label30.TabIndex = 24
        Me.Label30.Text = "Green:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Location = New System.Drawing.Point(33, 4)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(30, 13)
        Me.Label31.TabIndex = 22
        Me.Label31.Text = "Red:"
        '
        'txtbrownsgreen
        '
        Me.txtbrownsgreen.BackColor = System.Drawing.Color.White
        Me.txtbrownsgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbrownsgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbrownsgreen.Location = New System.Drawing.Point(40, 22)
        Me.txtbrownsgreen.Multiline = True
        Me.txtbrownsgreen.Name = "txtbrownsgreen"
        Me.txtbrownsgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtbrownsgreen.TabIndex = 23
        Me.txtbrownsgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlbrowncustomcolour
        '
        Me.pnlbrowncustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrowncustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlbrowncustomcolour.Name = "pnlbrowncustomcolour"
        Me.pnlbrowncustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlbrowncustomcolour.TabIndex = 18
        Me.pnlbrowncustomcolour.Visible = False
        '
        'pnlbrown16
        '
        Me.pnlbrown16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown16.Location = New System.Drawing.Point(259, 25)
        Me.pnlbrown16.Name = "pnlbrown16"
        Me.pnlbrown16.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown16.TabIndex = 17
        Me.pnlbrown16.Visible = False
        '
        'pnlbrown12
        '
        Me.pnlbrown12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown12.Location = New System.Drawing.Point(155, 25)
        Me.pnlbrown12.Name = "pnlbrown12"
        Me.pnlbrown12.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown12.TabIndex = 9
        Me.pnlbrown12.Visible = False
        '
        'pnlbrown14
        '
        Me.pnlbrown14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown14.Location = New System.Drawing.Point(207, 25)
        Me.pnlbrown14.Name = "pnlbrown14"
        Me.pnlbrown14.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown14.TabIndex = 13
        Me.pnlbrown14.Visible = False
        '
        'pnlbrown10
        '
        Me.pnlbrown10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown10.Location = New System.Drawing.Point(103, 25)
        Me.pnlbrown10.Name = "pnlbrown10"
        Me.pnlbrown10.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown10.TabIndex = 5
        Me.pnlbrown10.Visible = False
        '
        'pnlbrown8
        '
        Me.pnlbrown8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown8.Location = New System.Drawing.Point(259, 8)
        Me.pnlbrown8.Name = "pnlbrown8"
        Me.pnlbrown8.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown8.TabIndex = 16
        Me.pnlbrown8.Visible = False
        '
        'pnlbrown4
        '
        Me.pnlbrown4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown4.Location = New System.Drawing.Point(155, 8)
        Me.pnlbrown4.Name = "pnlbrown4"
        Me.pnlbrown4.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown4.TabIndex = 8
        Me.pnlbrown4.Visible = False
        '
        'pnlbrown6
        '
        Me.pnlbrown6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown6.Location = New System.Drawing.Point(207, 8)
        Me.pnlbrown6.Name = "pnlbrown6"
        Me.pnlbrown6.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown6.TabIndex = 12
        Me.pnlbrown6.Visible = False
        '
        'pnlbrown15
        '
        Me.pnlbrown15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown15.Location = New System.Drawing.Point(233, 25)
        Me.pnlbrown15.Name = "pnlbrown15"
        Me.pnlbrown15.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown15.TabIndex = 15
        Me.pnlbrown15.Visible = False
        '
        'pnlbrown2
        '
        Me.pnlbrown2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown2.Location = New System.Drawing.Point(103, 8)
        Me.pnlbrown2.Name = "pnlbrown2"
        Me.pnlbrown2.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown2.TabIndex = 4
        Me.pnlbrown2.Visible = False
        '
        'pnlbrown13
        '
        Me.pnlbrown13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown13.Location = New System.Drawing.Point(181, 25)
        Me.pnlbrown13.Name = "pnlbrown13"
        Me.pnlbrown13.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown13.TabIndex = 11
        Me.pnlbrown13.Visible = False
        '
        'pnlbrown11
        '
        Me.pnlbrown11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown11.Location = New System.Drawing.Point(129, 25)
        Me.pnlbrown11.Name = "pnlbrown11"
        Me.pnlbrown11.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown11.TabIndex = 7
        Me.pnlbrown11.Visible = False
        '
        'pnlbrown7
        '
        Me.pnlbrown7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown7.Location = New System.Drawing.Point(233, 8)
        Me.pnlbrown7.Name = "pnlbrown7"
        Me.pnlbrown7.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown7.TabIndex = 14
        Me.pnlbrown7.Visible = False
        '
        'pnlbrown9
        '
        Me.pnlbrown9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown9.Location = New System.Drawing.Point(77, 25)
        Me.pnlbrown9.Name = "pnlbrown9"
        Me.pnlbrown9.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown9.TabIndex = 3
        Me.pnlbrown9.Visible = False
        '
        'pnlbrown5
        '
        Me.pnlbrown5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown5.Location = New System.Drawing.Point(181, 8)
        Me.pnlbrown5.Name = "pnlbrown5"
        Me.pnlbrown5.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown5.TabIndex = 10
        Me.pnlbrown5.Visible = False
        '
        'pnlbrown3
        '
        Me.pnlbrown3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown3.Location = New System.Drawing.Point(129, 8)
        Me.pnlbrown3.Name = "pnlbrown3"
        Me.pnlbrown3.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown3.TabIndex = 6
        Me.pnlbrown3.Visible = False
        '
        'pnlbrown1
        '
        Me.pnlbrown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbrown1.Location = New System.Drawing.Point(77, 8)
        Me.pnlbrown1.Name = "pnlbrown1"
        Me.pnlbrown1.Size = New System.Drawing.Size(20, 13)
        Me.pnlbrown1.TabIndex = 2
        Me.pnlbrown1.Visible = False
        '
        'lblbrownlevel
        '
        Me.lblbrownlevel.AutoSize = True
        Me.lblbrownlevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbrownlevel.Location = New System.Drawing.Point(5, 25)
        Me.lblbrownlevel.Name = "lblbrownlevel"
        Me.lblbrownlevel.Size = New System.Drawing.Size(49, 15)
        Me.lblbrownlevel.TabIndex = 1
        Me.lblbrownlevel.Text = "Level: 4"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(3, 2)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(67, 23)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Brown"
        '
        'pnlorangecolours
        '
        Me.pnlorangecolours.BackColor = System.Drawing.Color.White
        Me.pnlorangecolours.Controls.Add(Me.pnlorangeoptions)
        Me.pnlorangecolours.Controls.Add(Me.pnlorangecustomcolour)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange16)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange12)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange14)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange10)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange8)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange4)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange6)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange15)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange2)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange13)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange11)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange7)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange9)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange5)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange3)
        Me.pnlorangecolours.Controls.Add(Me.pnlorange1)
        Me.pnlorangecolours.Controls.Add(Me.lblorangelevel)
        Me.pnlorangecolours.Controls.Add(Me.Label13)
        Me.pnlorangecolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlorangecolours.Location = New System.Drawing.Point(0, 383)
        Me.pnlorangecolours.Name = "pnlorangecolours"
        Me.pnlorangecolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlorangecolours.TabIndex = 7
        Me.pnlorangecolours.Visible = False
        '
        'pnlorangeoptions
        '
        Me.pnlorangeoptions.Controls.Add(Me.Label25)
        Me.pnlorangeoptions.Controls.Add(Me.txtorangesblue)
        Me.pnlorangeoptions.Controls.Add(Me.txtorangesred)
        Me.pnlorangeoptions.Controls.Add(Me.Label27)
        Me.pnlorangeoptions.Controls.Add(Me.Label28)
        Me.pnlorangeoptions.Controls.Add(Me.txtorangesgreen)
        Me.pnlorangeoptions.Location = New System.Drawing.Point(282, 3)
        Me.pnlorangeoptions.Name = "pnlorangeoptions"
        Me.pnlorangeoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlorangeoptions.TabIndex = 30
        Me.pnlorangeoptions.Visible = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Location = New System.Drawing.Point(64, 24)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(31, 13)
        Me.Label25.TabIndex = 26
        Me.Label25.Text = "Blue:"
        '
        'txtorangesblue
        '
        Me.txtorangesblue.BackColor = System.Drawing.Color.White
        Me.txtorangesblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtorangesblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorangesblue.Location = New System.Drawing.Point(95, 22)
        Me.txtorangesblue.Multiline = True
        Me.txtorangesblue.Name = "txtorangesblue"
        Me.txtorangesblue.Size = New System.Drawing.Size(23, 17)
        Me.txtorangesblue.TabIndex = 25
        Me.txtorangesblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtorangesred
        '
        Me.txtorangesred.BackColor = System.Drawing.Color.White
        Me.txtorangesred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtorangesred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorangesred.Location = New System.Drawing.Point(64, 2)
        Me.txtorangesred.Multiline = True
        Me.txtorangesred.Name = "txtorangesred"
        Me.txtorangesred.Size = New System.Drawing.Size(23, 17)
        Me.txtorangesred.TabIndex = 21
        Me.txtorangesred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Location = New System.Drawing.Point(1, 23)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(39, 13)
        Me.Label27.TabIndex = 24
        Me.Label27.Text = "Green:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Location = New System.Drawing.Point(33, 4)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(30, 13)
        Me.Label28.TabIndex = 22
        Me.Label28.Text = "Red:"
        '
        'txtorangesgreen
        '
        Me.txtorangesgreen.BackColor = System.Drawing.Color.White
        Me.txtorangesgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtorangesgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorangesgreen.Location = New System.Drawing.Point(40, 22)
        Me.txtorangesgreen.Multiline = True
        Me.txtorangesgreen.Name = "txtorangesgreen"
        Me.txtorangesgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtorangesgreen.TabIndex = 23
        Me.txtorangesgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlorangecustomcolour
        '
        Me.pnlorangecustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorangecustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlorangecustomcolour.Name = "pnlorangecustomcolour"
        Me.pnlorangecustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlorangecustomcolour.TabIndex = 18
        Me.pnlorangecustomcolour.Visible = False
        '
        'pnlorange16
        '
        Me.pnlorange16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange16.Location = New System.Drawing.Point(259, 25)
        Me.pnlorange16.Name = "pnlorange16"
        Me.pnlorange16.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange16.TabIndex = 17
        Me.pnlorange16.Visible = False
        '
        'pnlorange12
        '
        Me.pnlorange12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange12.Location = New System.Drawing.Point(155, 25)
        Me.pnlorange12.Name = "pnlorange12"
        Me.pnlorange12.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange12.TabIndex = 9
        Me.pnlorange12.Visible = False
        '
        'pnlorange14
        '
        Me.pnlorange14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange14.Location = New System.Drawing.Point(207, 25)
        Me.pnlorange14.Name = "pnlorange14"
        Me.pnlorange14.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange14.TabIndex = 13
        Me.pnlorange14.Visible = False
        '
        'pnlorange10
        '
        Me.pnlorange10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange10.Location = New System.Drawing.Point(103, 25)
        Me.pnlorange10.Name = "pnlorange10"
        Me.pnlorange10.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange10.TabIndex = 5
        Me.pnlorange10.Visible = False
        '
        'pnlorange8
        '
        Me.pnlorange8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange8.Location = New System.Drawing.Point(259, 8)
        Me.pnlorange8.Name = "pnlorange8"
        Me.pnlorange8.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange8.TabIndex = 16
        Me.pnlorange8.Visible = False
        '
        'pnlorange4
        '
        Me.pnlorange4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange4.Location = New System.Drawing.Point(155, 8)
        Me.pnlorange4.Name = "pnlorange4"
        Me.pnlorange4.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange4.TabIndex = 8
        Me.pnlorange4.Visible = False
        '
        'pnlorange6
        '
        Me.pnlorange6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange6.Location = New System.Drawing.Point(207, 8)
        Me.pnlorange6.Name = "pnlorange6"
        Me.pnlorange6.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange6.TabIndex = 12
        Me.pnlorange6.Visible = False
        '
        'pnlorange15
        '
        Me.pnlorange15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange15.Location = New System.Drawing.Point(233, 25)
        Me.pnlorange15.Name = "pnlorange15"
        Me.pnlorange15.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange15.TabIndex = 15
        Me.pnlorange15.Visible = False
        '
        'pnlorange2
        '
        Me.pnlorange2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange2.Location = New System.Drawing.Point(103, 8)
        Me.pnlorange2.Name = "pnlorange2"
        Me.pnlorange2.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange2.TabIndex = 4
        Me.pnlorange2.Visible = False
        '
        'pnlorange13
        '
        Me.pnlorange13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange13.Location = New System.Drawing.Point(181, 25)
        Me.pnlorange13.Name = "pnlorange13"
        Me.pnlorange13.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange13.TabIndex = 11
        Me.pnlorange13.Visible = False
        '
        'pnlorange11
        '
        Me.pnlorange11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange11.Location = New System.Drawing.Point(129, 25)
        Me.pnlorange11.Name = "pnlorange11"
        Me.pnlorange11.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange11.TabIndex = 7
        Me.pnlorange11.Visible = False
        '
        'pnlorange7
        '
        Me.pnlorange7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange7.Location = New System.Drawing.Point(233, 8)
        Me.pnlorange7.Name = "pnlorange7"
        Me.pnlorange7.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange7.TabIndex = 14
        Me.pnlorange7.Visible = False
        '
        'pnlorange9
        '
        Me.pnlorange9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange9.Location = New System.Drawing.Point(77, 25)
        Me.pnlorange9.Name = "pnlorange9"
        Me.pnlorange9.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange9.TabIndex = 3
        Me.pnlorange9.Visible = False
        '
        'pnlorange5
        '
        Me.pnlorange5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange5.Location = New System.Drawing.Point(181, 8)
        Me.pnlorange5.Name = "pnlorange5"
        Me.pnlorange5.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange5.TabIndex = 10
        Me.pnlorange5.Visible = False
        '
        'pnlorange3
        '
        Me.pnlorange3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange3.Location = New System.Drawing.Point(129, 8)
        Me.pnlorange3.Name = "pnlorange3"
        Me.pnlorange3.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange3.TabIndex = 6
        Me.pnlorange3.Visible = False
        '
        'pnlorange1
        '
        Me.pnlorange1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlorange1.Location = New System.Drawing.Point(77, 8)
        Me.pnlorange1.Name = "pnlorange1"
        Me.pnlorange1.Size = New System.Drawing.Size(20, 13)
        Me.pnlorange1.TabIndex = 2
        Me.pnlorange1.Visible = False
        '
        'lblorangelevel
        '
        Me.lblorangelevel.AutoSize = True
        Me.lblorangelevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblorangelevel.Location = New System.Drawing.Point(5, 25)
        Me.lblorangelevel.Name = "lblorangelevel"
        Me.lblorangelevel.Size = New System.Drawing.Size(49, 15)
        Me.lblorangelevel.TabIndex = 1
        Me.lblorangelevel.Text = "Level: 4"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(3, 2)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(74, 23)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Orange"
        '
        'pnlyellowcolours
        '
        Me.pnlyellowcolours.BackColor = System.Drawing.Color.White
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellowoptions)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellowcustomcolour)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow16)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow12)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow14)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow10)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow8)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow4)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow6)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow15)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow2)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow13)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow11)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow7)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow9)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow5)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow3)
        Me.pnlyellowcolours.Controls.Add(Me.pnlyellow1)
        Me.pnlyellowcolours.Controls.Add(Me.lblyellowlevel)
        Me.pnlyellowcolours.Controls.Add(Me.Label11)
        Me.pnlyellowcolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlyellowcolours.Location = New System.Drawing.Point(0, 337)
        Me.pnlyellowcolours.Name = "pnlyellowcolours"
        Me.pnlyellowcolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlyellowcolours.TabIndex = 6
        Me.pnlyellowcolours.Visible = False
        '
        'pnlyellowoptions
        '
        Me.pnlyellowoptions.Controls.Add(Me.Label20)
        Me.pnlyellowoptions.Controls.Add(Me.txtyellowsblue)
        Me.pnlyellowoptions.Controls.Add(Me.txtyellowsred)
        Me.pnlyellowoptions.Controls.Add(Me.Label22)
        Me.pnlyellowoptions.Controls.Add(Me.Label24)
        Me.pnlyellowoptions.Controls.Add(Me.txtyellowsgreen)
        Me.pnlyellowoptions.Location = New System.Drawing.Point(282, 3)
        Me.pnlyellowoptions.Name = "pnlyellowoptions"
        Me.pnlyellowoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlyellowoptions.TabIndex = 29
        Me.pnlyellowoptions.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Location = New System.Drawing.Point(64, 24)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(31, 13)
        Me.Label20.TabIndex = 26
        Me.Label20.Text = "Blue:"
        '
        'txtyellowsblue
        '
        Me.txtyellowsblue.BackColor = System.Drawing.Color.White
        Me.txtyellowsblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyellowsblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyellowsblue.Location = New System.Drawing.Point(95, 22)
        Me.txtyellowsblue.Multiline = True
        Me.txtyellowsblue.Name = "txtyellowsblue"
        Me.txtyellowsblue.Size = New System.Drawing.Size(23, 17)
        Me.txtyellowsblue.TabIndex = 25
        Me.txtyellowsblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtyellowsred
        '
        Me.txtyellowsred.BackColor = System.Drawing.Color.White
        Me.txtyellowsred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyellowsred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyellowsred.Location = New System.Drawing.Point(64, 2)
        Me.txtyellowsred.Multiline = True
        Me.txtyellowsred.Name = "txtyellowsred"
        Me.txtyellowsred.Size = New System.Drawing.Size(23, 17)
        Me.txtyellowsred.TabIndex = 21
        Me.txtyellowsred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Location = New System.Drawing.Point(1, 23)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(39, 13)
        Me.Label22.TabIndex = 24
        Me.Label22.Text = "Green:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Location = New System.Drawing.Point(33, 4)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(30, 13)
        Me.Label24.TabIndex = 22
        Me.Label24.Text = "Red:"
        '
        'txtyellowsgreen
        '
        Me.txtyellowsgreen.BackColor = System.Drawing.Color.White
        Me.txtyellowsgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyellowsgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyellowsgreen.Location = New System.Drawing.Point(40, 22)
        Me.txtyellowsgreen.Multiline = True
        Me.txtyellowsgreen.Name = "txtyellowsgreen"
        Me.txtyellowsgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtyellowsgreen.TabIndex = 23
        Me.txtyellowsgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlyellowcustomcolour
        '
        Me.pnlyellowcustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellowcustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlyellowcustomcolour.Name = "pnlyellowcustomcolour"
        Me.pnlyellowcustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlyellowcustomcolour.TabIndex = 18
        Me.pnlyellowcustomcolour.Visible = False
        '
        'pnlyellow16
        '
        Me.pnlyellow16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow16.Location = New System.Drawing.Point(259, 25)
        Me.pnlyellow16.Name = "pnlyellow16"
        Me.pnlyellow16.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow16.TabIndex = 17
        Me.pnlyellow16.Visible = False
        '
        'pnlyellow12
        '
        Me.pnlyellow12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow12.Location = New System.Drawing.Point(155, 25)
        Me.pnlyellow12.Name = "pnlyellow12"
        Me.pnlyellow12.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow12.TabIndex = 9
        Me.pnlyellow12.Visible = False
        '
        'pnlyellow14
        '
        Me.pnlyellow14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow14.Location = New System.Drawing.Point(207, 25)
        Me.pnlyellow14.Name = "pnlyellow14"
        Me.pnlyellow14.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow14.TabIndex = 13
        Me.pnlyellow14.Visible = False
        '
        'pnlyellow10
        '
        Me.pnlyellow10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow10.Location = New System.Drawing.Point(103, 25)
        Me.pnlyellow10.Name = "pnlyellow10"
        Me.pnlyellow10.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow10.TabIndex = 5
        Me.pnlyellow10.Visible = False
        '
        'pnlyellow8
        '
        Me.pnlyellow8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow8.Location = New System.Drawing.Point(259, 8)
        Me.pnlyellow8.Name = "pnlyellow8"
        Me.pnlyellow8.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow8.TabIndex = 16
        Me.pnlyellow8.Visible = False
        '
        'pnlyellow4
        '
        Me.pnlyellow4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow4.Location = New System.Drawing.Point(155, 8)
        Me.pnlyellow4.Name = "pnlyellow4"
        Me.pnlyellow4.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow4.TabIndex = 8
        Me.pnlyellow4.Visible = False
        '
        'pnlyellow6
        '
        Me.pnlyellow6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow6.Location = New System.Drawing.Point(207, 8)
        Me.pnlyellow6.Name = "pnlyellow6"
        Me.pnlyellow6.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow6.TabIndex = 12
        Me.pnlyellow6.Visible = False
        '
        'pnlyellow15
        '
        Me.pnlyellow15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow15.Location = New System.Drawing.Point(233, 25)
        Me.pnlyellow15.Name = "pnlyellow15"
        Me.pnlyellow15.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow15.TabIndex = 15
        Me.pnlyellow15.Visible = False
        '
        'pnlyellow2
        '
        Me.pnlyellow2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow2.Location = New System.Drawing.Point(103, 8)
        Me.pnlyellow2.Name = "pnlyellow2"
        Me.pnlyellow2.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow2.TabIndex = 4
        Me.pnlyellow2.Visible = False
        '
        'pnlyellow13
        '
        Me.pnlyellow13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow13.Location = New System.Drawing.Point(181, 25)
        Me.pnlyellow13.Name = "pnlyellow13"
        Me.pnlyellow13.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow13.TabIndex = 11
        Me.pnlyellow13.Visible = False
        '
        'pnlyellow11
        '
        Me.pnlyellow11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow11.Location = New System.Drawing.Point(129, 25)
        Me.pnlyellow11.Name = "pnlyellow11"
        Me.pnlyellow11.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow11.TabIndex = 7
        Me.pnlyellow11.Visible = False
        '
        'pnlyellow7
        '
        Me.pnlyellow7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow7.Location = New System.Drawing.Point(233, 8)
        Me.pnlyellow7.Name = "pnlyellow7"
        Me.pnlyellow7.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow7.TabIndex = 14
        Me.pnlyellow7.Visible = False
        '
        'pnlyellow9
        '
        Me.pnlyellow9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow9.Location = New System.Drawing.Point(77, 25)
        Me.pnlyellow9.Name = "pnlyellow9"
        Me.pnlyellow9.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow9.TabIndex = 3
        Me.pnlyellow9.Visible = False
        '
        'pnlyellow5
        '
        Me.pnlyellow5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow5.Location = New System.Drawing.Point(181, 8)
        Me.pnlyellow5.Name = "pnlyellow5"
        Me.pnlyellow5.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow5.TabIndex = 10
        Me.pnlyellow5.Visible = False
        '
        'pnlyellow3
        '
        Me.pnlyellow3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow3.Location = New System.Drawing.Point(129, 8)
        Me.pnlyellow3.Name = "pnlyellow3"
        Me.pnlyellow3.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow3.TabIndex = 6
        Me.pnlyellow3.Visible = False
        '
        'pnlyellow1
        '
        Me.pnlyellow1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlyellow1.Location = New System.Drawing.Point(77, 8)
        Me.pnlyellow1.Name = "pnlyellow1"
        Me.pnlyellow1.Size = New System.Drawing.Size(20, 13)
        Me.pnlyellow1.TabIndex = 2
        Me.pnlyellow1.Visible = False
        '
        'lblyellowlevel
        '
        Me.lblyellowlevel.AutoSize = True
        Me.lblyellowlevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblyellowlevel.Location = New System.Drawing.Point(5, 25)
        Me.lblyellowlevel.Name = "lblyellowlevel"
        Me.lblyellowlevel.Size = New System.Drawing.Size(49, 15)
        Me.lblyellowlevel.TabIndex = 1
        Me.lblyellowlevel.Text = "Level: 4"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(3, 2)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 23)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Yellow"
        '
        'pnlgreencolours
        '
        Me.pnlgreencolours.BackColor = System.Drawing.Color.White
        Me.pnlgreencolours.Controls.Add(Me.pnlgreenoptions)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreencustomcolour)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen16)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen12)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen14)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen10)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen8)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen4)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen6)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen15)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen2)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen13)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen11)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen7)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen9)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen5)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen3)
        Me.pnlgreencolours.Controls.Add(Me.pnlgreen1)
        Me.pnlgreencolours.Controls.Add(Me.lblgreenlevel)
        Me.pnlgreencolours.Controls.Add(Me.Label9)
        Me.pnlgreencolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlgreencolours.Location = New System.Drawing.Point(0, 291)
        Me.pnlgreencolours.Name = "pnlgreencolours"
        Me.pnlgreencolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlgreencolours.TabIndex = 5
        Me.pnlgreencolours.Visible = False
        '
        'pnlgreenoptions
        '
        Me.pnlgreenoptions.Controls.Add(Me.Label15)
        Me.pnlgreenoptions.Controls.Add(Me.txtgreensred)
        Me.pnlgreenoptions.Controls.Add(Me.txtgreensgreen)
        Me.pnlgreenoptions.Controls.Add(Me.Label16)
        Me.pnlgreenoptions.Controls.Add(Me.Label18)
        Me.pnlgreenoptions.Controls.Add(Me.txtgreensblue)
        Me.pnlgreenoptions.Location = New System.Drawing.Point(282, 3)
        Me.pnlgreenoptions.Name = "pnlgreenoptions"
        Me.pnlgreenoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlgreenoptions.TabIndex = 29
        Me.pnlgreenoptions.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Location = New System.Drawing.Point(62, 24)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(30, 13)
        Me.Label15.TabIndex = 26
        Me.Label15.Text = "Red:"
        '
        'txtgreensred
        '
        Me.txtgreensred.BackColor = System.Drawing.Color.White
        Me.txtgreensred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgreensred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgreensred.Location = New System.Drawing.Point(92, 22)
        Me.txtgreensred.Multiline = True
        Me.txtgreensred.Name = "txtgreensred"
        Me.txtgreensred.Size = New System.Drawing.Size(23, 17)
        Me.txtgreensred.TabIndex = 25
        Me.txtgreensred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtgreensgreen
        '
        Me.txtgreensgreen.BackColor = System.Drawing.Color.White
        Me.txtgreensgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgreensgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgreensgreen.Location = New System.Drawing.Point(66, 2)
        Me.txtgreensgreen.Multiline = True
        Me.txtgreensgreen.Name = "txtgreensgreen"
        Me.txtgreensgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtgreensgreen.TabIndex = 21
        Me.txtgreensgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Location = New System.Drawing.Point(2, 23)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(31, 13)
        Me.Label16.TabIndex = 24
        Me.Label16.Text = "Blue:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Location = New System.Drawing.Point(28, 4)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(39, 13)
        Me.Label18.TabIndex = 22
        Me.Label18.Text = "Green:"
        '
        'txtgreensblue
        '
        Me.txtgreensblue.BackColor = System.Drawing.Color.White
        Me.txtgreensblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgreensblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgreensblue.Location = New System.Drawing.Point(33, 22)
        Me.txtgreensblue.Multiline = True
        Me.txtgreensblue.Name = "txtgreensblue"
        Me.txtgreensblue.Size = New System.Drawing.Size(23, 17)
        Me.txtgreensblue.TabIndex = 23
        Me.txtgreensblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlgreencustomcolour
        '
        Me.pnlgreencustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreencustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlgreencustomcolour.Name = "pnlgreencustomcolour"
        Me.pnlgreencustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlgreencustomcolour.TabIndex = 18
        Me.pnlgreencustomcolour.Visible = False
        '
        'pnlgreen16
        '
        Me.pnlgreen16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen16.Location = New System.Drawing.Point(259, 25)
        Me.pnlgreen16.Name = "pnlgreen16"
        Me.pnlgreen16.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen16.TabIndex = 17
        Me.pnlgreen16.Visible = False
        '
        'pnlgreen12
        '
        Me.pnlgreen12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen12.Location = New System.Drawing.Point(155, 25)
        Me.pnlgreen12.Name = "pnlgreen12"
        Me.pnlgreen12.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen12.TabIndex = 9
        Me.pnlgreen12.Visible = False
        '
        'pnlgreen14
        '
        Me.pnlgreen14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen14.Location = New System.Drawing.Point(207, 25)
        Me.pnlgreen14.Name = "pnlgreen14"
        Me.pnlgreen14.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen14.TabIndex = 13
        Me.pnlgreen14.Visible = False
        '
        'pnlgreen10
        '
        Me.pnlgreen10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen10.Location = New System.Drawing.Point(103, 25)
        Me.pnlgreen10.Name = "pnlgreen10"
        Me.pnlgreen10.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen10.TabIndex = 5
        Me.pnlgreen10.Visible = False
        '
        'pnlgreen8
        '
        Me.pnlgreen8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen8.Location = New System.Drawing.Point(259, 8)
        Me.pnlgreen8.Name = "pnlgreen8"
        Me.pnlgreen8.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen8.TabIndex = 16
        Me.pnlgreen8.Visible = False
        '
        'pnlgreen4
        '
        Me.pnlgreen4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen4.Location = New System.Drawing.Point(155, 8)
        Me.pnlgreen4.Name = "pnlgreen4"
        Me.pnlgreen4.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen4.TabIndex = 8
        Me.pnlgreen4.Visible = False
        '
        'pnlgreen6
        '
        Me.pnlgreen6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen6.Location = New System.Drawing.Point(207, 8)
        Me.pnlgreen6.Name = "pnlgreen6"
        Me.pnlgreen6.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen6.TabIndex = 12
        Me.pnlgreen6.Visible = False
        '
        'pnlgreen15
        '
        Me.pnlgreen15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen15.Location = New System.Drawing.Point(233, 25)
        Me.pnlgreen15.Name = "pnlgreen15"
        Me.pnlgreen15.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen15.TabIndex = 15
        Me.pnlgreen15.Visible = False
        '
        'pnlgreen2
        '
        Me.pnlgreen2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen2.Location = New System.Drawing.Point(103, 8)
        Me.pnlgreen2.Name = "pnlgreen2"
        Me.pnlgreen2.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen2.TabIndex = 4
        Me.pnlgreen2.Visible = False
        '
        'pnlgreen13
        '
        Me.pnlgreen13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen13.Location = New System.Drawing.Point(181, 25)
        Me.pnlgreen13.Name = "pnlgreen13"
        Me.pnlgreen13.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen13.TabIndex = 11
        Me.pnlgreen13.Visible = False
        '
        'pnlgreen11
        '
        Me.pnlgreen11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen11.Location = New System.Drawing.Point(129, 25)
        Me.pnlgreen11.Name = "pnlgreen11"
        Me.pnlgreen11.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen11.TabIndex = 7
        Me.pnlgreen11.Visible = False
        '
        'pnlgreen7
        '
        Me.pnlgreen7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen7.Location = New System.Drawing.Point(233, 8)
        Me.pnlgreen7.Name = "pnlgreen7"
        Me.pnlgreen7.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen7.TabIndex = 14
        Me.pnlgreen7.Visible = False
        '
        'pnlgreen9
        '
        Me.pnlgreen9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen9.Location = New System.Drawing.Point(77, 25)
        Me.pnlgreen9.Name = "pnlgreen9"
        Me.pnlgreen9.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen9.TabIndex = 3
        Me.pnlgreen9.Visible = False
        '
        'pnlgreen5
        '
        Me.pnlgreen5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen5.Location = New System.Drawing.Point(181, 8)
        Me.pnlgreen5.Name = "pnlgreen5"
        Me.pnlgreen5.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen5.TabIndex = 10
        Me.pnlgreen5.Visible = False
        '
        'pnlgreen3
        '
        Me.pnlgreen3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen3.Location = New System.Drawing.Point(129, 8)
        Me.pnlgreen3.Name = "pnlgreen3"
        Me.pnlgreen3.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen3.TabIndex = 6
        Me.pnlgreen3.Visible = False
        '
        'pnlgreen1
        '
        Me.pnlgreen1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgreen1.Location = New System.Drawing.Point(77, 8)
        Me.pnlgreen1.Name = "pnlgreen1"
        Me.pnlgreen1.Size = New System.Drawing.Size(20, 13)
        Me.pnlgreen1.TabIndex = 2
        Me.pnlgreen1.Visible = False
        '
        'lblgreenlevel
        '
        Me.lblgreenlevel.AutoSize = True
        Me.lblgreenlevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgreenlevel.Location = New System.Drawing.Point(5, 25)
        Me.lblgreenlevel.Name = "lblgreenlevel"
        Me.lblgreenlevel.Size = New System.Drawing.Size(49, 15)
        Me.lblgreenlevel.TabIndex = 1
        Me.lblgreenlevel.Text = "Level: 4"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 23)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Green"
        '
        'pnlbluecolours
        '
        Me.pnlbluecolours.BackColor = System.Drawing.Color.White
        Me.pnlbluecolours.Controls.Add(Me.pnlblueoptions)
        Me.pnlbluecolours.Controls.Add(Me.pnlbluecustomcolour)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue16)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue12)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue14)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue10)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue8)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue4)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue6)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue15)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue2)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue13)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue11)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue7)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue9)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue5)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue3)
        Me.pnlbluecolours.Controls.Add(Me.pnlblue1)
        Me.pnlbluecolours.Controls.Add(Me.lblbluelevel)
        Me.pnlbluecolours.Controls.Add(Me.Label7)
        Me.pnlbluecolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlbluecolours.Location = New System.Drawing.Point(0, 245)
        Me.pnlbluecolours.Name = "pnlbluecolours"
        Me.pnlbluecolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlbluecolours.TabIndex = 4
        Me.pnlbluecolours.Visible = False
        '
        'pnlblueoptions
        '
        Me.pnlblueoptions.Controls.Add(Me.Label6)
        Me.pnlblueoptions.Controls.Add(Me.txtbluesred)
        Me.pnlblueoptions.Controls.Add(Me.txtbluesblue)
        Me.pnlblueoptions.Controls.Add(Me.Label4)
        Me.pnlblueoptions.Controls.Add(Me.Label2)
        Me.pnlblueoptions.Controls.Add(Me.txtbluesgreen)
        Me.pnlblueoptions.Location = New System.Drawing.Point(282, 3)
        Me.pnlblueoptions.Name = "pnlblueoptions"
        Me.pnlblueoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlblueoptions.TabIndex = 27
        Me.pnlblueoptions.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(65, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 13)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "Red:"
        '
        'txtbluesred
        '
        Me.txtbluesred.BackColor = System.Drawing.Color.White
        Me.txtbluesred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbluesred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbluesred.Location = New System.Drawing.Point(95, 22)
        Me.txtbluesred.Multiline = True
        Me.txtbluesred.Name = "txtbluesred"
        Me.txtbluesred.Size = New System.Drawing.Size(23, 17)
        Me.txtbluesred.TabIndex = 25
        Me.txtbluesred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtbluesblue
        '
        Me.txtbluesblue.BackColor = System.Drawing.Color.White
        Me.txtbluesblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbluesblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbluesblue.Location = New System.Drawing.Point(65, 2)
        Me.txtbluesblue.Multiline = True
        Me.txtbluesblue.Name = "txtbluesblue"
        Me.txtbluesblue.Size = New System.Drawing.Size(23, 17)
        Me.txtbluesblue.TabIndex = 21
        Me.txtbluesblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(2, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Green:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(33, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Blue:"
        '
        'txtbluesgreen
        '
        Me.txtbluesgreen.BackColor = System.Drawing.Color.White
        Me.txtbluesgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbluesgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbluesgreen.Location = New System.Drawing.Point(41, 22)
        Me.txtbluesgreen.Multiline = True
        Me.txtbluesgreen.Name = "txtbluesgreen"
        Me.txtbluesgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtbluesgreen.TabIndex = 23
        Me.txtbluesgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlbluecustomcolour
        '
        Me.pnlbluecustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlbluecustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlbluecustomcolour.Name = "pnlbluecustomcolour"
        Me.pnlbluecustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlbluecustomcolour.TabIndex = 18
        Me.pnlbluecustomcolour.Visible = False
        '
        'pnlblue16
        '
        Me.pnlblue16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue16.Location = New System.Drawing.Point(259, 25)
        Me.pnlblue16.Name = "pnlblue16"
        Me.pnlblue16.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue16.TabIndex = 17
        Me.pnlblue16.Visible = False
        '
        'pnlblue12
        '
        Me.pnlblue12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue12.Location = New System.Drawing.Point(155, 25)
        Me.pnlblue12.Name = "pnlblue12"
        Me.pnlblue12.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue12.TabIndex = 9
        Me.pnlblue12.Visible = False
        '
        'pnlblue14
        '
        Me.pnlblue14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue14.Location = New System.Drawing.Point(207, 25)
        Me.pnlblue14.Name = "pnlblue14"
        Me.pnlblue14.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue14.TabIndex = 13
        Me.pnlblue14.Visible = False
        '
        'pnlblue10
        '
        Me.pnlblue10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue10.Location = New System.Drawing.Point(103, 25)
        Me.pnlblue10.Name = "pnlblue10"
        Me.pnlblue10.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue10.TabIndex = 5
        Me.pnlblue10.Visible = False
        '
        'pnlblue8
        '
        Me.pnlblue8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue8.Location = New System.Drawing.Point(259, 8)
        Me.pnlblue8.Name = "pnlblue8"
        Me.pnlblue8.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue8.TabIndex = 16
        Me.pnlblue8.Visible = False
        '
        'pnlblue4
        '
        Me.pnlblue4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue4.Location = New System.Drawing.Point(155, 8)
        Me.pnlblue4.Name = "pnlblue4"
        Me.pnlblue4.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue4.TabIndex = 8
        Me.pnlblue4.Visible = False
        '
        'pnlblue6
        '
        Me.pnlblue6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue6.Location = New System.Drawing.Point(207, 8)
        Me.pnlblue6.Name = "pnlblue6"
        Me.pnlblue6.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue6.TabIndex = 12
        Me.pnlblue6.Visible = False
        '
        'pnlblue15
        '
        Me.pnlblue15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue15.Location = New System.Drawing.Point(233, 25)
        Me.pnlblue15.Name = "pnlblue15"
        Me.pnlblue15.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue15.TabIndex = 15
        Me.pnlblue15.Visible = False
        '
        'pnlblue2
        '
        Me.pnlblue2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue2.Location = New System.Drawing.Point(103, 8)
        Me.pnlblue2.Name = "pnlblue2"
        Me.pnlblue2.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue2.TabIndex = 4
        Me.pnlblue2.Visible = False
        '
        'pnlblue13
        '
        Me.pnlblue13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue13.Location = New System.Drawing.Point(181, 25)
        Me.pnlblue13.Name = "pnlblue13"
        Me.pnlblue13.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue13.TabIndex = 11
        Me.pnlblue13.Visible = False
        '
        'pnlblue11
        '
        Me.pnlblue11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue11.Location = New System.Drawing.Point(129, 25)
        Me.pnlblue11.Name = "pnlblue11"
        Me.pnlblue11.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue11.TabIndex = 7
        Me.pnlblue11.Visible = False
        '
        'pnlblue7
        '
        Me.pnlblue7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue7.Location = New System.Drawing.Point(233, 8)
        Me.pnlblue7.Name = "pnlblue7"
        Me.pnlblue7.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue7.TabIndex = 14
        Me.pnlblue7.Visible = False
        '
        'pnlblue9
        '
        Me.pnlblue9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue9.Location = New System.Drawing.Point(77, 25)
        Me.pnlblue9.Name = "pnlblue9"
        Me.pnlblue9.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue9.TabIndex = 3
        Me.pnlblue9.Visible = False
        '
        'pnlblue5
        '
        Me.pnlblue5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue5.Location = New System.Drawing.Point(181, 8)
        Me.pnlblue5.Name = "pnlblue5"
        Me.pnlblue5.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue5.TabIndex = 10
        Me.pnlblue5.Visible = False
        '
        'pnlblue3
        '
        Me.pnlblue3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue3.Location = New System.Drawing.Point(129, 8)
        Me.pnlblue3.Name = "pnlblue3"
        Me.pnlblue3.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue3.TabIndex = 6
        Me.pnlblue3.Visible = False
        '
        'pnlblue1
        '
        Me.pnlblue1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlblue1.Location = New System.Drawing.Point(77, 8)
        Me.pnlblue1.Name = "pnlblue1"
        Me.pnlblue1.Size = New System.Drawing.Size(20, 13)
        Me.pnlblue1.TabIndex = 2
        Me.pnlblue1.Visible = False
        '
        'lblbluelevel
        '
        Me.lblbluelevel.AutoSize = True
        Me.lblbluelevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbluelevel.Location = New System.Drawing.Point(5, 25)
        Me.lblbluelevel.Name = "lblbluelevel"
        Me.lblbluelevel.Size = New System.Drawing.Size(49, 15)
        Me.lblbluelevel.TabIndex = 1
        Me.lblbluelevel.Text = "Level: 4"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(3, 2)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 23)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Blue"
        '
        'pnlpurplecolours
        '
        Me.pnlpurplecolours.BackColor = System.Drawing.Color.White
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurpleoptions)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurplecustomcolour)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple16)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple12)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple14)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple10)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple8)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple4)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple6)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple15)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple2)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple13)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple11)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple7)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple9)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple5)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple3)
        Me.pnlpurplecolours.Controls.Add(Me.pnlpurple1)
        Me.pnlpurplecolours.Controls.Add(Me.lblpurplelevel)
        Me.pnlpurplecolours.Controls.Add(Me.Label5)
        Me.pnlpurplecolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlpurplecolours.Location = New System.Drawing.Point(0, 199)
        Me.pnlpurplecolours.Name = "pnlpurplecolours"
        Me.pnlpurplecolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlpurplecolours.TabIndex = 3
        Me.pnlpurplecolours.Visible = False
        '
        'pnlpurpleoptions
        '
        Me.pnlpurpleoptions.Controls.Add(Me.Label8)
        Me.pnlpurpleoptions.Controls.Add(Me.txtpurplesgreen)
        Me.pnlpurpleoptions.Controls.Add(Me.txtpurplesblue)
        Me.pnlpurpleoptions.Controls.Add(Me.Label10)
        Me.pnlpurpleoptions.Controls.Add(Me.Label12)
        Me.pnlpurpleoptions.Controls.Add(Me.txtpurplesred)
        Me.pnlpurpleoptions.Location = New System.Drawing.Point(282, 3)
        Me.pnlpurpleoptions.Name = "pnlpurpleoptions"
        Me.pnlpurpleoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlpurpleoptions.TabIndex = 28
        Me.pnlpurpleoptions.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(56, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "Green:"
        '
        'txtpurplesgreen
        '
        Me.txtpurplesgreen.BackColor = System.Drawing.Color.White
        Me.txtpurplesgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpurplesgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpurplesgreen.Location = New System.Drawing.Point(95, 22)
        Me.txtpurplesgreen.Multiline = True
        Me.txtpurplesgreen.Name = "txtpurplesgreen"
        Me.txtpurplesgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtpurplesgreen.TabIndex = 25
        Me.txtpurplesgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtpurplesblue
        '
        Me.txtpurplesblue.BackColor = System.Drawing.Color.White
        Me.txtpurplesblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpurplesblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpurplesblue.Location = New System.Drawing.Point(65, 2)
        Me.txtpurplesblue.Multiline = True
        Me.txtpurplesblue.Name = "txtpurplesblue"
        Me.txtpurplesblue.Size = New System.Drawing.Size(23, 17)
        Me.txtpurplesblue.TabIndex = 21
        Me.txtpurplesblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(2, 23)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(30, 13)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "Red:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Location = New System.Drawing.Point(33, 4)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(31, 13)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Blue:"
        '
        'txtpurplesred
        '
        Me.txtpurplesred.BackColor = System.Drawing.Color.White
        Me.txtpurplesred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpurplesred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpurplesred.Location = New System.Drawing.Point(32, 22)
        Me.txtpurplesred.Multiline = True
        Me.txtpurplesred.Name = "txtpurplesred"
        Me.txtpurplesred.Size = New System.Drawing.Size(23, 17)
        Me.txtpurplesred.TabIndex = 23
        Me.txtpurplesred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlpurplecustomcolour
        '
        Me.pnlpurplecustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurplecustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlpurplecustomcolour.Name = "pnlpurplecustomcolour"
        Me.pnlpurplecustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlpurplecustomcolour.TabIndex = 18
        Me.pnlpurplecustomcolour.Visible = False
        '
        'pnlpurple16
        '
        Me.pnlpurple16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple16.Location = New System.Drawing.Point(259, 25)
        Me.pnlpurple16.Name = "pnlpurple16"
        Me.pnlpurple16.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple16.TabIndex = 17
        Me.pnlpurple16.Visible = False
        '
        'pnlpurple12
        '
        Me.pnlpurple12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple12.Location = New System.Drawing.Point(155, 25)
        Me.pnlpurple12.Name = "pnlpurple12"
        Me.pnlpurple12.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple12.TabIndex = 9
        Me.pnlpurple12.Visible = False
        '
        'pnlpurple14
        '
        Me.pnlpurple14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple14.Location = New System.Drawing.Point(207, 25)
        Me.pnlpurple14.Name = "pnlpurple14"
        Me.pnlpurple14.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple14.TabIndex = 13
        Me.pnlpurple14.Visible = False
        '
        'pnlpurple10
        '
        Me.pnlpurple10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple10.Location = New System.Drawing.Point(103, 25)
        Me.pnlpurple10.Name = "pnlpurple10"
        Me.pnlpurple10.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple10.TabIndex = 5
        Me.pnlpurple10.Visible = False
        '
        'pnlpurple8
        '
        Me.pnlpurple8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple8.Location = New System.Drawing.Point(259, 8)
        Me.pnlpurple8.Name = "pnlpurple8"
        Me.pnlpurple8.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple8.TabIndex = 16
        Me.pnlpurple8.Visible = False
        '
        'pnlpurple4
        '
        Me.pnlpurple4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple4.Location = New System.Drawing.Point(155, 8)
        Me.pnlpurple4.Name = "pnlpurple4"
        Me.pnlpurple4.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple4.TabIndex = 8
        Me.pnlpurple4.Visible = False
        '
        'pnlpurple6
        '
        Me.pnlpurple6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple6.Location = New System.Drawing.Point(207, 8)
        Me.pnlpurple6.Name = "pnlpurple6"
        Me.pnlpurple6.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple6.TabIndex = 12
        Me.pnlpurple6.Visible = False
        '
        'pnlpurple15
        '
        Me.pnlpurple15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple15.Location = New System.Drawing.Point(233, 25)
        Me.pnlpurple15.Name = "pnlpurple15"
        Me.pnlpurple15.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple15.TabIndex = 15
        Me.pnlpurple15.Visible = False
        '
        'pnlpurple2
        '
        Me.pnlpurple2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple2.Location = New System.Drawing.Point(103, 8)
        Me.pnlpurple2.Name = "pnlpurple2"
        Me.pnlpurple2.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple2.TabIndex = 4
        Me.pnlpurple2.Visible = False
        '
        'pnlpurple13
        '
        Me.pnlpurple13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple13.Location = New System.Drawing.Point(181, 25)
        Me.pnlpurple13.Name = "pnlpurple13"
        Me.pnlpurple13.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple13.TabIndex = 11
        Me.pnlpurple13.Visible = False
        '
        'pnlpurple11
        '
        Me.pnlpurple11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple11.Location = New System.Drawing.Point(129, 25)
        Me.pnlpurple11.Name = "pnlpurple11"
        Me.pnlpurple11.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple11.TabIndex = 7
        Me.pnlpurple11.Visible = False
        '
        'pnlpurple7
        '
        Me.pnlpurple7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple7.Location = New System.Drawing.Point(233, 8)
        Me.pnlpurple7.Name = "pnlpurple7"
        Me.pnlpurple7.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple7.TabIndex = 14
        Me.pnlpurple7.Visible = False
        '
        'pnlpurple9
        '
        Me.pnlpurple9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple9.Location = New System.Drawing.Point(77, 25)
        Me.pnlpurple9.Name = "pnlpurple9"
        Me.pnlpurple9.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple9.TabIndex = 3
        Me.pnlpurple9.Visible = False
        '
        'pnlpurple5
        '
        Me.pnlpurple5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple5.Location = New System.Drawing.Point(181, 8)
        Me.pnlpurple5.Name = "pnlpurple5"
        Me.pnlpurple5.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple5.TabIndex = 10
        Me.pnlpurple5.Visible = False
        '
        'pnlpurple3
        '
        Me.pnlpurple3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple3.Location = New System.Drawing.Point(129, 8)
        Me.pnlpurple3.Name = "pnlpurple3"
        Me.pnlpurple3.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple3.TabIndex = 6
        Me.pnlpurple3.Visible = False
        '
        'pnlpurple1
        '
        Me.pnlpurple1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlpurple1.Location = New System.Drawing.Point(77, 8)
        Me.pnlpurple1.Name = "pnlpurple1"
        Me.pnlpurple1.Size = New System.Drawing.Size(20, 13)
        Me.pnlpurple1.TabIndex = 2
        Me.pnlpurple1.Visible = False
        '
        'lblpurplelevel
        '
        Me.lblpurplelevel.AutoSize = True
        Me.lblpurplelevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpurplelevel.Location = New System.Drawing.Point(5, 25)
        Me.lblpurplelevel.Name = "lblpurplelevel"
        Me.lblpurplelevel.Size = New System.Drawing.Size(49, 15)
        Me.lblpurplelevel.TabIndex = 1
        Me.lblpurplelevel.Text = "Level: 4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(3, 2)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 23)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Purple"
        '
        'pnlgraycolours
        '
        Me.pnlgraycolours.BackColor = System.Drawing.Color.White
        Me.pnlgraycolours.Controls.Add(Me.lblcustomshadetut)
        Me.pnlgraycolours.Controls.Add(Me.txtcustomgrayshade)
        Me.pnlgraycolours.Controls.Add(Me.pnlgraycustomcolour)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray16)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray12)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray14)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray10)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray8)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray4)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray6)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray15)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray2)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray13)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray11)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray7)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray9)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray5)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray3)
        Me.pnlgraycolours.Controls.Add(Me.pnlgray1)
        Me.pnlgraycolours.Controls.Add(Me.lblgraylevel)
        Me.pnlgraycolours.Controls.Add(Me.Label3)
        Me.pnlgraycolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlgraycolours.Location = New System.Drawing.Point(0, 153)
        Me.pnlgraycolours.Name = "pnlgraycolours"
        Me.pnlgraycolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlgraycolours.TabIndex = 2
        Me.pnlgraycolours.Visible = False
        '
        'lblcustomshadetut
        '
        Me.lblcustomshadetut.AutoSize = True
        Me.lblcustomshadetut.BackColor = System.Drawing.Color.Transparent
        Me.lblcustomshadetut.Location = New System.Drawing.Point(290, 5)
        Me.lblcustomshadetut.Name = "lblcustomshadetut"
        Me.lblcustomshadetut.Size = New System.Drawing.Size(102, 13)
        Me.lblcustomshadetut.TabIndex = 20
        Me.lblcustomshadetut.Text = "Enter Shade (0-255)"
        Me.lblcustomshadetut.Visible = False
        '
        'txtcustomgrayshade
        '
        Me.txtcustomgrayshade.BackColor = System.Drawing.Color.White
        Me.txtcustomgrayshade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcustomgrayshade.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcustomgrayshade.Location = New System.Drawing.Point(317, 20)
        Me.txtcustomgrayshade.Multiline = True
        Me.txtcustomgrayshade.Name = "txtcustomgrayshade"
        Me.txtcustomgrayshade.Size = New System.Drawing.Size(45, 17)
        Me.txtcustomgrayshade.TabIndex = 19
        Me.txtcustomgrayshade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtcustomgrayshade.Visible = False
        '
        'pnlgraycustomcolour
        '
        Me.pnlgraycustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgraycustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlgraycustomcolour.Name = "pnlgraycustomcolour"
        Me.pnlgraycustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlgraycustomcolour.TabIndex = 18
        Me.pnlgraycustomcolour.Visible = False
        '
        'pnlgray16
        '
        Me.pnlgray16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray16.Location = New System.Drawing.Point(259, 25)
        Me.pnlgray16.Name = "pnlgray16"
        Me.pnlgray16.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray16.TabIndex = 17
        Me.pnlgray16.Visible = False
        '
        'pnlgray12
        '
        Me.pnlgray12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray12.Location = New System.Drawing.Point(155, 25)
        Me.pnlgray12.Name = "pnlgray12"
        Me.pnlgray12.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray12.TabIndex = 9
        Me.pnlgray12.Visible = False
        '
        'pnlgray14
        '
        Me.pnlgray14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray14.Location = New System.Drawing.Point(207, 25)
        Me.pnlgray14.Name = "pnlgray14"
        Me.pnlgray14.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray14.TabIndex = 13
        Me.pnlgray14.Visible = False
        '
        'pnlgray10
        '
        Me.pnlgray10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray10.Location = New System.Drawing.Point(103, 25)
        Me.pnlgray10.Name = "pnlgray10"
        Me.pnlgray10.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray10.TabIndex = 5
        Me.pnlgray10.Visible = False
        '
        'pnlgray8
        '
        Me.pnlgray8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray8.Location = New System.Drawing.Point(259, 8)
        Me.pnlgray8.Name = "pnlgray8"
        Me.pnlgray8.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray8.TabIndex = 16
        Me.pnlgray8.Visible = False
        '
        'pnlgray4
        '
        Me.pnlgray4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray4.Location = New System.Drawing.Point(155, 8)
        Me.pnlgray4.Name = "pnlgray4"
        Me.pnlgray4.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray4.TabIndex = 8
        Me.pnlgray4.Visible = False
        '
        'pnlgray6
        '
        Me.pnlgray6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray6.Location = New System.Drawing.Point(207, 8)
        Me.pnlgray6.Name = "pnlgray6"
        Me.pnlgray6.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray6.TabIndex = 12
        Me.pnlgray6.Visible = False
        '
        'pnlgray15
        '
        Me.pnlgray15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray15.Location = New System.Drawing.Point(233, 25)
        Me.pnlgray15.Name = "pnlgray15"
        Me.pnlgray15.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray15.TabIndex = 15
        Me.pnlgray15.Visible = False
        '
        'pnlgray2
        '
        Me.pnlgray2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray2.Location = New System.Drawing.Point(103, 8)
        Me.pnlgray2.Name = "pnlgray2"
        Me.pnlgray2.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray2.TabIndex = 4
        Me.pnlgray2.Visible = False
        '
        'pnlgray13
        '
        Me.pnlgray13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray13.Location = New System.Drawing.Point(181, 25)
        Me.pnlgray13.Name = "pnlgray13"
        Me.pnlgray13.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray13.TabIndex = 11
        Me.pnlgray13.Visible = False
        '
        'pnlgray11
        '
        Me.pnlgray11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray11.Location = New System.Drawing.Point(129, 25)
        Me.pnlgray11.Name = "pnlgray11"
        Me.pnlgray11.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray11.TabIndex = 7
        Me.pnlgray11.Visible = False
        '
        'pnlgray7
        '
        Me.pnlgray7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray7.Location = New System.Drawing.Point(233, 8)
        Me.pnlgray7.Name = "pnlgray7"
        Me.pnlgray7.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray7.TabIndex = 14
        Me.pnlgray7.Visible = False
        '
        'pnlgray9
        '
        Me.pnlgray9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray9.Location = New System.Drawing.Point(77, 25)
        Me.pnlgray9.Name = "pnlgray9"
        Me.pnlgray9.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray9.TabIndex = 3
        Me.pnlgray9.Visible = False
        '
        'pnlgray5
        '
        Me.pnlgray5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray5.Location = New System.Drawing.Point(181, 8)
        Me.pnlgray5.Name = "pnlgray5"
        Me.pnlgray5.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray5.TabIndex = 10
        Me.pnlgray5.Visible = False
        '
        'pnlgray3
        '
        Me.pnlgray3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray3.Location = New System.Drawing.Point(129, 8)
        Me.pnlgray3.Name = "pnlgray3"
        Me.pnlgray3.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray3.TabIndex = 6
        Me.pnlgray3.Visible = False
        '
        'pnlgray1
        '
        Me.pnlgray1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlgray1.Location = New System.Drawing.Point(77, 8)
        Me.pnlgray1.Name = "pnlgray1"
        Me.pnlgray1.Size = New System.Drawing.Size(20, 13)
        Me.pnlgray1.TabIndex = 2
        Me.pnlgray1.Visible = False
        '
        'lblgraylevel
        '
        Me.lblgraylevel.AutoSize = True
        Me.lblgraylevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgraylevel.Location = New System.Drawing.Point(5, 25)
        Me.lblgraylevel.Name = "lblgraylevel"
        Me.lblgraylevel.Size = New System.Drawing.Size(49, 15)
        Me.lblgraylevel.TabIndex = 1
        Me.lblgraylevel.Text = "Level: 4"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 2)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 23)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Gray"
        '
        'pnlanycolours
        '
        Me.pnlanycolours.BackColor = System.Drawing.Color.White
        Me.pnlanycolours.Controls.Add(Me.pnlanyoptions)
        Me.pnlanycolours.Controls.Add(Me.pnlanycustomcolour)
        Me.pnlanycolours.Controls.Add(Me.pnlany16)
        Me.pnlanycolours.Controls.Add(Me.pnlany12)
        Me.pnlanycolours.Controls.Add(Me.pnlany14)
        Me.pnlanycolours.Controls.Add(Me.pnlany10)
        Me.pnlanycolours.Controls.Add(Me.pnlany8)
        Me.pnlanycolours.Controls.Add(Me.pnlany4)
        Me.pnlanycolours.Controls.Add(Me.pnlany6)
        Me.pnlanycolours.Controls.Add(Me.pnlany15)
        Me.pnlanycolours.Controls.Add(Me.pnlany2)
        Me.pnlanycolours.Controls.Add(Me.pnlany13)
        Me.pnlanycolours.Controls.Add(Me.pnlany11)
        Me.pnlanycolours.Controls.Add(Me.pnlany7)
        Me.pnlanycolours.Controls.Add(Me.pnlany9)
        Me.pnlanycolours.Controls.Add(Me.pnlany5)
        Me.pnlanycolours.Controls.Add(Me.pnlany3)
        Me.pnlanycolours.Controls.Add(Me.pnlany1)
        Me.pnlanycolours.Controls.Add(Me.lblanylevel)
        Me.pnlanycolours.Controls.Add(Me.Label1)
        Me.pnlanycolours.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlanycolours.Location = New System.Drawing.Point(0, 107)
        Me.pnlanycolours.Name = "pnlanycolours"
        Me.pnlanycolours.Size = New System.Drawing.Size(443, 46)
        Me.pnlanycolours.TabIndex = 1
        Me.pnlanycolours.Visible = False
        '
        'pnlanyoptions
        '
        Me.pnlanyoptions.Controls.Add(Me.Label38)
        Me.pnlanyoptions.Controls.Add(Me.txtanysgreen)
        Me.pnlanyoptions.Controls.Add(Me.txtanysred)
        Me.pnlanyoptions.Controls.Add(Me.Label39)
        Me.pnlanyoptions.Controls.Add(Me.Label40)
        Me.pnlanyoptions.Controls.Add(Me.txtanysblue)
        Me.pnlanyoptions.Location = New System.Drawing.Point(282, 3)
        Me.pnlanyoptions.Name = "pnlanyoptions"
        Me.pnlanyoptions.Size = New System.Drawing.Size(120, 40)
        Me.pnlanyoptions.TabIndex = 34
        Me.pnlanyoptions.Visible = False
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.Location = New System.Drawing.Point(56, 24)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(39, 13)
        Me.Label38.TabIndex = 26
        Me.Label38.Text = "Green:"
        '
        'txtanysgreen
        '
        Me.txtanysgreen.BackColor = System.Drawing.Color.White
        Me.txtanysgreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtanysgreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtanysgreen.Location = New System.Drawing.Point(95, 22)
        Me.txtanysgreen.Multiline = True
        Me.txtanysgreen.Name = "txtanysgreen"
        Me.txtanysgreen.Size = New System.Drawing.Size(23, 17)
        Me.txtanysgreen.TabIndex = 25
        Me.txtanysgreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtanysred
        '
        Me.txtanysred.BackColor = System.Drawing.Color.White
        Me.txtanysred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtanysred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtanysred.Location = New System.Drawing.Point(62, 2)
        Me.txtanysred.Multiline = True
        Me.txtanysred.Name = "txtanysred"
        Me.txtanysred.Size = New System.Drawing.Size(23, 17)
        Me.txtanysred.TabIndex = 21
        Me.txtanysred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.BackColor = System.Drawing.Color.Transparent
        Me.Label39.Location = New System.Drawing.Point(1, 23)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(31, 13)
        Me.Label39.TabIndex = 24
        Me.Label39.Text = "Blue:"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.BackColor = System.Drawing.Color.Transparent
        Me.Label40.Location = New System.Drawing.Point(31, 4)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(30, 13)
        Me.Label40.TabIndex = 22
        Me.Label40.Text = "Red:"
        '
        'txtanysblue
        '
        Me.txtanysblue.BackColor = System.Drawing.Color.White
        Me.txtanysblue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtanysblue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtanysblue.Location = New System.Drawing.Point(32, 22)
        Me.txtanysblue.Multiline = True
        Me.txtanysblue.Name = "txtanysblue"
        Me.txtanysblue.Size = New System.Drawing.Size(23, 17)
        Me.txtanysblue.TabIndex = 23
        Me.txtanysblue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnlanycustomcolour
        '
        Me.pnlanycustomcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlanycustomcolour.Location = New System.Drawing.Point(406, 8)
        Me.pnlanycustomcolour.Name = "pnlanycustomcolour"
        Me.pnlanycustomcolour.Size = New System.Drawing.Size(32, 30)
        Me.pnlanycustomcolour.TabIndex = 17
        Me.pnlanycustomcolour.Visible = False
        '
        'pnlany16
        '
        Me.pnlany16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany16.Location = New System.Drawing.Point(259, 25)
        Me.pnlany16.Name = "pnlany16"
        Me.pnlany16.Size = New System.Drawing.Size(20, 13)
        Me.pnlany16.TabIndex = 17
        Me.pnlany16.Visible = False
        '
        'pnlany12
        '
        Me.pnlany12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany12.Location = New System.Drawing.Point(155, 25)
        Me.pnlany12.Name = "pnlany12"
        Me.pnlany12.Size = New System.Drawing.Size(20, 13)
        Me.pnlany12.TabIndex = 9
        Me.pnlany12.Visible = False
        '
        'pnlany14
        '
        Me.pnlany14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany14.Location = New System.Drawing.Point(207, 25)
        Me.pnlany14.Name = "pnlany14"
        Me.pnlany14.Size = New System.Drawing.Size(20, 13)
        Me.pnlany14.TabIndex = 13
        Me.pnlany14.Visible = False
        '
        'pnlany10
        '
        Me.pnlany10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany10.Location = New System.Drawing.Point(103, 25)
        Me.pnlany10.Name = "pnlany10"
        Me.pnlany10.Size = New System.Drawing.Size(20, 13)
        Me.pnlany10.TabIndex = 5
        Me.pnlany10.Visible = False
        '
        'pnlany8
        '
        Me.pnlany8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany8.Location = New System.Drawing.Point(259, 8)
        Me.pnlany8.Name = "pnlany8"
        Me.pnlany8.Size = New System.Drawing.Size(20, 13)
        Me.pnlany8.TabIndex = 16
        Me.pnlany8.Visible = False
        '
        'pnlany4
        '
        Me.pnlany4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany4.Location = New System.Drawing.Point(155, 8)
        Me.pnlany4.Name = "pnlany4"
        Me.pnlany4.Size = New System.Drawing.Size(20, 13)
        Me.pnlany4.TabIndex = 8
        Me.pnlany4.Visible = False
        '
        'pnlany6
        '
        Me.pnlany6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany6.Location = New System.Drawing.Point(207, 8)
        Me.pnlany6.Name = "pnlany6"
        Me.pnlany6.Size = New System.Drawing.Size(20, 13)
        Me.pnlany6.TabIndex = 12
        Me.pnlany6.Visible = False
        '
        'pnlany15
        '
        Me.pnlany15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany15.Location = New System.Drawing.Point(233, 25)
        Me.pnlany15.Name = "pnlany15"
        Me.pnlany15.Size = New System.Drawing.Size(20, 13)
        Me.pnlany15.TabIndex = 15
        Me.pnlany15.Visible = False
        '
        'pnlany2
        '
        Me.pnlany2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany2.Location = New System.Drawing.Point(103, 8)
        Me.pnlany2.Name = "pnlany2"
        Me.pnlany2.Size = New System.Drawing.Size(20, 13)
        Me.pnlany2.TabIndex = 4
        Me.pnlany2.Visible = False
        '
        'pnlany13
        '
        Me.pnlany13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany13.Location = New System.Drawing.Point(181, 25)
        Me.pnlany13.Name = "pnlany13"
        Me.pnlany13.Size = New System.Drawing.Size(20, 13)
        Me.pnlany13.TabIndex = 11
        Me.pnlany13.Visible = False
        '
        'pnlany11
        '
        Me.pnlany11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany11.Location = New System.Drawing.Point(129, 25)
        Me.pnlany11.Name = "pnlany11"
        Me.pnlany11.Size = New System.Drawing.Size(20, 13)
        Me.pnlany11.TabIndex = 7
        Me.pnlany11.Visible = False
        '
        'pnlany7
        '
        Me.pnlany7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany7.Location = New System.Drawing.Point(233, 8)
        Me.pnlany7.Name = "pnlany7"
        Me.pnlany7.Size = New System.Drawing.Size(20, 13)
        Me.pnlany7.TabIndex = 14
        Me.pnlany7.Visible = False
        '
        'pnlany9
        '
        Me.pnlany9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany9.Location = New System.Drawing.Point(77, 25)
        Me.pnlany9.Name = "pnlany9"
        Me.pnlany9.Size = New System.Drawing.Size(20, 13)
        Me.pnlany9.TabIndex = 3
        Me.pnlany9.Visible = False
        '
        'pnlany5
        '
        Me.pnlany5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany5.Location = New System.Drawing.Point(181, 8)
        Me.pnlany5.Name = "pnlany5"
        Me.pnlany5.Size = New System.Drawing.Size(20, 13)
        Me.pnlany5.TabIndex = 10
        Me.pnlany5.Visible = False
        '
        'pnlany3
        '
        Me.pnlany3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany3.Location = New System.Drawing.Point(129, 8)
        Me.pnlany3.Name = "pnlany3"
        Me.pnlany3.Size = New System.Drawing.Size(20, 13)
        Me.pnlany3.TabIndex = 6
        Me.pnlany3.Visible = False
        '
        'pnlany1
        '
        Me.pnlany1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlany1.Location = New System.Drawing.Point(77, 8)
        Me.pnlany1.Name = "pnlany1"
        Me.pnlany1.Size = New System.Drawing.Size(20, 13)
        Me.pnlany1.TabIndex = 2
        Me.pnlany1.Visible = False
        '
        'lblanylevel
        '
        Me.lblanylevel.AutoSize = True
        Me.lblanylevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblanylevel.Location = New System.Drawing.Point(5, 25)
        Me.lblanylevel.Name = "lblanylevel"
        Me.lblanylevel.Size = New System.Drawing.Size(49, 15)
        Me.lblanylevel.TabIndex = 1
        Me.lblanylevel.Text = "Level: 4"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Any"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.lblnewcolourrgb)
        Me.Panel1.Controls.Add(Me.lblnewcolourname)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.lbloldcolourrgb)
        Me.Panel1.Controls.Add(Me.lbloldcolourname)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.pnlnewcolour)
        Me.Panel1.Controls.Add(Me.pnloldcolour)
        Me.Panel1.Controls.Add(Me.lblobjecttocolour)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(443, 107)
        Me.Panel1.TabIndex = 0
        '
        'lblnewcolourrgb
        '
        Me.lblnewcolourrgb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnewcolourrgb.Location = New System.Drawing.Point(298, 66)
        Me.lblnewcolourrgb.Name = "lblnewcolourrgb"
        Me.lblnewcolourrgb.Size = New System.Drawing.Size(147, 18)
        Me.lblnewcolourrgb.TabIndex = 10
        Me.lblnewcolourrgb.Text = "RGB: 234, 341, 111"
        '
        'lblnewcolourname
        '
        Me.lblnewcolourname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnewcolourname.Location = New System.Drawing.Point(298, 49)
        Me.lblnewcolourname.Name = "lblnewcolourname"
        Me.lblnewcolourname.Size = New System.Drawing.Size(145, 18)
        Me.lblnewcolourname.TabIndex = 9
        Me.lblnewcolourname.Text = "Name: Whitesmoke"
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(298, 32)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(145, 18)
        Me.Label26.TabIndex = 8
        Me.Label26.Text = "New Colour"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 87)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(426, 13)
        Me.Label17.TabIndex = 7
        Me.Label17.Text = "Click the new colour above to confirm your colour choice or click the old colour " & _
    "to cancel"
        '
        'lbloldcolourrgb
        '
        Me.lbloldcolourrgb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbloldcolourrgb.Location = New System.Drawing.Point(-2, 66)
        Me.lbloldcolourrgb.Name = "lbloldcolourrgb"
        Me.lbloldcolourrgb.Size = New System.Drawing.Size(151, 18)
        Me.lbloldcolourrgb.TabIndex = 6
        Me.lbloldcolourrgb.Text = "50, 60, 20 :RGB"
        Me.lbloldcolourrgb.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbloldcolourname
        '
        Me.lbloldcolourname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbloldcolourname.Location = New System.Drawing.Point(-2, 49)
        Me.lbloldcolourname.Name = "lbloldcolourname"
        Me.lbloldcolourname.Size = New System.Drawing.Size(151, 18)
        Me.lbloldcolourname.TabIndex = 5
        Me.lbloldcolourname.Text = "Red :Name"
        Me.lbloldcolourname.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(-2, 32)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(151, 18)
        Me.Label14.TabIndex = 4
        Me.Label14.Text = "Old Colour"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pnlnewcolour
        '
        Me.pnlnewcolour.Location = New System.Drawing.Point(227, 32)
        Me.pnlnewcolour.Name = "pnlnewcolour"
        Me.pnlnewcolour.Size = New System.Drawing.Size(67, 52)
        Me.pnlnewcolour.TabIndex = 3
        '
        'pnloldcolour
        '
        Me.pnloldcolour.Location = New System.Drawing.Point(153, 32)
        Me.pnloldcolour.Name = "pnloldcolour"
        Me.pnloldcolour.Size = New System.Drawing.Size(67, 52)
        Me.pnloldcolour.TabIndex = 2
        '
        'lblobjecttocolour
        '
        Me.lblobjecttocolour.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblobjecttocolour.Location = New System.Drawing.Point(10, 5)
        Me.lblobjecttocolour.Name = "lblobjecttocolour"
        Me.lblobjecttocolour.Size = New System.Drawing.Size(423, 23)
        Me.lblobjecttocolour.TabIndex = 1
        Me.lblobjecttocolour.Text = "Close Button Colour"
        Me.lblobjecttocolour.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 570)
        Me.pgleft.TabIndex = 21
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 568)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(445, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 570)
        Me.pgright.TabIndex = 22
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 568)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(447, 30)
        Me.titlebar.TabIndex = 19
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(246, 3)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 23
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconColourPicker
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(274, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(302, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Felix Titling", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(148, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Colour Picker"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(445, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 598)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(443, 2)
        Me.pgbottom.TabIndex = 23
        '
        'Colour_Picker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(447, 600)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "Colour_Picker"
        Me.Text = "Colour_Picker"
        Me.TopMost = True
        Me.pgcontents.ResumeLayout(False)
        Me.pnlpinkcolours.ResumeLayout(False)
        Me.pnlpinkcolours.PerformLayout()
        Me.pnlpinkoptions.ResumeLayout(False)
        Me.pnlpinkoptions.PerformLayout()
        Me.pnlredcolours.ResumeLayout(False)
        Me.pnlredcolours.PerformLayout()
        Me.pnlredoptions.ResumeLayout(False)
        Me.pnlredoptions.PerformLayout()
        Me.pnlbrowncolours.ResumeLayout(False)
        Me.pnlbrowncolours.PerformLayout()
        Me.pnlbrownoptions.ResumeLayout(False)
        Me.pnlbrownoptions.PerformLayout()
        Me.pnlorangecolours.ResumeLayout(False)
        Me.pnlorangecolours.PerformLayout()
        Me.pnlorangeoptions.ResumeLayout(False)
        Me.pnlorangeoptions.PerformLayout()
        Me.pnlyellowcolours.ResumeLayout(False)
        Me.pnlyellowcolours.PerformLayout()
        Me.pnlyellowoptions.ResumeLayout(False)
        Me.pnlyellowoptions.PerformLayout()
        Me.pnlgreencolours.ResumeLayout(False)
        Me.pnlgreencolours.PerformLayout()
        Me.pnlgreenoptions.ResumeLayout(False)
        Me.pnlgreenoptions.PerformLayout()
        Me.pnlbluecolours.ResumeLayout(False)
        Me.pnlbluecolours.PerformLayout()
        Me.pnlblueoptions.ResumeLayout(False)
        Me.pnlblueoptions.PerformLayout()
        Me.pnlpurplecolours.ResumeLayout(False)
        Me.pnlpurplecolours.PerformLayout()
        Me.pnlpurpleoptions.ResumeLayout(False)
        Me.pnlpurpleoptions.PerformLayout()
        Me.pnlgraycolours.ResumeLayout(False)
        Me.pnlgraycolours.PerformLayout()
        Me.pnlanycolours.ResumeLayout(False)
        Me.pnlanycolours.PerformLayout()
        Me.pnlanyoptions.ResumeLayout(False)
        Me.pnlanyoptions.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pgleft.ResumeLayout(False)
        Me.pgright.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents pnlanycolours As System.Windows.Forms.Panel
    Friend WithEvents pnlany16 As System.Windows.Forms.Panel
    Friend WithEvents pnlany12 As System.Windows.Forms.Panel
    Friend WithEvents pnlany14 As System.Windows.Forms.Panel
    Friend WithEvents pnlany10 As System.Windows.Forms.Panel
    Friend WithEvents pnlany4 As System.Windows.Forms.Panel
    Friend WithEvents pnlany6 As System.Windows.Forms.Panel
    Friend WithEvents pnlany15 As System.Windows.Forms.Panel
    Friend WithEvents pnlany2 As System.Windows.Forms.Panel
    Friend WithEvents pnlany13 As System.Windows.Forms.Panel
    Friend WithEvents pnlany11 As System.Windows.Forms.Panel
    Friend WithEvents pnlany7 As System.Windows.Forms.Panel
    Friend WithEvents pnlany9 As System.Windows.Forms.Panel
    Friend WithEvents pnlany5 As System.Windows.Forms.Panel
    Friend WithEvents pnlany3 As System.Windows.Forms.Panel
    Friend WithEvents pnlany1 As System.Windows.Forms.Panel
    Friend WithEvents lblanylevel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents pnlnewcolour As System.Windows.Forms.Panel
    Friend WithEvents pnloldcolour As System.Windows.Forms.Panel
    Friend WithEvents lblobjecttocolour As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lbloldcolourrgb As System.Windows.Forms.Label
    Friend WithEvents lbloldcolourname As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents pnlpinkcolours As System.Windows.Forms.Panel
    Friend WithEvents pnlpink16 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink12 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink14 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink10 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink8 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink4 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink6 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink15 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink2 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink13 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink11 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink7 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink9 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink5 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink3 As System.Windows.Forms.Panel
    Friend WithEvents pnlpink1 As System.Windows.Forms.Panel
    Friend WithEvents lblpinklevel As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents pnlredcolours As System.Windows.Forms.Panel
    Friend WithEvents pnlred16 As System.Windows.Forms.Panel
    Friend WithEvents pnlred12 As System.Windows.Forms.Panel
    Friend WithEvents pnlred14 As System.Windows.Forms.Panel
    Friend WithEvents pnlred10 As System.Windows.Forms.Panel
    Friend WithEvents pnlred8 As System.Windows.Forms.Panel
    Friend WithEvents pnlred4 As System.Windows.Forms.Panel
    Friend WithEvents pnlred6 As System.Windows.Forms.Panel
    Friend WithEvents pnlred15 As System.Windows.Forms.Panel
    Friend WithEvents pnlred2 As System.Windows.Forms.Panel
    Friend WithEvents pnlred13 As System.Windows.Forms.Panel
    Friend WithEvents pnlred11 As System.Windows.Forms.Panel
    Friend WithEvents pnlred7 As System.Windows.Forms.Panel
    Friend WithEvents pnlred9 As System.Windows.Forms.Panel
    Friend WithEvents pnlred5 As System.Windows.Forms.Panel
    Friend WithEvents pnlred3 As System.Windows.Forms.Panel
    Friend WithEvents pnlred1 As System.Windows.Forms.Panel
    Friend WithEvents lblredlevel As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents pnlbrowncolours As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown16 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown12 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown14 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown10 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown8 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown4 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown6 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown15 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown2 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown13 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown11 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown7 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown9 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown5 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown3 As System.Windows.Forms.Panel
    Friend WithEvents pnlbrown1 As System.Windows.Forms.Panel
    Friend WithEvents lblbrownlevel As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents pnlorangecolours As System.Windows.Forms.Panel
    Friend WithEvents pnlorange16 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange12 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange14 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange10 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange8 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange4 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange6 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange15 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange2 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange13 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange11 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange7 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange9 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange5 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange3 As System.Windows.Forms.Panel
    Friend WithEvents pnlorange1 As System.Windows.Forms.Panel
    Friend WithEvents lblorangelevel As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents pnlyellowcolours As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow16 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow12 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow14 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow10 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow8 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow4 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow6 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow15 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow2 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow13 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow11 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow7 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow9 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow5 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow3 As System.Windows.Forms.Panel
    Friend WithEvents pnlyellow1 As System.Windows.Forms.Panel
    Friend WithEvents lblyellowlevel As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents pnlgreencolours As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen16 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen12 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen14 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen10 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen8 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen4 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen6 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen15 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen2 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen13 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen11 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen7 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen9 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen5 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen3 As System.Windows.Forms.Panel
    Friend WithEvents pnlgreen1 As System.Windows.Forms.Panel
    Friend WithEvents lblgreenlevel As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents pnlbluecolours As System.Windows.Forms.Panel
    Friend WithEvents pnlblue16 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue12 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue14 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue10 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue8 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue4 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue6 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue15 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue2 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue13 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue11 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue7 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue9 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue5 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue3 As System.Windows.Forms.Panel
    Friend WithEvents pnlblue1 As System.Windows.Forms.Panel
    Friend WithEvents lblbluelevel As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents pnlpurplecolours As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple16 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple12 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple14 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple10 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple8 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple4 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple6 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple15 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple2 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple13 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple11 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple7 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple9 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple5 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple3 As System.Windows.Forms.Panel
    Friend WithEvents pnlpurple1 As System.Windows.Forms.Panel
    Friend WithEvents lblpurplelevel As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents pnlgraycolours As System.Windows.Forms.Panel
    Friend WithEvents pnlgray16 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray12 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray14 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray10 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray8 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray4 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray6 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray15 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray2 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray13 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray11 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray7 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray9 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray5 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray3 As System.Windows.Forms.Panel
    Friend WithEvents pnlgray1 As System.Windows.Forms.Panel
    Friend WithEvents lblgraylevel As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents pnlpinkcustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlredcustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlbrowncustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlorangecustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlyellowcustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlgreencustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlbluecustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlpurplecustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlgraycustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlanycustomcolour As System.Windows.Forms.Panel
    Friend WithEvents pnlany8 As System.Windows.Forms.Panel
    Friend WithEvents lblnewcolourrgb As System.Windows.Forms.Label
    Friend WithEvents lblnewcolourname As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents lblcustomshadetut As System.Windows.Forms.Label
    Friend WithEvents txtcustomgrayshade As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtbluesred As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtbluesgreen As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtbluesblue As System.Windows.Forms.TextBox
    Friend WithEvents pnlblueoptions As System.Windows.Forms.Panel
    Friend WithEvents pnlyellowoptions As System.Windows.Forms.Panel
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtyellowsblue As System.Windows.Forms.TextBox
    Friend WithEvents txtyellowsred As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtyellowsgreen As System.Windows.Forms.TextBox
    Friend WithEvents pnlgreenoptions As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtgreensred As System.Windows.Forms.TextBox
    Friend WithEvents txtgreensgreen As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtgreensblue As System.Windows.Forms.TextBox
    Friend WithEvents pnlpurpleoptions As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtpurplesgreen As System.Windows.Forms.TextBox
    Friend WithEvents txtpurplesblue As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtpurplesred As System.Windows.Forms.TextBox
    Friend WithEvents pnlpinkoptions As System.Windows.Forms.Panel
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtpinksgreen As System.Windows.Forms.TextBox
    Friend WithEvents txtpinksred As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txtpinksblue As System.Windows.Forms.TextBox
    Friend WithEvents pnlredoptions As System.Windows.Forms.Panel
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtredsblue As System.Windows.Forms.TextBox
    Friend WithEvents txtredsred As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtredsgreen As System.Windows.Forms.TextBox
    Friend WithEvents pnlbrownoptions As System.Windows.Forms.Panel
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtbrownsblue As System.Windows.Forms.TextBox
    Friend WithEvents txtbrownsred As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtbrownsgreen As System.Windows.Forms.TextBox
    Friend WithEvents pnlorangeoptions As System.Windows.Forms.Panel
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtorangesblue As System.Windows.Forms.TextBox
    Friend WithEvents txtorangesred As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtorangesgreen As System.Windows.Forms.TextBox
    Friend WithEvents pnlanyoptions As System.Windows.Forms.Panel
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtanysgreen As System.Windows.Forms.TextBox
    Friend WithEvents txtanysred As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtanysblue As System.Windows.Forms.TextBox
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
End Class
