﻿Imports ShiftOS.MyNamespace

Public Class MyToolStripRenderer
    Inherits ToolStripProfessionalRenderer
    Public Sub New()
        MyBase.New(New CustomColorTable())
    End Sub
End Class
