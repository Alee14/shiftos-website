﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Name_Changer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pullside = New System.Windows.Forms.Timer(Me.components)
        Me.pullbs = New System.Windows.Forms.Timer(Me.components)
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.pullbottom = New System.Windows.Forms.Timer(Me.components)
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.pnlprogramlistholder = New System.Windows.Forms.Panel()
        Me.pnlterminalsettings = New System.Windows.Forms.Panel()
        Me.txtterminalname = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.picterminalicon = New System.Windows.Forms.PictureBox()
        Me.pnliconmanagersettings = New System.Windows.Forms.Panel()
        Me.txticonmanager = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.piciconmanagericon = New System.Windows.Forms.PictureBox()
        Me.pnlnamechangersettings = New System.Windows.Forms.Panel()
        Me.txtnamechanger = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.picnamechangericon = New System.Windows.Forms.PictureBox()
        Me.pnlvideoplayersettings = New System.Windows.Forms.Panel()
        Me.txtvideoplayername = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.picvideoplayericon = New System.Windows.Forms.PictureBox()
        Me.pnlwebbrowsersettings = New System.Windows.Forms.Panel()
        Me.txtwebbrowsername = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.picwebbrowsericon = New System.Windows.Forms.PictureBox()
        Me.pnlaudioplayersettings = New System.Windows.Forms.Panel()
        Me.txtaudioplayername = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.picaudioplayericon = New System.Windows.Forms.PictureBox()
        Me.pnlcalculatorsettings = New System.Windows.Forms.Panel()
        Me.txtcalculatorname = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.piccalculatoricon = New System.Windows.Forms.PictureBox()
        Me.pnlartpadsettings = New System.Windows.Forms.Panel()
        Me.txtartpadname = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.picartpadicon = New System.Windows.Forms.PictureBox()
        Me.pnlskinloadersettings = New System.Windows.Forms.Panel()
        Me.txtskinloadername = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.picskinloadericon = New System.Windows.Forms.PictureBox()
        Me.pnlgraphicpickersettings = New System.Windows.Forms.Panel()
        Me.txtgraphicpickername = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.picgraphicpickericon = New System.Windows.Forms.PictureBox()
        Me.pnltextpadsettings = New System.Windows.Forms.Panel()
        Me.txttextpadname = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.pictextpadicon = New System.Windows.Forms.PictureBox()
        Me.pnlfilesaversettings = New System.Windows.Forms.Panel()
        Me.txtfilesavername = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.picfilesavericon = New System.Windows.Forms.PictureBox()
        Me.pnlfileopenersettings = New System.Windows.Forms.Panel()
        Me.txtfileopenername = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.picfileopenericon = New System.Windows.Forms.PictureBox()
        Me.pnlfileskimmersettings = New System.Windows.Forms.Panel()
        Me.txtfileskimmername = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.picfileskimmericon = New System.Windows.Forms.PictureBox()
        Me.pnlpongsettings = New System.Windows.Forms.Panel()
        Me.txtpongname = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.picpongicon = New System.Windows.Forms.PictureBox()
        Me.pnlcolourpickersettings = New System.Windows.Forms.Panel()
        Me.txtcolourpickername = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.piccolourpickericon = New System.Windows.Forms.PictureBox()
        Me.pnlshiftersettings = New System.Windows.Forms.Panel()
        Me.txtshiftername = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.picshiftericon = New System.Windows.Forms.PictureBox()
        Me.pnlclocksettings = New System.Windows.Forms.Panel()
        Me.txtclockname = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.picclockicon = New System.Windows.Forms.PictureBox()
        Me.pnlshiftoriumsettings = New System.Windows.Forms.Panel()
        Me.txtshiftoriumname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.picshiftoriumicon = New System.Windows.Forms.PictureBox()
        Me.pnlknowledgeinputsettings = New System.Windows.Forms.Panel()
        Me.txtknowledgeinputname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.picknowledgeinputicon = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnApply = New System.Windows.Forms.Button()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.pnlwallet = New System.Windows.Forms.Panel()
        Me.txtwallet = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.picwallet = New System.Windows.Forms.PictureBox()
        Me.pnldigger = New System.Windows.Forms.Panel()
        Me.txtdigger = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.picdigger = New System.Windows.Forms.PictureBox()
        Me.pnlskinshifter = New System.Windows.Forms.Panel()
        Me.txtskinshifter = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.picskinshifter = New System.Windows.Forms.PictureBox()
        Me.pnlshiftnet = New System.Windows.Forms.Panel()
        Me.txtshiftnet = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.picshiftnet = New System.Windows.Forms.PictureBox()
        Me.pnldodge = New System.Windows.Forms.Panel()
        Me.txtdodge = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.picdodge = New System.Windows.Forms.PictureBox()
        Me.pnldownload = New System.Windows.Forms.Panel()
        Me.txtdownload = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.picdownload = New System.Windows.Forms.PictureBox()
        Me.pnlinstaller = New System.Windows.Forms.Panel()
        Me.txtinstaller = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.picinstaller = New System.Windows.Forms.PictureBox()
        Me.pnlsysinfo = New System.Windows.Forms.Panel()
        Me.txtsysinfo = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.picsysinfo = New System.Windows.Forms.PictureBox()
        Me.pnlorcwrite = New System.Windows.Forms.Panel()
        Me.txtorcwrite = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.picorcwrite = New System.Windows.Forms.PictureBox()
        Me.pnlfloodgate = New System.Windows.Forms.Panel()
        Me.txtfloodgate = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.picfloodgate = New System.Windows.Forms.PictureBox()
        Me.pnlmaze = New System.Windows.Forms.Panel()
        Me.txtmaze = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.picmaze = New System.Windows.Forms.PictureBox()
        Me.pnlvirusscanner = New System.Windows.Forms.Panel()
        Me.txtvirusscanner = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.picvirusscanner = New System.Windows.Forms.PictureBox()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pgright.SuspendLayout()
        Me.pgcontents.SuspendLayout()
        Me.pnlprogramlistholder.SuspendLayout()
        Me.pnlterminalsettings.SuspendLayout()
        CType(Me.picterminalicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnliconmanagersettings.SuspendLayout()
        CType(Me.piciconmanagericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlnamechangersettings.SuspendLayout()
        CType(Me.picnamechangericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlvideoplayersettings.SuspendLayout()
        CType(Me.picvideoplayericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlwebbrowsersettings.SuspendLayout()
        CType(Me.picwebbrowsericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlaudioplayersettings.SuspendLayout()
        CType(Me.picaudioplayericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlcalculatorsettings.SuspendLayout()
        CType(Me.piccalculatoricon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlartpadsettings.SuspendLayout()
        CType(Me.picartpadicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlskinloadersettings.SuspendLayout()
        CType(Me.picskinloadericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlgraphicpickersettings.SuspendLayout()
        CType(Me.picgraphicpickericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnltextpadsettings.SuspendLayout()
        CType(Me.pictextpadicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfilesaversettings.SuspendLayout()
        CType(Me.picfilesavericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfileopenersettings.SuspendLayout()
        CType(Me.picfileopenericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfileskimmersettings.SuspendLayout()
        CType(Me.picfileskimmericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpongsettings.SuspendLayout()
        CType(Me.picpongicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlcolourpickersettings.SuspendLayout()
        CType(Me.piccolourpickericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlshiftersettings.SuspendLayout()
        CType(Me.picshiftericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlclocksettings.SuspendLayout()
        CType(Me.picclockicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlshiftoriumsettings.SuspendLayout()
        CType(Me.picshiftoriumicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlknowledgeinputsettings.SuspendLayout()
        CType(Me.picknowledgeinputicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pgleft.SuspendLayout()
        Me.titlebar.SuspendLayout()
        Me.pnlwallet.SuspendLayout()
        CType(Me.picwallet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnldigger.SuspendLayout()
        CType(Me.picdigger, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlskinshifter.SuspendLayout()
        CType(Me.picskinshifter, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlshiftnet.SuspendLayout()
        CType(Me.picshiftnet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnldodge.SuspendLayout()
        CType(Me.picdodge, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnldownload.SuspendLayout()
        CType(Me.picdownload, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlinstaller.SuspendLayout()
        CType(Me.picinstaller, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlsysinfo.SuspendLayout()
        CType(Me.picsysinfo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlorcwrite.SuspendLayout()
        CType(Me.picorcwrite, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlfloodgate.SuspendLayout()
        CType(Me.picfloodgate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlmaze.SuspendLayout()
        CType(Me.picmaze, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlvirusscanner.SuspendLayout()
        CType(Me.picvirusscanner, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pullside
        '
        Me.pullside.Interval = 1
        '
        'pullbs
        '
        Me.pullbs.Interval = 1
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 763)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(330, 2)
        Me.pgbottom.TabIndex = 23
        '
        'pullbottom
        '
        Me.pullbottom.Interval = 1
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(246, 5)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 24
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconNameChanger
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(274, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 733)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(332, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 735)
        Me.pgright.TabIndex = 22
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(302, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(120, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Name Changer"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(332, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 733)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgcontents
        '
        Me.pgcontents.BackColor = System.Drawing.Color.White
        Me.pgcontents.Controls.Add(Me.pnlprogramlistholder)
        Me.pgcontents.Controls.Add(Me.Panel2)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(330, 733)
        Me.pgcontents.TabIndex = 20
        '
        'pnlprogramlistholder
        '
        Me.pnlprogramlistholder.AutoScroll = True
        Me.pnlprogramlistholder.BackColor = System.Drawing.Color.White
        Me.pnlprogramlistholder.Controls.Add(Me.pnlvirusscanner)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlmaze)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlfloodgate)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlorcwrite)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlsysinfo)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlinstaller)
        Me.pnlprogramlistholder.Controls.Add(Me.pnldownload)
        Me.pnlprogramlistholder.Controls.Add(Me.pnldodge)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlshiftnet)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlskinshifter)
        Me.pnlprogramlistholder.Controls.Add(Me.pnldigger)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlwallet)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlterminalsettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnliconmanagersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlnamechangersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlvideoplayersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlwebbrowsersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlaudioplayersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlcalculatorsettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlartpadsettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlskinloadersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlgraphicpickersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnltextpadsettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlfilesaversettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlfileopenersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlfileskimmersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlpongsettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlcolourpickersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlshiftersettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlclocksettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlshiftoriumsettings)
        Me.pnlprogramlistholder.Controls.Add(Me.pnlknowledgeinputsettings)
        Me.pnlprogramlistholder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlprogramlistholder.Location = New System.Drawing.Point(0, 0)
        Me.pnlprogramlistholder.Name = "pnlprogramlistholder"
        Me.pnlprogramlistholder.Size = New System.Drawing.Size(330, 693)
        Me.pnlprogramlistholder.TabIndex = 1
        '
        'pnlterminalsettings
        '
        Me.pnlterminalsettings.Controls.Add(Me.txtterminalname)
        Me.pnlterminalsettings.Controls.Add(Me.Label19)
        Me.pnlterminalsettings.Controls.Add(Me.picterminalicon)
        Me.pnlterminalsettings.Location = New System.Drawing.Point(0, 868)
        Me.pnlterminalsettings.Name = "pnlterminalsettings"
        Me.pnlterminalsettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlterminalsettings.TabIndex = 37
        '
        'txtterminalname
        '
        Me.txtterminalname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtterminalname.BackColor = System.Drawing.Color.White
        Me.txtterminalname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtterminalname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtterminalname.Location = New System.Drawing.Point(151, 3)
        Me.txtterminalname.Name = "txtterminalname"
        Me.txtterminalname.Size = New System.Drawing.Size(175, 22)
        Me.txtterminalname.TabIndex = 2
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(28, 6)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(61, 16)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Terminal"
        '
        'picterminalicon
        '
        Me.picterminalicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picterminalicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picterminalicon.Location = New System.Drawing.Point(7, 6)
        Me.picterminalicon.Name = "picterminalicon"
        Me.picterminalicon.Size = New System.Drawing.Size(16, 16)
        Me.picterminalicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picterminalicon.TabIndex = 0
        Me.picterminalicon.TabStop = False
        '
        'pnliconmanagersettings
        '
        Me.pnliconmanagersettings.Controls.Add(Me.txticonmanager)
        Me.pnliconmanagersettings.Controls.Add(Me.Label20)
        Me.pnliconmanagersettings.Controls.Add(Me.piciconmanagericon)
        Me.pnliconmanagersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnliconmanagersettings.Location = New System.Drawing.Point(0, 504)
        Me.pnliconmanagersettings.Name = "pnliconmanagersettings"
        Me.pnliconmanagersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnliconmanagersettings.TabIndex = 38
        Me.pnliconmanagersettings.Visible = False
        '
        'txticonmanager
        '
        Me.txticonmanager.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txticonmanager.BackColor = System.Drawing.Color.White
        Me.txticonmanager.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txticonmanager.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txticonmanager.Location = New System.Drawing.Point(151, 3)
        Me.txticonmanager.Name = "txticonmanager"
        Me.txticonmanager.Size = New System.Drawing.Size(175, 22)
        Me.txticonmanager.TabIndex = 2
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(28, 6)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(90, 16)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Icon Manager"
        '
        'piciconmanagericon
        '
        Me.piciconmanagericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.piciconmanagericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.piciconmanagericon.Location = New System.Drawing.Point(7, 6)
        Me.piciconmanagericon.Name = "piciconmanagericon"
        Me.piciconmanagericon.Size = New System.Drawing.Size(16, 16)
        Me.piciconmanagericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.piciconmanagericon.TabIndex = 0
        Me.piciconmanagericon.TabStop = False
        '
        'pnlnamechangersettings
        '
        Me.pnlnamechangersettings.Controls.Add(Me.txtnamechanger)
        Me.pnlnamechangersettings.Controls.Add(Me.Label18)
        Me.pnlnamechangersettings.Controls.Add(Me.picnamechangericon)
        Me.pnlnamechangersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlnamechangersettings.Location = New System.Drawing.Point(0, 476)
        Me.pnlnamechangersettings.Name = "pnlnamechangersettings"
        Me.pnlnamechangersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlnamechangersettings.TabIndex = 35
        Me.pnlnamechangersettings.Visible = False
        '
        'txtnamechanger
        '
        Me.txtnamechanger.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtnamechanger.BackColor = System.Drawing.Color.White
        Me.txtnamechanger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnamechanger.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnamechanger.Location = New System.Drawing.Point(151, 3)
        Me.txtnamechanger.Name = "txtnamechanger"
        Me.txtnamechanger.Size = New System.Drawing.Size(175, 22)
        Me.txtnamechanger.TabIndex = 2
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(28, 6)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(99, 16)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "Name Changer"
        '
        'picnamechangericon
        '
        Me.picnamechangericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picnamechangericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picnamechangericon.Location = New System.Drawing.Point(7, 6)
        Me.picnamechangericon.Name = "picnamechangericon"
        Me.picnamechangericon.Size = New System.Drawing.Size(16, 16)
        Me.picnamechangericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picnamechangericon.TabIndex = 0
        Me.picnamechangericon.TabStop = False
        '
        'pnlvideoplayersettings
        '
        Me.pnlvideoplayersettings.Controls.Add(Me.txtvideoplayername)
        Me.pnlvideoplayersettings.Controls.Add(Me.Label17)
        Me.pnlvideoplayersettings.Controls.Add(Me.picvideoplayericon)
        Me.pnlvideoplayersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlvideoplayersettings.Location = New System.Drawing.Point(0, 448)
        Me.pnlvideoplayersettings.Name = "pnlvideoplayersettings"
        Me.pnlvideoplayersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlvideoplayersettings.TabIndex = 33
        Me.pnlvideoplayersettings.Visible = False
        '
        'txtvideoplayername
        '
        Me.txtvideoplayername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtvideoplayername.BackColor = System.Drawing.Color.White
        Me.txtvideoplayername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtvideoplayername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtvideoplayername.Location = New System.Drawing.Point(151, 3)
        Me.txtvideoplayername.Name = "txtvideoplayername"
        Me.txtvideoplayername.Size = New System.Drawing.Size(175, 22)
        Me.txtvideoplayername.TabIndex = 2
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(28, 6)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(86, 16)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Video Player"
        '
        'picvideoplayericon
        '
        Me.picvideoplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picvideoplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picvideoplayericon.Location = New System.Drawing.Point(7, 6)
        Me.picvideoplayericon.Name = "picvideoplayericon"
        Me.picvideoplayericon.Size = New System.Drawing.Size(16, 16)
        Me.picvideoplayericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picvideoplayericon.TabIndex = 0
        Me.picvideoplayericon.TabStop = False
        '
        'pnlwebbrowsersettings
        '
        Me.pnlwebbrowsersettings.Controls.Add(Me.txtwebbrowsername)
        Me.pnlwebbrowsersettings.Controls.Add(Me.Label16)
        Me.pnlwebbrowsersettings.Controls.Add(Me.picwebbrowsericon)
        Me.pnlwebbrowsersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlwebbrowsersettings.Location = New System.Drawing.Point(0, 420)
        Me.pnlwebbrowsersettings.Name = "pnlwebbrowsersettings"
        Me.pnlwebbrowsersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlwebbrowsersettings.TabIndex = 31
        Me.pnlwebbrowsersettings.Visible = False
        '
        'txtwebbrowsername
        '
        Me.txtwebbrowsername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtwebbrowsername.BackColor = System.Drawing.Color.White
        Me.txtwebbrowsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtwebbrowsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtwebbrowsername.Location = New System.Drawing.Point(151, 3)
        Me.txtwebbrowsername.Name = "txtwebbrowsername"
        Me.txtwebbrowsername.Size = New System.Drawing.Size(175, 22)
        Me.txtwebbrowsername.TabIndex = 2
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(28, 6)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(89, 16)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Web Browser"
        '
        'picwebbrowsericon
        '
        Me.picwebbrowsericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picwebbrowsericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picwebbrowsericon.Location = New System.Drawing.Point(7, 6)
        Me.picwebbrowsericon.Name = "picwebbrowsericon"
        Me.picwebbrowsericon.Size = New System.Drawing.Size(16, 16)
        Me.picwebbrowsericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picwebbrowsericon.TabIndex = 0
        Me.picwebbrowsericon.TabStop = False
        '
        'pnlaudioplayersettings
        '
        Me.pnlaudioplayersettings.Controls.Add(Me.txtaudioplayername)
        Me.pnlaudioplayersettings.Controls.Add(Me.Label15)
        Me.pnlaudioplayersettings.Controls.Add(Me.picaudioplayericon)
        Me.pnlaudioplayersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlaudioplayersettings.Location = New System.Drawing.Point(0, 392)
        Me.pnlaudioplayersettings.Name = "pnlaudioplayersettings"
        Me.pnlaudioplayersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlaudioplayersettings.TabIndex = 29
        Me.pnlaudioplayersettings.Visible = False
        '
        'txtaudioplayername
        '
        Me.txtaudioplayername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtaudioplayername.BackColor = System.Drawing.Color.White
        Me.txtaudioplayername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtaudioplayername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaudioplayername.Location = New System.Drawing.Point(151, 3)
        Me.txtaudioplayername.Name = "txtaudioplayername"
        Me.txtaudioplayername.Size = New System.Drawing.Size(175, 22)
        Me.txtaudioplayername.TabIndex = 2
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(28, 6)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(85, 16)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Audio Player"
        '
        'picaudioplayericon
        '
        Me.picaudioplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picaudioplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picaudioplayericon.Location = New System.Drawing.Point(7, 6)
        Me.picaudioplayericon.Name = "picaudioplayericon"
        Me.picaudioplayericon.Size = New System.Drawing.Size(16, 16)
        Me.picaudioplayericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picaudioplayericon.TabIndex = 0
        Me.picaudioplayericon.TabStop = False
        '
        'pnlcalculatorsettings
        '
        Me.pnlcalculatorsettings.Controls.Add(Me.txtcalculatorname)
        Me.pnlcalculatorsettings.Controls.Add(Me.Label14)
        Me.pnlcalculatorsettings.Controls.Add(Me.piccalculatoricon)
        Me.pnlcalculatorsettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlcalculatorsettings.Location = New System.Drawing.Point(0, 364)
        Me.pnlcalculatorsettings.Name = "pnlcalculatorsettings"
        Me.pnlcalculatorsettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlcalculatorsettings.TabIndex = 27
        Me.pnlcalculatorsettings.Visible = False
        '
        'txtcalculatorname
        '
        Me.txtcalculatorname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcalculatorname.BackColor = System.Drawing.Color.White
        Me.txtcalculatorname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcalculatorname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcalculatorname.Location = New System.Drawing.Point(151, 3)
        Me.txtcalculatorname.Name = "txtcalculatorname"
        Me.txtcalculatorname.Size = New System.Drawing.Size(175, 22)
        Me.txtcalculatorname.TabIndex = 2
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(28, 6)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(68, 16)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Calculator"
        '
        'piccalculatoricon
        '
        Me.piccalculatoricon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.piccalculatoricon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.piccalculatoricon.Location = New System.Drawing.Point(7, 6)
        Me.piccalculatoricon.Name = "piccalculatoricon"
        Me.piccalculatoricon.Size = New System.Drawing.Size(16, 16)
        Me.piccalculatoricon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.piccalculatoricon.TabIndex = 0
        Me.piccalculatoricon.TabStop = False
        '
        'pnlartpadsettings
        '
        Me.pnlartpadsettings.Controls.Add(Me.txtartpadname)
        Me.pnlartpadsettings.Controls.Add(Me.Label13)
        Me.pnlartpadsettings.Controls.Add(Me.picartpadicon)
        Me.pnlartpadsettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlartpadsettings.Location = New System.Drawing.Point(0, 336)
        Me.pnlartpadsettings.Name = "pnlartpadsettings"
        Me.pnlartpadsettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlartpadsettings.TabIndex = 25
        Me.pnlartpadsettings.Visible = False
        '
        'txtartpadname
        '
        Me.txtartpadname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtartpadname.BackColor = System.Drawing.Color.White
        Me.txtartpadname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtartpadname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtartpadname.Location = New System.Drawing.Point(151, 3)
        Me.txtartpadname.Name = "txtartpadname"
        Me.txtartpadname.Size = New System.Drawing.Size(175, 22)
        Me.txtartpadname.TabIndex = 2
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(28, 6)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 16)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Artpad"
        '
        'picartpadicon
        '
        Me.picartpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picartpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picartpadicon.Location = New System.Drawing.Point(7, 6)
        Me.picartpadicon.Name = "picartpadicon"
        Me.picartpadicon.Size = New System.Drawing.Size(16, 16)
        Me.picartpadicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picartpadicon.TabIndex = 0
        Me.picartpadicon.TabStop = False
        '
        'pnlskinloadersettings
        '
        Me.pnlskinloadersettings.Controls.Add(Me.txtskinloadername)
        Me.pnlskinloadersettings.Controls.Add(Me.Label12)
        Me.pnlskinloadersettings.Controls.Add(Me.picskinloadericon)
        Me.pnlskinloadersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlskinloadersettings.Location = New System.Drawing.Point(0, 308)
        Me.pnlskinloadersettings.Name = "pnlskinloadersettings"
        Me.pnlskinloadersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlskinloadersettings.TabIndex = 23
        Me.pnlskinloadersettings.Visible = False
        '
        'txtskinloadername
        '
        Me.txtskinloadername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtskinloadername.BackColor = System.Drawing.Color.White
        Me.txtskinloadername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtskinloadername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtskinloadername.Location = New System.Drawing.Point(151, 3)
        Me.txtskinloadername.Name = "txtskinloadername"
        Me.txtskinloadername.Size = New System.Drawing.Size(175, 22)
        Me.txtskinloadername.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(28, 6)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(80, 16)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Skin Loader"
        '
        'picskinloadericon
        '
        Me.picskinloadericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picskinloadericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picskinloadericon.Location = New System.Drawing.Point(7, 6)
        Me.picskinloadericon.Name = "picskinloadericon"
        Me.picskinloadericon.Size = New System.Drawing.Size(16, 16)
        Me.picskinloadericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picskinloadericon.TabIndex = 0
        Me.picskinloadericon.TabStop = False
        '
        'pnlgraphicpickersettings
        '
        Me.pnlgraphicpickersettings.Controls.Add(Me.txtgraphicpickername)
        Me.pnlgraphicpickersettings.Controls.Add(Me.Label11)
        Me.pnlgraphicpickersettings.Controls.Add(Me.picgraphicpickericon)
        Me.pnlgraphicpickersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlgraphicpickersettings.Location = New System.Drawing.Point(0, 280)
        Me.pnlgraphicpickersettings.Name = "pnlgraphicpickersettings"
        Me.pnlgraphicpickersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlgraphicpickersettings.TabIndex = 21
        Me.pnlgraphicpickersettings.Visible = False
        '
        'txtgraphicpickername
        '
        Me.txtgraphicpickername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtgraphicpickername.BackColor = System.Drawing.Color.White
        Me.txtgraphicpickername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgraphicpickername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgraphicpickername.Location = New System.Drawing.Point(151, 3)
        Me.txtgraphicpickername.Name = "txtgraphicpickername"
        Me.txtgraphicpickername.Size = New System.Drawing.Size(175, 22)
        Me.txtgraphicpickername.TabIndex = 2
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(28, 6)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(96, 16)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Graphic Picker"
        '
        'picgraphicpickericon
        '
        Me.picgraphicpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picgraphicpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picgraphicpickericon.Location = New System.Drawing.Point(7, 6)
        Me.picgraphicpickericon.Name = "picgraphicpickericon"
        Me.picgraphicpickericon.Size = New System.Drawing.Size(16, 16)
        Me.picgraphicpickericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picgraphicpickericon.TabIndex = 0
        Me.picgraphicpickericon.TabStop = False
        '
        'pnltextpadsettings
        '
        Me.pnltextpadsettings.Controls.Add(Me.txttextpadname)
        Me.pnltextpadsettings.Controls.Add(Me.Label10)
        Me.pnltextpadsettings.Controls.Add(Me.pictextpadicon)
        Me.pnltextpadsettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnltextpadsettings.Location = New System.Drawing.Point(0, 252)
        Me.pnltextpadsettings.Name = "pnltextpadsettings"
        Me.pnltextpadsettings.Size = New System.Drawing.Size(330, 28)
        Me.pnltextpadsettings.TabIndex = 19
        Me.pnltextpadsettings.Visible = False
        '
        'txttextpadname
        '
        Me.txttextpadname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txttextpadname.BackColor = System.Drawing.Color.White
        Me.txttextpadname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttextpadname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttextpadname.Location = New System.Drawing.Point(151, 3)
        Me.txttextpadname.Name = "txttextpadname"
        Me.txttextpadname.Size = New System.Drawing.Size(175, 22)
        Me.txttextpadname.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(28, 6)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 16)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "TextPad"
        '
        'pictextpadicon
        '
        Me.pictextpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pictextpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pictextpadicon.Location = New System.Drawing.Point(7, 6)
        Me.pictextpadicon.Name = "pictextpadicon"
        Me.pictextpadicon.Size = New System.Drawing.Size(16, 16)
        Me.pictextpadicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictextpadicon.TabIndex = 0
        Me.pictextpadicon.TabStop = False
        '
        'pnlfilesaversettings
        '
        Me.pnlfilesaversettings.Controls.Add(Me.txtfilesavername)
        Me.pnlfilesaversettings.Controls.Add(Me.Label9)
        Me.pnlfilesaversettings.Controls.Add(Me.picfilesavericon)
        Me.pnlfilesaversettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlfilesaversettings.Location = New System.Drawing.Point(0, 224)
        Me.pnlfilesaversettings.Name = "pnlfilesaversettings"
        Me.pnlfilesaversettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlfilesaversettings.TabIndex = 17
        Me.pnlfilesaversettings.Visible = False
        '
        'txtfilesavername
        '
        Me.txtfilesavername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtfilesavername.BackColor = System.Drawing.Color.White
        Me.txtfilesavername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtfilesavername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfilesavername.Location = New System.Drawing.Point(151, 3)
        Me.txtfilesavername.Name = "txtfilesavername"
        Me.txtfilesavername.Size = New System.Drawing.Size(175, 22)
        Me.txtfilesavername.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(28, 6)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 16)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "File Saver"
        '
        'picfilesavericon
        '
        Me.picfilesavericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picfilesavericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picfilesavericon.Location = New System.Drawing.Point(7, 6)
        Me.picfilesavericon.Name = "picfilesavericon"
        Me.picfilesavericon.Size = New System.Drawing.Size(16, 16)
        Me.picfilesavericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picfilesavericon.TabIndex = 0
        Me.picfilesavericon.TabStop = False
        '
        'pnlfileopenersettings
        '
        Me.pnlfileopenersettings.Controls.Add(Me.txtfileopenername)
        Me.pnlfileopenersettings.Controls.Add(Me.Label8)
        Me.pnlfileopenersettings.Controls.Add(Me.picfileopenericon)
        Me.pnlfileopenersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlfileopenersettings.Location = New System.Drawing.Point(0, 196)
        Me.pnlfileopenersettings.Name = "pnlfileopenersettings"
        Me.pnlfileopenersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlfileopenersettings.TabIndex = 15
        Me.pnlfileopenersettings.Visible = False
        '
        'txtfileopenername
        '
        Me.txtfileopenername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtfileopenername.BackColor = System.Drawing.Color.White
        Me.txtfileopenername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtfileopenername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfileopenername.Location = New System.Drawing.Point(151, 3)
        Me.txtfileopenername.Name = "txtfileopenername"
        Me.txtfileopenername.Size = New System.Drawing.Size(175, 22)
        Me.txtfileopenername.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(28, 6)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 16)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "File Opener"
        '
        'picfileopenericon
        '
        Me.picfileopenericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picfileopenericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picfileopenericon.Location = New System.Drawing.Point(7, 6)
        Me.picfileopenericon.Name = "picfileopenericon"
        Me.picfileopenericon.Size = New System.Drawing.Size(16, 16)
        Me.picfileopenericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picfileopenericon.TabIndex = 0
        Me.picfileopenericon.TabStop = False
        '
        'pnlfileskimmersettings
        '
        Me.pnlfileskimmersettings.Controls.Add(Me.txtfileskimmername)
        Me.pnlfileskimmersettings.Controls.Add(Me.Label7)
        Me.pnlfileskimmersettings.Controls.Add(Me.picfileskimmericon)
        Me.pnlfileskimmersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlfileskimmersettings.Location = New System.Drawing.Point(0, 168)
        Me.pnlfileskimmersettings.Name = "pnlfileskimmersettings"
        Me.pnlfileskimmersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlfileskimmersettings.TabIndex = 13
        Me.pnlfileskimmersettings.Visible = False
        '
        'txtfileskimmername
        '
        Me.txtfileskimmername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtfileskimmername.BackColor = System.Drawing.Color.White
        Me.txtfileskimmername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtfileskimmername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfileskimmername.Location = New System.Drawing.Point(151, 3)
        Me.txtfileskimmername.Name = "txtfileskimmername"
        Me.txtfileskimmername.Size = New System.Drawing.Size(175, 22)
        Me.txtfileskimmername.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(28, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 16)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "File Skimmer"
        '
        'picfileskimmericon
        '
        Me.picfileskimmericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picfileskimmericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picfileskimmericon.Location = New System.Drawing.Point(7, 6)
        Me.picfileskimmericon.Name = "picfileskimmericon"
        Me.picfileskimmericon.Size = New System.Drawing.Size(16, 16)
        Me.picfileskimmericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picfileskimmericon.TabIndex = 0
        Me.picfileskimmericon.TabStop = False
        '
        'pnlpongsettings
        '
        Me.pnlpongsettings.Controls.Add(Me.txtpongname)
        Me.pnlpongsettings.Controls.Add(Me.Label6)
        Me.pnlpongsettings.Controls.Add(Me.picpongicon)
        Me.pnlpongsettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlpongsettings.Location = New System.Drawing.Point(0, 140)
        Me.pnlpongsettings.Name = "pnlpongsettings"
        Me.pnlpongsettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlpongsettings.TabIndex = 11
        Me.pnlpongsettings.Visible = False
        '
        'txtpongname
        '
        Me.txtpongname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtpongname.BackColor = System.Drawing.Color.White
        Me.txtpongname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpongname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpongname.Location = New System.Drawing.Point(151, 3)
        Me.txtpongname.Name = "txtpongname"
        Me.txtpongname.Size = New System.Drawing.Size(175, 22)
        Me.txtpongname.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(28, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 16)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Pong"
        '
        'picpongicon
        '
        Me.picpongicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picpongicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picpongicon.Location = New System.Drawing.Point(7, 6)
        Me.picpongicon.Name = "picpongicon"
        Me.picpongicon.Size = New System.Drawing.Size(16, 16)
        Me.picpongicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picpongicon.TabIndex = 0
        Me.picpongicon.TabStop = False
        '
        'pnlcolourpickersettings
        '
        Me.pnlcolourpickersettings.Controls.Add(Me.txtcolourpickername)
        Me.pnlcolourpickersettings.Controls.Add(Me.Label5)
        Me.pnlcolourpickersettings.Controls.Add(Me.piccolourpickericon)
        Me.pnlcolourpickersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlcolourpickersettings.Location = New System.Drawing.Point(0, 112)
        Me.pnlcolourpickersettings.Name = "pnlcolourpickersettings"
        Me.pnlcolourpickersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlcolourpickersettings.TabIndex = 9
        Me.pnlcolourpickersettings.Visible = False
        '
        'txtcolourpickername
        '
        Me.txtcolourpickername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtcolourpickername.BackColor = System.Drawing.Color.White
        Me.txtcolourpickername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcolourpickername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcolourpickername.Location = New System.Drawing.Point(151, 3)
        Me.txtcolourpickername.Name = "txtcolourpickername"
        Me.txtcolourpickername.Size = New System.Drawing.Size(175, 22)
        Me.txtcolourpickername.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(28, 6)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(88, 16)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Colour Picker"
        '
        'piccolourpickericon
        '
        Me.piccolourpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.piccolourpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.piccolourpickericon.Location = New System.Drawing.Point(7, 6)
        Me.piccolourpickericon.Name = "piccolourpickericon"
        Me.piccolourpickericon.Size = New System.Drawing.Size(16, 16)
        Me.piccolourpickericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.piccolourpickericon.TabIndex = 0
        Me.piccolourpickericon.TabStop = False
        '
        'pnlshiftersettings
        '
        Me.pnlshiftersettings.Controls.Add(Me.txtshiftername)
        Me.pnlshiftersettings.Controls.Add(Me.Label4)
        Me.pnlshiftersettings.Controls.Add(Me.picshiftericon)
        Me.pnlshiftersettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlshiftersettings.Location = New System.Drawing.Point(0, 84)
        Me.pnlshiftersettings.Name = "pnlshiftersettings"
        Me.pnlshiftersettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlshiftersettings.TabIndex = 7
        Me.pnlshiftersettings.Visible = False
        '
        'txtshiftername
        '
        Me.txtshiftername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtshiftername.BackColor = System.Drawing.Color.White
        Me.txtshiftername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtshiftername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtshiftername.Location = New System.Drawing.Point(151, 3)
        Me.txtshiftername.Name = "txtshiftername"
        Me.txtshiftername.Size = New System.Drawing.Size(175, 22)
        Me.txtshiftername.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(28, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 16)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Shifter"
        '
        'picshiftericon
        '
        Me.picshiftericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picshiftericon.Location = New System.Drawing.Point(7, 6)
        Me.picshiftericon.Name = "picshiftericon"
        Me.picshiftericon.Size = New System.Drawing.Size(16, 16)
        Me.picshiftericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picshiftericon.TabIndex = 0
        Me.picshiftericon.TabStop = False
        '
        'pnlclocksettings
        '
        Me.pnlclocksettings.Controls.Add(Me.txtclockname)
        Me.pnlclocksettings.Controls.Add(Me.Label3)
        Me.pnlclocksettings.Controls.Add(Me.picclockicon)
        Me.pnlclocksettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlclocksettings.Location = New System.Drawing.Point(0, 56)
        Me.pnlclocksettings.Name = "pnlclocksettings"
        Me.pnlclocksettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlclocksettings.TabIndex = 5
        Me.pnlclocksettings.Visible = False
        '
        'txtclockname
        '
        Me.txtclockname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtclockname.BackColor = System.Drawing.Color.White
        Me.txtclockname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclockname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclockname.Location = New System.Drawing.Point(151, 3)
        Me.txtclockname.Name = "txtclockname"
        Me.txtclockname.Size = New System.Drawing.Size(175, 22)
        Me.txtclockname.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(28, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 16)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Clock"
        '
        'picclockicon
        '
        Me.picclockicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picclockicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picclockicon.Location = New System.Drawing.Point(7, 6)
        Me.picclockicon.Name = "picclockicon"
        Me.picclockicon.Size = New System.Drawing.Size(16, 16)
        Me.picclockicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picclockicon.TabIndex = 0
        Me.picclockicon.TabStop = False
        '
        'pnlshiftoriumsettings
        '
        Me.pnlshiftoriumsettings.Controls.Add(Me.txtshiftoriumname)
        Me.pnlshiftoriumsettings.Controls.Add(Me.Label2)
        Me.pnlshiftoriumsettings.Controls.Add(Me.picshiftoriumicon)
        Me.pnlshiftoriumsettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlshiftoriumsettings.Location = New System.Drawing.Point(0, 28)
        Me.pnlshiftoriumsettings.Name = "pnlshiftoriumsettings"
        Me.pnlshiftoriumsettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlshiftoriumsettings.TabIndex = 3
        '
        'txtshiftoriumname
        '
        Me.txtshiftoriumname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtshiftoriumname.BackColor = System.Drawing.Color.White
        Me.txtshiftoriumname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtshiftoriumname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtshiftoriumname.Location = New System.Drawing.Point(151, 3)
        Me.txtshiftoriumname.Name = "txtshiftoriumname"
        Me.txtshiftoriumname.Size = New System.Drawing.Size(175, 22)
        Me.txtshiftoriumname.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(28, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Shiftorium"
        '
        'picshiftoriumicon
        '
        Me.picshiftoriumicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picshiftoriumicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picshiftoriumicon.Location = New System.Drawing.Point(7, 6)
        Me.picshiftoriumicon.Name = "picshiftoriumicon"
        Me.picshiftoriumicon.Size = New System.Drawing.Size(16, 16)
        Me.picshiftoriumicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picshiftoriumicon.TabIndex = 0
        Me.picshiftoriumicon.TabStop = False
        '
        'pnlknowledgeinputsettings
        '
        Me.pnlknowledgeinputsettings.Controls.Add(Me.txtknowledgeinputname)
        Me.pnlknowledgeinputsettings.Controls.Add(Me.Label1)
        Me.pnlknowledgeinputsettings.Controls.Add(Me.picknowledgeinputicon)
        Me.pnlknowledgeinputsettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlknowledgeinputsettings.Location = New System.Drawing.Point(0, 0)
        Me.pnlknowledgeinputsettings.Name = "pnlknowledgeinputsettings"
        Me.pnlknowledgeinputsettings.Size = New System.Drawing.Size(330, 28)
        Me.pnlknowledgeinputsettings.TabIndex = 1
        '
        'txtknowledgeinputname
        '
        Me.txtknowledgeinputname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtknowledgeinputname.BackColor = System.Drawing.Color.White
        Me.txtknowledgeinputname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtknowledgeinputname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtknowledgeinputname.Location = New System.Drawing.Point(151, 3)
        Me.txtknowledgeinputname.Name = "txtknowledgeinputname"
        Me.txtknowledgeinputname.Size = New System.Drawing.Size(175, 22)
        Me.txtknowledgeinputname.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Knowledge Input"
        '
        'picknowledgeinputicon
        '
        Me.picknowledgeinputicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picknowledgeinputicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picknowledgeinputicon.Location = New System.Drawing.Point(7, 6)
        Me.picknowledgeinputicon.Name = "picknowledgeinputicon"
        Me.picknowledgeinputicon.Size = New System.Drawing.Size(16, 16)
        Me.picknowledgeinputicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picknowledgeinputicon.TabIndex = 0
        Me.picknowledgeinputicon.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnLoad)
        Me.Panel2.Controls.Add(Me.btnSave)
        Me.Panel2.Controls.Add(Me.PictureBox13)
        Me.Panel2.Controls.Add(Me.btnReset)
        Me.Panel2.Controls.Add(Me.btnApply)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 693)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(330, 40)
        Me.Panel2.TabIndex = 2
        '
        'btnLoad
        '
        Me.btnLoad.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnLoad.BackColor = System.Drawing.Color.White
        Me.btnLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLoad.Location = New System.Drawing.Point(4, 5)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(77, 30)
        Me.btnLoad.TabIndex = 17
        Me.btnLoad.Text = "Load"
        Me.btnLoad.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnSave.BackColor = System.Drawing.Color.White
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Location = New System.Drawing.Point(86, 5)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(77, 30)
        Me.btnSave.TabIndex = 16
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.Black
        Me.PictureBox13.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox13.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(330, 1)
        Me.PictureBox13.TabIndex = 15
        Me.PictureBox13.TabStop = False
        '
        'btnReset
        '
        Me.btnReset.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnReset.BackColor = System.Drawing.Color.White
        Me.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReset.Location = New System.Drawing.Point(168, 5)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(77, 30)
        Me.btnReset.TabIndex = 1
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'btnApply
        '
        Me.btnApply.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnApply.BackColor = System.Drawing.Color.White
        Me.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnApply.Location = New System.Drawing.Point(250, 5)
        Me.btnApply.Name = "btnApply"
        Me.btnApply.Size = New System.Drawing.Size(77, 30)
        Me.btnApply.TabIndex = 0
        Me.btnApply.Text = "Apply"
        Me.btnApply.UseVisualStyleBackColor = False
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 735)
        Me.pgleft.TabIndex = 21
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(334, 30)
        Me.titlebar.TabIndex = 19
        '
        'pnlwallet
        '
        Me.pnlwallet.Controls.Add(Me.txtwallet)
        Me.pnlwallet.Controls.Add(Me.Label21)
        Me.pnlwallet.Controls.Add(Me.picwallet)
        Me.pnlwallet.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlwallet.Location = New System.Drawing.Point(0, 532)
        Me.pnlwallet.Name = "pnlwallet"
        Me.pnlwallet.Size = New System.Drawing.Size(330, 28)
        Me.pnlwallet.TabIndex = 39
        Me.pnlwallet.Visible = False
        '
        'txtwallet
        '
        Me.txtwallet.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtwallet.BackColor = System.Drawing.Color.White
        Me.txtwallet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtwallet.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtwallet.Location = New System.Drawing.Point(151, 3)
        Me.txtwallet.Name = "txtwallet"
        Me.txtwallet.Size = New System.Drawing.Size(175, 22)
        Me.txtwallet.TabIndex = 2
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(28, 6)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(90, 16)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Bitnote Wallet"
        '
        'picwallet
        '
        Me.picwallet.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picwallet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picwallet.Location = New System.Drawing.Point(7, 6)
        Me.picwallet.Name = "picwallet"
        Me.picwallet.Size = New System.Drawing.Size(16, 16)
        Me.picwallet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picwallet.TabIndex = 0
        Me.picwallet.TabStop = False
        '
        'pnldigger
        '
        Me.pnldigger.Controls.Add(Me.txtdigger)
        Me.pnldigger.Controls.Add(Me.Label22)
        Me.pnldigger.Controls.Add(Me.picdigger)
        Me.pnldigger.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnldigger.Location = New System.Drawing.Point(0, 560)
        Me.pnldigger.Name = "pnldigger"
        Me.pnldigger.Size = New System.Drawing.Size(330, 28)
        Me.pnldigger.TabIndex = 40
        Me.pnldigger.Visible = False
        '
        'txtdigger
        '
        Me.txtdigger.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdigger.BackColor = System.Drawing.Color.White
        Me.txtdigger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdigger.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdigger.Location = New System.Drawing.Point(151, 3)
        Me.txtdigger.Name = "txtdigger"
        Me.txtdigger.Size = New System.Drawing.Size(175, 22)
        Me.txtdigger.TabIndex = 2
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(28, 6)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(93, 16)
        Me.Label22.TabIndex = 1
        Me.Label22.Text = "Bitnote Digger"
        '
        'picdigger
        '
        Me.picdigger.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picdigger.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picdigger.Location = New System.Drawing.Point(7, 6)
        Me.picdigger.Name = "picdigger"
        Me.picdigger.Size = New System.Drawing.Size(16, 16)
        Me.picdigger.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picdigger.TabIndex = 0
        Me.picdigger.TabStop = False
        '
        'pnlskinshifter
        '
        Me.pnlskinshifter.Controls.Add(Me.txtskinshifter)
        Me.pnlskinshifter.Controls.Add(Me.Label23)
        Me.pnlskinshifter.Controls.Add(Me.picskinshifter)
        Me.pnlskinshifter.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlskinshifter.Location = New System.Drawing.Point(0, 588)
        Me.pnlskinshifter.Name = "pnlskinshifter"
        Me.pnlskinshifter.Size = New System.Drawing.Size(330, 28)
        Me.pnlskinshifter.TabIndex = 41
        Me.pnlskinshifter.Visible = False
        '
        'txtskinshifter
        '
        Me.txtskinshifter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtskinshifter.BackColor = System.Drawing.Color.White
        Me.txtskinshifter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtskinshifter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtskinshifter.Location = New System.Drawing.Point(151, 3)
        Me.txtskinshifter.Name = "txtskinshifter"
        Me.txtskinshifter.Size = New System.Drawing.Size(175, 22)
        Me.txtskinshifter.TabIndex = 2
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(28, 6)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(74, 16)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Skin Shifter"
        '
        'picskinshifter
        '
        Me.picskinshifter.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picskinshifter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picskinshifter.Location = New System.Drawing.Point(7, 6)
        Me.picskinshifter.Name = "picskinshifter"
        Me.picskinshifter.Size = New System.Drawing.Size(16, 16)
        Me.picskinshifter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picskinshifter.TabIndex = 0
        Me.picskinshifter.TabStop = False
        '
        'pnlshiftnet
        '
        Me.pnlshiftnet.Controls.Add(Me.txtshiftnet)
        Me.pnlshiftnet.Controls.Add(Me.Label24)
        Me.pnlshiftnet.Controls.Add(Me.picshiftnet)
        Me.pnlshiftnet.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlshiftnet.Location = New System.Drawing.Point(0, 616)
        Me.pnlshiftnet.Name = "pnlshiftnet"
        Me.pnlshiftnet.Size = New System.Drawing.Size(330, 28)
        Me.pnlshiftnet.TabIndex = 42
        Me.pnlshiftnet.Visible = False
        '
        'txtshiftnet
        '
        Me.txtshiftnet.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtshiftnet.BackColor = System.Drawing.Color.White
        Me.txtshiftnet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtshiftnet.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtshiftnet.Location = New System.Drawing.Point(151, 3)
        Me.txtshiftnet.Name = "txtshiftnet"
        Me.txtshiftnet.Size = New System.Drawing.Size(175, 22)
        Me.txtshiftnet.TabIndex = 2
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(28, 6)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(51, 16)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Shiftnet"
        '
        'picshiftnet
        '
        Me.picshiftnet.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picshiftnet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picshiftnet.Location = New System.Drawing.Point(7, 6)
        Me.picshiftnet.Name = "picshiftnet"
        Me.picshiftnet.Size = New System.Drawing.Size(16, 16)
        Me.picshiftnet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picshiftnet.TabIndex = 0
        Me.picshiftnet.TabStop = False
        '
        'pnldodge
        '
        Me.pnldodge.Controls.Add(Me.txtdodge)
        Me.pnldodge.Controls.Add(Me.Label25)
        Me.pnldodge.Controls.Add(Me.picdodge)
        Me.pnldodge.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnldodge.Location = New System.Drawing.Point(0, 644)
        Me.pnldodge.Name = "pnldodge"
        Me.pnldodge.Size = New System.Drawing.Size(330, 28)
        Me.pnldodge.TabIndex = 43
        Me.pnldodge.Visible = False
        '
        'txtdodge
        '
        Me.txtdodge.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdodge.BackColor = System.Drawing.Color.White
        Me.txtdodge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdodge.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdodge.Location = New System.Drawing.Point(151, 3)
        Me.txtdodge.Name = "txtdodge"
        Me.txtdodge.Size = New System.Drawing.Size(175, 22)
        Me.txtdodge.TabIndex = 2
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(28, 6)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(50, 16)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Dodge"
        '
        'picdodge
        '
        Me.picdodge.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picdodge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picdodge.Location = New System.Drawing.Point(7, 6)
        Me.picdodge.Name = "picdodge"
        Me.picdodge.Size = New System.Drawing.Size(16, 16)
        Me.picdodge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picdodge.TabIndex = 0
        Me.picdodge.TabStop = False
        '
        'pnldownload
        '
        Me.pnldownload.Controls.Add(Me.txtdownload)
        Me.pnldownload.Controls.Add(Me.Label26)
        Me.pnldownload.Controls.Add(Me.picdownload)
        Me.pnldownload.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnldownload.Location = New System.Drawing.Point(0, 672)
        Me.pnldownload.Name = "pnldownload"
        Me.pnldownload.Size = New System.Drawing.Size(330, 28)
        Me.pnldownload.TabIndex = 44
        Me.pnldownload.Visible = False
        '
        'txtdownload
        '
        Me.txtdownload.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtdownload.BackColor = System.Drawing.Color.White
        Me.txtdownload.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdownload.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdownload.Location = New System.Drawing.Point(151, 3)
        Me.txtdownload.Name = "txtdownload"
        Me.txtdownload.Size = New System.Drawing.Size(175, 22)
        Me.txtdownload.TabIndex = 2
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(28, 6)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(126, 16)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Download Manager"
        '
        'picdownload
        '
        Me.picdownload.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picdownload.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picdownload.Location = New System.Drawing.Point(7, 6)
        Me.picdownload.Name = "picdownload"
        Me.picdownload.Size = New System.Drawing.Size(16, 16)
        Me.picdownload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picdownload.TabIndex = 0
        Me.picdownload.TabStop = False
        '
        'pnlinstaller
        '
        Me.pnlinstaller.Controls.Add(Me.txtinstaller)
        Me.pnlinstaller.Controls.Add(Me.Label27)
        Me.pnlinstaller.Controls.Add(Me.picinstaller)
        Me.pnlinstaller.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlinstaller.Location = New System.Drawing.Point(0, 700)
        Me.pnlinstaller.Name = "pnlinstaller"
        Me.pnlinstaller.Size = New System.Drawing.Size(330, 28)
        Me.pnlinstaller.TabIndex = 45
        Me.pnlinstaller.Visible = False
        '
        'txtinstaller
        '
        Me.txtinstaller.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtinstaller.BackColor = System.Drawing.Color.White
        Me.txtinstaller.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtinstaller.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtinstaller.Location = New System.Drawing.Point(151, 3)
        Me.txtinstaller.Name = "txtinstaller"
        Me.txtinstaller.Size = New System.Drawing.Size(175, 22)
        Me.txtinstaller.TabIndex = 2
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(28, 6)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(54, 16)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "Installer"
        '
        'picinstaller
        '
        Me.picinstaller.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picinstaller.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picinstaller.Location = New System.Drawing.Point(7, 6)
        Me.picinstaller.Name = "picinstaller"
        Me.picinstaller.Size = New System.Drawing.Size(16, 16)
        Me.picinstaller.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picinstaller.TabIndex = 0
        Me.picinstaller.TabStop = False
        '
        'pnlsysinfo
        '
        Me.pnlsysinfo.Controls.Add(Me.txtsysinfo)
        Me.pnlsysinfo.Controls.Add(Me.Label28)
        Me.pnlsysinfo.Controls.Add(Me.picsysinfo)
        Me.pnlsysinfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlsysinfo.Location = New System.Drawing.Point(0, 728)
        Me.pnlsysinfo.Name = "pnlsysinfo"
        Me.pnlsysinfo.Size = New System.Drawing.Size(330, 28)
        Me.pnlsysinfo.TabIndex = 46
        Me.pnlsysinfo.Visible = False
        '
        'txtsysinfo
        '
        Me.txtsysinfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtsysinfo.BackColor = System.Drawing.Color.White
        Me.txtsysinfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsysinfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsysinfo.Location = New System.Drawing.Point(151, 3)
        Me.txtsysinfo.Name = "txtsysinfo"
        Me.txtsysinfo.Size = New System.Drawing.Size(175, 22)
        Me.txtsysinfo.TabIndex = 2
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(28, 6)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(121, 16)
        Me.Label28.TabIndex = 1
        Me.Label28.Text = "System Information"
        '
        'picsysinfo
        '
        Me.picsysinfo.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picsysinfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picsysinfo.Location = New System.Drawing.Point(7, 6)
        Me.picsysinfo.Name = "picsysinfo"
        Me.picsysinfo.Size = New System.Drawing.Size(16, 16)
        Me.picsysinfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picsysinfo.TabIndex = 0
        Me.picsysinfo.TabStop = False
        '
        'pnlorcwrite
        '
        Me.pnlorcwrite.Controls.Add(Me.txtorcwrite)
        Me.pnlorcwrite.Controls.Add(Me.Label29)
        Me.pnlorcwrite.Controls.Add(Me.picorcwrite)
        Me.pnlorcwrite.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlorcwrite.Location = New System.Drawing.Point(0, 756)
        Me.pnlorcwrite.Name = "pnlorcwrite"
        Me.pnlorcwrite.Size = New System.Drawing.Size(330, 28)
        Me.pnlorcwrite.TabIndex = 47
        Me.pnlorcwrite.Visible = False
        '
        'txtorcwrite
        '
        Me.txtorcwrite.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtorcwrite.BackColor = System.Drawing.Color.White
        Me.txtorcwrite.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtorcwrite.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtorcwrite.Location = New System.Drawing.Point(151, 3)
        Me.txtorcwrite.Name = "txtorcwrite"
        Me.txtorcwrite.Size = New System.Drawing.Size(175, 22)
        Me.txtorcwrite.TabIndex = 2
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(28, 6)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(60, 16)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = "OrcWrite"
        '
        'picorcwrite
        '
        Me.picorcwrite.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picorcwrite.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picorcwrite.Location = New System.Drawing.Point(7, 6)
        Me.picorcwrite.Name = "picorcwrite"
        Me.picorcwrite.Size = New System.Drawing.Size(16, 16)
        Me.picorcwrite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picorcwrite.TabIndex = 0
        Me.picorcwrite.TabStop = False
        '
        'pnlfloodgate
        '
        Me.pnlfloodgate.Controls.Add(Me.txtfloodgate)
        Me.pnlfloodgate.Controls.Add(Me.Label30)
        Me.pnlfloodgate.Controls.Add(Me.picfloodgate)
        Me.pnlfloodgate.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlfloodgate.Location = New System.Drawing.Point(0, 784)
        Me.pnlfloodgate.Name = "pnlfloodgate"
        Me.pnlfloodgate.Size = New System.Drawing.Size(330, 28)
        Me.pnlfloodgate.TabIndex = 48
        Me.pnlfloodgate.Visible = False
        '
        'txtfloodgate
        '
        Me.txtfloodgate.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtfloodgate.BackColor = System.Drawing.Color.White
        Me.txtfloodgate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtfloodgate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfloodgate.Location = New System.Drawing.Point(151, 3)
        Me.txtfloodgate.Name = "txtfloodgate"
        Me.txtfloodgate.Size = New System.Drawing.Size(175, 22)
        Me.txtfloodgate.TabIndex = 2
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(28, 6)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(75, 16)
        Me.Label30.TabIndex = 1
        Me.Label30.Text = "Flood Gate"
        '
        'picfloodgate
        '
        Me.picfloodgate.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picfloodgate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picfloodgate.Location = New System.Drawing.Point(7, 6)
        Me.picfloodgate.Name = "picfloodgate"
        Me.picfloodgate.Size = New System.Drawing.Size(16, 16)
        Me.picfloodgate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picfloodgate.TabIndex = 0
        Me.picfloodgate.TabStop = False
        '
        'pnlmaze
        '
        Me.pnlmaze.Controls.Add(Me.txtmaze)
        Me.pnlmaze.Controls.Add(Me.Label31)
        Me.pnlmaze.Controls.Add(Me.picmaze)
        Me.pnlmaze.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlmaze.Location = New System.Drawing.Point(0, 812)
        Me.pnlmaze.Name = "pnlmaze"
        Me.pnlmaze.Size = New System.Drawing.Size(330, 28)
        Me.pnlmaze.TabIndex = 49
        Me.pnlmaze.Visible = False
        '
        'txtmaze
        '
        Me.txtmaze.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtmaze.BackColor = System.Drawing.Color.White
        Me.txtmaze.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtmaze.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmaze.Location = New System.Drawing.Point(151, 3)
        Me.txtmaze.Name = "txtmaze"
        Me.txtmaze.Size = New System.Drawing.Size(175, 22)
        Me.txtmaze.TabIndex = 2
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(28, 6)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(62, 16)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "Labyrinth"
        '
        'picmaze
        '
        Me.picmaze.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picmaze.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picmaze.Location = New System.Drawing.Point(7, 6)
        Me.picmaze.Name = "picmaze"
        Me.picmaze.Size = New System.Drawing.Size(16, 16)
        Me.picmaze.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picmaze.TabIndex = 0
        Me.picmaze.TabStop = False
        '
        'pnlvirusscanner
        '
        Me.pnlvirusscanner.Controls.Add(Me.txtvirusscanner)
        Me.pnlvirusscanner.Controls.Add(Me.Label32)
        Me.pnlvirusscanner.Controls.Add(Me.picvirusscanner)
        Me.pnlvirusscanner.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlvirusscanner.Location = New System.Drawing.Point(0, 840)
        Me.pnlvirusscanner.Name = "pnlvirusscanner"
        Me.pnlvirusscanner.Size = New System.Drawing.Size(330, 28)
        Me.pnlvirusscanner.TabIndex = 50
        Me.pnlvirusscanner.Visible = False
        '
        'txtvirusscanner
        '
        Me.txtvirusscanner.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtvirusscanner.BackColor = System.Drawing.Color.White
        Me.txtvirusscanner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtvirusscanner.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtvirusscanner.Location = New System.Drawing.Point(151, 3)
        Me.txtvirusscanner.Name = "txtvirusscanner"
        Me.txtvirusscanner.Size = New System.Drawing.Size(175, 22)
        Me.txtvirusscanner.TabIndex = 2
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(28, 6)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(91, 16)
        Me.Label32.TabIndex = 1
        Me.Label32.Text = "Virus Scanner"
        '
        'picvirusscanner
        '
        Me.picvirusscanner.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.picvirusscanner.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picvirusscanner.Location = New System.Drawing.Point(7, 6)
        Me.picvirusscanner.Name = "picvirusscanner"
        Me.picvirusscanner.Size = New System.Drawing.Size(16, 16)
        Me.picvirusscanner.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picvirusscanner.TabIndex = 0
        Me.picvirusscanner.TabStop = False
        '
        'Name_Changer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(334, 765)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MinimumSize = New System.Drawing.Size(300, 400)
        Me.Name = "Name_Changer"
        Me.Text = "Name_Changer"
        Me.TopMost = True
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pgright.ResumeLayout(False)
        Me.pgcontents.ResumeLayout(False)
        Me.pnlprogramlistholder.ResumeLayout(False)
        Me.pnlterminalsettings.ResumeLayout(False)
        Me.pnlterminalsettings.PerformLayout()
        CType(Me.picterminalicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnliconmanagersettings.ResumeLayout(False)
        Me.pnliconmanagersettings.PerformLayout()
        CType(Me.piciconmanagericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlnamechangersettings.ResumeLayout(False)
        Me.pnlnamechangersettings.PerformLayout()
        CType(Me.picnamechangericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlvideoplayersettings.ResumeLayout(False)
        Me.pnlvideoplayersettings.PerformLayout()
        CType(Me.picvideoplayericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlwebbrowsersettings.ResumeLayout(False)
        Me.pnlwebbrowsersettings.PerformLayout()
        CType(Me.picwebbrowsericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlaudioplayersettings.ResumeLayout(False)
        Me.pnlaudioplayersettings.PerformLayout()
        CType(Me.picaudioplayericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlcalculatorsettings.ResumeLayout(False)
        Me.pnlcalculatorsettings.PerformLayout()
        CType(Me.piccalculatoricon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlartpadsettings.ResumeLayout(False)
        Me.pnlartpadsettings.PerformLayout()
        CType(Me.picartpadicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlskinloadersettings.ResumeLayout(False)
        Me.pnlskinloadersettings.PerformLayout()
        CType(Me.picskinloadericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlgraphicpickersettings.ResumeLayout(False)
        Me.pnlgraphicpickersettings.PerformLayout()
        CType(Me.picgraphicpickericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnltextpadsettings.ResumeLayout(False)
        Me.pnltextpadsettings.PerformLayout()
        CType(Me.pictextpadicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfilesaversettings.ResumeLayout(False)
        Me.pnlfilesaversettings.PerformLayout()
        CType(Me.picfilesavericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfileopenersettings.ResumeLayout(False)
        Me.pnlfileopenersettings.PerformLayout()
        CType(Me.picfileopenericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfileskimmersettings.ResumeLayout(False)
        Me.pnlfileskimmersettings.PerformLayout()
        CType(Me.picfileskimmericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpongsettings.ResumeLayout(False)
        Me.pnlpongsettings.PerformLayout()
        CType(Me.picpongicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlcolourpickersettings.ResumeLayout(False)
        Me.pnlcolourpickersettings.PerformLayout()
        CType(Me.piccolourpickericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlshiftersettings.ResumeLayout(False)
        Me.pnlshiftersettings.PerformLayout()
        CType(Me.picshiftericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlclocksettings.ResumeLayout(False)
        Me.pnlclocksettings.PerformLayout()
        CType(Me.picclockicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlshiftoriumsettings.ResumeLayout(False)
        Me.pnlshiftoriumsettings.PerformLayout()
        CType(Me.picshiftoriumicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlknowledgeinputsettings.ResumeLayout(False)
        Me.pnlknowledgeinputsettings.PerformLayout()
        CType(Me.picknowledgeinputicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pgleft.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        Me.pnlwallet.ResumeLayout(False)
        Me.pnlwallet.PerformLayout()
        CType(Me.picwallet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnldigger.ResumeLayout(False)
        Me.pnldigger.PerformLayout()
        CType(Me.picdigger, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlskinshifter.ResumeLayout(False)
        Me.pnlskinshifter.PerformLayout()
        CType(Me.picskinshifter, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlshiftnet.ResumeLayout(False)
        Me.pnlshiftnet.PerformLayout()
        CType(Me.picshiftnet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnldodge.ResumeLayout(False)
        Me.pnldodge.PerformLayout()
        CType(Me.picdodge, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnldownload.ResumeLayout(False)
        Me.pnldownload.PerformLayout()
        CType(Me.picdownload, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlinstaller.ResumeLayout(False)
        Me.pnlinstaller.PerformLayout()
        CType(Me.picinstaller, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlsysinfo.ResumeLayout(False)
        Me.pnlsysinfo.PerformLayout()
        CType(Me.picsysinfo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlorcwrite.ResumeLayout(False)
        Me.pnlorcwrite.PerformLayout()
        CType(Me.picorcwrite, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlfloodgate.ResumeLayout(False)
        Me.pnlfloodgate.PerformLayout()
        CType(Me.picfloodgate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlmaze.ResumeLayout(False)
        Me.pnlmaze.PerformLayout()
        CType(Me.picmaze, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlvirusscanner.ResumeLayout(False)
        Me.pnlvirusscanner.PerformLayout()
        CType(Me.picvirusscanner, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pullside As System.Windows.Forms.Timer
    Friend WithEvents pullbs As System.Windows.Forms.Timer
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents pullbottom As System.Windows.Forms.Timer
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnApply As System.Windows.Forms.Button
    Friend WithEvents pnlprogramlistholder As System.Windows.Forms.Panel
    Friend WithEvents pnlknowledgeinputsettings As System.Windows.Forms.Panel
    Friend WithEvents txtknowledgeinputname As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents picknowledgeinputicon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlfileskimmersettings As System.Windows.Forms.Panel
    Friend WithEvents txtfileskimmername As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents picfileskimmericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlpongsettings As System.Windows.Forms.Panel
    Friend WithEvents txtpongname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents picpongicon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlcolourpickersettings As System.Windows.Forms.Panel
    Friend WithEvents txtcolourpickername As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents piccolourpickericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlshiftersettings As System.Windows.Forms.Panel
    Friend WithEvents txtshiftername As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents picshiftericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlclocksettings As System.Windows.Forms.Panel
    Friend WithEvents txtclockname As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents picclockicon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlshiftoriumsettings As System.Windows.Forms.Panel
    Friend WithEvents txtshiftoriumname As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents picshiftoriumicon As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents pnlartpadsettings As System.Windows.Forms.Panel
    Friend WithEvents txtartpadname As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents picartpadicon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlskinloadersettings As System.Windows.Forms.Panel
    Friend WithEvents txtskinloadername As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents picskinloadericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlgraphicpickersettings As System.Windows.Forms.Panel
    Friend WithEvents txtgraphicpickername As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents picgraphicpickericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnltextpadsettings As System.Windows.Forms.Panel
    Friend WithEvents txttextpadname As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents pictextpadicon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlfilesaversettings As System.Windows.Forms.Panel
    Friend WithEvents txtfilesavername As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents picfilesavericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlfileopenersettings As System.Windows.Forms.Panel
    Friend WithEvents txtfileopenername As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents picfileopenericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlterminalsettings As System.Windows.Forms.Panel
    Friend WithEvents txtterminalname As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents picterminalicon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlvideoplayersettings As System.Windows.Forms.Panel
    Friend WithEvents txtvideoplayername As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents picvideoplayericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlwebbrowsersettings As System.Windows.Forms.Panel
    Friend WithEvents txtwebbrowsername As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents picwebbrowsericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlaudioplayersettings As System.Windows.Forms.Panel
    Friend WithEvents txtaudioplayername As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents picaudioplayericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnlcalculatorsettings As System.Windows.Forms.Panel
    Friend WithEvents txtcalculatorname As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents piccalculatoricon As System.Windows.Forms.PictureBox
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents pnlnamechangersettings As System.Windows.Forms.Panel
    Friend WithEvents txtnamechanger As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents picnamechangericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnliconmanagersettings As System.Windows.Forms.Panel
    Friend WithEvents txticonmanager As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents piciconmanagericon As System.Windows.Forms.PictureBox
    Friend WithEvents pnldigger As System.Windows.Forms.Panel
    Friend WithEvents txtdigger As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents picdigger As System.Windows.Forms.PictureBox
    Friend WithEvents pnlwallet As System.Windows.Forms.Panel
    Friend WithEvents txtwallet As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents picwallet As System.Windows.Forms.PictureBox
    Friend WithEvents pnlvirusscanner As System.Windows.Forms.Panel
    Friend WithEvents txtvirusscanner As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents picvirusscanner As System.Windows.Forms.PictureBox
    Friend WithEvents pnlmaze As System.Windows.Forms.Panel
    Friend WithEvents txtmaze As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents picmaze As System.Windows.Forms.PictureBox
    Friend WithEvents pnlfloodgate As System.Windows.Forms.Panel
    Friend WithEvents txtfloodgate As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents picfloodgate As System.Windows.Forms.PictureBox
    Friend WithEvents pnlorcwrite As System.Windows.Forms.Panel
    Friend WithEvents txtorcwrite As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents picorcwrite As System.Windows.Forms.PictureBox
    Friend WithEvents pnlsysinfo As System.Windows.Forms.Panel
    Friend WithEvents txtsysinfo As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents picsysinfo As System.Windows.Forms.PictureBox
    Friend WithEvents pnlinstaller As System.Windows.Forms.Panel
    Friend WithEvents txtinstaller As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents picinstaller As System.Windows.Forms.PictureBox
    Friend WithEvents pnldownload As System.Windows.Forms.Panel
    Friend WithEvents txtdownload As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents picdownload As System.Windows.Forms.PictureBox
    Friend WithEvents pnldodge As System.Windows.Forms.Panel
    Friend WithEvents txtdodge As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents picdodge As System.Windows.Forms.PictureBox
    Friend WithEvents pnlshiftnet As System.Windows.Forms.Panel
    Friend WithEvents txtshiftnet As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents picshiftnet As System.Windows.Forms.PictureBox
    Friend WithEvents pnlskinshifter As System.Windows.Forms.Panel
    Friend WithEvents txtskinshifter As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents picskinshifter As System.Windows.Forms.PictureBox
End Class
