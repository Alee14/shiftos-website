﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Skin_Loader
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.btnapplyskin = New System.Windows.Forms.Button()
        Me.btnsaveskin = New System.Windows.Forms.Button()
        Me.btnloadskin = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.pnldesktoppreview = New System.Windows.Forms.Panel()
        Me.predesktoppanel = New System.Windows.Forms.Panel()
        Me.prepnlpanelbuttonholder = New System.Windows.Forms.FlowLayoutPanel()
        Me.prepnlpanelbutton = New System.Windows.Forms.Panel()
        Me.pretbicon = New System.Windows.Forms.PictureBox()
        Me.pretbctext = New System.Windows.Forms.Label()
        Me.pretimepanel = New System.Windows.Forms.Panel()
        Me.prepaneltimetext = New System.Windows.Forms.Label()
        Me.preapplaunchermenuholder = New System.Windows.Forms.Panel()
        Me.predesktopappmenu = New System.Windows.Forms.MenuStrip()
        Me.ApplicationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KnowledgeInputToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShiftoriumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShifterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlwindowpreview = New System.Windows.Forms.Panel()
        Me.prepgcontent = New System.Windows.Forms.Panel()
        Me.prepgbottom = New System.Windows.Forms.Panel()
        Me.prepgleft = New System.Windows.Forms.Panel()
        Me.prepgbottomlcorner = New System.Windows.Forms.Panel()
        Me.prepgright = New System.Windows.Forms.Panel()
        Me.prepgbottomrcorner = New System.Windows.Forms.Panel()
        Me.pretitlebar = New System.Windows.Forms.Panel()
        Me.preminimizebutton = New System.Windows.Forms.Panel()
        Me.prepnlicon = New System.Windows.Forms.PictureBox()
        Me.prerollupbutton = New System.Windows.Forms.Panel()
        Me.preclosebutton = New System.Windows.Forms.Panel()
        Me.pretitletext = New System.Windows.Forms.Label()
        Me.prepgtoplcorner = New System.Windows.Forms.Panel()
        Me.prepgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.pgcontents.SuspendLayout()
        Me.pnldesktoppreview.SuspendLayout()
        Me.predesktoppanel.SuspendLayout()
        Me.prepnlpanelbuttonholder.SuspendLayout()
        Me.prepnlpanelbutton.SuspendLayout()
        CType(Me.pretbicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pretimepanel.SuspendLayout()
        Me.preapplaunchermenuholder.SuspendLayout()
        Me.predesktopappmenu.SuspendLayout()
        Me.pnlwindowpreview.SuspendLayout()
        Me.prepgleft.SuspendLayout()
        Me.prepgright.SuspendLayout()
        Me.pretitlebar.SuspendLayout()
        CType(Me.prepnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pgleft.SuspendLayout()
        Me.pgright.SuspendLayout()
        Me.titlebar.SuspendLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pgcontents
        '
        Me.pgcontents.BackColor = System.Drawing.Color.White
        Me.pgcontents.Controls.Add(Me.btnapplyskin)
        Me.pgcontents.Controls.Add(Me.btnsaveskin)
        Me.pgcontents.Controls.Add(Me.btnloadskin)
        Me.pgcontents.Controls.Add(Me.Label2)
        Me.pgcontents.Controls.Add(Me.btnclose)
        Me.pgcontents.Controls.Add(Me.pnldesktoppreview)
        Me.pgcontents.Controls.Add(Me.Label1)
        Me.pgcontents.Controls.Add(Me.pnlwindowpreview)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(472, 430)
        Me.pgcontents.TabIndex = 20
        '
        'btnapplyskin
        '
        Me.btnapplyskin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnapplyskin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnapplyskin.Location = New System.Drawing.Point(352, 389)
        Me.btnapplyskin.Name = "btnapplyskin"
        Me.btnapplyskin.Size = New System.Drawing.Size(107, 32)
        Me.btnapplyskin.TabIndex = 9
        Me.btnapplyskin.Text = "Apply Skin"
        Me.btnapplyskin.UseVisualStyleBackColor = True
        '
        'btnsaveskin
        '
        Me.btnsaveskin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsaveskin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsaveskin.Location = New System.Drawing.Point(239, 389)
        Me.btnsaveskin.Name = "btnsaveskin"
        Me.btnsaveskin.Size = New System.Drawing.Size(107, 32)
        Me.btnsaveskin.TabIndex = 8
        Me.btnsaveskin.Text = "Save Skin"
        Me.btnsaveskin.UseVisualStyleBackColor = True
        '
        'btnloadskin
        '
        Me.btnloadskin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnloadskin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnloadskin.Location = New System.Drawing.Point(126, 389)
        Me.btnloadskin.Name = "btnloadskin"
        Me.btnloadskin.Size = New System.Drawing.Size(107, 32)
        Me.btnloadskin.TabIndex = 7
        Me.btnloadskin.Text = "Load Skin"
        Me.btnloadskin.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 200)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(464, 30)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Desktop Preview"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnclose
        '
        Me.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclose.Location = New System.Drawing.Point(13, 389)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(107, 32)
        Me.btnclose.TabIndex = 5
        Me.btnclose.Text = "Close"
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'pnldesktoppreview
        '
        Me.pnldesktoppreview.Controls.Add(Me.predesktoppanel)
        Me.pnldesktoppreview.Location = New System.Drawing.Point(13, 233)
        Me.pnldesktoppreview.Name = "pnldesktoppreview"
        Me.pnldesktoppreview.Size = New System.Drawing.Size(448, 148)
        Me.pnldesktoppreview.TabIndex = 4
        '
        'predesktoppanel
        '
        Me.predesktoppanel.BackColor = System.Drawing.Color.Gray
        Me.predesktoppanel.Controls.Add(Me.prepnlpanelbuttonholder)
        Me.predesktoppanel.Controls.Add(Me.pretimepanel)
        Me.predesktoppanel.Controls.Add(Me.preapplaunchermenuholder)
        Me.predesktoppanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.predesktoppanel.Location = New System.Drawing.Point(0, 0)
        Me.predesktoppanel.Name = "predesktoppanel"
        Me.predesktoppanel.Size = New System.Drawing.Size(448, 25)
        Me.predesktoppanel.TabIndex = 1
        '
        'prepnlpanelbuttonholder
        '
        Me.prepnlpanelbuttonholder.BackColor = System.Drawing.Color.Transparent
        Me.prepnlpanelbuttonholder.Controls.Add(Me.prepnlpanelbutton)
        Me.prepnlpanelbuttonholder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.prepnlpanelbuttonholder.Location = New System.Drawing.Point(116, 0)
        Me.prepnlpanelbuttonholder.Name = "prepnlpanelbuttonholder"
        Me.prepnlpanelbuttonholder.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.prepnlpanelbuttonholder.Size = New System.Drawing.Size(235, 25)
        Me.prepnlpanelbuttonholder.TabIndex = 7
        '
        'prepnlpanelbutton
        '
        Me.prepnlpanelbutton.BackColor = System.Drawing.Color.Black
        Me.prepnlpanelbutton.Controls.Add(Me.pretbicon)
        Me.prepnlpanelbutton.Controls.Add(Me.pretbctext)
        Me.prepnlpanelbutton.Location = New System.Drawing.Point(5, 3)
        Me.prepnlpanelbutton.Name = "prepnlpanelbutton"
        Me.prepnlpanelbutton.Size = New System.Drawing.Size(126, 20)
        Me.prepnlpanelbutton.TabIndex = 18
        Me.prepnlpanelbutton.Visible = False
        '
        'pretbicon
        '
        Me.pretbicon.BackColor = System.Drawing.Color.Transparent
        Me.pretbicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pretbicon.Image = Global.ShiftOS.My.Resources.Resources.iconShifter
        Me.pretbicon.Location = New System.Drawing.Point(4, 2)
        Me.pretbicon.Name = "pretbicon"
        Me.pretbicon.Size = New System.Drawing.Size(16, 16)
        Me.pretbicon.TabIndex = 1
        Me.pretbicon.TabStop = False
        '
        'pretbctext
        '
        Me.pretbctext.AutoSize = True
        Me.pretbctext.BackColor = System.Drawing.Color.Transparent
        Me.pretbctext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pretbctext.ForeColor = System.Drawing.Color.White
        Me.pretbctext.Location = New System.Drawing.Point(24, 2)
        Me.pretbctext.Name = "pretbctext"
        Me.pretbctext.Size = New System.Drawing.Size(45, 16)
        Me.pretbctext.TabIndex = 0
        Me.pretbctext.Text = "Shifter"
        '
        'pretimepanel
        '
        Me.pretimepanel.Controls.Add(Me.prepaneltimetext)
        Me.pretimepanel.Dock = System.Windows.Forms.DockStyle.Right
        Me.pretimepanel.Location = New System.Drawing.Point(351, 0)
        Me.pretimepanel.Name = "pretimepanel"
        Me.pretimepanel.Size = New System.Drawing.Size(97, 25)
        Me.pretimepanel.TabIndex = 5
        '
        'prepaneltimetext
        '
        Me.prepaneltimetext.AutoSize = True
        Me.prepaneltimetext.BackColor = System.Drawing.Color.Transparent
        Me.prepaneltimetext.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prepaneltimetext.Location = New System.Drawing.Point(5, 0)
        Me.prepaneltimetext.Name = "prepaneltimetext"
        Me.prepaneltimetext.Size = New System.Drawing.Size(80, 24)
        Me.prepaneltimetext.TabIndex = 1
        Me.prepaneltimetext.Text = "5000023"
        Me.prepaneltimetext.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'preapplaunchermenuholder
        '
        Me.preapplaunchermenuholder.Controls.Add(Me.predesktopappmenu)
        Me.preapplaunchermenuholder.Dock = System.Windows.Forms.DockStyle.Left
        Me.preapplaunchermenuholder.Location = New System.Drawing.Point(0, 0)
        Me.preapplaunchermenuholder.Name = "preapplaunchermenuholder"
        Me.preapplaunchermenuholder.Size = New System.Drawing.Size(116, 25)
        Me.preapplaunchermenuholder.TabIndex = 4
        '
        'predesktopappmenu
        '
        Me.predesktopappmenu.AutoSize = False
        Me.predesktopappmenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplicationsToolStripMenuItem})
        Me.predesktopappmenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.predesktopappmenu.Location = New System.Drawing.Point(0, 0)
        Me.predesktopappmenu.Name = "predesktopappmenu"
        Me.predesktopappmenu.Padding = New System.Windows.Forms.Padding(0)
        Me.predesktopappmenu.Size = New System.Drawing.Size(116, 24)
        Me.predesktopappmenu.TabIndex = 0
        Me.predesktopappmenu.Text = "MenuStrip1"
        '
        'ApplicationsToolStripMenuItem
        '
        Me.ApplicationsToolStripMenuItem.AutoSize = False
        Me.ApplicationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KnowledgeInputToolStripMenuItem, Me.ShiftoriumToolStripMenuItem, Me.ClockToolStripMenuItem, Me.TerminalToolStripMenuItem, Me.ShifterToolStripMenuItem, Me.ToolStripSeparator1, Me.ShutdownToolStripMenuItem})
        Me.ApplicationsToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ApplicationsToolStripMenuItem.Name = "ApplicationsToolStripMenuItem"
        Me.ApplicationsToolStripMenuItem.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ApplicationsToolStripMenuItem.ShowShortcutKeys = False
        Me.ApplicationsToolStripMenuItem.Size = New System.Drawing.Size(102, 24)
        Me.ApplicationsToolStripMenuItem.Text = "Applications"
        Me.ApplicationsToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        Me.ApplicationsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'KnowledgeInputToolStripMenuItem
        '
        Me.KnowledgeInputToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.KnowledgeInputToolStripMenuItem.Name = "KnowledgeInputToolStripMenuItem"
        Me.KnowledgeInputToolStripMenuItem.ShowShortcutKeys = False
        Me.KnowledgeInputToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.KnowledgeInputToolStripMenuItem.Text = "Knowledge Input"
        '
        'ShiftoriumToolStripMenuItem
        '
        Me.ShiftoriumToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShiftoriumToolStripMenuItem.Name = "ShiftoriumToolStripMenuItem"
        Me.ShiftoriumToolStripMenuItem.ShowShortcutKeys = False
        Me.ShiftoriumToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ShiftoriumToolStripMenuItem.Text = "Shiftorium"
        '
        'ClockToolStripMenuItem
        '
        Me.ClockToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ClockToolStripMenuItem.Name = "ClockToolStripMenuItem"
        Me.ClockToolStripMenuItem.ShowShortcutKeys = False
        Me.ClockToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ClockToolStripMenuItem.Text = "Clock"
        '
        'TerminalToolStripMenuItem
        '
        Me.TerminalToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.TerminalToolStripMenuItem.Name = "TerminalToolStripMenuItem"
        Me.TerminalToolStripMenuItem.ShowShortcutKeys = False
        Me.TerminalToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.TerminalToolStripMenuItem.Text = "Terminal"
        '
        'ShifterToolStripMenuItem
        '
        Me.ShifterToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShifterToolStripMenuItem.Name = "ShifterToolStripMenuItem"
        Me.ShifterToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ShifterToolStripMenuItem.Text = "Shifter"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripSeparator1.ForeColor = System.Drawing.Color.White
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(178, 6)
        '
        'ShutdownToolStripMenuItem
        '
        Me.ShutdownToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShutdownToolStripMenuItem.Name = "ShutdownToolStripMenuItem"
        Me.ShutdownToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ShutdownToolStripMenuItem.Text = "Shut Down"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(464, 30)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Window Preview"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlwindowpreview
        '
        Me.pnlwindowpreview.Controls.Add(Me.prepgcontent)
        Me.pnlwindowpreview.Controls.Add(Me.prepgbottom)
        Me.pnlwindowpreview.Controls.Add(Me.prepgleft)
        Me.pnlwindowpreview.Controls.Add(Me.prepgright)
        Me.pnlwindowpreview.Controls.Add(Me.pretitlebar)
        Me.pnlwindowpreview.Location = New System.Drawing.Point(13, 39)
        Me.pnlwindowpreview.Name = "pnlwindowpreview"
        Me.pnlwindowpreview.Size = New System.Drawing.Size(448, 148)
        Me.pnlwindowpreview.TabIndex = 1
        '
        'prepgcontent
        '
        Me.prepgcontent.Dock = System.Windows.Forms.DockStyle.Fill
        Me.prepgcontent.Location = New System.Drawing.Point(2, 30)
        Me.prepgcontent.Name = "prepgcontent"
        Me.prepgcontent.Size = New System.Drawing.Size(444, 116)
        Me.prepgcontent.TabIndex = 20
        '
        'prepgbottom
        '
        Me.prepgbottom.BackColor = System.Drawing.Color.Gray
        Me.prepgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.prepgbottom.Location = New System.Drawing.Point(2, 146)
        Me.prepgbottom.Name = "prepgbottom"
        Me.prepgbottom.Size = New System.Drawing.Size(444, 2)
        Me.prepgbottom.TabIndex = 23
        '
        'prepgleft
        '
        Me.prepgleft.BackColor = System.Drawing.Color.Gray
        Me.prepgleft.Controls.Add(Me.prepgbottomlcorner)
        Me.prepgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.prepgleft.Location = New System.Drawing.Point(0, 30)
        Me.prepgleft.Name = "prepgleft"
        Me.prepgleft.Size = New System.Drawing.Size(2, 118)
        Me.prepgleft.TabIndex = 21
        '
        'prepgbottomlcorner
        '
        Me.prepgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.prepgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.prepgbottomlcorner.Location = New System.Drawing.Point(0, 116)
        Me.prepgbottomlcorner.Name = "prepgbottomlcorner"
        Me.prepgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.prepgbottomlcorner.TabIndex = 14
        '
        'prepgright
        '
        Me.prepgright.BackColor = System.Drawing.Color.Gray
        Me.prepgright.Controls.Add(Me.prepgbottomrcorner)
        Me.prepgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.prepgright.Location = New System.Drawing.Point(446, 30)
        Me.prepgright.Name = "prepgright"
        Me.prepgright.Size = New System.Drawing.Size(2, 118)
        Me.prepgright.TabIndex = 22
        '
        'prepgbottomrcorner
        '
        Me.prepgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.prepgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.prepgbottomrcorner.Location = New System.Drawing.Point(0, 116)
        Me.prepgbottomrcorner.Name = "prepgbottomrcorner"
        Me.prepgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.prepgbottomrcorner.TabIndex = 15
        '
        'pretitlebar
        '
        Me.pretitlebar.BackColor = System.Drawing.Color.Gray
        Me.pretitlebar.Controls.Add(Me.preminimizebutton)
        Me.pretitlebar.Controls.Add(Me.prepnlicon)
        Me.pretitlebar.Controls.Add(Me.prerollupbutton)
        Me.pretitlebar.Controls.Add(Me.preclosebutton)
        Me.pretitlebar.Controls.Add(Me.pretitletext)
        Me.pretitlebar.Controls.Add(Me.prepgtoplcorner)
        Me.pretitlebar.Controls.Add(Me.prepgtoprcorner)
        Me.pretitlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pretitlebar.ForeColor = System.Drawing.Color.White
        Me.pretitlebar.Location = New System.Drawing.Point(0, 0)
        Me.pretitlebar.Name = "pretitlebar"
        Me.pretitlebar.Size = New System.Drawing.Size(448, 30)
        Me.pretitlebar.TabIndex = 19
        '
        'preminimizebutton
        '
        Me.preminimizebutton.BackColor = System.Drawing.Color.Black
        Me.preminimizebutton.Location = New System.Drawing.Point(362, 5)
        Me.preminimizebutton.Name = "preminimizebutton"
        Me.preminimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.preminimizebutton.TabIndex = 32
        '
        'prepnlicon
        '
        Me.prepnlicon.BackColor = System.Drawing.Color.Transparent
        Me.prepnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconSkinLoader
        Me.prepnlicon.Location = New System.Drawing.Point(8, 8)
        Me.prepnlicon.Name = "prepnlicon"
        Me.prepnlicon.Size = New System.Drawing.Size(16, 16)
        Me.prepnlicon.TabIndex = 32
        Me.prepnlicon.TabStop = False
        Me.prepnlicon.Visible = False
        '
        'prerollupbutton
        '
        Me.prerollupbutton.BackColor = System.Drawing.Color.Black
        Me.prerollupbutton.Location = New System.Drawing.Point(390, 5)
        Me.prerollupbutton.Name = "prerollupbutton"
        Me.prerollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.prerollupbutton.TabIndex = 31
        '
        'preclosebutton
        '
        Me.preclosebutton.BackColor = System.Drawing.Color.Black
        Me.preclosebutton.Location = New System.Drawing.Point(419, 5)
        Me.preclosebutton.Name = "preclosebutton"
        Me.preclosebutton.Size = New System.Drawing.Size(22, 22)
        Me.preclosebutton.TabIndex = 20
        '
        'pretitletext
        '
        Me.pretitletext.AutoSize = True
        Me.pretitletext.BackColor = System.Drawing.Color.Transparent
        Me.pretitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pretitletext.Location = New System.Drawing.Point(29, 7)
        Me.pretitletext.Name = "pretitletext"
        Me.pretitletext.Size = New System.Drawing.Size(77, 18)
        Me.pretitletext.TabIndex = 19
        Me.pretitletext.Text = "Template"
        '
        'prepgtoplcorner
        '
        Me.prepgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.prepgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.prepgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.prepgtoplcorner.Name = "prepgtoplcorner"
        Me.prepgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.prepgtoplcorner.TabIndex = 17
        '
        'prepgtoprcorner
        '
        Me.prepgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.prepgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.prepgtoprcorner.Location = New System.Drawing.Point(446, 0)
        Me.prepgtoprcorner.Name = "prepgtoprcorner"
        Me.prepgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.prepgtoprcorner.TabIndex = 16
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 432)
        Me.pgleft.TabIndex = 21
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 430)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(474, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 432)
        Me.pgright.TabIndex = 22
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 430)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(476, 30)
        Me.titlebar.TabIndex = 19
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(391, 2)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 24
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconSkinLoader
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(419, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(447, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(98, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Skin Loader"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(474, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 460)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(472, 2)
        Me.pgbottom.TabIndex = 23
        '
        'Skin_Loader
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(476, 462)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Skin_Loader"
        Me.Text = "Skin_Loader"
        Me.TopMost = True
        Me.pgcontents.ResumeLayout(False)
        Me.pnldesktoppreview.ResumeLayout(False)
        Me.predesktoppanel.ResumeLayout(False)
        Me.prepnlpanelbuttonholder.ResumeLayout(False)
        Me.prepnlpanelbutton.ResumeLayout(False)
        Me.prepnlpanelbutton.PerformLayout()
        CType(Me.pretbicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pretimepanel.ResumeLayout(False)
        Me.pretimepanel.PerformLayout()
        Me.preapplaunchermenuholder.ResumeLayout(False)
        Me.predesktopappmenu.ResumeLayout(False)
        Me.predesktopappmenu.PerformLayout()
        Me.pnlwindowpreview.ResumeLayout(False)
        Me.prepgleft.ResumeLayout(False)
        Me.prepgright.ResumeLayout(False)
        Me.pretitlebar.ResumeLayout(False)
        Me.pretitlebar.PerformLayout()
        CType(Me.prepnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pgleft.ResumeLayout(False)
        Me.pgright.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pnlwindowpreview As System.Windows.Forms.Panel
    Friend WithEvents prepgcontent As System.Windows.Forms.Panel
    Friend WithEvents prepgbottom As System.Windows.Forms.Panel
    Friend WithEvents prepgleft As System.Windows.Forms.Panel
    Friend WithEvents prepgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents prepgright As System.Windows.Forms.Panel
    Friend WithEvents prepgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents pretitlebar As System.Windows.Forms.Panel
    Friend WithEvents prepnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents prerollupbutton As System.Windows.Forms.Panel
    Friend WithEvents preclosebutton As System.Windows.Forms.Panel
    Friend WithEvents pretitletext As System.Windows.Forms.Label
    Friend WithEvents prepgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents prepgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents btnapplyskin As System.Windows.Forms.Button
    Friend WithEvents btnsaveskin As System.Windows.Forms.Button
    Friend WithEvents btnloadskin As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnclose As System.Windows.Forms.Button
    Friend WithEvents pnldesktoppreview As System.Windows.Forms.Panel
    Friend WithEvents predesktoppanel As System.Windows.Forms.Panel
    Friend WithEvents pretimepanel As System.Windows.Forms.Panel
    Friend WithEvents prepaneltimetext As System.Windows.Forms.Label
    Friend WithEvents preapplaunchermenuholder As System.Windows.Forms.Panel
    Friend WithEvents predesktopappmenu As System.Windows.Forms.MenuStrip
    Friend WithEvents ApplicationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KnowledgeInputToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShiftoriumToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TerminalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShifterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ShutdownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents preminimizebutton As System.Windows.Forms.Panel
    Friend WithEvents prepnlpanelbuttonholder As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents prepnlpanelbutton As System.Windows.Forms.Panel
    Friend WithEvents pretbicon As System.Windows.Forms.PictureBox
    Friend WithEvents pretbctext As System.Windows.Forms.Label
End Class
