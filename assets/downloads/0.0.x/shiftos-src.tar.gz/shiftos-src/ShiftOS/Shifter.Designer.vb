﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Shifter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Shifter))
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.clocktick = New System.Windows.Forms.Timer(Me.components)
        Me.customizationtime = New System.Windows.Forms.Timer(Me.components)
        Me.timerearned = New System.Windows.Forms.Timer(Me.components)
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnapply = New System.Windows.Forms.Button()
        Me.catholder = New System.Windows.Forms.Panel()
        Me.btnreset = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btndeskdoubleplus = New System.Windows.Forms.Button()
        Me.btnprograms = New System.Windows.Forms.Button()
        Me.btnicons = New System.Windows.Forms.Button()
        Me.btnwindows = New System.Windows.Forms.Button()
        Me.btndesktop = New System.Windows.Forms.Button()
        Me.pnlshifterintro = New System.Windows.Forms.Panel()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.pnldesktopoptions = New System.Windows.Forms.Panel()
        Me.pnlapplauncheroptions = New System.Windows.Forms.Panel()
        Me.pnllauncheritems = New System.Windows.Forms.Panel()
        Me.launcheritemtxtcolour = New System.Windows.Forms.Panel()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.launcheritemstyle = New System.Windows.Forms.ComboBox()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.launcheritemfont = New System.Windows.Forms.ComboBox()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.txtlauncheritemtxtsize = New System.Windows.Forms.TextBox()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.btnshowlauncheritems = New System.Windows.Forms.Button()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.txtapplauncherwidth = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.txtappbuttonlabel = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.pnlmaintextcolour = New System.Windows.Forms.Panel()
        Me.comboappbuttontextstyle = New System.Windows.Forms.ComboBox()
        Me.comboappbuttontextfont = New System.Windows.Forms.ComboBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.txtappbuttontextsize = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.pnlmenuitemsmouseover = New System.Windows.Forms.Panel()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.pnlmenuitemscolour = New System.Windows.Forms.Panel()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.pnlmainbuttonactivated = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtapplicationsbuttonheight = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.pnlmainbuttoncolour = New System.Windows.Forms.Panel()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.pnldesktoppreview = New System.Windows.Forms.Panel()
        Me.predesktoppanel = New System.Windows.Forms.Panel()
        Me.prepnlpanelbuttonholder = New System.Windows.Forms.FlowLayoutPanel()
        Me.prepnlpanelbutton = New System.Windows.Forms.Panel()
        Me.pretbicon = New System.Windows.Forms.PictureBox()
        Me.pretbctext = New System.Windows.Forms.Label()
        Me.pretimepanel = New System.Windows.Forms.Panel()
        Me.prepaneltimetext = New System.Windows.Forms.Label()
        Me.preapplaunchermenuholder = New System.Windows.Forms.Panel()
        Me.predesktopappmenu = New System.Windows.Forms.MenuStrip()
        Me.ApplicationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KnowledgeInputToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShiftoriumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShifterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnlpanelbuttonsoptions = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttontextcolour = New System.Windows.Forms.Panel()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.txtpanelbuttontexttop = New System.Windows.Forms.TextBox()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.txtpanelbuttontextside = New System.Windows.Forms.TextBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.txtpanelbuttontop = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.txtpanelbuttoninitalgap = New System.Windows.Forms.TextBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.txtpanelbuttonicontop = New System.Windows.Forms.TextBox()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.txtpanelbuttoniconside = New System.Windows.Forms.TextBox()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.txtpanelbuttoniconsize = New System.Windows.Forms.TextBox()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.cbpanelbuttontextstyle = New System.Windows.Forms.ComboBox()
        Me.cbpanelbuttonfont = New System.Windows.Forms.ComboBox()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.txtpaneltextbuttonsize = New System.Windows.Forms.TextBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.txtpanelbuttongap = New System.Windows.Forms.TextBox()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.txtpanelbuttonheight = New System.Windows.Forms.TextBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.txtpanelbuttonwidth = New System.Windows.Forms.TextBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.pnlpanelbuttoncolour = New System.Windows.Forms.Panel()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.pnldesktoppaneloptions = New System.Windows.Forms.Panel()
        Me.btnpanelbuttons = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.combodesktoppanelposition = New System.Windows.Forms.ComboBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.txtdesktoppanelheight = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.pnldesktoppanelcolour = New System.Windows.Forms.Panel()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.pnldesktopintro = New System.Windows.Forms.Panel()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.pnlpanelclockoptions = New System.Windows.Forms.Panel()
        Me.pnlclockbackgroundcolour = New System.Windows.Forms.Panel()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.comboclocktextstyle = New System.Windows.Forms.ComboBox()
        Me.comboclocktextfont = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtclocktextfromtop = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtclocktextsize = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.pnlpanelclocktextcolour = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.pnldesktopbackgroundoptions = New System.Windows.Forms.Panel()
        Me.pnldesktopcolour = New System.Windows.Forms.Panel()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.btndesktopitself = New System.Windows.Forms.Button()
        Me.btnpanelclock = New System.Windows.Forms.Button()
        Me.btnapplauncher = New System.Windows.Forms.Button()
        Me.btndesktoppanel = New System.Windows.Forms.Button()
        Me.txtpanelbuttoniconheight = New System.Windows.Forms.TextBox()
        Me.pnlwindowsoptions = New System.Windows.Forms.Panel()
        Me.pnlbuttonoptions = New System.Windows.Forms.Panel()
        Me.pnlminimizebuttonoptions = New System.Windows.Forms.Panel()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.pnlminimizebuttoncolour = New System.Windows.Forms.Panel()
        Me.txtminimizebuttonside = New System.Windows.Forms.TextBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.txtminimizebuttonheight = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.txtminimizebuttontop = New System.Windows.Forms.TextBox()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.txtminimizebuttonwidth = New System.Windows.Forms.TextBox()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.pnlrollupbuttonoptions = New System.Windows.Forms.Panel()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.pnlrollupbuttoncolour = New System.Windows.Forms.Panel()
        Me.txtrollupbuttonside = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.txtrollupbuttonheight = New System.Windows.Forms.TextBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.txtrollupbuttontop = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.txtrollupbuttonwidth = New System.Windows.Forms.TextBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.combobuttonoption = New System.Windows.Forms.ComboBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.pnlclosebuttonoptions = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.pnlclosebuttoncolour = New System.Windows.Forms.Panel()
        Me.txtclosebuttonfromside = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtclosebuttonheight = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtclosebuttonfromtop = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtclosebuttonwidth = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.pnltitlebaroptions = New System.Windows.Forms.Panel()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.txticonfromtop = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.txticonfromside = New System.Windows.Forms.TextBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.lbcornerwidthpx = New System.Windows.Forms.Label()
        Me.txttitlebarcornerwidth = New System.Windows.Forms.TextBox()
        Me.lbcornerwidth = New System.Windows.Forms.Label()
        Me.pnltitlebarrightcornercolour = New System.Windows.Forms.Panel()
        Me.pnltitlebarleftcornercolour = New System.Windows.Forms.Panel()
        Me.lbrightcornercolor = New System.Windows.Forms.Label()
        Me.lbleftcornercolor = New System.Windows.Forms.Label()
        Me.cboxtitlebarcorners = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txttitlebarheight = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.pnltitlebarcolour = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pnlborderoptions = New System.Windows.Forms.Panel()
        Me.cbindividualbordercolours = New System.Windows.Forms.CheckBox()
        Me.pnlborderbottomrightcolour = New System.Windows.Forms.Panel()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.pnlborderbottomcolour = New System.Windows.Forms.Panel()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.pnlborderbottomleftcolour = New System.Windows.Forms.Panel()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.pnlborderrightcolour = New System.Windows.Forms.Panel()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.pnlborderleftcolour = New System.Windows.Forms.Panel()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.pnlbordercolour = New System.Windows.Forms.Panel()
        Me.txtbordersize = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.pnltitletextoptions = New System.Windows.Forms.Panel()
        Me.combotitletextposition = New System.Windows.Forms.ComboBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.combotitletextstyle = New System.Windows.Forms.ComboBox()
        Me.combotitletextfont = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txttitletextside = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txttitletexttop = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txttitletextsize = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.pnltitletextcolour = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.pnlwindowsintro = New System.Windows.Forms.Panel()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.pnlwindowsobjects = New System.Windows.Forms.Panel()
        Me.btnborders = New System.Windows.Forms.Button()
        Me.btnbuttons = New System.Windows.Forms.Button()
        Me.btntitletext = New System.Windows.Forms.Button()
        Me.btntitlebar = New System.Windows.Forms.Button()
        Me.pnlwindowpreview = New System.Windows.Forms.Panel()
        Me.prepgcontent = New System.Windows.Forms.Panel()
        Me.prepgbottom = New System.Windows.Forms.Panel()
        Me.prepgleft = New System.Windows.Forms.Panel()
        Me.prepgbottomlcorner = New System.Windows.Forms.Panel()
        Me.prepgright = New System.Windows.Forms.Panel()
        Me.prepgbottomrcorner = New System.Windows.Forms.Panel()
        Me.pretitlebar = New System.Windows.Forms.Panel()
        Me.preminimizebutton = New System.Windows.Forms.Panel()
        Me.prepnlicon = New System.Windows.Forms.PictureBox()
        Me.prerollupbutton = New System.Windows.Forms.Panel()
        Me.preclosebutton = New System.Windows.Forms.Panel()
        Me.pretitletext = New System.Windows.Forms.Label()
        Me.prepgtoplcorner = New System.Windows.Forms.Panel()
        Me.prepgtoprcorner = New System.Windows.Forms.Panel()
        Me.pnlreset = New System.Windows.Forms.Panel()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.btnresetallsettings = New System.Windows.Forms.Button()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.pnlshiftadvapplauncher = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnaalpwrpnlbg = New System.Windows.Forms.Button()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.btnaalusrpnlbg = New System.Windows.Forms.Button()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.btnaalshutdowntextcolor = New System.Windows.Forms.Button()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.cmbaalusrstyle = New System.Windows.Forms.ComboBox()
        Me.nudusrsize = New System.Windows.Forms.NumericUpDown()
        Me.cmbaalusrfont = New System.Windows.Forms.ComboBox()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.btnaalusrtextcolor = New System.Windows.Forms.Button()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.pnldeskdoubleplus = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.desktopiconspreview = New System.Windows.Forms.ListView()
        Me.pnldppoptions = New System.Windows.Forms.Panel()
        Me.pnldppicons = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.pnldppfunctions = New System.Windows.Forms.Panel()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.btndppfunctions = New System.Windows.Forms.Button()
        Me.btndppappearance = New System.Windows.Forms.Button()
        Me.btndppfiles = New System.Windows.Forms.Button()
        Me.btndppicons = New System.Windows.Forms.Button()
        Me.tmrfix = New System.Windows.Forms.Timer(Me.components)
        Me.tmrdelay = New System.Windows.Forms.Timer(Me.components)
        Me.pgleft.SuspendLayout()
        Me.pgright.SuspendLayout()
        Me.titlebar.SuspendLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.catholder.SuspendLayout()
        Me.pnlshifterintro.SuspendLayout()
        Me.pnldesktopoptions.SuspendLayout()
        Me.pnlapplauncheroptions.SuspendLayout()
        Me.pnllauncheritems.SuspendLayout()
        Me.pnldesktoppreview.SuspendLayout()
        Me.predesktoppanel.SuspendLayout()
        Me.prepnlpanelbuttonholder.SuspendLayout()
        Me.prepnlpanelbutton.SuspendLayout()
        CType(Me.pretbicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pretimepanel.SuspendLayout()
        Me.preapplaunchermenuholder.SuspendLayout()
        Me.predesktopappmenu.SuspendLayout()
        Me.pnlpanelbuttonsoptions.SuspendLayout()
        Me.pnldesktoppaneloptions.SuspendLayout()
        Me.pnldesktopintro.SuspendLayout()
        Me.pnlpanelclockoptions.SuspendLayout()
        Me.pnldesktopbackgroundoptions.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.pnlwindowsoptions.SuspendLayout()
        Me.pnlbuttonoptions.SuspendLayout()
        Me.pnlminimizebuttonoptions.SuspendLayout()
        Me.pnlrollupbuttonoptions.SuspendLayout()
        Me.pnlclosebuttonoptions.SuspendLayout()
        Me.pnltitlebaroptions.SuspendLayout()
        Me.pnlborderoptions.SuspendLayout()
        Me.pnltitletextoptions.SuspendLayout()
        Me.pnlwindowsintro.SuspendLayout()
        Me.pnlwindowsobjects.SuspendLayout()
        Me.pnlwindowpreview.SuspendLayout()
        Me.prepgleft.SuspendLayout()
        Me.prepgright.SuspendLayout()
        Me.pretitlebar.SuspendLayout()
        CType(Me.prepnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlreset.SuspendLayout()
        Me.pgcontents.SuspendLayout()
        Me.pnlshiftadvapplauncher.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.nudusrsize, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnldeskdoubleplus.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnldppoptions.SuspendLayout()
        Me.pnldppicons.SuspendLayout()
        Me.pnldppfunctions.SuspendLayout()
        Me.SuspendLayout()
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 309)
        Me.pgleft.TabIndex = 27
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 307)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(598, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 309)
        Me.pgright.TabIndex = 28
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 307)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 337)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(596, 2)
        Me.pgbottom.TabIndex = 29
        '
        'clocktick
        '
        Me.clocktick.Enabled = True
        Me.clocktick.Interval = 1000
        '
        'customizationtime
        '
        Me.customizationtime.Enabled = True
        Me.customizationtime.Interval = 10000
        '
        'timerearned
        '
        Me.timerearned.Interval = 3000
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(600, 30)
        Me.titlebar.TabIndex = 25
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(246, 3)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 30
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconShifter
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 31
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(274, 5)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 30
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(302, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(57, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Shifter"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(598, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(597, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        '
        'btnapply
        '
        Me.btnapply.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnapply.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnapply.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnapply.Location = New System.Drawing.Point(7, 270)
        Me.btnapply.Name = "btnapply"
        Me.btnapply.Size = New System.Drawing.Size(119, 29)
        Me.btnapply.TabIndex = 3
        Me.btnapply.TabStop = False
        Me.btnapply.Text = "Apply Changes"
        Me.btnapply.UseVisualStyleBackColor = True
        '
        'catholder
        '
        Me.catholder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.catholder.BackColor = System.Drawing.Color.White
        Me.catholder.Controls.Add(Me.btnreset)
        Me.catholder.Controls.Add(Me.Button2)
        Me.catholder.Controls.Add(Me.btndeskdoubleplus)
        Me.catholder.Controls.Add(Me.btnprograms)
        Me.catholder.Controls.Add(Me.btnicons)
        Me.catholder.Controls.Add(Me.btnwindows)
        Me.catholder.Controls.Add(Me.btndesktop)
        Me.catholder.Location = New System.Drawing.Point(7, 9)
        Me.catholder.Name = "catholder"
        Me.catholder.Size = New System.Drawing.Size(119, 255)
        Me.catholder.TabIndex = 5
        '
        'btnreset
        '
        Me.btnreset.BackColor = System.Drawing.Color.White
        Me.btnreset.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnreset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnreset.Font = New System.Drawing.Font("Cambria", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreset.Location = New System.Drawing.Point(0, 193)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(119, 29)
        Me.btnreset.TabIndex = 8
        Me.btnreset.TabStop = False
        Me.btnreset.Text = "Reset"
        Me.btnreset.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Cambria", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(0, 145)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(119, 48)
        Me.Button2.TabIndex = 10
        Me.Button2.TabStop = False
        Me.Button2.Text = "Adv. App Launcher"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'btndeskdoubleplus
        '
        Me.btndeskdoubleplus.BackColor = System.Drawing.Color.White
        Me.btndeskdoubleplus.Dock = System.Windows.Forms.DockStyle.Top
        Me.btndeskdoubleplus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndeskdoubleplus.Font = New System.Drawing.Font("Cambria", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndeskdoubleplus.Location = New System.Drawing.Point(0, 116)
        Me.btndeskdoubleplus.Name = "btndeskdoubleplus"
        Me.btndeskdoubleplus.Size = New System.Drawing.Size(119, 29)
        Me.btndeskdoubleplus.TabIndex = 9
        Me.btndeskdoubleplus.TabStop = False
        Me.btndeskdoubleplus.Text = "Desktop++"
        Me.btndeskdoubleplus.UseVisualStyleBackColor = False
        '
        'btnprograms
        '
        Me.btnprograms.BackColor = System.Drawing.Color.White
        Me.btnprograms.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnprograms.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnprograms.Font = New System.Drawing.Font("Cambria", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprograms.Location = New System.Drawing.Point(0, 87)
        Me.btnprograms.Name = "btnprograms"
        Me.btnprograms.Size = New System.Drawing.Size(119, 29)
        Me.btnprograms.TabIndex = 7
        Me.btnprograms.TabStop = False
        Me.btnprograms.Text = "Programs"
        Me.btnprograms.UseVisualStyleBackColor = False
        Me.btnprograms.Visible = False
        '
        'btnicons
        '
        Me.btnicons.BackColor = System.Drawing.Color.White
        Me.btnicons.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnicons.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnicons.Font = New System.Drawing.Font("Cambria", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnicons.Location = New System.Drawing.Point(0, 58)
        Me.btnicons.Name = "btnicons"
        Me.btnicons.Size = New System.Drawing.Size(119, 29)
        Me.btnicons.TabIndex = 6
        Me.btnicons.TabStop = False
        Me.btnicons.Text = "Icons"
        Me.btnicons.UseVisualStyleBackColor = False
        Me.btnicons.Visible = False
        '
        'btnwindows
        '
        Me.btnwindows.BackColor = System.Drawing.Color.White
        Me.btnwindows.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnwindows.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnwindows.Font = New System.Drawing.Font("Cambria", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnwindows.Location = New System.Drawing.Point(0, 29)
        Me.btnwindows.Name = "btnwindows"
        Me.btnwindows.Size = New System.Drawing.Size(119, 29)
        Me.btnwindows.TabIndex = 5
        Me.btnwindows.TabStop = False
        Me.btnwindows.Text = "Windows"
        Me.btnwindows.UseVisualStyleBackColor = False
        '
        'btndesktop
        '
        Me.btndesktop.BackColor = System.Drawing.Color.White
        Me.btndesktop.Dock = System.Windows.Forms.DockStyle.Top
        Me.btndesktop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndesktop.Font = New System.Drawing.Font("Cambria", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndesktop.Location = New System.Drawing.Point(0, 0)
        Me.btndesktop.Name = "btndesktop"
        Me.btndesktop.Size = New System.Drawing.Size(119, 29)
        Me.btndesktop.TabIndex = 4
        Me.btndesktop.TabStop = False
        Me.btndesktop.Text = "Desktop"
        Me.btndesktop.UseVisualStyleBackColor = False
        '
        'pnlshifterintro
        '
        Me.pnlshifterintro.BackColor = System.Drawing.Color.White
        Me.pnlshifterintro.Controls.Add(Me.Label66)
        Me.pnlshifterintro.Controls.Add(Me.Label65)
        Me.pnlshifterintro.Controls.Add(Me.Label64)
        Me.pnlshifterintro.Controls.Add(Me.Label63)
        Me.pnlshifterintro.Location = New System.Drawing.Point(519, 256)
        Me.pnlshifterintro.Name = "pnlshifterintro"
        Me.pnlshifterintro.Size = New System.Drawing.Size(72, 47)
        Me.pnlshifterintro.TabIndex = 17
        '
        'Label66
        '
        Me.Label66.BackColor = System.Drawing.Color.Transparent
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(3, 227)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(451, 65)
        Me.Label66.TabIndex = 3
        Me.Label66.Text = resources.GetString("Label66.Text")
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(53, 204)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(352, 20)
        Me.Label65.TabIndex = 2
        Me.Label65.Text = "You can earn codepoints using the Shifter!"
        '
        'Label64
        '
        Me.Label64.BackColor = System.Drawing.Color.Transparent
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(4, 32)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(451, 163)
        Me.Label64.TabIndex = 1
        Me.Label64.Text = resources.GetString("Label64.Text")
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label63
        '
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(72, 0)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(332, 29)
        Me.Label63.TabIndex = 0
        Me.Label63.Text = "Welcome to the Shifter!"
        '
        'pnldesktopoptions
        '
        Me.pnldesktopoptions.BackColor = System.Drawing.Color.White
        Me.pnldesktopoptions.Controls.Add(Me.pnlapplauncheroptions)
        Me.pnldesktopoptions.Controls.Add(Me.pnldesktoppreview)
        Me.pnldesktopoptions.Controls.Add(Me.pnlpanelbuttonsoptions)
        Me.pnldesktopoptions.Controls.Add(Me.pnldesktoppaneloptions)
        Me.pnldesktopoptions.Controls.Add(Me.pnldesktopintro)
        Me.pnldesktopoptions.Controls.Add(Me.pnlpanelclockoptions)
        Me.pnldesktopoptions.Controls.Add(Me.pnldesktopbackgroundoptions)
        Me.pnldesktopoptions.Controls.Add(Me.Panel10)
        Me.pnldesktopoptions.Location = New System.Drawing.Point(134, 9)
        Me.pnldesktopoptions.Name = "pnldesktopoptions"
        Me.pnldesktopoptions.Size = New System.Drawing.Size(457, 292)
        Me.pnldesktopoptions.TabIndex = 16
        Me.pnldesktopoptions.Visible = False
        '
        'pnlapplauncheroptions
        '
        Me.pnlapplauncheroptions.Controls.Add(Me.pnllauncheritems)
        Me.pnlapplauncheroptions.Controls.Add(Me.btnshowlauncheritems)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label71)
        Me.pnlapplauncheroptions.Controls.Add(Me.txtapplauncherwidth)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label72)
        Me.pnlapplauncheroptions.Controls.Add(Me.txtappbuttonlabel)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label51)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label50)
        Me.pnlapplauncheroptions.Controls.Add(Me.pnlmaintextcolour)
        Me.pnlapplauncheroptions.Controls.Add(Me.comboappbuttontextstyle)
        Me.pnlapplauncheroptions.Controls.Add(Me.comboappbuttontextfont)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label37)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label38)
        Me.pnlapplauncheroptions.Controls.Add(Me.txtappbuttontextsize)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label39)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label40)
        Me.pnlapplauncheroptions.Controls.Add(Me.pnlmenuitemsmouseover)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label41)
        Me.pnlapplauncheroptions.Controls.Add(Me.pnlmenuitemscolour)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label42)
        Me.pnlapplauncheroptions.Controls.Add(Me.pnlmainbuttonactivated)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label28)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label35)
        Me.pnlapplauncheroptions.Controls.Add(Me.txtapplicationsbuttonheight)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label36)
        Me.pnlapplauncheroptions.Controls.Add(Me.pnlmainbuttoncolour)
        Me.pnlapplauncheroptions.Controls.Add(Me.Label43)
        Me.pnlapplauncheroptions.Location = New System.Drawing.Point(0, 0)
        Me.pnlapplauncheroptions.Name = "pnlapplauncheroptions"
        Me.pnlapplauncheroptions.Size = New System.Drawing.Size(60, 60)
        Me.pnlapplauncheroptions.TabIndex = 10
        Me.pnlapplauncheroptions.Visible = False
        '
        'pnllauncheritems
        '
        Me.pnllauncheritems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnllauncheritems.Controls.Add(Me.launcheritemtxtcolour)
        Me.pnllauncheritems.Controls.Add(Me.Label116)
        Me.pnllauncheritems.Controls.Add(Me.launcheritemstyle)
        Me.pnllauncheritems.Controls.Add(Me.Label115)
        Me.pnllauncheritems.Controls.Add(Me.launcheritemfont)
        Me.pnllauncheritems.Controls.Add(Me.Label114)
        Me.pnllauncheritems.Controls.Add(Me.txtlauncheritemtxtsize)
        Me.pnllauncheritems.Controls.Add(Me.Label107)
        Me.pnllauncheritems.Location = New System.Drawing.Point(3, 136)
        Me.pnllauncheritems.Name = "pnllauncheritems"
        Me.pnllauncheritems.Size = New System.Drawing.Size(312, 107)
        Me.pnllauncheritems.TabIndex = 35
        '
        'launcheritemtxtcolour
        '
        Me.launcheritemtxtcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.launcheritemtxtcolour.Location = New System.Drawing.Point(239, 36)
        Me.launcheritemtxtcolour.Name = "launcheritemtxtcolour"
        Me.launcheritemtxtcolour.Size = New System.Drawing.Size(41, 20)
        Me.launcheritemtxtcolour.TabIndex = 31
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.Location = New System.Drawing.Point(157, 37)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(79, 16)
        Me.Label116.TabIndex = 30
        Me.Label116.Text = "Text Colour:"
        '
        'launcheritemstyle
        '
        Me.launcheritemstyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.launcheritemstyle.FormattingEnabled = True
        Me.launcheritemstyle.Items.AddRange(New Object() {"Bold", "Italic", "Regular", "Strikeout", "Underline"})
        Me.launcheritemstyle.Location = New System.Drawing.Point(54, 31)
        Me.launcheritemstyle.Name = "launcheritemstyle"
        Me.launcheritemstyle.Size = New System.Drawing.Size(97, 24)
        Me.launcheritemstyle.TabIndex = 29
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.Label115.Location = New System.Drawing.Point(8, 35)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(41, 16)
        Me.Label115.TabIndex = 28
        Me.Label115.Text = "Style:"
        '
        'launcheritemfont
        '
        Me.launcheritemfont.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.launcheritemfont.FormattingEnabled = True
        Me.launcheritemfont.Location = New System.Drawing.Point(157, 4)
        Me.launcheritemfont.Name = "launcheritemfont"
        Me.launcheritemfont.Size = New System.Drawing.Size(125, 24)
        Me.launcheritemfont.TabIndex = 27
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.Label114.Location = New System.Drawing.Point(115, 6)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(37, 16)
        Me.Label114.TabIndex = 15
        Me.Label114.Text = "Font:"
        '
        'txtlauncheritemtxtsize
        '
        Me.txtlauncheritemtxtsize.BackColor = System.Drawing.Color.White
        Me.txtlauncheritemtxtsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtlauncheritemtxtsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlauncheritemtxtsize.ForeColor = System.Drawing.Color.Black
        Me.txtlauncheritemtxtsize.Location = New System.Drawing.Point(75, 4)
        Me.txtlauncheritemtxtsize.Name = "txtlauncheritemtxtsize"
        Me.txtlauncheritemtxtsize.Size = New System.Drawing.Size(23, 22)
        Me.txtlauncheritemtxtsize.TabIndex = 14
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.Label107.Location = New System.Drawing.Point(5, 6)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(66, 16)
        Me.Label107.TabIndex = 0
        Me.Label107.Text = "Text Size:"
        '
        'btnshowlauncheritems
        '
        Me.btnshowlauncheritems.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnshowlauncheritems.Location = New System.Drawing.Point(233, 106)
        Me.btnshowlauncheritems.Name = "btnshowlauncheritems"
        Me.btnshowlauncheritems.Size = New System.Drawing.Size(75, 23)
        Me.btnshowlauncheritems.TabIndex = 34
        Me.btnshowlauncheritems.Text = "Items >"
        Me.btnshowlauncheritems.UseVisualStyleBackColor = True
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(204, 108)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(22, 16)
        Me.Label71.TabIndex = 33
        Me.Label71.Text = "px"
        '
        'txtapplauncherwidth
        '
        Me.txtapplauncherwidth.BackColor = System.Drawing.Color.White
        Me.txtapplauncherwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtapplauncherwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtapplauncherwidth.ForeColor = System.Drawing.Color.Black
        Me.txtapplauncherwidth.Location = New System.Drawing.Point(149, 106)
        Me.txtapplauncherwidth.Name = "txtapplauncherwidth"
        Me.txtapplauncherwidth.Size = New System.Drawing.Size(54, 22)
        Me.txtapplauncherwidth.TabIndex = 32
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(104, 108)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(45, 16)
        Me.Label72.TabIndex = 31
        Me.Label72.Text = "Width:"
        '
        'txtappbuttonlabel
        '
        Me.txtappbuttonlabel.BackColor = System.Drawing.Color.White
        Me.txtappbuttonlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtappbuttonlabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtappbuttonlabel.ForeColor = System.Drawing.Color.Black
        Me.txtappbuttonlabel.Location = New System.Drawing.Point(54, 81)
        Me.txtappbuttonlabel.Name = "txtappbuttonlabel"
        Me.txtappbuttonlabel.Size = New System.Drawing.Size(81, 22)
        Me.txtappbuttonlabel.TabIndex = 30
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(3, 84)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(45, 16)
        Me.Label51.TabIndex = 29
        Me.Label51.Text = "Label:"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(141, 84)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(37, 16)
        Me.Label50.TabIndex = 28
        Me.Label50.Text = "Font:"
        '
        'pnlmaintextcolour
        '
        Me.pnlmaintextcolour.Location = New System.Drawing.Point(156, 56)
        Me.pnlmaintextcolour.Name = "pnlmaintextcolour"
        Me.pnlmaintextcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlmaintextcolour.TabIndex = 19
        '
        'comboappbuttontextstyle
        '
        Me.comboappbuttontextstyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboappbuttontextstyle.FormattingEnabled = True
        Me.comboappbuttontextstyle.Items.AddRange(New Object() {"Bold", "Italic", "Regular", "Strikeout", "Underline"})
        Me.comboappbuttontextstyle.Location = New System.Drawing.Point(244, 54)
        Me.comboappbuttontextstyle.Name = "comboappbuttontextstyle"
        Me.comboappbuttontextstyle.Size = New System.Drawing.Size(64, 24)
        Me.comboappbuttontextstyle.TabIndex = 27
        '
        'comboappbuttontextfont
        '
        Me.comboappbuttontextfont.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboappbuttontextfont.FormattingEnabled = True
        Me.comboappbuttontextfont.Location = New System.Drawing.Point(182, 80)
        Me.comboappbuttontextfont.Name = "comboappbuttontextfont"
        Me.comboappbuttontextfont.Size = New System.Drawing.Size(125, 24)
        Me.comboappbuttontextfont.TabIndex = 26
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(201, 57)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(41, 16)
        Me.Label37.TabIndex = 25
        Me.Label37.Text = "Style:"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(76, 57)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(22, 16)
        Me.Label38.TabIndex = 24
        Me.Label38.Text = "px"
        '
        'txtappbuttontextsize
        '
        Me.txtappbuttontextsize.BackColor = System.Drawing.Color.White
        Me.txtappbuttontextsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtappbuttontextsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtappbuttontextsize.ForeColor = System.Drawing.Color.Black
        Me.txtappbuttontextsize.Location = New System.Drawing.Point(52, 55)
        Me.txtappbuttontextsize.Name = "txtappbuttontextsize"
        Me.txtappbuttontextsize.Size = New System.Drawing.Size(23, 22)
        Me.txtappbuttontextsize.TabIndex = 23
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(2, 57)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(49, 16)
        Me.Label39.TabIndex = 22
        Me.Label39.Text = "T Size:"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(102, 58)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(50, 16)
        Me.Label40.TabIndex = 21
        Me.Label40.Text = "Colour:"
        '
        'pnlmenuitemsmouseover
        '
        Me.pnlmenuitemsmouseover.Location = New System.Drawing.Point(267, 31)
        Me.pnlmenuitemsmouseover.Name = "pnlmenuitemsmouseover"
        Me.pnlmenuitemsmouseover.Size = New System.Drawing.Size(41, 20)
        Me.pnlmenuitemsmouseover.TabIndex = 20
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(177, 32)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(84, 16)
        Me.Label41.TabIndex = 19
        Me.Label41.Text = "Mouse Over:"
        '
        'pnlmenuitemscolour
        '
        Me.pnlmenuitemscolour.Location = New System.Drawing.Point(128, 30)
        Me.pnlmenuitemscolour.Name = "pnlmenuitemscolour"
        Me.pnlmenuitemscolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlmenuitemscolour.TabIndex = 18
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(3, 32)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(121, 16)
        Me.Label42.TabIndex = 17
        Me.Label42.Text = "Menu Items Colour:"
        '
        'pnlmainbuttonactivated
        '
        Me.pnlmainbuttonactivated.Location = New System.Drawing.Point(267, 6)
        Me.pnlmainbuttonactivated.Name = "pnlmainbuttonactivated"
        Me.pnlmainbuttonactivated.Size = New System.Drawing.Size(41, 20)
        Me.pnlmainbuttonactivated.TabIndex = 16
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(177, 7)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(67, 16)
        Me.Label28.TabIndex = 15
        Me.Label28.Text = "Activated:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(78, 108)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(22, 16)
        Me.Label35.TabIndex = 14
        Me.Label35.Text = "px"
        '
        'txtapplicationsbuttonheight
        '
        Me.txtapplicationsbuttonheight.BackColor = System.Drawing.Color.White
        Me.txtapplicationsbuttonheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtapplicationsbuttonheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtapplicationsbuttonheight.ForeColor = System.Drawing.Color.Black
        Me.txtapplicationsbuttonheight.Location = New System.Drawing.Point(54, 106)
        Me.txtapplicationsbuttonheight.Name = "txtapplicationsbuttonheight"
        Me.txtapplicationsbuttonheight.Size = New System.Drawing.Size(23, 22)
        Me.txtapplicationsbuttonheight.TabIndex = 13
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(3, 108)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(50, 16)
        Me.Label36.TabIndex = 12
        Me.Label36.Text = "Height:"
        '
        'pnlmainbuttoncolour
        '
        Me.pnlmainbuttoncolour.Location = New System.Drawing.Point(128, 4)
        Me.pnlmainbuttoncolour.Name = "pnlmainbuttoncolour"
        Me.pnlmainbuttoncolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlmainbuttoncolour.TabIndex = 1
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(3, 7)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(122, 16)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Main Button Colour:"
        '
        'pnldesktoppreview
        '
        Me.pnldesktoppreview.Controls.Add(Me.predesktoppanel)
        Me.pnldesktoppreview.Location = New System.Drawing.Point(5, 3)
        Me.pnldesktoppreview.Name = "pnldesktoppreview"
        Me.pnldesktoppreview.Size = New System.Drawing.Size(448, 148)
        Me.pnldesktoppreview.TabIndex = 0
        '
        'predesktoppanel
        '
        Me.predesktoppanel.BackColor = System.Drawing.Color.Gray
        Me.predesktoppanel.Controls.Add(Me.prepnlpanelbuttonholder)
        Me.predesktoppanel.Controls.Add(Me.pretimepanel)
        Me.predesktoppanel.Controls.Add(Me.preapplaunchermenuholder)
        Me.predesktoppanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.predesktoppanel.Location = New System.Drawing.Point(0, 0)
        Me.predesktoppanel.Name = "predesktoppanel"
        Me.predesktoppanel.Size = New System.Drawing.Size(448, 25)
        Me.predesktoppanel.TabIndex = 1
        '
        'prepnlpanelbuttonholder
        '
        Me.prepnlpanelbuttonholder.BackColor = System.Drawing.Color.Transparent
        Me.prepnlpanelbuttonholder.Controls.Add(Me.prepnlpanelbutton)
        Me.prepnlpanelbuttonholder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.prepnlpanelbuttonholder.Location = New System.Drawing.Point(116, 0)
        Me.prepnlpanelbuttonholder.Name = "prepnlpanelbuttonholder"
        Me.prepnlpanelbuttonholder.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.prepnlpanelbuttonholder.Size = New System.Drawing.Size(235, 25)
        Me.prepnlpanelbuttonholder.TabIndex = 6
        '
        'prepnlpanelbutton
        '
        Me.prepnlpanelbutton.BackColor = System.Drawing.Color.Black
        Me.prepnlpanelbutton.Controls.Add(Me.pretbicon)
        Me.prepnlpanelbutton.Controls.Add(Me.pretbctext)
        Me.prepnlpanelbutton.Location = New System.Drawing.Point(5, 3)
        Me.prepnlpanelbutton.Name = "prepnlpanelbutton"
        Me.prepnlpanelbutton.Size = New System.Drawing.Size(126, 20)
        Me.prepnlpanelbutton.TabIndex = 18
        Me.prepnlpanelbutton.Visible = False
        '
        'pretbicon
        '
        Me.pretbicon.BackColor = System.Drawing.Color.Transparent
        Me.pretbicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pretbicon.Image = Global.ShiftOS.My.Resources.Resources.iconShifter
        Me.pretbicon.Location = New System.Drawing.Point(4, 2)
        Me.pretbicon.Name = "pretbicon"
        Me.pretbicon.Size = New System.Drawing.Size(16, 16)
        Me.pretbicon.TabIndex = 1
        Me.pretbicon.TabStop = False
        '
        'pretbctext
        '
        Me.pretbctext.AutoSize = True
        Me.pretbctext.BackColor = System.Drawing.Color.Transparent
        Me.pretbctext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pretbctext.ForeColor = System.Drawing.Color.White
        Me.pretbctext.Location = New System.Drawing.Point(24, 2)
        Me.pretbctext.Name = "pretbctext"
        Me.pretbctext.Size = New System.Drawing.Size(45, 16)
        Me.pretbctext.TabIndex = 0
        Me.pretbctext.Text = "Shifter"
        '
        'pretimepanel
        '
        Me.pretimepanel.Controls.Add(Me.prepaneltimetext)
        Me.pretimepanel.Dock = System.Windows.Forms.DockStyle.Right
        Me.pretimepanel.Location = New System.Drawing.Point(351, 0)
        Me.pretimepanel.Name = "pretimepanel"
        Me.pretimepanel.Size = New System.Drawing.Size(97, 25)
        Me.pretimepanel.TabIndex = 5
        '
        'prepaneltimetext
        '
        Me.prepaneltimetext.AutoSize = True
        Me.prepaneltimetext.BackColor = System.Drawing.Color.Transparent
        Me.prepaneltimetext.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prepaneltimetext.Location = New System.Drawing.Point(5, 0)
        Me.prepaneltimetext.Name = "prepaneltimetext"
        Me.prepaneltimetext.Size = New System.Drawing.Size(80, 24)
        Me.prepaneltimetext.TabIndex = 1
        Me.prepaneltimetext.Text = "5000023"
        Me.prepaneltimetext.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'preapplaunchermenuholder
        '
        Me.preapplaunchermenuholder.Controls.Add(Me.predesktopappmenu)
        Me.preapplaunchermenuholder.Dock = System.Windows.Forms.DockStyle.Left
        Me.preapplaunchermenuholder.Location = New System.Drawing.Point(0, 0)
        Me.preapplaunchermenuholder.Name = "preapplaunchermenuholder"
        Me.preapplaunchermenuholder.Size = New System.Drawing.Size(116, 25)
        Me.preapplaunchermenuholder.TabIndex = 4
        '
        'predesktopappmenu
        '
        Me.predesktopappmenu.AutoSize = False
        Me.predesktopappmenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplicationsToolStripMenuItem})
        Me.predesktopappmenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.predesktopappmenu.Location = New System.Drawing.Point(0, 0)
        Me.predesktopappmenu.Name = "predesktopappmenu"
        Me.predesktopappmenu.Padding = New System.Windows.Forms.Padding(0)
        Me.predesktopappmenu.Size = New System.Drawing.Size(116, 24)
        Me.predesktopappmenu.TabIndex = 0
        Me.predesktopappmenu.Text = "MenuStrip1"
        '
        'ApplicationsToolStripMenuItem
        '
        Me.ApplicationsToolStripMenuItem.AutoSize = False
        Me.ApplicationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KnowledgeInputToolStripMenuItem, Me.ShiftoriumToolStripMenuItem, Me.ClockToolStripMenuItem, Me.TerminalToolStripMenuItem, Me.ShifterToolStripMenuItem, Me.ToolStripSeparator1, Me.ShutdownToolStripMenuItem})
        Me.ApplicationsToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ApplicationsToolStripMenuItem.Name = "ApplicationsToolStripMenuItem"
        Me.ApplicationsToolStripMenuItem.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ApplicationsToolStripMenuItem.ShowShortcutKeys = False
        Me.ApplicationsToolStripMenuItem.Size = New System.Drawing.Size(102, 24)
        Me.ApplicationsToolStripMenuItem.Text = "Applications"
        Me.ApplicationsToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        Me.ApplicationsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'KnowledgeInputToolStripMenuItem
        '
        Me.KnowledgeInputToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.KnowledgeInputToolStripMenuItem.Name = "KnowledgeInputToolStripMenuItem"
        Me.KnowledgeInputToolStripMenuItem.ShowShortcutKeys = False
        Me.KnowledgeInputToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.KnowledgeInputToolStripMenuItem.Text = "Knowledge Input"
        '
        'ShiftoriumToolStripMenuItem
        '
        Me.ShiftoriumToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShiftoriumToolStripMenuItem.Name = "ShiftoriumToolStripMenuItem"
        Me.ShiftoriumToolStripMenuItem.ShowShortcutKeys = False
        Me.ShiftoriumToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ShiftoriumToolStripMenuItem.Text = "Shiftorium"
        '
        'ClockToolStripMenuItem
        '
        Me.ClockToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ClockToolStripMenuItem.Name = "ClockToolStripMenuItem"
        Me.ClockToolStripMenuItem.ShowShortcutKeys = False
        Me.ClockToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ClockToolStripMenuItem.Text = "Clock"
        '
        'TerminalToolStripMenuItem
        '
        Me.TerminalToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.TerminalToolStripMenuItem.Name = "TerminalToolStripMenuItem"
        Me.TerminalToolStripMenuItem.ShowShortcutKeys = False
        Me.TerminalToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.TerminalToolStripMenuItem.Text = "Terminal"
        '
        'ShifterToolStripMenuItem
        '
        Me.ShifterToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShifterToolStripMenuItem.Name = "ShifterToolStripMenuItem"
        Me.ShifterToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ShifterToolStripMenuItem.Text = "Shifter"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripSeparator1.ForeColor = System.Drawing.Color.White
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(178, 6)
        '
        'ShutdownToolStripMenuItem
        '
        Me.ShutdownToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShutdownToolStripMenuItem.Name = "ShutdownToolStripMenuItem"
        Me.ShutdownToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ShutdownToolStripMenuItem.Text = "Shut Down"
        '
        'pnlpanelbuttonsoptions
        '
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.pnlpanelbuttontextcolour)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label101)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttontexttop)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label104)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttontextside)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label106)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label93)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttontop)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label94)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttoninitalgap)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label108)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttonicontop)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label110)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttoniconside)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label112)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttoniconsize)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label105)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.cbpanelbuttontextstyle)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.cbpanelbuttonfont)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label100)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpaneltextbuttonsize)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label102)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label103)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label98)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttongap)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label99)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label96)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttonheight)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label97)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label92)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.txtpanelbuttonwidth)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label91)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.pnlpanelbuttoncolour)
        Me.pnlpanelbuttonsoptions.Controls.Add(Me.Label95)
        Me.pnlpanelbuttonsoptions.Location = New System.Drawing.Point(135, 159)
        Me.pnlpanelbuttonsoptions.Name = "pnlpanelbuttonsoptions"
        Me.pnlpanelbuttonsoptions.Size = New System.Drawing.Size(317, 134)
        Me.pnlpanelbuttonsoptions.TabIndex = 10
        Me.pnlpanelbuttonsoptions.Visible = False
        '
        'pnlpanelbuttontextcolour
        '
        Me.pnlpanelbuttontextcolour.Location = New System.Drawing.Point(270, 57)
        Me.pnlpanelbuttontextcolour.Name = "pnlpanelbuttontextcolour"
        Me.pnlpanelbuttontextcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlpanelbuttontextcolour.TabIndex = 50
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(219, 59)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(50, 16)
        Me.Label101.TabIndex = 49
        Me.Label101.Text = "Colour:"
        '
        'txtpanelbuttontexttop
        '
        Me.txtpanelbuttontexttop.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttontexttop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttontexttop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttontexttop.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttontexttop.Location = New System.Drawing.Point(225, 82)
        Me.txtpanelbuttontexttop.Name = "txtpanelbuttontexttop"
        Me.txtpanelbuttontexttop.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttontexttop.TabIndex = 48
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(191, 84)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(36, 16)
        Me.Label104.TabIndex = 47
        Me.Label104.Text = "Top:"
        '
        'txtpanelbuttontextside
        '
        Me.txtpanelbuttontextside.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttontextside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttontextside.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttontextside.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttontextside.Location = New System.Drawing.Point(165, 82)
        Me.txtpanelbuttontextside.Name = "txtpanelbuttontextside"
        Me.txtpanelbuttontextside.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttontextside.TabIndex = 46
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(128, 84)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(39, 16)
        Me.Label106.TabIndex = 45
        Me.Label106.Text = "Side:"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(292, 7)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(22, 16)
        Me.Label93.TabIndex = 43
        Me.Label93.Text = "px"
        '
        'txtpanelbuttontop
        '
        Me.txtpanelbuttontop.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttontop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttontop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttontop.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttontop.Location = New System.Drawing.Point(268, 5)
        Me.txtpanelbuttontop.Name = "txtpanelbuttontop"
        Me.txtpanelbuttontop.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttontop.TabIndex = 42
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(233, 7)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(36, 16)
        Me.Label94.TabIndex = 41
        Me.Label94.Text = "Top:"
        '
        'txtpanelbuttoninitalgap
        '
        Me.txtpanelbuttoninitalgap.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttoninitalgap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttoninitalgap.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttoninitalgap.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttoninitalgap.Location = New System.Drawing.Point(207, 5)
        Me.txtpanelbuttoninitalgap.Name = "txtpanelbuttoninitalgap"
        Me.txtpanelbuttoninitalgap.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttoninitalgap.TabIndex = 40
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(137, 7)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(70, 16)
        Me.Label108.TabIndex = 39
        Me.Label108.Text = "Initial Gap:"
        '
        'txtpanelbuttonicontop
        '
        Me.txtpanelbuttonicontop.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttonicontop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttonicontop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttonicontop.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttonicontop.Location = New System.Drawing.Point(287, 108)
        Me.txtpanelbuttonicontop.Name = "txtpanelbuttonicontop"
        Me.txtpanelbuttonicontop.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttonicontop.TabIndex = 37
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(221, 110)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(64, 16)
        Me.Label110.TabIndex = 36
        Me.Label110.Text = "Icon Top:"
        '
        'txtpanelbuttoniconside
        '
        Me.txtpanelbuttoniconside.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttoniconside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttoniconside.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttoniconside.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttoniconside.Location = New System.Drawing.Point(180, 108)
        Me.txtpanelbuttoniconside.Name = "txtpanelbuttoniconside"
        Me.txtpanelbuttoniconside.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttoniconside.TabIndex = 34
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(113, 110)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(67, 16)
        Me.Label112.TabIndex = 33
        Me.Label112.Text = "Icon Side:"
        '
        'txtpanelbuttoniconsize
        '
        Me.txtpanelbuttoniconsize.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttoniconsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttoniconsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttoniconsize.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttoniconsize.Location = New System.Drawing.Point(70, 108)
        Me.txtpanelbuttoniconsize.Name = "txtpanelbuttoniconsize"
        Me.txtpanelbuttoniconsize.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttoniconsize.TabIndex = 27
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(3, 110)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(65, 16)
        Me.Label105.TabIndex = 26
        Me.Label105.Text = "Icon Size:"
        '
        'cbpanelbuttontextstyle
        '
        Me.cbpanelbuttontextstyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbpanelbuttontextstyle.FormattingEnabled = True
        Me.cbpanelbuttontextstyle.Items.AddRange(New Object() {"Bold", "Italic", "Regular", "Strikeout", "Underline"})
        Me.cbpanelbuttontextstyle.Location = New System.Drawing.Point(46, 83)
        Me.cbpanelbuttontextstyle.Name = "cbpanelbuttontextstyle"
        Me.cbpanelbuttontextstyle.Size = New System.Drawing.Size(80, 24)
        Me.cbpanelbuttontextstyle.TabIndex = 25
        '
        'cbpanelbuttonfont
        '
        Me.cbpanelbuttonfont.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbpanelbuttonfont.FormattingEnabled = True
        Me.cbpanelbuttonfont.Location = New System.Drawing.Point(70, 56)
        Me.cbpanelbuttonfont.Name = "cbpanelbuttonfont"
        Me.cbpanelbuttonfont.Size = New System.Drawing.Size(147, 24)
        Me.cbpanelbuttonfont.TabIndex = 24
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(3, 86)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(41, 16)
        Me.Label100.TabIndex = 23
        Me.Label100.Text = "Style:"
        '
        'txtpaneltextbuttonsize
        '
        Me.txtpaneltextbuttonsize.BackColor = System.Drawing.Color.White
        Me.txtpaneltextbuttonsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpaneltextbuttonsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpaneltextbuttonsize.ForeColor = System.Drawing.Color.Black
        Me.txtpaneltextbuttonsize.Location = New System.Drawing.Point(287, 82)
        Me.txtpaneltextbuttonsize.Name = "txtpaneltextbuttonsize"
        Me.txtpaneltextbuttonsize.Size = New System.Drawing.Size(23, 22)
        Me.txtpaneltextbuttonsize.TabIndex = 21
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(252, 84)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(37, 16)
        Me.Label102.TabIndex = 20
        Me.Label102.Text = "Size:"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(3, 60)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(66, 16)
        Me.Label103.TabIndex = 19
        Me.Label103.Text = "Text Font:"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.BackColor = System.Drawing.Color.Transparent
        Me.Label98.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(292, 33)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(22, 16)
        Me.Label98.TabIndex = 14
        Me.Label98.Text = "px"
        '
        'txtpanelbuttongap
        '
        Me.txtpanelbuttongap.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttongap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttongap.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttongap.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttongap.Location = New System.Drawing.Point(268, 31)
        Me.txtpanelbuttongap.Name = "txtpanelbuttongap"
        Me.txtpanelbuttongap.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttongap.TabIndex = 13
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.Location = New System.Drawing.Point(232, 33)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(37, 16)
        Me.Label99.TabIndex = 12
        Me.Label99.Text = "Gap:"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(209, 34)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(22, 16)
        Me.Label96.TabIndex = 11
        Me.Label96.Text = "px"
        '
        'txtpanelbuttonheight
        '
        Me.txtpanelbuttonheight.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttonheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttonheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttonheight.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttonheight.Location = New System.Drawing.Point(185, 32)
        Me.txtpanelbuttonheight.Name = "txtpanelbuttonheight"
        Me.txtpanelbuttonheight.Size = New System.Drawing.Size(23, 22)
        Me.txtpanelbuttonheight.TabIndex = 10
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.Location = New System.Drawing.Point(135, 34)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(50, 16)
        Me.Label97.TabIndex = 9
        Me.Label97.Text = "Height:"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(114, 33)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(22, 16)
        Me.Label92.TabIndex = 8
        Me.Label92.Text = "px"
        '
        'txtpanelbuttonwidth
        '
        Me.txtpanelbuttonwidth.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttonwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttonwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttonwidth.ForeColor = System.Drawing.Color.Black
        Me.txtpanelbuttonwidth.Location = New System.Drawing.Point(88, 31)
        Me.txtpanelbuttonwidth.Name = "txtpanelbuttonwidth"
        Me.txtpanelbuttonwidth.Size = New System.Drawing.Size(26, 22)
        Me.txtpanelbuttonwidth.TabIndex = 7
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(3, 33)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(85, 16)
        Me.Label91.TabIndex = 6
        Me.Label91.Text = "Button Width:"
        '
        'pnlpanelbuttoncolour
        '
        Me.pnlpanelbuttoncolour.Location = New System.Drawing.Point(94, 5)
        Me.pnlpanelbuttoncolour.Name = "pnlpanelbuttoncolour"
        Me.pnlpanelbuttoncolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlpanelbuttoncolour.TabIndex = 1
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(3, 7)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(90, 16)
        Me.Label95.TabIndex = 0
        Me.Label95.Text = "Button Colour:"
        '
        'pnldesktoppaneloptions
        '
        Me.pnldesktoppaneloptions.Controls.Add(Me.btnpanelbuttons)
        Me.pnldesktoppaneloptions.Controls.Add(Me.Label27)
        Me.pnldesktoppaneloptions.Controls.Add(Me.combodesktoppanelposition)
        Me.pnldesktoppaneloptions.Controls.Add(Me.Label46)
        Me.pnldesktoppaneloptions.Controls.Add(Me.Label47)
        Me.pnldesktoppaneloptions.Controls.Add(Me.txtdesktoppanelheight)
        Me.pnldesktoppaneloptions.Controls.Add(Me.Label48)
        Me.pnldesktoppaneloptions.Controls.Add(Me.pnldesktoppanelcolour)
        Me.pnldesktoppaneloptions.Controls.Add(Me.Label49)
        Me.pnldesktoppaneloptions.Location = New System.Drawing.Point(393, 265)
        Me.pnldesktoppaneloptions.Name = "pnldesktoppaneloptions"
        Me.pnldesktoppaneloptions.Size = New System.Drawing.Size(60, 28)
        Me.pnldesktoppaneloptions.TabIndex = 9
        Me.pnldesktoppaneloptions.Visible = False
        '
        'btnpanelbuttons
        '
        Me.btnpanelbuttons.BackColor = System.Drawing.Color.White
        Me.btnpanelbuttons.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpanelbuttons.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpanelbuttons.Location = New System.Drawing.Point(193, 101)
        Me.btnpanelbuttons.Name = "btnpanelbuttons"
        Me.btnpanelbuttons.Size = New System.Drawing.Size(119, 29)
        Me.btnpanelbuttons.TabIndex = 8
        Me.btnpanelbuttons.Text = "Panel Buttons >"
        Me.btnpanelbuttons.UseVisualStyleBackColor = False
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(3, 52)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(290, 42)
        Me.Label27.TabIndex = 8
        Me.Label27.Text = "Warning: If you set the panel position to the bottom you must hide your windows t" & _
    "askbar and restart ShiftOS on your host operating system to prevent a visual bug" & _
    "."
        '
        'combodesktoppanelposition
        '
        Me.combodesktoppanelposition.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combodesktoppanelposition.FormattingEnabled = True
        Me.combodesktoppanelposition.Items.AddRange(New Object() {"Top", "Bottom"})
        Me.combodesktoppanelposition.Location = New System.Drawing.Point(103, 28)
        Me.combodesktoppanelposition.Name = "combodesktoppanelposition"
        Me.combodesktoppanelposition.Size = New System.Drawing.Size(59, 24)
        Me.combodesktoppanelposition.TabIndex = 7
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(3, 31)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(97, 16)
        Me.Label46.TabIndex = 6
        Me.Label46.Text = "Panel Position:"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(213, 7)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(22, 16)
        Me.Label47.TabIndex = 5
        Me.Label47.Text = "px"
        '
        'txtdesktoppanelheight
        '
        Me.txtdesktoppanelheight.BackColor = System.Drawing.Color.White
        Me.txtdesktoppanelheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdesktoppanelheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdesktoppanelheight.ForeColor = System.Drawing.Color.Black
        Me.txtdesktoppanelheight.Location = New System.Drawing.Point(189, 5)
        Me.txtdesktoppanelheight.Name = "txtdesktoppanelheight"
        Me.txtdesktoppanelheight.Size = New System.Drawing.Size(23, 22)
        Me.txtdesktoppanelheight.TabIndex = 4
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(138, 7)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(50, 16)
        Me.Label48.TabIndex = 2
        Me.Label48.Text = "Height:"
        '
        'pnldesktoppanelcolour
        '
        Me.pnldesktoppanelcolour.Location = New System.Drawing.Point(92, 5)
        Me.pnldesktoppanelcolour.Name = "pnldesktoppanelcolour"
        Me.pnldesktoppanelcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnldesktoppanelcolour.TabIndex = 1
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(3, 7)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(88, 16)
        Me.Label49.TabIndex = 0
        Me.Label49.Text = "Panel Colour:"
        '
        'pnldesktopintro
        '
        Me.pnldesktopintro.Controls.Add(Me.Label69)
        Me.pnldesktopintro.Controls.Add(Me.Label70)
        Me.pnldesktopintro.Location = New System.Drawing.Point(154, 173)
        Me.pnldesktopintro.Name = "pnldesktopintro"
        Me.pnldesktopintro.Size = New System.Drawing.Size(47, 48)
        Me.pnldesktopintro.TabIndex = 17
        '
        'Label69
        '
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(3, 20)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(312, 113)
        Me.Label69.TabIndex = 1
        Me.Label69.Text = resources.GetString("Label69.Text")
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(86, -2)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(148, 20)
        Me.Label70.TabIndex = 0
        Me.Label70.Text = "Desktop Settings"
        '
        'pnlpanelclockoptions
        '
        Me.pnlpanelclockoptions.Controls.Add(Me.pnlclockbackgroundcolour)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label44)
        Me.pnlpanelclockoptions.Controls.Add(Me.comboclocktextstyle)
        Me.pnlpanelclockoptions.Controls.Add(Me.comboclocktextfont)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label26)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label29)
        Me.pnlpanelclockoptions.Controls.Add(Me.txtclocktextfromtop)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label30)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label31)
        Me.pnlpanelclockoptions.Controls.Add(Me.txtclocktextsize)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label32)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label33)
        Me.pnlpanelclockoptions.Controls.Add(Me.pnlpanelclocktextcolour)
        Me.pnlpanelclockoptions.Controls.Add(Me.Label34)
        Me.pnlpanelclockoptions.Location = New System.Drawing.Point(217, 170)
        Me.pnlpanelclockoptions.Name = "pnlpanelclockoptions"
        Me.pnlpanelclockoptions.Size = New System.Drawing.Size(110, 64)
        Me.pnlpanelclockoptions.TabIndex = 15
        Me.pnlpanelclockoptions.Visible = False
        '
        'pnlclockbackgroundcolour
        '
        Me.pnlclockbackgroundcolour.Location = New System.Drawing.Point(261, 5)
        Me.pnlclockbackgroundcolour.Name = "pnlclockbackgroundcolour"
        Me.pnlclockbackgroundcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlclockbackgroundcolour.TabIndex = 20
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(173, 7)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(84, 16)
        Me.Label44.TabIndex = 19
        Me.Label44.Text = "Background:"
        '
        'comboclocktextstyle
        '
        Me.comboclocktextstyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboclocktextstyle.FormattingEnabled = True
        Me.comboclocktextstyle.Items.AddRange(New Object() {"Bold", "Italic", "Regular", "Strikeout", "Underline"})
        Me.comboclocktextstyle.Location = New System.Drawing.Point(209, 54)
        Me.comboclocktextstyle.Name = "comboclocktextstyle"
        Me.comboclocktextstyle.Size = New System.Drawing.Size(99, 24)
        Me.comboclocktextstyle.TabIndex = 18
        '
        'comboclocktextfont
        '
        Me.comboclocktextfont.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboclocktextfont.FormattingEnabled = True
        Me.comboclocktextfont.Location = New System.Drawing.Point(114, 28)
        Me.comboclocktextfont.Name = "comboclocktextfont"
        Me.comboclocktextfont.Size = New System.Drawing.Size(192, 24)
        Me.comboclocktextfont.TabIndex = 17
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(166, 57)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(41, 16)
        Me.Label26.TabIndex = 15
        Me.Label26.Text = "Style:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(163, 82)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(22, 16)
        Me.Label29.TabIndex = 11
        Me.Label29.Text = "px"
        '
        'txtclocktextfromtop
        '
        Me.txtclocktextfromtop.BackColor = System.Drawing.Color.White
        Me.txtclocktextfromtop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclocktextfromtop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclocktextfromtop.ForeColor = System.Drawing.Color.Black
        Me.txtclocktextfromtop.Location = New System.Drawing.Point(139, 80)
        Me.txtclocktextfromtop.Name = "txtclocktextfromtop"
        Me.txtclocktextfromtop.Size = New System.Drawing.Size(23, 22)
        Me.txtclocktextfromtop.TabIndex = 10
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(3, 82)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(136, 16)
        Me.Label30.TabIndex = 9
        Me.Label30.Text = "Clock Text From Top:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(138, 57)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(22, 16)
        Me.Label31.TabIndex = 8
        Me.Label31.Text = "px"
        '
        'txtclocktextsize
        '
        Me.txtclocktextsize.BackColor = System.Drawing.Color.White
        Me.txtclocktextsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclocktextsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclocktextsize.ForeColor = System.Drawing.Color.Black
        Me.txtclocktextsize.Location = New System.Drawing.Point(114, 55)
        Me.txtclocktextsize.Name = "txtclocktextsize"
        Me.txtclocktextsize.Size = New System.Drawing.Size(23, 22)
        Me.txtclocktextsize.TabIndex = 7
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(3, 57)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(103, 16)
        Me.Label32.TabIndex = 6
        Me.Label32.Text = "Clock Text Size:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(3, 32)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(103, 16)
        Me.Label33.TabIndex = 2
        Me.Label33.Text = "Clock Text Font:"
        '
        'pnlpanelclocktextcolour
        '
        Me.pnlpanelclocktextcolour.Location = New System.Drawing.Point(121, 5)
        Me.pnlpanelclocktextcolour.Name = "pnlpanelclocktextcolour"
        Me.pnlpanelclocktextcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlpanelclocktextcolour.TabIndex = 1
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(3, 7)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(116, 16)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Clock Text Colour:"
        '
        'pnldesktopbackgroundoptions
        '
        Me.pnldesktopbackgroundoptions.Controls.Add(Me.pnldesktopcolour)
        Me.pnldesktopbackgroundoptions.Controls.Add(Me.Label45)
        Me.pnldesktopbackgroundoptions.Location = New System.Drawing.Point(354, 163)
        Me.pnldesktopbackgroundoptions.Name = "pnldesktopbackgroundoptions"
        Me.pnldesktopbackgroundoptions.Size = New System.Drawing.Size(103, 70)
        Me.pnldesktopbackgroundoptions.TabIndex = 10
        Me.pnldesktopbackgroundoptions.Visible = False
        '
        'pnldesktopcolour
        '
        Me.pnldesktopcolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnldesktopcolour.Location = New System.Drawing.Point(112, 5)
        Me.pnldesktopcolour.Name = "pnldesktopcolour"
        Me.pnldesktopcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnldesktopcolour.TabIndex = 3
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(3, 7)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(104, 16)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "Desktop Colour:"
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.btndesktopitself)
        Me.Panel10.Controls.Add(Me.btnpanelclock)
        Me.Panel10.Controls.Add(Me.btnapplauncher)
        Me.Panel10.Controls.Add(Me.btndesktoppanel)
        Me.Panel10.Location = New System.Drawing.Point(1, 159)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(128, 135)
        Me.Panel10.TabIndex = 8
        '
        'btndesktopitself
        '
        Me.btndesktopitself.BackColor = System.Drawing.Color.White
        Me.btndesktopitself.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndesktopitself.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndesktopitself.Location = New System.Drawing.Point(4, 105)
        Me.btndesktopitself.Name = "btndesktopitself"
        Me.btndesktopitself.Size = New System.Drawing.Size(119, 29)
        Me.btndesktopitself.TabIndex = 7
        Me.btndesktopitself.Text = "Desktop"
        Me.btndesktopitself.UseVisualStyleBackColor = False
        '
        'btnpanelclock
        '
        Me.btnpanelclock.BackColor = System.Drawing.Color.White
        Me.btnpanelclock.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpanelclock.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpanelclock.Location = New System.Drawing.Point(4, 70)
        Me.btnpanelclock.Name = "btnpanelclock"
        Me.btnpanelclock.Size = New System.Drawing.Size(119, 29)
        Me.btnpanelclock.TabIndex = 6
        Me.btnpanelclock.Text = "Panel Clock"
        Me.btnpanelclock.UseVisualStyleBackColor = False
        '
        'btnapplauncher
        '
        Me.btnapplauncher.BackColor = System.Drawing.Color.White
        Me.btnapplauncher.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnapplauncher.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnapplauncher.Location = New System.Drawing.Point(4, 35)
        Me.btnapplauncher.Name = "btnapplauncher"
        Me.btnapplauncher.Size = New System.Drawing.Size(119, 29)
        Me.btnapplauncher.TabIndex = 5
        Me.btnapplauncher.Text = "App Launcher"
        Me.btnapplauncher.UseVisualStyleBackColor = False
        '
        'btndesktoppanel
        '
        Me.btndesktoppanel.BackColor = System.Drawing.Color.White
        Me.btndesktoppanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndesktoppanel.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndesktoppanel.Location = New System.Drawing.Point(4, 0)
        Me.btndesktoppanel.Name = "btndesktoppanel"
        Me.btndesktoppanel.Size = New System.Drawing.Size(119, 29)
        Me.btndesktoppanel.TabIndex = 4
        Me.btndesktoppanel.Text = "Desktop Panel"
        Me.btndesktoppanel.UseVisualStyleBackColor = False
        '
        'txtpanelbuttoniconheight
        '
        Me.txtpanelbuttoniconheight.Location = New System.Drawing.Point(0, 0)
        Me.txtpanelbuttoniconheight.Name = "txtpanelbuttoniconheight"
        Me.txtpanelbuttoniconheight.Size = New System.Drawing.Size(100, 20)
        Me.txtpanelbuttoniconheight.TabIndex = 0
        '
        'pnlwindowsoptions
        '
        Me.pnlwindowsoptions.BackColor = System.Drawing.Color.White
        Me.pnlwindowsoptions.Controls.Add(Me.pnlbuttonoptions)
        Me.pnlwindowsoptions.Controls.Add(Me.pnltitlebaroptions)
        Me.pnlwindowsoptions.Controls.Add(Me.pnlborderoptions)
        Me.pnlwindowsoptions.Controls.Add(Me.pnltitletextoptions)
        Me.pnlwindowsoptions.Controls.Add(Me.pnlwindowsintro)
        Me.pnlwindowsoptions.Controls.Add(Me.pnlwindowsobjects)
        Me.pnlwindowsoptions.Controls.Add(Me.pnlwindowpreview)
        Me.pnlwindowsoptions.Location = New System.Drawing.Point(539, 28)
        Me.pnlwindowsoptions.Name = "pnlwindowsoptions"
        Me.pnlwindowsoptions.Size = New System.Drawing.Size(46, 39)
        Me.pnlwindowsoptions.TabIndex = 4
        Me.pnlwindowsoptions.Visible = False
        '
        'pnlbuttonoptions
        '
        Me.pnlbuttonoptions.Controls.Add(Me.pnlminimizebuttonoptions)
        Me.pnlbuttonoptions.Controls.Add(Me.pnlrollupbuttonoptions)
        Me.pnlbuttonoptions.Controls.Add(Me.combobuttonoption)
        Me.pnlbuttonoptions.Controls.Add(Me.Label52)
        Me.pnlbuttonoptions.Controls.Add(Me.pnlclosebuttonoptions)
        Me.pnlbuttonoptions.Location = New System.Drawing.Point(312, 266)
        Me.pnlbuttonoptions.Name = "pnlbuttonoptions"
        Me.pnlbuttonoptions.Size = New System.Drawing.Size(66, 18)
        Me.pnlbuttonoptions.TabIndex = 10
        Me.pnlbuttonoptions.Visible = False
        '
        'pnlminimizebuttonoptions
        '
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label82)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label83)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.pnlminimizebuttoncolour)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.txtminimizebuttonside)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label84)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label85)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.txtminimizebuttonheight)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label86)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label87)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.txtminimizebuttontop)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label88)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label89)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.txtminimizebuttonwidth)
        Me.pnlminimizebuttonoptions.Controls.Add(Me.Label90)
        Me.pnlminimizebuttonoptions.Location = New System.Drawing.Point(4, 29)
        Me.pnlminimizebuttonoptions.Name = "pnlminimizebuttonoptions"
        Me.pnlminimizebuttonoptions.Size = New System.Drawing.Size(311, 105)
        Me.pnlminimizebuttonoptions.TabIndex = 18
        Me.pnlminimizebuttonoptions.Visible = False
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(3, 6)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(145, 16)
        Me.Label82.TabIndex = 0
        Me.Label82.Text = "Minimize Button Colour:"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(196, 82)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(22, 16)
        Me.Label83.TabIndex = 14
        Me.Label83.Text = "px"
        '
        'pnlminimizebuttoncolour
        '
        Me.pnlminimizebuttoncolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlminimizebuttoncolour.Location = New System.Drawing.Point(149, 4)
        Me.pnlminimizebuttoncolour.Name = "pnlminimizebuttoncolour"
        Me.pnlminimizebuttoncolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlminimizebuttoncolour.TabIndex = 1
        '
        'txtminimizebuttonside
        '
        Me.txtminimizebuttonside.BackColor = System.Drawing.Color.White
        Me.txtminimizebuttonside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtminimizebuttonside.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtminimizebuttonside.ForeColor = System.Drawing.Color.Black
        Me.txtminimizebuttonside.Location = New System.Drawing.Point(172, 80)
        Me.txtminimizebuttonside.Name = "txtminimizebuttonside"
        Me.txtminimizebuttonside.Size = New System.Drawing.Size(23, 22)
        Me.txtminimizebuttonside.TabIndex = 13
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(3, 32)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(145, 16)
        Me.Label84.TabIndex = 2
        Me.Label84.Text = "Minimize Button Height:"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(3, 82)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(168, 16)
        Me.Label85.TabIndex = 12
        Me.Label85.Text = "Minimize Button From Side:"
        '
        'txtminimizebuttonheight
        '
        Me.txtminimizebuttonheight.BackColor = System.Drawing.Color.White
        Me.txtminimizebuttonheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtminimizebuttonheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtminimizebuttonheight.ForeColor = System.Drawing.Color.Black
        Me.txtminimizebuttonheight.Location = New System.Drawing.Point(150, 30)
        Me.txtminimizebuttonheight.Name = "txtminimizebuttonheight"
        Me.txtminimizebuttonheight.Size = New System.Drawing.Size(23, 22)
        Me.txtminimizebuttonheight.TabIndex = 4
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(196, 57)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(22, 16)
        Me.Label86.TabIndex = 11
        Me.Label86.Text = "px"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(174, 32)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(22, 16)
        Me.Label87.TabIndex = 5
        Me.Label87.Text = "px"
        '
        'txtminimizebuttontop
        '
        Me.txtminimizebuttontop.BackColor = System.Drawing.Color.White
        Me.txtminimizebuttontop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtminimizebuttontop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtminimizebuttontop.ForeColor = System.Drawing.Color.Black
        Me.txtminimizebuttontop.Location = New System.Drawing.Point(172, 55)
        Me.txtminimizebuttontop.Name = "txtminimizebuttontop"
        Me.txtminimizebuttontop.Size = New System.Drawing.Size(23, 22)
        Me.txtminimizebuttontop.TabIndex = 10
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(198, 32)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(45, 16)
        Me.Label88.TabIndex = 6
        Me.Label88.Text = "Width:"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(3, 57)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(165, 16)
        Me.Label89.TabIndex = 9
        Me.Label89.Text = "Minimize Button From Top:"
        '
        'txtminimizebuttonwidth
        '
        Me.txtminimizebuttonwidth.BackColor = System.Drawing.Color.White
        Me.txtminimizebuttonwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtminimizebuttonwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtminimizebuttonwidth.ForeColor = System.Drawing.Color.Black
        Me.txtminimizebuttonwidth.Location = New System.Drawing.Point(247, 30)
        Me.txtminimizebuttonwidth.Name = "txtminimizebuttonwidth"
        Me.txtminimizebuttonwidth.Size = New System.Drawing.Size(23, 22)
        Me.txtminimizebuttonwidth.TabIndex = 7
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(269, 32)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(22, 16)
        Me.Label90.TabIndex = 8
        Me.Label90.Text = "px"
        '
        'pnlrollupbuttonoptions
        '
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label54)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label55)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.pnlrollupbuttoncolour)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.txtrollupbuttonside)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label56)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label57)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.txtrollupbuttonheight)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label58)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label59)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.txtrollupbuttontop)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label60)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label61)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.txtrollupbuttonwidth)
        Me.pnlrollupbuttonoptions.Controls.Add(Me.Label62)
        Me.pnlrollupbuttonoptions.Location = New System.Drawing.Point(235, 38)
        Me.pnlrollupbuttonoptions.Name = "pnlrollupbuttonoptions"
        Me.pnlrollupbuttonoptions.Size = New System.Drawing.Size(53, 39)
        Me.pnlrollupbuttonoptions.TabIndex = 16
        Me.pnlrollupbuttonoptions.Visible = False
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(3, 6)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(138, 16)
        Me.Label54.TabIndex = 0
        Me.Label54.Text = "Roll Up Button Colour:"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(188, 82)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(22, 16)
        Me.Label55.TabIndex = 14
        Me.Label55.Text = "px"
        '
        'pnlrollupbuttoncolour
        '
        Me.pnlrollupbuttoncolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlrollupbuttoncolour.Location = New System.Drawing.Point(143, 4)
        Me.pnlrollupbuttoncolour.Name = "pnlrollupbuttoncolour"
        Me.pnlrollupbuttoncolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlrollupbuttoncolour.TabIndex = 1
        '
        'txtrollupbuttonside
        '
        Me.txtrollupbuttonside.BackColor = System.Drawing.Color.White
        Me.txtrollupbuttonside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtrollupbuttonside.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrollupbuttonside.ForeColor = System.Drawing.Color.Black
        Me.txtrollupbuttonside.Location = New System.Drawing.Point(164, 80)
        Me.txtrollupbuttonside.Name = "txtrollupbuttonside"
        Me.txtrollupbuttonside.Size = New System.Drawing.Size(23, 22)
        Me.txtrollupbuttonside.TabIndex = 13
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(3, 32)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(138, 16)
        Me.Label56.TabIndex = 2
        Me.Label56.Text = "Roll Up Button Height:"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(3, 82)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(161, 16)
        Me.Label57.TabIndex = 12
        Me.Label57.Text = "Roll Up Button From Side:"
        '
        'txtrollupbuttonheight
        '
        Me.txtrollupbuttonheight.BackColor = System.Drawing.Color.White
        Me.txtrollupbuttonheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtrollupbuttonheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrollupbuttonheight.ForeColor = System.Drawing.Color.Black
        Me.txtrollupbuttonheight.Location = New System.Drawing.Point(143, 30)
        Me.txtrollupbuttonheight.Name = "txtrollupbuttonheight"
        Me.txtrollupbuttonheight.Size = New System.Drawing.Size(23, 22)
        Me.txtrollupbuttonheight.TabIndex = 4
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(188, 57)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(22, 16)
        Me.Label58.TabIndex = 11
        Me.Label58.Text = "px"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(167, 32)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(22, 16)
        Me.Label59.TabIndex = 5
        Me.Label59.Text = "px"
        '
        'txtrollupbuttontop
        '
        Me.txtrollupbuttontop.BackColor = System.Drawing.Color.White
        Me.txtrollupbuttontop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtrollupbuttontop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrollupbuttontop.ForeColor = System.Drawing.Color.Black
        Me.txtrollupbuttontop.Location = New System.Drawing.Point(164, 55)
        Me.txtrollupbuttontop.Name = "txtrollupbuttontop"
        Me.txtrollupbuttontop.Size = New System.Drawing.Size(23, 22)
        Me.txtrollupbuttontop.TabIndex = 10
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(195, 32)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(45, 16)
        Me.Label60.TabIndex = 6
        Me.Label60.Text = "Width:"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(3, 57)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(158, 16)
        Me.Label61.TabIndex = 9
        Me.Label61.Text = "Roll Up Button From Top:"
        '
        'txtrollupbuttonwidth
        '
        Me.txtrollupbuttonwidth.BackColor = System.Drawing.Color.White
        Me.txtrollupbuttonwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtrollupbuttonwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrollupbuttonwidth.ForeColor = System.Drawing.Color.Black
        Me.txtrollupbuttonwidth.Location = New System.Drawing.Point(245, 30)
        Me.txtrollupbuttonwidth.Name = "txtrollupbuttonwidth"
        Me.txtrollupbuttonwidth.Size = New System.Drawing.Size(23, 22)
        Me.txtrollupbuttonwidth.TabIndex = 7
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(269, 32)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(22, 16)
        Me.Label62.TabIndex = 8
        Me.Label62.Text = "px"
        '
        'combobuttonoption
        '
        Me.combobuttonoption.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combobuttonoption.FormattingEnabled = True
        Me.combobuttonoption.Items.AddRange(New Object() {"Close Button", "Roll Up Button"})
        Me.combobuttonoption.Location = New System.Drawing.Point(157, 4)
        Me.combobuttonoption.Name = "combobuttonoption"
        Me.combobuttonoption.Size = New System.Drawing.Size(121, 24)
        Me.combobuttonoption.TabIndex = 17
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(40, 6)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(111, 16)
        Me.Label52.TabIndex = 15
        Me.Label52.Text = "Button To Modify:"
        '
        'pnlclosebuttonoptions
        '
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label8)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label11)
        Me.pnlclosebuttonoptions.Controls.Add(Me.pnlclosebuttoncolour)
        Me.pnlclosebuttonoptions.Controls.Add(Me.txtclosebuttonfromside)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label7)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label12)
        Me.pnlclosebuttonoptions.Controls.Add(Me.txtclosebuttonheight)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label13)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label6)
        Me.pnlclosebuttonoptions.Controls.Add(Me.txtclosebuttonfromtop)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label10)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label14)
        Me.pnlclosebuttonoptions.Controls.Add(Me.txtclosebuttonwidth)
        Me.pnlclosebuttonoptions.Controls.Add(Me.Label9)
        Me.pnlclosebuttonoptions.Location = New System.Drawing.Point(212, 87)
        Me.pnlclosebuttonoptions.Name = "pnlclosebuttonoptions"
        Me.pnlclosebuttonoptions.Size = New System.Drawing.Size(104, 44)
        Me.pnlclosebuttonoptions.TabIndex = 15
        Me.pnlclosebuttonoptions.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(3, 6)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(128, 16)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Close Button Colour:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(177, 82)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(22, 16)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "px"
        '
        'pnlclosebuttoncolour
        '
        Me.pnlclosebuttoncolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlclosebuttoncolour.Location = New System.Drawing.Point(132, 4)
        Me.pnlclosebuttoncolour.Name = "pnlclosebuttoncolour"
        Me.pnlclosebuttoncolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlclosebuttoncolour.TabIndex = 1
        '
        'txtclosebuttonfromside
        '
        Me.txtclosebuttonfromside.BackColor = System.Drawing.Color.White
        Me.txtclosebuttonfromside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclosebuttonfromside.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclosebuttonfromside.ForeColor = System.Drawing.Color.Black
        Me.txtclosebuttonfromside.Location = New System.Drawing.Point(153, 80)
        Me.txtclosebuttonfromside.Name = "txtclosebuttonfromside"
        Me.txtclosebuttonfromside.Size = New System.Drawing.Size(23, 22)
        Me.txtclosebuttonfromside.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(3, 32)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 16)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Close Button Height:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(3, 82)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(151, 16)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Close Button From Side:"
        '
        'txtclosebuttonheight
        '
        Me.txtclosebuttonheight.BackColor = System.Drawing.Color.White
        Me.txtclosebuttonheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclosebuttonheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclosebuttonheight.ForeColor = System.Drawing.Color.Black
        Me.txtclosebuttonheight.Location = New System.Drawing.Point(132, 30)
        Me.txtclosebuttonheight.Name = "txtclosebuttonheight"
        Me.txtclosebuttonheight.Size = New System.Drawing.Size(23, 22)
        Me.txtclosebuttonheight.TabIndex = 4
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(177, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(22, 16)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "px"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(156, 32)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(22, 16)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "px"
        '
        'txtclosebuttonfromtop
        '
        Me.txtclosebuttonfromtop.BackColor = System.Drawing.Color.White
        Me.txtclosebuttonfromtop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclosebuttonfromtop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclosebuttonfromtop.ForeColor = System.Drawing.Color.Black
        Me.txtclosebuttonfromtop.Location = New System.Drawing.Point(153, 55)
        Me.txtclosebuttonfromtop.Name = "txtclosebuttonfromtop"
        Me.txtclosebuttonfromtop.Size = New System.Drawing.Size(23, 22)
        Me.txtclosebuttonfromtop.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(184, 32)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 16)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Width:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(3, 57)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(148, 16)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Close Button From Top:"
        '
        'txtclosebuttonwidth
        '
        Me.txtclosebuttonwidth.BackColor = System.Drawing.Color.White
        Me.txtclosebuttonwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtclosebuttonwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclosebuttonwidth.ForeColor = System.Drawing.Color.Black
        Me.txtclosebuttonwidth.Location = New System.Drawing.Point(234, 30)
        Me.txtclosebuttonwidth.Name = "txtclosebuttonwidth"
        Me.txtclosebuttonwidth.Size = New System.Drawing.Size(23, 22)
        Me.txtclosebuttonwidth.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(258, 32)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 16)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "px"
        '
        'pnltitlebaroptions
        '
        Me.pnltitlebaroptions.Controls.Add(Me.Label80)
        Me.pnltitlebaroptions.Controls.Add(Me.txticonfromtop)
        Me.pnltitlebaroptions.Controls.Add(Me.Label81)
        Me.pnltitlebaroptions.Controls.Add(Me.Label78)
        Me.pnltitlebaroptions.Controls.Add(Me.txticonfromside)
        Me.pnltitlebaroptions.Controls.Add(Me.Label79)
        Me.pnltitlebaroptions.Controls.Add(Me.lbcornerwidthpx)
        Me.pnltitlebaroptions.Controls.Add(Me.txttitlebarcornerwidth)
        Me.pnltitlebaroptions.Controls.Add(Me.lbcornerwidth)
        Me.pnltitlebaroptions.Controls.Add(Me.pnltitlebarrightcornercolour)
        Me.pnltitlebaroptions.Controls.Add(Me.pnltitlebarleftcornercolour)
        Me.pnltitlebaroptions.Controls.Add(Me.lbrightcornercolor)
        Me.pnltitlebaroptions.Controls.Add(Me.lbleftcornercolor)
        Me.pnltitlebaroptions.Controls.Add(Me.cboxtitlebarcorners)
        Me.pnltitlebaroptions.Controls.Add(Me.Label5)
        Me.pnltitlebaroptions.Controls.Add(Me.txttitlebarheight)
        Me.pnltitlebaroptions.Controls.Add(Me.Label4)
        Me.pnltitlebaroptions.Controls.Add(Me.pnltitlebarcolour)
        Me.pnltitlebaroptions.Controls.Add(Me.Label2)
        Me.pnltitlebaroptions.Location = New System.Drawing.Point(325, 159)
        Me.pnltitlebaroptions.Name = "pnltitlebaroptions"
        Me.pnltitlebaroptions.Size = New System.Drawing.Size(33, 65)
        Me.pnltitlebaroptions.TabIndex = 9
        Me.pnltitlebaroptions.Visible = False
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(277, 105)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(22, 16)
        Me.Label80.TabIndex = 19
        Me.Label80.Text = "px"
        '
        'txticonfromtop
        '
        Me.txticonfromtop.BackColor = System.Drawing.Color.White
        Me.txticonfromtop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txticonfromtop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txticonfromtop.ForeColor = System.Drawing.Color.Black
        Me.txticonfromtop.Location = New System.Drawing.Point(253, 103)
        Me.txticonfromtop.Name = "txticonfromtop"
        Me.txticonfromtop.Size = New System.Drawing.Size(23, 22)
        Me.txticonfromtop.TabIndex = 18
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(157, 105)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(98, 16)
        Me.Label81.TabIndex = 17
        Me.Label81.Text = "Icon From Top:"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(128, 105)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(22, 16)
        Me.Label78.TabIndex = 16
        Me.Label78.Text = "px"
        '
        'txticonfromside
        '
        Me.txticonfromside.BackColor = System.Drawing.Color.White
        Me.txticonfromside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txticonfromside.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txticonfromside.ForeColor = System.Drawing.Color.Black
        Me.txticonfromside.Location = New System.Drawing.Point(104, 103)
        Me.txticonfromside.Name = "txticonfromside"
        Me.txticonfromside.Size = New System.Drawing.Size(23, 22)
        Me.txticonfromside.TabIndex = 15
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(3, 105)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(101, 16)
        Me.Label79.TabIndex = 14
        Me.Label79.Text = "Icon From Side:"
        '
        'lbcornerwidthpx
        '
        Me.lbcornerwidthpx.AutoSize = True
        Me.lbcornerwidthpx.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcornerwidthpx.Location = New System.Drawing.Point(277, 32)
        Me.lbcornerwidthpx.Name = "lbcornerwidthpx"
        Me.lbcornerwidthpx.Size = New System.Drawing.Size(22, 16)
        Me.lbcornerwidthpx.TabIndex = 13
        Me.lbcornerwidthpx.Text = "px"
        '
        'txttitlebarcornerwidth
        '
        Me.txttitlebarcornerwidth.BackColor = System.Drawing.Color.White
        Me.txttitlebarcornerwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttitlebarcornerwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttitlebarcornerwidth.ForeColor = System.Drawing.Color.Black
        Me.txttitlebarcornerwidth.Location = New System.Drawing.Point(253, 30)
        Me.txttitlebarcornerwidth.Name = "txttitlebarcornerwidth"
        Me.txttitlebarcornerwidth.Size = New System.Drawing.Size(23, 22)
        Me.txttitlebarcornerwidth.TabIndex = 12
        '
        'lbcornerwidth
        '
        Me.lbcornerwidth.AutoSize = True
        Me.lbcornerwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcornerwidth.Location = New System.Drawing.Point(163, 32)
        Me.lbcornerwidth.Name = "lbcornerwidth"
        Me.lbcornerwidth.Size = New System.Drawing.Size(88, 16)
        Me.lbcornerwidth.TabIndex = 11
        Me.lbcornerwidth.Text = "Corner Width:"
        '
        'pnltitlebarrightcornercolour
        '
        Me.pnltitlebarrightcornercolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnltitlebarrightcornercolour.Location = New System.Drawing.Point(136, 80)
        Me.pnltitlebarrightcornercolour.Name = "pnltitlebarrightcornercolour"
        Me.pnltitlebarrightcornercolour.Size = New System.Drawing.Size(41, 20)
        Me.pnltitlebarrightcornercolour.TabIndex = 10
        '
        'pnltitlebarleftcornercolour
        '
        Me.pnltitlebarleftcornercolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnltitlebarleftcornercolour.Location = New System.Drawing.Point(126, 56)
        Me.pnltitlebarleftcornercolour.Name = "pnltitlebarleftcornercolour"
        Me.pnltitlebarleftcornercolour.Size = New System.Drawing.Size(41, 20)
        Me.pnltitlebarleftcornercolour.TabIndex = 8
        '
        'lbrightcornercolor
        '
        Me.lbrightcornercolor.AutoSize = True
        Me.lbrightcornercolor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbrightcornercolor.Location = New System.Drawing.Point(3, 81)
        Me.lbrightcornercolor.Name = "lbrightcornercolor"
        Me.lbrightcornercolor.Size = New System.Drawing.Size(127, 16)
        Me.lbrightcornercolor.TabIndex = 9
        Me.lbrightcornercolor.Text = "Right Corner Colour:"
        '
        'lbleftcornercolor
        '
        Me.lbleftcornercolor.AutoSize = True
        Me.lbleftcornercolor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbleftcornercolor.Location = New System.Drawing.Point(3, 57)
        Me.lbleftcornercolor.Name = "lbleftcornercolor"
        Me.lbleftcornercolor.Size = New System.Drawing.Size(117, 16)
        Me.lbleftcornercolor.TabIndex = 7
        Me.lbleftcornercolor.Text = "Left Corner Colour:"
        '
        'cboxtitlebarcorners
        '
        Me.cboxtitlebarcorners.AutoSize = True
        Me.cboxtitlebarcorners.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.cboxtitlebarcorners.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cboxtitlebarcorners.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboxtitlebarcorners.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.cboxtitlebarcorners.Location = New System.Drawing.Point(166, 4)
        Me.cboxtitlebarcorners.Name = "cboxtitlebarcorners"
        Me.cboxtitlebarcorners.Size = New System.Drawing.Size(131, 21)
        Me.cboxtitlebarcorners.TabIndex = 6
        Me.cboxtitlebarcorners.Text = "Title Bar Corners"
        Me.cboxtitlebarcorners.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(136, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(22, 16)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "px"
        '
        'txttitlebarheight
        '
        Me.txttitlebarheight.BackColor = System.Drawing.Color.White
        Me.txttitlebarheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttitlebarheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttitlebarheight.ForeColor = System.Drawing.Color.Black
        Me.txttitlebarheight.Location = New System.Drawing.Point(112, 30)
        Me.txttitlebarheight.Name = "txttitlebarheight"
        Me.txttitlebarheight.Size = New System.Drawing.Size(23, 22)
        Me.txttitlebarheight.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(3, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Title Bar Height:"
        '
        'pnltitlebarcolour
        '
        Me.pnltitlebarcolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnltitlebarcolour.Location = New System.Drawing.Point(112, 5)
        Me.pnltitlebarcolour.Name = "pnltitlebarcolour"
        Me.pnltitlebarcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnltitlebarcolour.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Title Bar Colour:"
        '
        'pnlborderoptions
        '
        Me.pnlborderoptions.Controls.Add(Me.cbindividualbordercolours)
        Me.pnlborderoptions.Controls.Add(Me.pnlborderbottomrightcolour)
        Me.pnlborderoptions.Controls.Add(Me.Label77)
        Me.pnlborderoptions.Controls.Add(Me.pnlborderbottomcolour)
        Me.pnlborderoptions.Controls.Add(Me.Label76)
        Me.pnlborderoptions.Controls.Add(Me.pnlborderbottomleftcolour)
        Me.pnlborderoptions.Controls.Add(Me.Label75)
        Me.pnlborderoptions.Controls.Add(Me.pnlborderrightcolour)
        Me.pnlborderoptions.Controls.Add(Me.Label74)
        Me.pnlborderoptions.Controls.Add(Me.pnlborderleftcolour)
        Me.pnlborderoptions.Controls.Add(Me.Label73)
        Me.pnlborderoptions.Controls.Add(Me.Label15)
        Me.pnlborderoptions.Controls.Add(Me.pnlbordercolour)
        Me.pnlborderoptions.Controls.Add(Me.txtbordersize)
        Me.pnlborderoptions.Controls.Add(Me.Label3)
        Me.pnlborderoptions.Controls.Add(Me.Label16)
        Me.pnlborderoptions.Location = New System.Drawing.Point(407, 188)
        Me.pnlborderoptions.Name = "pnlborderoptions"
        Me.pnlborderoptions.Size = New System.Drawing.Size(44, 52)
        Me.pnlborderoptions.TabIndex = 10
        Me.pnlborderoptions.Visible = False
        '
        'cbindividualbordercolours
        '
        Me.cbindividualbordercolours.AutoSize = True
        Me.cbindividualbordercolours.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.cbindividualbordercolours.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black
        Me.cbindividualbordercolours.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cbindividualbordercolours.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.cbindividualbordercolours.Location = New System.Drawing.Point(161, 4)
        Me.cbindividualbordercolours.Name = "cbindividualbordercolours"
        Me.cbindividualbordercolours.Size = New System.Drawing.Size(135, 21)
        Me.cbindividualbordercolours.TabIndex = 28
        Me.cbindividualbordercolours.Text = "Individual Colours"
        Me.cbindividualbordercolours.UseVisualStyleBackColor = True
        '
        'pnlborderbottomrightcolour
        '
        Me.pnlborderbottomrightcolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlborderbottomrightcolour.Location = New System.Drawing.Point(132, 101)
        Me.pnlborderbottomrightcolour.Name = "pnlborderbottomrightcolour"
        Me.pnlborderbottomrightcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlborderbottomrightcolour.TabIndex = 27
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(3, 103)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(129, 16)
        Me.Label77.TabIndex = 26
        Me.Label77.Text = "Bottom Right Colour:"
        '
        'pnlborderbottomcolour
        '
        Me.pnlborderbottomcolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlborderbottomcolour.Location = New System.Drawing.Point(263, 31)
        Me.pnlborderbottomcolour.Name = "pnlborderbottomcolour"
        Me.pnlborderbottomcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlborderbottomcolour.TabIndex = 25
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(158, 32)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(95, 16)
        Me.Label76.TabIndex = 24
        Me.Label76.Text = "Bottom Colour:"
        '
        'pnlborderbottomleftcolour
        '
        Me.pnlborderbottomleftcolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlborderbottomleftcolour.Location = New System.Drawing.Point(124, 78)
        Me.pnlborderbottomleftcolour.Name = "pnlborderbottomleftcolour"
        Me.pnlborderbottomleftcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlborderbottomleftcolour.TabIndex = 23
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(3, 80)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(119, 16)
        Me.Label75.TabIndex = 22
        Me.Label75.Text = "Bottom Left Colour:"
        '
        'pnlborderrightcolour
        '
        Me.pnlborderrightcolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlborderrightcolour.Location = New System.Drawing.Point(263, 54)
        Me.pnlborderrightcolour.Name = "pnlborderrightcolour"
        Me.pnlborderrightcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlborderrightcolour.TabIndex = 21
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(157, 56)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(84, 16)
        Me.Label74.TabIndex = 20
        Me.Label74.Text = "Right Colour:"
        '
        'pnlborderleftcolour
        '
        Me.pnlborderleftcolour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlborderleftcolour.Location = New System.Drawing.Point(102, 54)
        Me.pnlborderleftcolour.Name = "pnlborderleftcolour"
        Me.pnlborderleftcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlborderleftcolour.TabIndex = 19
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(3, 56)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(74, 16)
        Me.Label73.TabIndex = 18
        Me.Label73.Text = "Left Colour:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(126, 31)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(22, 16)
        Me.Label15.TabIndex = 17
        Me.Label15.Text = "px"
        '
        'pnlbordercolour
        '
        Me.pnlbordercolour.Location = New System.Drawing.Point(102, 5)
        Me.pnlbordercolour.Name = "pnlbordercolour"
        Me.pnlbordercolour.Size = New System.Drawing.Size(41, 20)
        Me.pnlbordercolour.TabIndex = 3
        '
        'txtbordersize
        '
        Me.txtbordersize.BackColor = System.Drawing.Color.White
        Me.txtbordersize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbordersize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbordersize.ForeColor = System.Drawing.Color.Black
        Me.txtbordersize.Location = New System.Drawing.Point(102, 29)
        Me.txtbordersize.Name = "txtbordersize"
        Me.txtbordersize.Size = New System.Drawing.Size(23, 22)
        Me.txtbordersize.TabIndex = 16
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(94, 16)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Border Colour:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(3, 31)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(81, 16)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "Border Size:"
        '
        'pnltitletextoptions
        '
        Me.pnltitletextoptions.Controls.Add(Me.combotitletextposition)
        Me.pnltitletextoptions.Controls.Add(Me.Label53)
        Me.pnltitletextoptions.Controls.Add(Me.combotitletextstyle)
        Me.pnltitletextoptions.Controls.Add(Me.combotitletextfont)
        Me.pnltitletextoptions.Controls.Add(Me.Label23)
        Me.pnltitletextoptions.Controls.Add(Me.Label17)
        Me.pnltitletextoptions.Controls.Add(Me.txttitletextside)
        Me.pnltitletextoptions.Controls.Add(Me.Label18)
        Me.pnltitletextoptions.Controls.Add(Me.Label19)
        Me.pnltitletextoptions.Controls.Add(Me.txttitletexttop)
        Me.pnltitletextoptions.Controls.Add(Me.Label20)
        Me.pnltitletextoptions.Controls.Add(Me.Label21)
        Me.pnltitletextoptions.Controls.Add(Me.txttitletextsize)
        Me.pnltitletextoptions.Controls.Add(Me.Label22)
        Me.pnltitletextoptions.Controls.Add(Me.Label24)
        Me.pnltitletextoptions.Controls.Add(Me.pnltitletextcolour)
        Me.pnltitletextoptions.Controls.Add(Me.Label25)
        Me.pnltitletextoptions.Location = New System.Drawing.Point(408, 264)
        Me.pnltitletextoptions.Name = "pnltitletextoptions"
        Me.pnltitletextoptions.Size = New System.Drawing.Size(43, 27)
        Me.pnltitletextoptions.TabIndex = 15
        Me.pnltitletextoptions.Visible = False
        '
        'combotitletextposition
        '
        Me.combotitletextposition.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combotitletextposition.FormattingEnabled = True
        Me.combotitletextposition.Items.AddRange(New Object() {"Left", "Centre"})
        Me.combotitletextposition.Location = New System.Drawing.Point(211, 54)
        Me.combotitletextposition.Name = "combotitletextposition"
        Me.combotitletextposition.Size = New System.Drawing.Size(95, 24)
        Me.combotitletextposition.TabIndex = 21
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(149, 57)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(59, 16)
        Me.Label53.TabIndex = 20
        Me.Label53.Text = "Position:"
        '
        'combotitletextstyle
        '
        Me.combotitletextstyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combotitletextstyle.FormattingEnabled = True
        Me.combotitletextstyle.Items.AddRange(New Object() {"Bold", "Italic", "Regular", "Strikeout", "Underline"})
        Me.combotitletextstyle.Location = New System.Drawing.Point(207, 3)
        Me.combotitletextstyle.Name = "combotitletextstyle"
        Me.combotitletextstyle.Size = New System.Drawing.Size(99, 24)
        Me.combotitletextstyle.TabIndex = 18
        '
        'combotitletextfont
        '
        Me.combotitletextfont.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combotitletextfont.FormattingEnabled = True
        Me.combotitletextfont.Location = New System.Drawing.Point(100, 30)
        Me.combotitletextfont.Name = "combotitletextfont"
        Me.combotitletextfont.Size = New System.Drawing.Size(202, 24)
        Me.combotitletextfont.TabIndex = 17
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(164, 7)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(41, 16)
        Me.Label23.TabIndex = 15
        Me.Label23.Text = "Style:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(159, 107)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(22, 16)
        Me.Label17.TabIndex = 14
        Me.Label17.Text = "px"
        '
        'txttitletextside
        '
        Me.txttitletextside.BackColor = System.Drawing.Color.White
        Me.txttitletextside.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttitletextside.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttitletextside.ForeColor = System.Drawing.Color.Black
        Me.txttitletextside.Location = New System.Drawing.Point(135, 105)
        Me.txttitletextside.Name = "txttitletextside"
        Me.txttitletextside.Size = New System.Drawing.Size(23, 22)
        Me.txttitletextside.TabIndex = 13
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(3, 107)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(131, 16)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "Title Text From Side:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(159, 82)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(22, 16)
        Me.Label19.TabIndex = 11
        Me.Label19.Text = "px"
        '
        'txttitletexttop
        '
        Me.txttitletexttop.BackColor = System.Drawing.Color.White
        Me.txttitletexttop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttitletexttop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttitletexttop.ForeColor = System.Drawing.Color.Black
        Me.txttitletexttop.Location = New System.Drawing.Point(135, 80)
        Me.txttitletexttop.Name = "txttitletexttop"
        Me.txttitletexttop.Size = New System.Drawing.Size(23, 22)
        Me.txttitletexttop.TabIndex = 10
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(3, 82)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(128, 16)
        Me.Label20.TabIndex = 9
        Me.Label20.Text = "Title Text From Top:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(124, 57)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(22, 16)
        Me.Label21.TabIndex = 8
        Me.Label21.Text = "px"
        '
        'txttitletextsize
        '
        Me.txttitletextsize.BackColor = System.Drawing.Color.White
        Me.txttitletextsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttitletextsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttitletextsize.ForeColor = System.Drawing.Color.Black
        Me.txttitletextsize.Location = New System.Drawing.Point(100, 55)
        Me.txttitletextsize.Name = "txttitletextsize"
        Me.txttitletextsize.Size = New System.Drawing.Size(23, 22)
        Me.txttitletextsize.TabIndex = 7
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(3, 57)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(95, 16)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "Title Text Size:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(3, 33)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(95, 16)
        Me.Label24.TabIndex = 2
        Me.Label24.Text = "Title Text Font:"
        '
        'pnltitletextcolour
        '
        Me.pnltitletextcolour.Location = New System.Drawing.Point(114, 5)
        Me.pnltitletextcolour.Name = "pnltitletextcolour"
        Me.pnltitletextcolour.Size = New System.Drawing.Size(41, 20)
        Me.pnltitletextcolour.TabIndex = 1
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(3, 7)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(108, 16)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Title Text Colour:"
        '
        'pnlwindowsintro
        '
        Me.pnlwindowsintro.Controls.Add(Me.Label68)
        Me.pnlwindowsintro.Controls.Add(Me.Label67)
        Me.pnlwindowsintro.Location = New System.Drawing.Point(156, 202)
        Me.pnlwindowsintro.Name = "pnlwindowsintro"
        Me.pnlwindowsintro.Size = New System.Drawing.Size(107, 74)
        Me.pnlwindowsintro.TabIndex = 16
        '
        'Label68
        '
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(3, 20)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(312, 113)
        Me.Label68.TabIndex = 1
        Me.Label68.Text = resources.GetString("Label68.Text")
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(89, -2)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(143, 20)
        Me.Label67.TabIndex = 0
        Me.Label67.Text = "Window Settings"
        '
        'pnlwindowsobjects
        '
        Me.pnlwindowsobjects.Controls.Add(Me.btnborders)
        Me.pnlwindowsobjects.Controls.Add(Me.btnbuttons)
        Me.pnlwindowsobjects.Controls.Add(Me.btntitletext)
        Me.pnlwindowsobjects.Controls.Add(Me.btntitlebar)
        Me.pnlwindowsobjects.Location = New System.Drawing.Point(1, 159)
        Me.pnlwindowsobjects.Name = "pnlwindowsobjects"
        Me.pnlwindowsobjects.Size = New System.Drawing.Size(128, 135)
        Me.pnlwindowsobjects.TabIndex = 8
        '
        'btnborders
        '
        Me.btnborders.BackColor = System.Drawing.Color.White
        Me.btnborders.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnborders.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnborders.Location = New System.Drawing.Point(4, 105)
        Me.btnborders.Name = "btnborders"
        Me.btnborders.Size = New System.Drawing.Size(119, 29)
        Me.btnborders.TabIndex = 7
        Me.btnborders.TabStop = False
        Me.btnborders.Text = "Borders"
        Me.btnborders.UseVisualStyleBackColor = False
        '
        'btnbuttons
        '
        Me.btnbuttons.BackColor = System.Drawing.Color.White
        Me.btnbuttons.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnbuttons.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbuttons.Location = New System.Drawing.Point(4, 70)
        Me.btnbuttons.Name = "btnbuttons"
        Me.btnbuttons.Size = New System.Drawing.Size(119, 29)
        Me.btnbuttons.TabIndex = 6
        Me.btnbuttons.TabStop = False
        Me.btnbuttons.Text = "Buttons"
        Me.btnbuttons.UseVisualStyleBackColor = False
        '
        'btntitletext
        '
        Me.btntitletext.BackColor = System.Drawing.Color.White
        Me.btntitletext.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntitletext.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntitletext.Location = New System.Drawing.Point(4, 35)
        Me.btntitletext.Name = "btntitletext"
        Me.btntitletext.Size = New System.Drawing.Size(119, 29)
        Me.btntitletext.TabIndex = 5
        Me.btntitletext.TabStop = False
        Me.btntitletext.Text = "Title Text"
        Me.btntitletext.UseVisualStyleBackColor = False
        '
        'btntitlebar
        '
        Me.btntitlebar.BackColor = System.Drawing.Color.White
        Me.btntitlebar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntitlebar.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntitlebar.Location = New System.Drawing.Point(4, 0)
        Me.btntitlebar.Name = "btntitlebar"
        Me.btntitlebar.Size = New System.Drawing.Size(119, 29)
        Me.btntitlebar.TabIndex = 4
        Me.btntitlebar.TabStop = False
        Me.btntitlebar.Text = "Title Bar"
        Me.btntitlebar.UseVisualStyleBackColor = False
        '
        'pnlwindowpreview
        '
        Me.pnlwindowpreview.Controls.Add(Me.prepgcontent)
        Me.pnlwindowpreview.Controls.Add(Me.prepgbottom)
        Me.pnlwindowpreview.Controls.Add(Me.prepgleft)
        Me.pnlwindowpreview.Controls.Add(Me.prepgright)
        Me.pnlwindowpreview.Controls.Add(Me.pretitlebar)
        Me.pnlwindowpreview.Location = New System.Drawing.Point(5, 3)
        Me.pnlwindowpreview.Name = "pnlwindowpreview"
        Me.pnlwindowpreview.Size = New System.Drawing.Size(448, 148)
        Me.pnlwindowpreview.TabIndex = 0
        '
        'prepgcontent
        '
        Me.prepgcontent.Dock = System.Windows.Forms.DockStyle.Fill
        Me.prepgcontent.Location = New System.Drawing.Point(2, 30)
        Me.prepgcontent.Name = "prepgcontent"
        Me.prepgcontent.Size = New System.Drawing.Size(444, 116)
        Me.prepgcontent.TabIndex = 20
        '
        'prepgbottom
        '
        Me.prepgbottom.BackColor = System.Drawing.Color.Gray
        Me.prepgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.prepgbottom.Location = New System.Drawing.Point(2, 146)
        Me.prepgbottom.Name = "prepgbottom"
        Me.prepgbottom.Size = New System.Drawing.Size(444, 2)
        Me.prepgbottom.TabIndex = 23
        '
        'prepgleft
        '
        Me.prepgleft.BackColor = System.Drawing.Color.Gray
        Me.prepgleft.Controls.Add(Me.prepgbottomlcorner)
        Me.prepgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.prepgleft.Location = New System.Drawing.Point(0, 30)
        Me.prepgleft.Name = "prepgleft"
        Me.prepgleft.Size = New System.Drawing.Size(2, 118)
        Me.prepgleft.TabIndex = 21
        '
        'prepgbottomlcorner
        '
        Me.prepgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.prepgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.prepgbottomlcorner.Location = New System.Drawing.Point(0, 116)
        Me.prepgbottomlcorner.Name = "prepgbottomlcorner"
        Me.prepgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.prepgbottomlcorner.TabIndex = 14
        '
        'prepgright
        '
        Me.prepgright.BackColor = System.Drawing.Color.Gray
        Me.prepgright.Controls.Add(Me.prepgbottomrcorner)
        Me.prepgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.prepgright.Location = New System.Drawing.Point(446, 30)
        Me.prepgright.Name = "prepgright"
        Me.prepgright.Size = New System.Drawing.Size(2, 118)
        Me.prepgright.TabIndex = 22
        '
        'prepgbottomrcorner
        '
        Me.prepgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.prepgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.prepgbottomrcorner.Location = New System.Drawing.Point(0, 116)
        Me.prepgbottomrcorner.Name = "prepgbottomrcorner"
        Me.prepgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.prepgbottomrcorner.TabIndex = 15
        '
        'pretitlebar
        '
        Me.pretitlebar.BackColor = System.Drawing.Color.Gray
        Me.pretitlebar.Controls.Add(Me.preminimizebutton)
        Me.pretitlebar.Controls.Add(Me.prepnlicon)
        Me.pretitlebar.Controls.Add(Me.prerollupbutton)
        Me.pretitlebar.Controls.Add(Me.preclosebutton)
        Me.pretitlebar.Controls.Add(Me.pretitletext)
        Me.pretitlebar.Controls.Add(Me.prepgtoplcorner)
        Me.pretitlebar.Controls.Add(Me.prepgtoprcorner)
        Me.pretitlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pretitlebar.ForeColor = System.Drawing.Color.White
        Me.pretitlebar.Location = New System.Drawing.Point(0, 0)
        Me.pretitlebar.Name = "pretitlebar"
        Me.pretitlebar.Size = New System.Drawing.Size(448, 30)
        Me.pretitlebar.TabIndex = 19
        '
        'preminimizebutton
        '
        Me.preminimizebutton.BackColor = System.Drawing.Color.Black
        Me.preminimizebutton.Location = New System.Drawing.Point(185, 5)
        Me.preminimizebutton.Name = "preminimizebutton"
        Me.preminimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.preminimizebutton.TabIndex = 31
        '
        'prepnlicon
        '
        Me.prepnlicon.BackColor = System.Drawing.Color.Transparent
        Me.prepnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconShifter
        Me.prepnlicon.Location = New System.Drawing.Point(8, 8)
        Me.prepnlicon.Name = "prepnlicon"
        Me.prepnlicon.Size = New System.Drawing.Size(16, 16)
        Me.prepnlicon.TabIndex = 32
        Me.prepnlicon.TabStop = False
        Me.prepnlicon.Visible = False
        '
        'prerollupbutton
        '
        Me.prerollupbutton.BackColor = System.Drawing.Color.Black
        Me.prerollupbutton.Location = New System.Drawing.Point(213, 5)
        Me.prerollupbutton.Name = "prerollupbutton"
        Me.prerollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.prerollupbutton.TabIndex = 31
        '
        'preclosebutton
        '
        Me.preclosebutton.BackColor = System.Drawing.Color.Black
        Me.preclosebutton.Location = New System.Drawing.Point(251, 5)
        Me.preclosebutton.Name = "preclosebutton"
        Me.preclosebutton.Size = New System.Drawing.Size(22, 22)
        Me.preclosebutton.TabIndex = 20
        '
        'pretitletext
        '
        Me.pretitletext.AutoSize = True
        Me.pretitletext.BackColor = System.Drawing.Color.Transparent
        Me.pretitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pretitletext.Location = New System.Drawing.Point(29, 7)
        Me.pretitletext.Name = "pretitletext"
        Me.pretitletext.Size = New System.Drawing.Size(77, 18)
        Me.pretitletext.TabIndex = 19
        Me.pretitletext.Text = "Template"
        '
        'prepgtoplcorner
        '
        Me.prepgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.prepgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.prepgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.prepgtoplcorner.Name = "prepgtoplcorner"
        Me.prepgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.prepgtoplcorner.TabIndex = 17
        '
        'prepgtoprcorner
        '
        Me.prepgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.prepgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.prepgtoprcorner.Location = New System.Drawing.Point(446, 0)
        Me.prepgtoprcorner.Name = "prepgtoprcorner"
        Me.prepgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.prepgtoprcorner.TabIndex = 16
        '
        'pnlreset
        '
        Me.pnlreset.Controls.Add(Me.Label113)
        Me.pnlreset.Controls.Add(Me.btnresetallsettings)
        Me.pnlreset.Controls.Add(Me.Label109)
        Me.pnlreset.Controls.Add(Me.Label111)
        Me.pnlreset.Location = New System.Drawing.Point(134, 272)
        Me.pnlreset.Name = "pnlreset"
        Me.pnlreset.Size = New System.Drawing.Size(55, 26)
        Me.pnlreset.TabIndex = 18
        '
        'Label113
        '
        Me.Label113.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label113.Location = New System.Drawing.Point(57, 231)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(332, 33)
        Me.Label113.TabIndex = 5
        Me.Label113.Text = "Warning! A Global Reset Is Irreversible!"
        Me.Label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnresetallsettings
        '
        Me.btnresetallsettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnresetallsettings.Font = New System.Drawing.Font("Cambria", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnresetallsettings.Location = New System.Drawing.Point(101, 145)
        Me.btnresetallsettings.Name = "btnresetallsettings"
        Me.btnresetallsettings.Size = New System.Drawing.Size(255, 83)
        Me.btnresetallsettings.TabIndex = 4
        Me.btnresetallsettings.TabStop = False
        Me.btnresetallsettings.Text = "Reset All Settings"
        Me.btnresetallsettings.UseVisualStyleBackColor = True
        '
        'Label109
        '
        Me.Label109.BackColor = System.Drawing.Color.Transparent
        Me.Label109.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label109.Location = New System.Drawing.Point(4, 40)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(451, 66)
        Me.Label109.TabIndex = 3
        Me.Label109.Text = resources.GetString("Label109.Text")
        Me.Label109.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label111
        '
        Me.Label111.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label111.Location = New System.Drawing.Point(68, 4)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(332, 33)
        Me.Label111.TabIndex = 2
        Me.Label111.Text = "Global Settings Reset!"
        Me.Label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pgcontents
        '
        Me.pgcontents.BackColor = System.Drawing.Color.White
        Me.pgcontents.Controls.Add(Me.pnlshiftadvapplauncher)
        Me.pgcontents.Controls.Add(Me.pnldeskdoubleplus)
        Me.pgcontents.Controls.Add(Me.pnlreset)
        Me.pgcontents.Controls.Add(Me.pnlwindowsoptions)
        Me.pgcontents.Controls.Add(Me.pnldesktopoptions)
        Me.pgcontents.Controls.Add(Me.pnlshifterintro)
        Me.pgcontents.Controls.Add(Me.catholder)
        Me.pgcontents.Controls.Add(Me.btnapply)
        Me.pgcontents.Controls.Add(Me.Label1)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(596, 307)
        Me.pgcontents.TabIndex = 0
        '
        'pnlshiftadvapplauncher
        '
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Panel1)
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Label119)
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Button7)
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Button6)
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Button5)
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Button4)
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Button3)
        Me.pnlshiftadvapplauncher.Controls.Add(Me.Label118)
        Me.pnlshiftadvapplauncher.Location = New System.Drawing.Point(134, 9)
        Me.pnlshiftadvapplauncher.Name = "pnlshiftadvapplauncher"
        Me.pnlshiftadvapplauncher.Size = New System.Drawing.Size(452, 292)
        Me.pnlshiftadvapplauncher.TabIndex = 20
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnaalpwrpnlbg)
        Me.Panel1.Controls.Add(Me.Label124)
        Me.Panel1.Controls.Add(Me.btnaalusrpnlbg)
        Me.Panel1.Controls.Add(Me.Label123)
        Me.Panel1.Controls.Add(Me.btnaalshutdowntextcolor)
        Me.Panel1.Controls.Add(Me.Label122)
        Me.Panel1.Controls.Add(Me.cmbaalusrstyle)
        Me.Panel1.Controls.Add(Me.nudusrsize)
        Me.Panel1.Controls.Add(Me.cmbaalusrfont)
        Me.Panel1.Controls.Add(Me.Label121)
        Me.Panel1.Controls.Add(Me.btnaalusrtextcolor)
        Me.Panel1.Controls.Add(Me.Label120)
        Me.Panel1.Location = New System.Drawing.Point(4, 104)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(444, 157)
        Me.Panel1.TabIndex = 7
        '
        'btnaalpwrpnlbg
        '
        Me.btnaalpwrpnlbg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaalpwrpnlbg.Location = New System.Drawing.Point(346, 84)
        Me.btnaalpwrpnlbg.Name = "btnaalpwrpnlbg"
        Me.btnaalpwrpnlbg.Size = New System.Drawing.Size(34, 23)
        Me.btnaalpwrpnlbg.TabIndex = 11
        Me.btnaalpwrpnlbg.UseVisualStyleBackColor = True
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Location = New System.Drawing.Point(213, 90)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(131, 13)
        Me.Label124.TabIndex = 10
        Me.Label124.Text = "Power Panel Background:"
        '
        'btnaalusrpnlbg
        '
        Me.btnaalusrpnlbg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaalusrpnlbg.Location = New System.Drawing.Point(167, 84)
        Me.btnaalusrpnlbg.Name = "btnaalusrpnlbg"
        Me.btnaalusrpnlbg.Size = New System.Drawing.Size(34, 23)
        Me.btnaalusrpnlbg.TabIndex = 9
        Me.btnaalusrpnlbg.UseVisualStyleBackColor = True
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Location = New System.Drawing.Point(14, 89)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(149, 13)
        Me.Label123.TabIndex = 8
        Me.Label123.Text = "Username Panel Background:"
        '
        'btnaalshutdowntextcolor
        '
        Me.btnaalshutdowntextcolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaalshutdowntextcolor.Location = New System.Drawing.Point(310, 7)
        Me.btnaalshutdowntextcolor.Name = "btnaalshutdowntextcolor"
        Me.btnaalshutdowntextcolor.Size = New System.Drawing.Size(34, 23)
        Me.btnaalshutdowntextcolor.TabIndex = 7
        Me.btnaalshutdowntextcolor.UseVisualStyleBackColor = True
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Location = New System.Drawing.Point(164, 12)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(143, 13)
        Me.Label122.TabIndex = 6
        Me.Label122.Text = "Shutdown Button Text Color:"
        '
        'cmbaalusrstyle
        '
        Me.cmbaalusrstyle.FormattingEnabled = True
        Me.cmbaalusrstyle.Items.AddRange(New Object() {"Regular", "Bold", "Italic", "Underline"})
        Me.cmbaalusrstyle.Location = New System.Drawing.Point(295, 44)
        Me.cmbaalusrstyle.Name = "cmbaalusrstyle"
        Me.cmbaalusrstyle.Size = New System.Drawing.Size(60, 21)
        Me.cmbaalusrstyle.TabIndex = 5
        Me.cmbaalusrstyle.Text = "Regular"
        '
        'nudusrsize
        '
        Me.nudusrsize.Location = New System.Drawing.Point(243, 44)
        Me.nudusrsize.Name = "nudusrsize"
        Me.nudusrsize.Size = New System.Drawing.Size(39, 20)
        Me.nudusrsize.TabIndex = 4
        '
        'cmbaalusrfont
        '
        Me.cmbaalusrfont.FormattingEnabled = True
        Me.cmbaalusrfont.Location = New System.Drawing.Point(119, 44)
        Me.cmbaalusrfont.Name = "cmbaalusrfont"
        Me.cmbaalusrfont.Size = New System.Drawing.Size(121, 21)
        Me.cmbaalusrfont.TabIndex = 3
        Me.cmbaalusrfont.Text = "[Insert Font Here]"
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Location = New System.Drawing.Point(14, 47)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(106, 13)
        Me.Label121.TabIndex = 2
        Me.Label121.Text = "Username Text Font:"
        '
        'btnaalusrtextcolor
        '
        Me.btnaalusrtextcolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaalusrtextcolor.Location = New System.Drawing.Point(124, 7)
        Me.btnaalusrtextcolor.Name = "btnaalusrtextcolor"
        Me.btnaalusrtextcolor.Size = New System.Drawing.Size(34, 23)
        Me.btnaalusrtextcolor.TabIndex = 1
        Me.btnaalusrtextcolor.UseVisualStyleBackColor = True
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Location = New System.Drawing.Point(11, 12)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(109, 13)
        Me.Label120.TabIndex = 0
        Me.Label120.Text = "Username Text Color:"
        '
        'Label119
        '
        Me.Label119.Location = New System.Drawing.Point(9, 46)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(437, 58)
        Me.Label119.TabIndex = 6
        Me.Label119.Text = resources.GetString("Label119.Text")
        '
        'Button7
        '
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Location = New System.Drawing.Point(351, 264)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 5
        Me.Button7.Text = "Misc."
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Location = New System.Drawing.Point(273, 264)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 4
        Me.Button6.Text = "Behavior"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Location = New System.Drawing.Point(194, 264)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 3
        Me.Button5.Text = "Icons"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Location = New System.Drawing.Point(113, 264)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 2
        Me.Button4.Text = "Positions"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(4, 264)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(105, 23)
        Me.Button3.TabIndex = 1
        Me.Button3.Text = "Colors and Fonts"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
        Me.Label118.Location = New System.Drawing.Point(5, 13)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(292, 24)
        Me.Label118.TabIndex = 0
        Me.Label118.Text = "Advanced App Launcher Settings"
        '
        'pnldeskdoubleplus
        '
        Me.pnldeskdoubleplus.Controls.Add(Me.Panel2)
        Me.pnldeskdoubleplus.Controls.Add(Me.pnldppoptions)
        Me.pnldeskdoubleplus.Location = New System.Drawing.Point(134, 9)
        Me.pnldeskdoubleplus.Name = "pnldeskdoubleplus"
        Me.pnldeskdoubleplus.Size = New System.Drawing.Size(457, 292)
        Me.pnldeskdoubleplus.TabIndex = 19
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.desktopiconspreview)
        Me.Panel2.Location = New System.Drawing.Point(5, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(448, 166)
        Me.Panel2.TabIndex = 1
        '
        'desktopiconspreview
        '
        Me.desktopiconspreview.Dock = System.Windows.Forms.DockStyle.Fill
        Me.desktopiconspreview.Location = New System.Drawing.Point(0, 0)
        Me.desktopiconspreview.Name = "desktopiconspreview"
        Me.desktopiconspreview.Size = New System.Drawing.Size(448, 166)
        Me.desktopiconspreview.TabIndex = 0
        Me.desktopiconspreview.UseCompatibleStateImageBehavior = False
        '
        'pnldppoptions
        '
        Me.pnldppoptions.Controls.Add(Me.pnldppicons)
        Me.pnldppoptions.Controls.Add(Me.pnldppfunctions)
        Me.pnldppoptions.Controls.Add(Me.btndppfunctions)
        Me.pnldppoptions.Controls.Add(Me.btndppappearance)
        Me.pnldppoptions.Controls.Add(Me.btndppfiles)
        Me.pnldppoptions.Controls.Add(Me.btndppicons)
        Me.pnldppoptions.Location = New System.Drawing.Point(5, 176)
        Me.pnldppoptions.Name = "pnldppoptions"
        Me.pnldppoptions.Size = New System.Drawing.Size(446, 110)
        Me.pnldppoptions.TabIndex = 0
        '
        'pnldppicons
        '
        Me.pnldppicons.Controls.Add(Me.Button1)
        Me.pnldppicons.Controls.Add(Me.Label117)
        Me.pnldppicons.Location = New System.Drawing.Point(89, 6)
        Me.pnldppicons.Name = "pnldppicons"
        Me.pnldppicons.Size = New System.Drawing.Size(352, 100)
        Me.pnldppicons.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(88, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(29, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Location = New System.Drawing.Point(7, 12)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(82, 13)
        Me.Label117.TabIndex = 0
        Me.Label117.Text = "Icon Text Color:"
        '
        'pnldppfunctions
        '
        Me.pnldppfunctions.Controls.Add(Me.CheckBox1)
        Me.pnldppfunctions.Location = New System.Drawing.Point(89, 6)
        Me.pnldppfunctions.Name = "pnldppfunctions"
        Me.pnldppfunctions.Size = New System.Drawing.Size(352, 100)
        Me.pnldppfunctions.TabIndex = 4
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(7, 8)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(122, 17)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Icons are Draggable"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'btndppfunctions
        '
        Me.btndppfunctions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndppfunctions.Location = New System.Drawing.Point(7, 12)
        Me.btndppfunctions.Name = "btndppfunctions"
        Me.btndppfunctions.Size = New System.Drawing.Size(75, 23)
        Me.btndppfunctions.TabIndex = 3
        Me.btndppfunctions.Text = "Functions"
        Me.btndppfunctions.UseVisualStyleBackColor = True
        '
        'btndppappearance
        '
        Me.btndppappearance.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndppappearance.Location = New System.Drawing.Point(7, 81)
        Me.btndppappearance.Name = "btndppappearance"
        Me.btndppappearance.Size = New System.Drawing.Size(75, 23)
        Me.btndppappearance.TabIndex = 2
        Me.btndppappearance.Text = "Appearance"
        Me.btndppappearance.UseVisualStyleBackColor = True
        '
        'btndppfiles
        '
        Me.btndppfiles.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndppfiles.Location = New System.Drawing.Point(7, 58)
        Me.btndppfiles.Name = "btndppfiles"
        Me.btndppfiles.Size = New System.Drawing.Size(75, 23)
        Me.btndppfiles.TabIndex = 1
        Me.btndppfiles.Text = "Files"
        Me.btndppfiles.UseVisualStyleBackColor = True
        '
        'btndppicons
        '
        Me.btndppicons.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndppicons.Location = New System.Drawing.Point(7, 35)
        Me.btndppicons.Name = "btndppicons"
        Me.btndppicons.Size = New System.Drawing.Size(75, 23)
        Me.btndppicons.TabIndex = 0
        Me.btndppicons.Text = "Icons"
        Me.btndppicons.UseVisualStyleBackColor = True
        '
        'tmrfix
        '
        Me.tmrfix.Interval = 5000
        '
        'tmrdelay
        '
        '
        'Shifter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 339)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Shifter"
        Me.Text = "Shifter"
        Me.TopMost = True
        Me.pgleft.ResumeLayout(False)
        Me.pgright.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.catholder.ResumeLayout(False)
        Me.pnlshifterintro.ResumeLayout(False)
        Me.pnlshifterintro.PerformLayout()
        Me.pnldesktopoptions.ResumeLayout(False)
        Me.pnlapplauncheroptions.ResumeLayout(False)
        Me.pnlapplauncheroptions.PerformLayout()
        Me.pnllauncheritems.ResumeLayout(False)
        Me.pnllauncheritems.PerformLayout()
        Me.pnldesktoppreview.ResumeLayout(False)
        Me.predesktoppanel.ResumeLayout(False)
        Me.prepnlpanelbuttonholder.ResumeLayout(False)
        Me.prepnlpanelbutton.ResumeLayout(False)
        Me.prepnlpanelbutton.PerformLayout()
        CType(Me.pretbicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pretimepanel.ResumeLayout(False)
        Me.pretimepanel.PerformLayout()
        Me.preapplaunchermenuholder.ResumeLayout(False)
        Me.predesktopappmenu.ResumeLayout(False)
        Me.predesktopappmenu.PerformLayout()
        Me.pnlpanelbuttonsoptions.ResumeLayout(False)
        Me.pnlpanelbuttonsoptions.PerformLayout()
        Me.pnldesktoppaneloptions.ResumeLayout(False)
        Me.pnldesktoppaneloptions.PerformLayout()
        Me.pnldesktopintro.ResumeLayout(False)
        Me.pnldesktopintro.PerformLayout()
        Me.pnlpanelclockoptions.ResumeLayout(False)
        Me.pnlpanelclockoptions.PerformLayout()
        Me.pnldesktopbackgroundoptions.ResumeLayout(False)
        Me.pnldesktopbackgroundoptions.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.pnlwindowsoptions.ResumeLayout(False)
        Me.pnlbuttonoptions.ResumeLayout(False)
        Me.pnlbuttonoptions.PerformLayout()
        Me.pnlminimizebuttonoptions.ResumeLayout(False)
        Me.pnlminimizebuttonoptions.PerformLayout()
        Me.pnlrollupbuttonoptions.ResumeLayout(False)
        Me.pnlrollupbuttonoptions.PerformLayout()
        Me.pnlclosebuttonoptions.ResumeLayout(False)
        Me.pnlclosebuttonoptions.PerformLayout()
        Me.pnltitlebaroptions.ResumeLayout(False)
        Me.pnltitlebaroptions.PerformLayout()
        Me.pnlborderoptions.ResumeLayout(False)
        Me.pnlborderoptions.PerformLayout()
        Me.pnltitletextoptions.ResumeLayout(False)
        Me.pnltitletextoptions.PerformLayout()
        Me.pnlwindowsintro.ResumeLayout(False)
        Me.pnlwindowsintro.PerformLayout()
        Me.pnlwindowsobjects.ResumeLayout(False)
        Me.pnlwindowpreview.ResumeLayout(False)
        Me.prepgleft.ResumeLayout(False)
        Me.prepgright.ResumeLayout(False)
        Me.pretitlebar.ResumeLayout(False)
        Me.pretitlebar.PerformLayout()
        CType(Me.prepnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlreset.ResumeLayout(False)
        Me.pgcontents.ResumeLayout(False)
        Me.pgcontents.PerformLayout()
        Me.pnlshiftadvapplauncher.ResumeLayout(False)
        Me.pnlshiftadvapplauncher.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.nudusrsize, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnldeskdoubleplus.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.pnldppoptions.ResumeLayout(False)
        Me.pnldppicons.ResumeLayout(False)
        Me.pnldppicons.PerformLayout()
        Me.pnldppfunctions.ResumeLayout(False)
        Me.pnldppfunctions.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents clocktick As System.Windows.Forms.Timer
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents customizationtime As System.Windows.Forms.Timer
    Friend WithEvents timerearned As System.Windows.Forms.Timer
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnapply As System.Windows.Forms.Button
    Friend WithEvents catholder As System.Windows.Forms.Panel
    Friend WithEvents btnreset As System.Windows.Forms.Button
    Friend WithEvents btnprograms As System.Windows.Forms.Button
    Friend WithEvents btnicons As System.Windows.Forms.Button
    Friend WithEvents btnwindows As System.Windows.Forms.Button
    Friend WithEvents btndesktop As System.Windows.Forms.Button
    Friend WithEvents pnlshifterintro As System.Windows.Forms.Panel
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents pnldesktopoptions As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonsoptions As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttontextcolour As System.Windows.Forms.Panel
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttontexttop As System.Windows.Forms.TextBox
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttontextside As System.Windows.Forms.TextBox
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttontop As System.Windows.Forms.TextBox
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttoninitalgap As System.Windows.Forms.TextBox
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttonicontop As System.Windows.Forms.TextBox
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttoniconside As System.Windows.Forms.TextBox
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttoniconsize As System.Windows.Forms.TextBox
    Friend WithEvents txtpanelbuttoniconheight As System.Windows.Forms.TextBox
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents cbpanelbuttontextstyle As System.Windows.Forms.ComboBox
    Friend WithEvents cbpanelbuttonfont As System.Windows.Forms.ComboBox
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents txtpaneltextbuttonsize As System.Windows.Forms.TextBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttongap As System.Windows.Forms.TextBox
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttonheight As System.Windows.Forms.TextBox
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttonwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttoncolour As System.Windows.Forms.Panel
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents pnldesktoppaneloptions As System.Windows.Forms.Panel
    Friend WithEvents btnpanelbuttons As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents combodesktoppanelposition As System.Windows.Forms.ComboBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtdesktoppanelheight As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents pnldesktoppanelcolour As System.Windows.Forms.Panel
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents pnlapplauncheroptions As System.Windows.Forms.Panel
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents txtapplauncherwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents txtappbuttonlabel As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents pnlmaintextcolour As System.Windows.Forms.Panel
    Friend WithEvents comboappbuttontextstyle As System.Windows.Forms.ComboBox
    Friend WithEvents comboappbuttontextfont As System.Windows.Forms.ComboBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtappbuttontextsize As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents pnlmenuitemsmouseover As System.Windows.Forms.Panel
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents pnlmenuitemscolour As System.Windows.Forms.Panel
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents pnlmainbuttonactivated As System.Windows.Forms.Panel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtapplicationsbuttonheight As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents pnlmainbuttoncolour As System.Windows.Forms.Panel
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents pnldesktopintro As System.Windows.Forms.Panel
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents pnlpanelclockoptions As System.Windows.Forms.Panel
    Friend WithEvents pnlclockbackgroundcolour As System.Windows.Forms.Panel
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents comboclocktextstyle As System.Windows.Forms.ComboBox
    Friend WithEvents comboclocktextfont As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtclocktextfromtop As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtclocktextsize As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents pnlpanelclocktextcolour As System.Windows.Forms.Panel
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents pnldesktopbackgroundoptions As System.Windows.Forms.Panel
    Friend WithEvents pnldesktopcolour As System.Windows.Forms.Panel
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents btndesktopitself As System.Windows.Forms.Button
    Friend WithEvents btnpanelclock As System.Windows.Forms.Button
    Friend WithEvents btnapplauncher As System.Windows.Forms.Button
    Friend WithEvents btndesktoppanel As System.Windows.Forms.Button
    Friend WithEvents pnldesktoppreview As System.Windows.Forms.Panel
    Friend WithEvents predesktoppanel As System.Windows.Forms.Panel
    Friend WithEvents prepnlpanelbuttonholder As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents prepnlpanelbutton As System.Windows.Forms.Panel
    Friend WithEvents pretbicon As System.Windows.Forms.PictureBox
    Friend WithEvents pretbctext As System.Windows.Forms.Label
    Friend WithEvents pretimepanel As System.Windows.Forms.Panel
    Friend WithEvents prepaneltimetext As System.Windows.Forms.Label
    Friend WithEvents preapplaunchermenuholder As System.Windows.Forms.Panel
    Friend WithEvents predesktopappmenu As System.Windows.Forms.MenuStrip
    Friend WithEvents ApplicationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KnowledgeInputToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShiftoriumToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TerminalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShifterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ShutdownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlwindowsoptions As System.Windows.Forms.Panel
    Friend WithEvents pnlbuttonoptions As System.Windows.Forms.Panel
    Friend WithEvents pnlminimizebuttonoptions As System.Windows.Forms.Panel
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents pnlminimizebuttoncolour As System.Windows.Forms.Panel
    Friend WithEvents txtminimizebuttonside As System.Windows.Forms.TextBox
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents txtminimizebuttonheight As System.Windows.Forms.TextBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents txtminimizebuttontop As System.Windows.Forms.TextBox
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents txtminimizebuttonwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents pnlrollupbuttonoptions As System.Windows.Forms.Panel
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents pnlrollupbuttoncolour As System.Windows.Forms.Panel
    Friend WithEvents txtrollupbuttonside As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents txtrollupbuttonheight As System.Windows.Forms.TextBox
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents txtrollupbuttontop As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents txtrollupbuttonwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents combobuttonoption As System.Windows.Forms.ComboBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents pnlclosebuttonoptions As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents pnlclosebuttoncolour As System.Windows.Forms.Panel
    Friend WithEvents txtclosebuttonfromside As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtclosebuttonheight As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtclosebuttonfromtop As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtclosebuttonwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents pnltitlebaroptions As System.Windows.Forms.Panel
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents txticonfromtop As System.Windows.Forms.TextBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents txticonfromside As System.Windows.Forms.TextBox
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents lbcornerwidthpx As System.Windows.Forms.Label
    Friend WithEvents txttitlebarcornerwidth As System.Windows.Forms.TextBox
    Friend WithEvents lbcornerwidth As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarrightcornercolour As System.Windows.Forms.Panel
    Friend WithEvents pnltitlebarleftcornercolour As System.Windows.Forms.Panel
    Friend WithEvents lbrightcornercolor As System.Windows.Forms.Label
    Friend WithEvents lbleftcornercolor As System.Windows.Forms.Label
    Friend WithEvents cboxtitlebarcorners As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txttitlebarheight As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarcolour As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents pnlborderoptions As System.Windows.Forms.Panel
    Friend WithEvents cbindividualbordercolours As System.Windows.Forms.CheckBox
    Friend WithEvents pnlborderbottomrightcolour As System.Windows.Forms.Panel
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents pnlborderbottomcolour As System.Windows.Forms.Panel
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents pnlborderbottomleftcolour As System.Windows.Forms.Panel
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents pnlborderrightcolour As System.Windows.Forms.Panel
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents pnlborderleftcolour As System.Windows.Forms.Panel
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents pnlbordercolour As System.Windows.Forms.Panel
    Friend WithEvents txtbordersize As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents pnltitletextoptions As System.Windows.Forms.Panel
    Friend WithEvents combotitletextposition As System.Windows.Forms.ComboBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents combotitletextstyle As System.Windows.Forms.ComboBox
    Friend WithEvents combotitletextfont As System.Windows.Forms.ComboBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txttitletextside As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txttitletexttop As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txttitletextsize As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents pnltitletextcolour As System.Windows.Forms.Panel
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents pnlwindowsintro As System.Windows.Forms.Panel
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents pnlwindowsobjects As System.Windows.Forms.Panel
    Friend WithEvents btnborders As System.Windows.Forms.Button
    Friend WithEvents btnbuttons As System.Windows.Forms.Button
    Friend WithEvents btntitletext As System.Windows.Forms.Button
    Friend WithEvents btntitlebar As System.Windows.Forms.Button
    Friend WithEvents pnlwindowpreview As System.Windows.Forms.Panel
    Friend WithEvents prepgcontent As System.Windows.Forms.Panel
    Friend WithEvents prepgbottom As System.Windows.Forms.Panel
    Friend WithEvents prepgleft As System.Windows.Forms.Panel
    Friend WithEvents prepgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents prepgright As System.Windows.Forms.Panel
    Friend WithEvents prepgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents pretitlebar As System.Windows.Forms.Panel
    Friend WithEvents preminimizebutton As System.Windows.Forms.Panel
    Friend WithEvents prepnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents prerollupbutton As System.Windows.Forms.Panel
    Friend WithEvents preclosebutton As System.Windows.Forms.Panel
    Friend WithEvents pretitletext As System.Windows.Forms.Label
    Friend WithEvents prepgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents prepgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pnlreset As System.Windows.Forms.Panel
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents btnresetallsettings As System.Windows.Forms.Button
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents tmrfix As System.Windows.Forms.Timer
    Friend WithEvents tmrdelay As System.Windows.Forms.Timer
    Friend WithEvents pnllauncheritems As System.Windows.Forms.Panel
    Friend WithEvents txtlauncheritemtxtsize As System.Windows.Forms.TextBox
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents btnshowlauncheritems As System.Windows.Forms.Button
    Friend WithEvents launcheritemtxtcolour As System.Windows.Forms.Panel
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents launcheritemstyle As System.Windows.Forms.ComboBox
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents launcheritemfont As System.Windows.Forms.ComboBox
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents btndeskdoubleplus As System.Windows.Forms.Button
    Friend WithEvents pnldeskdoubleplus As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents desktopiconspreview As System.Windows.Forms.ListView
    Friend WithEvents pnldppoptions As System.Windows.Forms.Panel
    Friend WithEvents pnldppfunctions As System.Windows.Forms.Panel
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents btndppfunctions As System.Windows.Forms.Button
    Friend WithEvents btndppappearance As System.Windows.Forms.Button
    Friend WithEvents btndppfiles As System.Windows.Forms.Button
    Friend WithEvents btndppicons As System.Windows.Forms.Button
    Friend WithEvents pnldppicons As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents pnlshiftadvapplauncher As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnaalpwrpnlbg As System.Windows.Forms.Button
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents btnaalusrpnlbg As System.Windows.Forms.Button
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents btnaalshutdowntextcolor As System.Windows.Forms.Button
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents cmbaalusrstyle As System.Windows.Forms.ComboBox
    Friend WithEvents nudusrsize As System.Windows.Forms.NumericUpDown
    Friend WithEvents cmbaalusrfont As System.Windows.Forms.ComboBox
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents btnaalusrtextcolor As System.Windows.Forms.Button
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label118 As System.Windows.Forms.Label
End Class
