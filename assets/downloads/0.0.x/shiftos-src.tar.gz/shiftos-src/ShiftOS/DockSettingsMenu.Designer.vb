﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DockSettingsMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.pullbs = New System.Windows.Forms.Timer(Me.components)
        Me.pullbottom = New System.Windows.Forms.Timer(Me.components)
        Me.pullside = New System.Windows.Forms.Timer(Me.components)
        Me.tilecolor = New System.Windows.Forms.ColorDialog()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnQuitDock = New System.Windows.Forms.Button()
        Me.btnQuitSet = New System.Windows.Forms.Button()
        Me.btnSetBottom = New System.Windows.Forms.Button()
        Me.btnSetTop = New System.Windows.Forms.Button()
        Me.btnTake = New System.Windows.Forms.Button()
        Me.btnPlus = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.pnlPrograms = New System.Windows.Forms.Panel()
        Me.lblShiftNet = New System.Windows.Forms.Label()
        Me.lblIconManager = New System.Windows.Forms.Label()
        Me.lblWebBrowser = New System.Windows.Forms.Label()
        Me.lblVirusScanner = New System.Windows.Forms.Label()
        Me.lblVideoPlayer = New System.Windows.Forms.Label()
        Me.lblTextPad = New System.Windows.Forms.Label()
        Me.lblTerminal = New System.Windows.Forms.Label()
        Me.lblShiftorium = New System.Windows.Forms.Label()
        Me.lblShifter = New System.Windows.Forms.Label()
        Me.lblPong = New System.Windows.Forms.Label()
        Me.lblOrcWrite = New System.Windows.Forms.Label()
        Me.lblNameChanger = New System.Windows.Forms.Label()
        Me.lblLabyrinth = New System.Windows.Forms.Label()
        Me.lblKnowledgeInput = New System.Windows.Forms.Label()
        Me.lblInstaller = New System.Windows.Forms.Label()
        Me.lblSnakey = New System.Windows.Forms.Label()
        Me.lblFloodGateManager = New System.Windows.Forms.Label()
        Me.lblFileSkimmer = New System.Windows.Forms.Label()
        Me.lblDManager = New System.Windows.Forms.Label()
        Me.lblDownloader = New System.Windows.Forms.Label()
        Me.lblDodge = New System.Windows.Forms.Label()
        Me.lblClock = New System.Windows.Forms.Label()
        Me.lblCatlyst = New System.Windows.Forms.Label()
        Me.lblCalc = New System.Windows.Forms.Label()
        Me.lblBitNoteWallet = New System.Windows.Forms.Label()
        Me.lblBitNoteDigger = New System.Windows.Forms.Label()
        Me.lblAudioPlayer = New System.Windows.Forms.Label()
        Me.lblArtpad = New System.Windows.Forms.Label()
        Me.lblToTile = New System.Windows.Forms.Label()
        Me.Udate = New System.Windows.Forms.Timer(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pgleft.SuspendLayout()
        Me.pgright.SuspendLayout()
        Me.titlebar.SuspendLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlPrograms.SuspendLayout()
        Me.SuspendLayout()
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 679)
        Me.pgleft.TabIndex = 16
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 677)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(265, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 679)
        Me.pgright.TabIndex = 17
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 677)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(267, 30)
        Me.titlebar.TabIndex = 14
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(170, 5)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 24
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconTextPad
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(198, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(226, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Felix Titling", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(83, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Settings"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(265, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 707)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(263, 2)
        Me.pgbottom.TabIndex = 18
        '
        'pullbs
        '
        Me.pullbs.Interval = 1
        '
        'pullbottom
        '
        Me.pullbottom.Interval = 1
        '
        'pullside
        '
        Me.pullside.Interval = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 101)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 13)
        Me.Label3.TabIndex = 50
        Me.Label3.Text = "Choose Program CLICK"
        '
        'btnQuitDock
        '
        Me.btnQuitDock.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnQuitDock.Location = New System.Drawing.Point(16, 619)
        Me.btnQuitDock.Name = "btnQuitDock"
        Me.btnQuitDock.Size = New System.Drawing.Size(235, 75)
        Me.btnQuitDock.TabIndex = 49
        Me.btnQuitDock.Text = "Quit ShiftDock"
        Me.btnQuitDock.UseVisualStyleBackColor = True
        '
        'btnQuitSet
        '
        Me.btnQuitSet.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnQuitSet.Location = New System.Drawing.Point(16, 538)
        Me.btnQuitSet.Name = "btnQuitSet"
        Me.btnQuitSet.Size = New System.Drawing.Size(235, 75)
        Me.btnQuitSet.TabIndex = 48
        Me.btnQuitSet.Text = "Quit Settings"
        Me.btnQuitSet.UseVisualStyleBackColor = True
        '
        'btnSetBottom
        '
        Me.btnSetBottom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSetBottom.Location = New System.Drawing.Point(16, 444)
        Me.btnSetBottom.Name = "btnSetBottom"
        Me.btnSetBottom.Size = New System.Drawing.Size(235, 75)
        Me.btnSetBottom.TabIndex = 47
        Me.btnSetBottom.Text = "Set Dock To Bottom"
        Me.btnSetBottom.UseVisualStyleBackColor = True
        '
        'btnSetTop
        '
        Me.btnSetTop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSetTop.Location = New System.Drawing.Point(17, 282)
        Me.btnSetTop.Name = "btnSetTop"
        Me.btnSetTop.Size = New System.Drawing.Size(235, 75)
        Me.btnSetTop.TabIndex = 46
        Me.btnSetTop.Text = "Set Dock To Top"
        Me.btnSetTop.UseVisualStyleBackColor = True
        '
        'btnTake
        '
        Me.btnTake.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTake.Location = New System.Drawing.Point(16, 363)
        Me.btnTake.Name = "btnTake"
        Me.btnTake.Size = New System.Drawing.Size(235, 75)
        Me.btnTake.TabIndex = 45
        Me.btnTake.Text = "Top -5"
        Me.btnTake.UseVisualStyleBackColor = True
        '
        'btnPlus
        '
        Me.btnPlus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPlus.Location = New System.Drawing.Point(17, 201)
        Me.btnPlus.Name = "btnPlus"
        Me.btnPlus.Size = New System.Drawing.Size(235, 75)
        Me.btnPlus.TabIndex = 44
        Me.btnPlus.Text = "Top + 5"
        Me.btnPlus.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(13, 177)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(244, 18)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "Dock Location (Does not save)"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 18)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "Tiles"
        '
        'btnAdd
        '
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdd.Location = New System.Drawing.Point(17, 123)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(234, 51)
        Me.btnAdd.TabIndex = 41
        Me.btnAdd.Text = "Add a tile"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'pnlPrograms
        '
        Me.pnlPrograms.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.pnlPrograms.Controls.Add(Me.lblShiftNet)
        Me.pnlPrograms.Controls.Add(Me.lblIconManager)
        Me.pnlPrograms.Controls.Add(Me.lblWebBrowser)
        Me.pnlPrograms.Controls.Add(Me.lblVirusScanner)
        Me.pnlPrograms.Controls.Add(Me.lblVideoPlayer)
        Me.pnlPrograms.Controls.Add(Me.lblTextPad)
        Me.pnlPrograms.Controls.Add(Me.lblTerminal)
        Me.pnlPrograms.Controls.Add(Me.lblShiftorium)
        Me.pnlPrograms.Controls.Add(Me.lblShifter)
        Me.pnlPrograms.Controls.Add(Me.lblPong)
        Me.pnlPrograms.Controls.Add(Me.lblOrcWrite)
        Me.pnlPrograms.Controls.Add(Me.lblNameChanger)
        Me.pnlPrograms.Controls.Add(Me.lblLabyrinth)
        Me.pnlPrograms.Controls.Add(Me.lblKnowledgeInput)
        Me.pnlPrograms.Controls.Add(Me.lblInstaller)
        Me.pnlPrograms.Controls.Add(Me.lblSnakey)
        Me.pnlPrograms.Controls.Add(Me.lblFloodGateManager)
        Me.pnlPrograms.Controls.Add(Me.lblFileSkimmer)
        Me.pnlPrograms.Controls.Add(Me.lblDManager)
        Me.pnlPrograms.Controls.Add(Me.lblDownloader)
        Me.pnlPrograms.Controls.Add(Me.lblDodge)
        Me.pnlPrograms.Controls.Add(Me.lblClock)
        Me.pnlPrograms.Controls.Add(Me.lblCatlyst)
        Me.pnlPrograms.Controls.Add(Me.lblCalc)
        Me.pnlPrograms.Controls.Add(Me.lblBitNoteWallet)
        Me.pnlPrograms.Controls.Add(Me.lblBitNoteDigger)
        Me.pnlPrograms.Controls.Add(Me.lblAudioPlayer)
        Me.pnlPrograms.Controls.Add(Me.lblArtpad)
        Me.pnlPrograms.Location = New System.Drawing.Point(30, 117)
        Me.pnlPrograms.Name = "pnlPrograms"
        Me.pnlPrograms.Size = New System.Drawing.Size(172, 521)
        Me.pnlPrograms.TabIndex = 51
        Me.pnlPrograms.Visible = False
        '
        'lblShiftNet
        '
        Me.lblShiftNet.AutoSize = True
        Me.lblShiftNet.BackColor = System.Drawing.Color.Transparent
        Me.lblShiftNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShiftNet.Location = New System.Drawing.Point(6, 366)
        Me.lblShiftNet.Name = "lblShiftNet"
        Me.lblShiftNet.Size = New System.Drawing.Size(68, 18)
        Me.lblShiftNet.TabIndex = 80
        Me.lblShiftNet.Text = "ShiftNet"
        '
        'lblIconManager
        '
        Me.lblIconManager.AutoSize = True
        Me.lblIconManager.BackColor = System.Drawing.Color.Transparent
        Me.lblIconManager.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIconManager.Location = New System.Drawing.Point(6, 221)
        Me.lblIconManager.Name = "lblIconManager"
        Me.lblIconManager.Size = New System.Drawing.Size(110, 18)
        Me.lblIconManager.TabIndex = 79
        Me.lblIconManager.Text = "Icon Manager"
        '
        'lblWebBrowser
        '
        Me.lblWebBrowser.AutoSize = True
        Me.lblWebBrowser.BackColor = System.Drawing.Color.Transparent
        Me.lblWebBrowser.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWebBrowser.Location = New System.Drawing.Point(6, 492)
        Me.lblWebBrowser.Name = "lblWebBrowser"
        Me.lblWebBrowser.Size = New System.Drawing.Size(105, 18)
        Me.lblWebBrowser.TabIndex = 78
        Me.lblWebBrowser.Text = "WebBrowser"
        '
        'lblVirusScanner
        '
        Me.lblVirusScanner.AutoSize = True
        Me.lblVirusScanner.BackColor = System.Drawing.Color.Transparent
        Me.lblVirusScanner.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVirusScanner.Location = New System.Drawing.Point(6, 474)
        Me.lblVirusScanner.Name = "lblVirusScanner"
        Me.lblVirusScanner.Size = New System.Drawing.Size(108, 18)
        Me.lblVirusScanner.TabIndex = 77
        Me.lblVirusScanner.Text = "VirusScanner"
        '
        'lblVideoPlayer
        '
        Me.lblVideoPlayer.AutoSize = True
        Me.lblVideoPlayer.BackColor = System.Drawing.Color.Transparent
        Me.lblVideoPlayer.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVideoPlayer.Location = New System.Drawing.Point(6, 456)
        Me.lblVideoPlayer.Name = "lblVideoPlayer"
        Me.lblVideoPlayer.Size = New System.Drawing.Size(102, 18)
        Me.lblVideoPlayer.TabIndex = 76
        Me.lblVideoPlayer.Text = "Video Player"
        '
        'lblTextPad
        '
        Me.lblTextPad.AutoSize = True
        Me.lblTextPad.BackColor = System.Drawing.Color.Transparent
        Me.lblTextPad.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTextPad.Location = New System.Drawing.Point(6, 438)
        Me.lblTextPad.Name = "lblTextPad"
        Me.lblTextPad.Size = New System.Drawing.Size(69, 18)
        Me.lblTextPad.TabIndex = 75
        Me.lblTextPad.Text = "TextPad"
        '
        'lblTerminal
        '
        Me.lblTerminal.AutoSize = True
        Me.lblTerminal.BackColor = System.Drawing.Color.Transparent
        Me.lblTerminal.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTerminal.Location = New System.Drawing.Point(6, 420)
        Me.lblTerminal.Name = "lblTerminal"
        Me.lblTerminal.Size = New System.Drawing.Size(73, 18)
        Me.lblTerminal.TabIndex = 74
        Me.lblTerminal.Text = "Terminal"
        '
        'lblShiftorium
        '
        Me.lblShiftorium.AutoSize = True
        Me.lblShiftorium.BackColor = System.Drawing.Color.Transparent
        Me.lblShiftorium.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShiftorium.Location = New System.Drawing.Point(6, 384)
        Me.lblShiftorium.Name = "lblShiftorium"
        Me.lblShiftorium.Size = New System.Drawing.Size(85, 18)
        Me.lblShiftorium.TabIndex = 72
        Me.lblShiftorium.Text = "Shiftorium"
        '
        'lblShifter
        '
        Me.lblShifter.AutoSize = True
        Me.lblShifter.BackColor = System.Drawing.Color.Transparent
        Me.lblShifter.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShifter.Location = New System.Drawing.Point(5, 348)
        Me.lblShifter.Name = "lblShifter"
        Me.lblShifter.Size = New System.Drawing.Size(57, 18)
        Me.lblShifter.TabIndex = 71
        Me.lblShifter.Text = "Shifter"
        '
        'lblPong
        '
        Me.lblPong.AutoSize = True
        Me.lblPong.BackColor = System.Drawing.Color.Transparent
        Me.lblPong.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPong.Location = New System.Drawing.Point(6, 330)
        Me.lblPong.Name = "lblPong"
        Me.lblPong.Size = New System.Drawing.Size(47, 18)
        Me.lblPong.TabIndex = 70
        Me.lblPong.Text = "Pong"
        '
        'lblOrcWrite
        '
        Me.lblOrcWrite.AutoSize = True
        Me.lblOrcWrite.BackColor = System.Drawing.Color.Transparent
        Me.lblOrcWrite.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrcWrite.Location = New System.Drawing.Point(6, 312)
        Me.lblOrcWrite.Name = "lblOrcWrite"
        Me.lblOrcWrite.Size = New System.Drawing.Size(76, 18)
        Me.lblOrcWrite.TabIndex = 69
        Me.lblOrcWrite.Text = "OrcWrite"
        '
        'lblNameChanger
        '
        Me.lblNameChanger.AutoSize = True
        Me.lblNameChanger.BackColor = System.Drawing.Color.Transparent
        Me.lblNameChanger.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameChanger.Location = New System.Drawing.Point(5, 294)
        Me.lblNameChanger.Name = "lblNameChanger"
        Me.lblNameChanger.Size = New System.Drawing.Size(120, 18)
        Me.lblNameChanger.TabIndex = 68
        Me.lblNameChanger.Text = "Name Changer"
        '
        'lblLabyrinth
        '
        Me.lblLabyrinth.AutoSize = True
        Me.lblLabyrinth.BackColor = System.Drawing.Color.Transparent
        Me.lblLabyrinth.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLabyrinth.Location = New System.Drawing.Point(5, 276)
        Me.lblLabyrinth.Name = "lblLabyrinth"
        Me.lblLabyrinth.Size = New System.Drawing.Size(76, 18)
        Me.lblLabyrinth.TabIndex = 67
        Me.lblLabyrinth.Text = "Labyrinth"
        '
        'lblKnowledgeInput
        '
        Me.lblKnowledgeInput.AutoSize = True
        Me.lblKnowledgeInput.BackColor = System.Drawing.Color.Transparent
        Me.lblKnowledgeInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKnowledgeInput.Location = New System.Drawing.Point(5, 258)
        Me.lblKnowledgeInput.Name = "lblKnowledgeInput"
        Me.lblKnowledgeInput.Size = New System.Drawing.Size(131, 18)
        Me.lblKnowledgeInput.TabIndex = 66
        Me.lblKnowledgeInput.Text = "Knowledge Input"
        '
        'lblInstaller
        '
        Me.lblInstaller.AutoSize = True
        Me.lblInstaller.BackColor = System.Drawing.Color.Transparent
        Me.lblInstaller.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstaller.Location = New System.Drawing.Point(5, 240)
        Me.lblInstaller.Name = "lblInstaller"
        Me.lblInstaller.Size = New System.Drawing.Size(67, 18)
        Me.lblInstaller.TabIndex = 65
        Me.lblInstaller.Text = "Installer"
        '
        'lblSnakey
        '
        Me.lblSnakey.AutoSize = True
        Me.lblSnakey.BackColor = System.Drawing.Color.Transparent
        Me.lblSnakey.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSnakey.Location = New System.Drawing.Point(6, 402)
        Me.lblSnakey.Name = "lblSnakey"
        Me.lblSnakey.Size = New System.Drawing.Size(63, 18)
        Me.lblSnakey.TabIndex = 64
        Me.lblSnakey.Text = "Snakey"
        '
        'lblFloodGateManager
        '
        Me.lblFloodGateManager.AutoSize = True
        Me.lblFloodGateManager.BackColor = System.Drawing.Color.Transparent
        Me.lblFloodGateManager.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFloodGateManager.Location = New System.Drawing.Point(5, 203)
        Me.lblFloodGateManager.Name = "lblFloodGateManager"
        Me.lblFloodGateManager.Size = New System.Drawing.Size(157, 18)
        Me.lblFloodGateManager.TabIndex = 63
        Me.lblFloodGateManager.Text = "FloodGate Manager"
        '
        'lblFileSkimmer
        '
        Me.lblFileSkimmer.AutoSize = True
        Me.lblFileSkimmer.BackColor = System.Drawing.Color.Transparent
        Me.lblFileSkimmer.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFileSkimmer.Location = New System.Drawing.Point(5, 185)
        Me.lblFileSkimmer.Name = "lblFileSkimmer"
        Me.lblFileSkimmer.Size = New System.Drawing.Size(107, 18)
        Me.lblFileSkimmer.TabIndex = 62
        Me.lblFileSkimmer.Text = "File Skimmer"
        '
        'lblDManager
        '
        Me.lblDManager.AutoSize = True
        Me.lblDManager.BackColor = System.Drawing.Color.Transparent
        Me.lblDManager.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDManager.Location = New System.Drawing.Point(5, 167)
        Me.lblDManager.Name = "lblDManager"
        Me.lblDManager.Size = New System.Drawing.Size(148, 18)
        Me.lblDManager.TabIndex = 61
        Me.lblDManager.Text = "DownloadManager"
        '
        'lblDownloader
        '
        Me.lblDownloader.AutoSize = True
        Me.lblDownloader.BackColor = System.Drawing.Color.Transparent
        Me.lblDownloader.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDownloader.Location = New System.Drawing.Point(5, 149)
        Me.lblDownloader.Name = "lblDownloader"
        Me.lblDownloader.Size = New System.Drawing.Size(98, 18)
        Me.lblDownloader.TabIndex = 60
        Me.lblDownloader.Text = "Downloader"
        '
        'lblDodge
        '
        Me.lblDodge.AutoSize = True
        Me.lblDodge.BackColor = System.Drawing.Color.Transparent
        Me.lblDodge.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDodge.Location = New System.Drawing.Point(5, 131)
        Me.lblDodge.Name = "lblDodge"
        Me.lblDodge.Size = New System.Drawing.Size(57, 18)
        Me.lblDodge.TabIndex = 59
        Me.lblDodge.Text = "Dodge"
        '
        'lblClock
        '
        Me.lblClock.AutoSize = True
        Me.lblClock.BackColor = System.Drawing.Color.Transparent
        Me.lblClock.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClock.Location = New System.Drawing.Point(5, 113)
        Me.lblClock.Name = "lblClock"
        Me.lblClock.Size = New System.Drawing.Size(52, 18)
        Me.lblClock.TabIndex = 58
        Me.lblClock.Text = "Clock"
        '
        'lblCatlyst
        '
        Me.lblCatlyst.AutoSize = True
        Me.lblCatlyst.BackColor = System.Drawing.Color.Transparent
        Me.lblCatlyst.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCatlyst.Location = New System.Drawing.Point(5, 95)
        Me.lblCatlyst.Name = "lblCatlyst"
        Me.lblCatlyst.Size = New System.Drawing.Size(60, 18)
        Me.lblCatlyst.TabIndex = 57
        Me.lblCatlyst.Text = "Catlyst"
        '
        'lblCalc
        '
        Me.lblCalc.AutoSize = True
        Me.lblCalc.BackColor = System.Drawing.Color.Transparent
        Me.lblCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCalc.Location = New System.Drawing.Point(5, 77)
        Me.lblCalc.Name = "lblCalc"
        Me.lblCalc.Size = New System.Drawing.Size(85, 18)
        Me.lblCalc.TabIndex = 56
        Me.lblCalc.Text = "Calculator"
        '
        'lblBitNoteWallet
        '
        Me.lblBitNoteWallet.AutoSize = True
        Me.lblBitNoteWallet.BackColor = System.Drawing.Color.Transparent
        Me.lblBitNoteWallet.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBitNoteWallet.Location = New System.Drawing.Point(5, 60)
        Me.lblBitNoteWallet.Name = "lblBitNoteWallet"
        Me.lblBitNoteWallet.Size = New System.Drawing.Size(121, 18)
        Me.lblBitNoteWallet.TabIndex = 55
        Me.lblBitNoteWallet.Text = "Bit Note Wallet"
        '
        'lblBitNoteDigger
        '
        Me.lblBitNoteDigger.AutoSize = True
        Me.lblBitNoteDigger.BackColor = System.Drawing.Color.Transparent
        Me.lblBitNoteDigger.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBitNoteDigger.Location = New System.Drawing.Point(5, 42)
        Me.lblBitNoteDigger.Name = "lblBitNoteDigger"
        Me.lblBitNoteDigger.Size = New System.Drawing.Size(123, 18)
        Me.lblBitNoteDigger.TabIndex = 54
        Me.lblBitNoteDigger.Text = "Bit Note Digger"
        '
        'lblAudioPlayer
        '
        Me.lblAudioPlayer.AutoSize = True
        Me.lblAudioPlayer.BackColor = System.Drawing.Color.Transparent
        Me.lblAudioPlayer.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAudioPlayer.Location = New System.Drawing.Point(5, 24)
        Me.lblAudioPlayer.Name = "lblAudioPlayer"
        Me.lblAudioPlayer.Size = New System.Drawing.Size(102, 18)
        Me.lblAudioPlayer.TabIndex = 53
        Me.lblAudioPlayer.Text = "Audio Player"
        '
        'lblArtpad
        '
        Me.lblArtpad.AutoSize = True
        Me.lblArtpad.BackColor = System.Drawing.Color.Transparent
        Me.lblArtpad.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblArtpad.Location = New System.Drawing.Point(5, 6)
        Me.lblArtpad.Name = "lblArtpad"
        Me.lblArtpad.Size = New System.Drawing.Size(58, 18)
        Me.lblArtpad.TabIndex = 52
        Me.lblArtpad.Text = "ArtPad"
        '
        'lblToTile
        '
        Me.lblToTile.AutoSize = True
        Me.lblToTile.BackColor = System.Drawing.Color.Transparent
        Me.lblToTile.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToTile.Location = New System.Drawing.Point(138, 78)
        Me.lblToTile.Name = "lblToTile"
        Me.lblToTile.Size = New System.Drawing.Size(44, 18)
        Me.lblToTile.TabIndex = 52
        Me.lblToTile.Text = "Tiles"
        '
        'Udate
        '
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 78)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 18)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = "Make Tile For:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(51, 37)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(165, 18)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "NOT FINAL DESIGN!"
        '
        'DockSettingsMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(267, 709)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblToTile)
        Me.Controls.Add(Me.pnlPrograms)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnQuitDock)
        Me.Controls.Add(Me.btnQuitSet)
        Me.Controls.Add(Me.btnSetBottom)
        Me.Controls.Add(Me.btnSetTop)
        Me.Controls.Add(Me.btnTake)
        Me.Controls.Add(Me.btnPlus)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "DockSettingsMenu"
        Me.Text = "template"
        Me.TopMost = True
        Me.pgleft.ResumeLayout(False)
        Me.pgright.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlPrograms.ResumeLayout(False)
        Me.pnlPrograms.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents pullbs As System.Windows.Forms.Timer
    Friend WithEvents pullbottom As System.Windows.Forms.Timer
    Friend WithEvents pullside As System.Windows.Forms.Timer
    Friend WithEvents tilecolor As System.Windows.Forms.ColorDialog
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnQuitDock As System.Windows.Forms.Button
    Friend WithEvents btnQuitSet As System.Windows.Forms.Button
    Friend WithEvents btnSetBottom As System.Windows.Forms.Button
    Friend WithEvents btnSetTop As System.Windows.Forms.Button
    Friend WithEvents btnTake As System.Windows.Forms.Button
    Friend WithEvents btnPlus As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents pnlPrograms As System.Windows.Forms.Panel
    Friend WithEvents lblSnakey As System.Windows.Forms.Label
    Friend WithEvents lblFloodGateManager As System.Windows.Forms.Label
    Friend WithEvents lblFileSkimmer As System.Windows.Forms.Label
    Friend WithEvents lblDManager As System.Windows.Forms.Label
    Friend WithEvents lblDownloader As System.Windows.Forms.Label
    Friend WithEvents lblDodge As System.Windows.Forms.Label
    Friend WithEvents lblClock As System.Windows.Forms.Label
    Friend WithEvents lblCatlyst As System.Windows.Forms.Label
    Friend WithEvents lblCalc As System.Windows.Forms.Label
    Friend WithEvents lblBitNoteWallet As System.Windows.Forms.Label
    Friend WithEvents lblBitNoteDigger As System.Windows.Forms.Label
    Friend WithEvents lblAudioPlayer As System.Windows.Forms.Label
    Friend WithEvents lblArtpad As System.Windows.Forms.Label
    Friend WithEvents lblOrcWrite As System.Windows.Forms.Label
    Friend WithEvents lblNameChanger As System.Windows.Forms.Label
    Friend WithEvents lblLabyrinth As System.Windows.Forms.Label
    Friend WithEvents lblKnowledgeInput As System.Windows.Forms.Label
    Friend WithEvents lblInstaller As System.Windows.Forms.Label
    Friend WithEvents lblShiftorium As System.Windows.Forms.Label
    Friend WithEvents lblShifter As System.Windows.Forms.Label
    Friend WithEvents lblPong As System.Windows.Forms.Label
    Friend WithEvents lblIconManager As System.Windows.Forms.Label
    Friend WithEvents lblWebBrowser As System.Windows.Forms.Label
    Friend WithEvents lblVirusScanner As System.Windows.Forms.Label
    Friend WithEvents lblVideoPlayer As System.Windows.Forms.Label
    Friend WithEvents lblTextPad As System.Windows.Forms.Label
    Friend WithEvents lblTerminal As System.Windows.Forms.Label
    Friend WithEvents lblToTile As System.Windows.Forms.Label
    Friend WithEvents Udate As System.Windows.Forms.Timer
    Friend WithEvents lblShiftNet As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
End Class
