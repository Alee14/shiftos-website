﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Custom_Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlcontrols = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.pnlrunicon = New System.Windows.Forms.Panel()
        Me.txtrun = New System.Windows.Forms.TextBox()
        Me.flpcat = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.flpmain = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnlknowledgeinput = New System.Windows.Forms.Panel()
        Me.lblknowledgeinputname = New System.Windows.Forms.Label()
        Me.pnlknowledgeinputicon = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.pnlcontrols.SuspendLayout()
        Me.flpcat.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.flpmain.SuspendLayout()
        Me.pnlknowledgeinput.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlcontrols
        '
        Me.pnlcontrols.Controls.Add(Me.Panel2)
        Me.pnlcontrols.Controls.Add(Me.TextBox2)
        Me.pnlcontrols.Controls.Add(Me.Panel1)
        Me.pnlcontrols.Controls.Add(Me.TextBox1)
        Me.pnlcontrols.Controls.Add(Me.pnlrunicon)
        Me.pnlcontrols.Controls.Add(Me.txtrun)
        Me.pnlcontrols.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlcontrols.Location = New System.Drawing.Point(0, 619)
        Me.pnlcontrols.Name = "pnlcontrols"
        Me.pnlcontrols.Size = New System.Drawing.Size(417, 31)
        Me.pnlcontrols.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(290, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(16, 16)
        Me.Panel2.TabIndex = 5
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(311, 6)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.Text = "Command"
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(149, 9)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(16, 16)
        Me.Panel1.TabIndex = 3
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(169, 7)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.Text = "Search"
        '
        'pnlrunicon
        '
        Me.pnlrunicon.Location = New System.Drawing.Point(12, 8)
        Me.pnlrunicon.Name = "pnlrunicon"
        Me.pnlrunicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlrunicon.TabIndex = 1
        '
        'txtrun
        '
        Me.txtrun.Location = New System.Drawing.Point(33, 6)
        Me.txtrun.Name = "txtrun"
        Me.txtrun.Size = New System.Drawing.Size(100, 20)
        Me.txtrun.TabIndex = 0
        Me.txtrun.Text = "Run"
        '
        'flpcat
        '
        Me.flpcat.Controls.Add(Me.Panel3)
        Me.flpcat.Controls.Add(Me.Panel5)
        Me.flpcat.Controls.Add(Me.Panel7)
        Me.flpcat.Controls.Add(Me.Panel9)
        Me.flpcat.Controls.Add(Me.Panel17)
        Me.flpcat.Dock = System.Windows.Forms.DockStyle.Right
        Me.flpcat.Location = New System.Drawing.Point(209, 0)
        Me.flpcat.Name = "flpcat"
        Me.flpcat.Size = New System.Drawing.Size(208, 619)
        Me.flpcat.TabIndex = 3
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Location = New System.Drawing.Point(3, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(200, 67)
        Me.Panel3.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(65, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 50)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "GAMES"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel4.Location = New System.Drawing.Point(9, 9)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(50, 50)
        Me.Panel4.TabIndex = 0
        '
        'flpmain
        '
        Me.flpmain.Controls.Add(Me.pnlknowledgeinput)
        Me.flpmain.Controls.Add(Me.Panel11)
        Me.flpmain.Controls.Add(Me.Panel13)
        Me.flpmain.Controls.Add(Me.Panel15)
        Me.flpmain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.flpmain.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.flpmain.Location = New System.Drawing.Point(0, 0)
        Me.flpmain.Name = "flpmain"
        Me.flpmain.Size = New System.Drawing.Size(209, 619)
        Me.flpmain.TabIndex = 4
        '
        'pnlknowledgeinput
        '
        Me.pnlknowledgeinput.Controls.Add(Me.lblknowledgeinputname)
        Me.pnlknowledgeinput.Controls.Add(Me.pnlknowledgeinputicon)
        Me.pnlknowledgeinput.Location = New System.Drawing.Point(3, 3)
        Me.pnlknowledgeinput.Name = "pnlknowledgeinput"
        Me.pnlknowledgeinput.Size = New System.Drawing.Size(200, 67)
        Me.pnlknowledgeinput.TabIndex = 0
        '
        'lblknowledgeinputname
        '
        Me.lblknowledgeinputname.BackColor = System.Drawing.Color.Transparent
        Me.lblknowledgeinputname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblknowledgeinputname.Location = New System.Drawing.Point(65, 9)
        Me.lblknowledgeinputname.Name = "lblknowledgeinputname"
        Me.lblknowledgeinputname.Size = New System.Drawing.Size(132, 50)
        Me.lblknowledgeinputname.TabIndex = 1
        Me.lblknowledgeinputname.Text = "Games >"
        Me.lblknowledgeinputname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlknowledgeinputicon
        '
        Me.pnlknowledgeinputicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlknowledgeinputicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlknowledgeinputicon.Location = New System.Drawing.Point(9, 9)
        Me.pnlknowledgeinputicon.Name = "pnlknowledgeinputicon"
        Me.pnlknowledgeinputicon.Size = New System.Drawing.Size(50, 50)
        Me.pnlknowledgeinputicon.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Location = New System.Drawing.Point(3, 76)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(200, 67)
        Me.Panel5.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(65, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 50)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Pong"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel6.Location = New System.Drawing.Point(9, 9)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(50, 50)
        Me.Panel6.TabIndex = 0
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.Label3)
        Me.Panel7.Controls.Add(Me.Panel8)
        Me.Panel7.Location = New System.Drawing.Point(3, 149)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(200, 67)
        Me.Panel7.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(65, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 50)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Dodge"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel8
        '
        Me.Panel8.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel8.Location = New System.Drawing.Point(9, 9)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(50, 50)
        Me.Panel8.TabIndex = 0
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.Label4)
        Me.Panel9.Controls.Add(Me.Panel10)
        Me.Panel9.Location = New System.Drawing.Point(3, 222)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(200, 67)
        Me.Panel9.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(65, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 50)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Labyrinth"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel10
        '
        Me.Panel10.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel10.Location = New System.Drawing.Point(9, 9)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(50, 50)
        Me.Panel10.TabIndex = 0
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.Label5)
        Me.Panel11.Controls.Add(Me.Panel12)
        Me.Panel11.Location = New System.Drawing.Point(3, 76)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(200, 67)
        Me.Panel11.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(65, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(132, 50)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Customization >"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel12
        '
        Me.Panel12.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel12.Location = New System.Drawing.Point(9, 9)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(50, 50)
        Me.Panel12.TabIndex = 0
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Label6)
        Me.Panel13.Controls.Add(Me.Panel14)
        Me.Panel13.Location = New System.Drawing.Point(3, 149)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(200, 67)
        Me.Panel13.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(65, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(132, 50)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Interwebz >"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel14
        '
        Me.Panel14.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel14.Location = New System.Drawing.Point(9, 9)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(50, 50)
        Me.Panel14.TabIndex = 0
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.Label7)
        Me.Panel15.Controls.Add(Me.Panel16)
        Me.Panel15.Location = New System.Drawing.Point(3, 222)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(200, 67)
        Me.Panel15.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(65, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(132, 50)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Office >"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel16
        '
        Me.Panel16.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel16.Location = New System.Drawing.Point(9, 9)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(50, 50)
        Me.Panel16.TabIndex = 0
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.Label8)
        Me.Panel17.Controls.Add(Me.Panel18)
        Me.Panel17.Location = New System.Drawing.Point(3, 295)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(200, 67)
        Me.Panel17.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(65, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(132, 50)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Knowledge Input"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel18
        '
        Me.Panel18.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.Panel18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel18.Location = New System.Drawing.Point(9, 9)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(50, 50)
        Me.Panel18.TabIndex = 0
        '
        'Custom_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(417, 650)
        Me.Controls.Add(Me.flpmain)
        Me.Controls.Add(Me.flpcat)
        Me.Controls.Add(Me.pnlcontrols)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Custom_Menu"
        Me.Text = "Custom_Menu"
        Me.TopMost = True
        Me.pnlcontrols.ResumeLayout(False)
        Me.pnlcontrols.PerformLayout()
        Me.flpcat.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.flpmain.ResumeLayout(False)
        Me.pnlknowledgeinput.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlcontrols As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents pnlrunicon As System.Windows.Forms.Panel
    Friend WithEvents txtrun As System.Windows.Forms.TextBox
    Friend WithEvents flpcat As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents flpmain As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents pnlknowledgeinput As System.Windows.Forms.Panel
    Friend WithEvents lblknowledgeinputname As System.Windows.Forms.Label
    Friend WithEvents pnlknowledgeinputicon As System.Windows.Forms.Panel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
End Class
