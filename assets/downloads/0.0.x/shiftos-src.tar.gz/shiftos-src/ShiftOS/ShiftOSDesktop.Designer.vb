﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ShiftOSDesktop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.desktoppanel = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonholder = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnlpanelbuttonclock = New System.Windows.Forms.Panel()
        Me.tbclockicon = New System.Windows.Forms.PictureBox()
        Me.tbclocktext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonsysinfo = New System.Windows.Forms.Panel()
        Me.tbsysinfoicon = New System.Windows.Forms.PictureBox()
        Me.tbsysinfotext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonskinloader = New System.Windows.Forms.Panel()
        Me.tbskinloadericon = New System.Windows.Forms.PictureBox()
        Me.tbskinloadertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonfileskimmer = New System.Windows.Forms.Panel()
        Me.tbfileskimmericon = New System.Windows.Forms.PictureBox()
        Me.tbfileskimmertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonfileopener = New System.Windows.Forms.Panel()
        Me.tbfileopenericon = New System.Windows.Forms.PictureBox()
        Me.tbfileopenertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttoninfobox = New System.Windows.Forms.Panel()
        Me.tbinfoboxicon = New System.Windows.Forms.PictureBox()
        Me.tbinfoboxtext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonknowledgeinput = New System.Windows.Forms.Panel()
        Me.tbknowledgeinputicon = New System.Windows.Forms.PictureBox()
        Me.tbknowledgeinputtext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttoncolourpicker = New System.Windows.Forms.Panel()
        Me.tbcolourpickericon = New System.Windows.Forms.PictureBox()
        Me.tbcolourpickertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonshiftorium = New System.Windows.Forms.Panel()
        Me.tbshiftoriumicon = New System.Windows.Forms.PictureBox()
        Me.tbshiftoriumtext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonpong = New System.Windows.Forms.Panel()
        Me.tbpongicon = New System.Windows.Forms.PictureBox()
        Me.tbpongtext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonterminal = New System.Windows.Forms.Panel()
        Me.tbterminalicon = New System.Windows.Forms.PictureBox()
        Me.tbterminaltext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttontextpad = New System.Windows.Forms.Panel()
        Me.tbtextpadicon = New System.Windows.Forms.PictureBox()
        Me.tbtextpadtext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttongraphicpicker = New System.Windows.Forms.Panel()
        Me.tbgraphicpickericon = New System.Windows.Forms.PictureBox()
        Me.tbgraphicpickertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonartpad = New System.Windows.Forms.Panel()
        Me.tbartpadicon = New System.Windows.Forms.PictureBox()
        Me.tbartpadtext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttoncalculator = New System.Windows.Forms.Panel()
        Me.tbcalculatoricon = New System.Windows.Forms.PictureBox()
        Me.tbcalculatortext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonaudioplayer = New System.Windows.Forms.Panel()
        Me.tbaudioplayericon = New System.Windows.Forms.PictureBox()
        Me.tbaudioplayertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonvideoplayer = New System.Windows.Forms.Panel()
        Me.tbvideoplayericon = New System.Windows.Forms.PictureBox()
        Me.tbvideoplayertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonwebbrowser = New System.Windows.Forms.Panel()
        Me.tbwebbrowsericon = New System.Windows.Forms.PictureBox()
        Me.tbwebbrowsertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonnamechanger = New System.Windows.Forms.Panel()
        Me.tbnamechangericon = New System.Windows.Forms.PictureBox()
        Me.tbnamechangertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttoniconmanager = New System.Windows.Forms.Panel()
        Me.tbiconmanagericon = New System.Windows.Forms.PictureBox()
        Me.tbiconmanagertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonbitnotewallet = New System.Windows.Forms.Panel()
        Me.tbbitnotewalleticon = New System.Windows.Forms.PictureBox()
        Me.tbbitnotewallettext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonbitnotedigger = New System.Windows.Forms.Panel()
        Me.tbbitnotediggericon = New System.Windows.Forms.PictureBox()
        Me.tbbitnotediggertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonskinshifter = New System.Windows.Forms.Panel()
        Me.tbskinshiftericon = New System.Windows.Forms.PictureBox()
        Me.tbskinshiftertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttondownloader = New System.Windows.Forms.Panel()
        Me.tbdownloadericon = New System.Windows.Forms.PictureBox()
        Me.tbdownloadertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonshiftnet = New System.Windows.Forms.Panel()
        Me.tbshiftneticon = New System.Windows.Forms.PictureBox()
        Me.tbshiftnettext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttondodge = New System.Windows.Forms.Panel()
        Me.tbdodgeicon = New System.Windows.Forms.PictureBox()
        Me.tbdodgetext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttondownloadmanager = New System.Windows.Forms.Panel()
        Me.tbdownloadmanagericon = New System.Windows.Forms.PictureBox()
        Me.tbdownloadmanagertext = New System.Windows.Forms.Label()
        Me.pnlcatalystpanelbutton = New System.Windows.Forms.Panel()
        Me.tbcatalysticon = New System.Windows.Forms.PictureBox()
        Me.lbcatalystname = New System.Windows.Forms.Label()
        Me.pnlpanelbuttoninstaller = New System.Windows.Forms.Panel()
        Me.tbinstallericon = New System.Windows.Forms.PictureBox()
        Me.tbinstallertext = New System.Windows.Forms.Label()
        Me.pnl_panelbuttonsnakey = New System.Windows.Forms.Panel()
        Me.tbsnakeyicon = New System.Windows.Forms.PictureBox()
        Me.tbsnakeytext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonorcwrite = New System.Windows.Forms.Panel()
        Me.tborcwriteicon = New System.Windows.Forms.PictureBox()
        Me.tborcwritetext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonsnakey = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonfloodgate = New System.Windows.Forms.Panel()
        Me.tbfloodgateicon = New System.Windows.Forms.PictureBox()
        Me.tbfloodgatetext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonmaze = New System.Windows.Forms.Panel()
        Me.tbmazeicon = New System.Windows.Forms.PictureBox()
        Me.tbmazetext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonvirusscanner = New System.Windows.Forms.Panel()
        Me.tbvirusscannericon = New System.Windows.Forms.PictureBox()
        Me.tbvirusscannertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonfilesaver = New System.Windows.Forms.Panel()
        Me.tbfilesavericon = New System.Windows.Forms.PictureBox()
        Me.tbfilesavertext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonshifter = New System.Windows.Forms.Panel()
        Me.tbshiftericon = New System.Windows.Forms.PictureBox()
        Me.tbshiftertext = New System.Windows.Forms.Label()
        Me.applaunchermenuholder = New System.Windows.Forms.Panel()
        Me.desktopappmenu = New System.Windows.Forms.MenuStrip()
        Me.ApplicationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArtpadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AudioplayerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitnoteDiggerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitnoteWalletToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DodgeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.downloadmanagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileSkimmerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FloodGateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IconManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InstallerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KnowledgeInputToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MazeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NameChangerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.orcwriteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PongToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShifterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CatalystToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShiftnetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShiftoriumToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkinLoaderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkinShifterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SnakeyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.sysinfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextPadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebBrowserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VideoplayerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VirusScannerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.unitySeperator = New System.Windows.Forms.ToolStripSeparator()
        Me.UnityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.timepanel = New System.Windows.Forms.Panel()
        Me.paneltimetext = New System.Windows.Forms.Label()
        Me.pnlpanelbuttonfloatybird = New System.Windows.Forms.Panel()
        Me.tbfloatybirdicon = New System.Windows.Forms.PictureBox()
        Me.tbfloatybirdtext = New System.Windows.Forms.Label()
        Me.floatybirdToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.clocktick = New System.Windows.Forms.Timer(Me.components)
        Me.autosave = New System.Windows.Forms.Timer(Me.components)
        Me.nocheat = New System.Windows.Forms.Timer(Me.components)
        Me.tmrwindowedtest = New System.Windows.Forms.Timer(Me.components)
        Me.desktopicons = New System.Windows.Forms.ListView()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ArtpadPictureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextDocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrcWriteDocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemInformationReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewSkin = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebpageToolStripMenuItem = New System.Windows.Forms.ToolStripSeparator()
        Me.ShortcutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.TileViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RenameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.fileActionsSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnladvapplauncher = New System.Windows.Forms.Panel()
        Me.pnladvmain = New System.Windows.Forms.Panel()
        Me.tscadvmainframe = New System.Windows.Forms.ToolStripContainer()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.allPrograms = New System.Windows.Forms.ToolStripDropDownButton()
        Me.UtilitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminalToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileSkimmerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShifterToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkinLoaderToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SkinShifterToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IconManagerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NameChangerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InternetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShiftnetToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShiftoriumToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebBrowserToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DownloadManagerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InstallerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitnoteDiggerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitnoteWalletToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FloodGateManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VirusScannerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CatalystToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GamesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DodgeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SnakeyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PongToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.KnowledgeInputToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LabyrinthToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccessoriesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArtpadToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextpadToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrcWriteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AudioPlayerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VideoPlayerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClockToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.lvadvfiles = New System.Windows.Forms.ListView()
        Me.pnladvplaces = New System.Windows.Forms.Panel()
        Me.lvadvplaces = New System.Windows.Forms.ListView()
        Me.pnladvbottombar = New System.Windows.Forms.Panel()
        Me.btnadvshutdown = New System.Windows.Forms.Button()
        Me.pnladvtopbar = New System.Windows.Forms.Panel()
        Me.lbuser = New System.Windows.Forms.Label()
        Me.desktoppanel.SuspendLayout()
        Me.pnlpanelbuttonholder.SuspendLayout()
        Me.pnlpanelbuttonclock.SuspendLayout()
        CType(Me.tbclockicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonsysinfo.SuspendLayout()
        CType(Me.tbsysinfoicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonskinloader.SuspendLayout()
        CType(Me.tbskinloadericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonfileskimmer.SuspendLayout()
        CType(Me.tbfileskimmericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonfileopener.SuspendLayout()
        CType(Me.tbfileopenericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttoninfobox.SuspendLayout()
        CType(Me.tbinfoboxicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonknowledgeinput.SuspendLayout()
        CType(Me.tbknowledgeinputicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttoncolourpicker.SuspendLayout()
        CType(Me.tbcolourpickericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonshiftorium.SuspendLayout()
        CType(Me.tbshiftoriumicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonpong.SuspendLayout()
        CType(Me.tbpongicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonterminal.SuspendLayout()
        CType(Me.tbterminalicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttontextpad.SuspendLayout()
        CType(Me.tbtextpadicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttongraphicpicker.SuspendLayout()
        CType(Me.tbgraphicpickericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonartpad.SuspendLayout()
        CType(Me.tbartpadicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttoncalculator.SuspendLayout()
        CType(Me.tbcalculatoricon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonaudioplayer.SuspendLayout()
        CType(Me.tbaudioplayericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonvideoplayer.SuspendLayout()
        CType(Me.tbvideoplayericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonwebbrowser.SuspendLayout()
        CType(Me.tbwebbrowsericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonnamechanger.SuspendLayout()
        CType(Me.tbnamechangericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttoniconmanager.SuspendLayout()
        CType(Me.tbiconmanagericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonbitnotewallet.SuspendLayout()
        CType(Me.tbbitnotewalleticon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonbitnotedigger.SuspendLayout()
        CType(Me.tbbitnotediggericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonskinshifter.SuspendLayout()
        CType(Me.tbskinshiftericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttondownloader.SuspendLayout()
        CType(Me.tbdownloadericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonshiftnet.SuspendLayout()
        CType(Me.tbshiftneticon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttondodge.SuspendLayout()
        CType(Me.tbdodgeicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttondownloadmanager.SuspendLayout()
        CType(Me.tbdownloadmanagericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlcatalystpanelbutton.SuspendLayout()
        CType(Me.tbcatalysticon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttoninstaller.SuspendLayout()
        CType(Me.tbinstallericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_panelbuttonsnakey.SuspendLayout()
        CType(Me.tbsnakeyicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonorcwrite.SuspendLayout()
        CType(Me.tborcwriteicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonfloodgate.SuspendLayout()
        CType(Me.tbfloodgateicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonmaze.SuspendLayout()
        CType(Me.tbmazeicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonvirusscanner.SuspendLayout()
        CType(Me.tbvirusscannericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonfilesaver.SuspendLayout()
        CType(Me.tbfilesavericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlpanelbuttonshifter.SuspendLayout()
        CType(Me.tbshiftericon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.applaunchermenuholder.SuspendLayout()
        Me.desktopappmenu.SuspendLayout()
        Me.timepanel.SuspendLayout()
        Me.pnlpanelbuttonfloatybird.SuspendLayout()
        CType(Me.tbfloatybirdicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.pnladvapplauncher.SuspendLayout()
        Me.pnladvmain.SuspendLayout()
        Me.tscadvmainframe.BottomToolStripPanel.SuspendLayout()
        Me.tscadvmainframe.ContentPanel.SuspendLayout()
        Me.tscadvmainframe.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.pnladvplaces.SuspendLayout()
        Me.pnladvbottombar.SuspendLayout()
        Me.pnladvtopbar.SuspendLayout()
        Me.SuspendLayout()
        '
        'desktoppanel
        '
        Me.desktoppanel.BackColor = System.Drawing.Color.Gray
        Me.desktoppanel.Controls.Add(Me.pnlpanelbuttonholder)
        Me.desktoppanel.Controls.Add(Me.applaunchermenuholder)
        Me.desktoppanel.Controls.Add(Me.timepanel)
        Me.desktoppanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.desktoppanel.Location = New System.Drawing.Point(0, 0)
        Me.desktoppanel.Name = "desktoppanel"
        Me.desktoppanel.Size = New System.Drawing.Size(1268, 24)
        Me.desktoppanel.TabIndex = 0
        Me.desktoppanel.Visible = False
        '
        'pnlpanelbuttonholder
        '
        Me.pnlpanelbuttonholder.BackColor = System.Drawing.Color.Transparent
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonclock)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonsysinfo)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonskinloader)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonfileskimmer)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonfileopener)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttoninfobox)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonknowledgeinput)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttoncolourpicker)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonshiftorium)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonpong)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonterminal)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttontextpad)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttongraphicpicker)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonartpad)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttoncalculator)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonaudioplayer)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonvideoplayer)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonwebbrowser)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonnamechanger)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttoniconmanager)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonbitnotewallet)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonbitnotedigger)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonskinshifter)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttondownloader)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonshiftnet)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttondodge)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttondownloadmanager)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlcatalystpanelbutton)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttoninstaller)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnl_panelbuttonsnakey)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonorcwrite)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonsnakey)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonfloodgate)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonmaze)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonvirusscanner)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonfilesaver)
        Me.pnlpanelbuttonholder.Controls.Add(Me.pnlpanelbuttonshifter)
        Me.pnlpanelbuttonholder.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlpanelbuttonholder.Location = New System.Drawing.Point(130, 0)
        Me.pnlpanelbuttonholder.Name = "pnlpanelbuttonholder"
        Me.pnlpanelbuttonholder.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.pnlpanelbuttonholder.Size = New System.Drawing.Size(1041, 24)
        Me.pnlpanelbuttonholder.TabIndex = 1
        '
        'pnlpanelbuttonclock
        '
        Me.pnlpanelbuttonclock.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonclock.Controls.Add(Me.tbclockicon)
        Me.pnlpanelbuttonclock.Controls.Add(Me.tbclocktext)
        Me.pnlpanelbuttonclock.Location = New System.Drawing.Point(5, 3)
        Me.pnlpanelbuttonclock.Name = "pnlpanelbuttonclock"
        Me.pnlpanelbuttonclock.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonclock.TabIndex = 5
        Me.pnlpanelbuttonclock.Visible = False
        '
        'tbclockicon
        '
        Me.tbclockicon.BackColor = System.Drawing.Color.Transparent
        Me.tbclockicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbclockicon.Image = Global.ShiftOS.My.Resources.Resources.iconClock
        Me.tbclockicon.Location = New System.Drawing.Point(4, 2)
        Me.tbclockicon.Name = "tbclockicon"
        Me.tbclockicon.Size = New System.Drawing.Size(16, 16)
        Me.tbclockicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbclockicon.TabIndex = 1
        Me.tbclockicon.TabStop = False
        '
        'tbclocktext
        '
        Me.tbclocktext.AutoSize = True
        Me.tbclocktext.BackColor = System.Drawing.Color.Transparent
        Me.tbclocktext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbclocktext.ForeColor = System.Drawing.Color.White
        Me.tbclocktext.Location = New System.Drawing.Point(24, 2)
        Me.tbclocktext.Name = "tbclocktext"
        Me.tbclocktext.Size = New System.Drawing.Size(42, 16)
        Me.tbclocktext.TabIndex = 0
        Me.tbclocktext.Text = "Clock"
        '
        'pnlpanelbuttonsysinfo
        '
        Me.pnlpanelbuttonsysinfo.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonsysinfo.Controls.Add(Me.tbsysinfoicon)
        Me.pnlpanelbuttonsysinfo.Controls.Add(Me.tbsysinfotext)
        Me.pnlpanelbuttonsysinfo.Location = New System.Drawing.Point(21, 3)
        Me.pnlpanelbuttonsysinfo.Name = "pnlpanelbuttonsysinfo"
        Me.pnlpanelbuttonsysinfo.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonsysinfo.TabIndex = 27
        Me.pnlpanelbuttonsysinfo.Visible = False
        '
        'tbsysinfoicon
        '
        Me.tbsysinfoicon.BackColor = System.Drawing.Color.Transparent
        Me.tbsysinfoicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbsysinfoicon.Image = Global.ShiftOS.My.Resources.Resources.floodgateicn
        Me.tbsysinfoicon.Location = New System.Drawing.Point(4, 2)
        Me.tbsysinfoicon.Name = "tbsysinfoicon"
        Me.tbsysinfoicon.Size = New System.Drawing.Size(16, 16)
        Me.tbsysinfoicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbsysinfoicon.TabIndex = 1
        Me.tbsysinfoicon.TabStop = False
        '
        'tbsysinfotext
        '
        Me.tbsysinfotext.AutoSize = True
        Me.tbsysinfotext.BackColor = System.Drawing.Color.Transparent
        Me.tbsysinfotext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbsysinfotext.ForeColor = System.Drawing.Color.White
        Me.tbsysinfotext.Location = New System.Drawing.Point(20, 0)
        Me.tbsysinfotext.Name = "tbsysinfotext"
        Me.tbsysinfotext.Size = New System.Drawing.Size(126, 16)
        Me.tbsysinfotext.TabIndex = 0
        Me.tbsysinfotext.Text = "Download Manager"
        '
        'pnlpanelbuttonskinloader
        '
        Me.pnlpanelbuttonskinloader.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonskinloader.Controls.Add(Me.tbskinloadericon)
        Me.pnlpanelbuttonskinloader.Controls.Add(Me.tbskinloadertext)
        Me.pnlpanelbuttonskinloader.Location = New System.Drawing.Point(37, 3)
        Me.pnlpanelbuttonskinloader.Name = "pnlpanelbuttonskinloader"
        Me.pnlpanelbuttonskinloader.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonskinloader.TabIndex = 7
        Me.pnlpanelbuttonskinloader.Visible = False
        '
        'tbskinloadericon
        '
        Me.tbskinloadericon.BackColor = System.Drawing.Color.Transparent
        Me.tbskinloadericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbskinloadericon.Image = Global.ShiftOS.My.Resources.Resources.iconSkinLoader
        Me.tbskinloadericon.Location = New System.Drawing.Point(4, 2)
        Me.tbskinloadericon.Name = "tbskinloadericon"
        Me.tbskinloadericon.Size = New System.Drawing.Size(16, 16)
        Me.tbskinloadericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbskinloadericon.TabIndex = 1
        Me.tbskinloadericon.TabStop = False
        '
        'tbskinloadertext
        '
        Me.tbskinloadertext.AutoSize = True
        Me.tbskinloadertext.BackColor = System.Drawing.Color.Transparent
        Me.tbskinloadertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbskinloadertext.ForeColor = System.Drawing.Color.White
        Me.tbskinloadertext.Location = New System.Drawing.Point(24, 2)
        Me.tbskinloadertext.Name = "tbskinloadertext"
        Me.tbskinloadertext.Size = New System.Drawing.Size(80, 16)
        Me.tbskinloadertext.TabIndex = 0
        Me.tbskinloadertext.Text = "Skin Loader"
        '
        'pnlpanelbuttonfileskimmer
        '
        Me.pnlpanelbuttonfileskimmer.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonfileskimmer.Controls.Add(Me.tbfileskimmericon)
        Me.pnlpanelbuttonfileskimmer.Controls.Add(Me.tbfileskimmertext)
        Me.pnlpanelbuttonfileskimmer.Location = New System.Drawing.Point(53, 3)
        Me.pnlpanelbuttonfileskimmer.Name = "pnlpanelbuttonfileskimmer"
        Me.pnlpanelbuttonfileskimmer.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonfileskimmer.TabIndex = 6
        Me.pnlpanelbuttonfileskimmer.Visible = False
        '
        'tbfileskimmericon
        '
        Me.tbfileskimmericon.BackColor = System.Drawing.Color.Transparent
        Me.tbfileskimmericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbfileskimmericon.Image = Global.ShiftOS.My.Resources.Resources.iconFileSkimmer
        Me.tbfileskimmericon.Location = New System.Drawing.Point(4, 2)
        Me.tbfileskimmericon.Name = "tbfileskimmericon"
        Me.tbfileskimmericon.Size = New System.Drawing.Size(16, 16)
        Me.tbfileskimmericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbfileskimmericon.TabIndex = 1
        Me.tbfileskimmericon.TabStop = False
        '
        'tbfileskimmertext
        '
        Me.tbfileskimmertext.AutoSize = True
        Me.tbfileskimmertext.BackColor = System.Drawing.Color.Transparent
        Me.tbfileskimmertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbfileskimmertext.ForeColor = System.Drawing.Color.White
        Me.tbfileskimmertext.Location = New System.Drawing.Point(24, 2)
        Me.tbfileskimmertext.Name = "tbfileskimmertext"
        Me.tbfileskimmertext.Size = New System.Drawing.Size(86, 16)
        Me.tbfileskimmertext.TabIndex = 0
        Me.tbfileskimmertext.Text = "File Skimmer"
        '
        'pnlpanelbuttonfileopener
        '
        Me.pnlpanelbuttonfileopener.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonfileopener.Controls.Add(Me.tbfileopenericon)
        Me.pnlpanelbuttonfileopener.Controls.Add(Me.tbfileopenertext)
        Me.pnlpanelbuttonfileopener.Location = New System.Drawing.Point(69, 3)
        Me.pnlpanelbuttonfileopener.Name = "pnlpanelbuttonfileopener"
        Me.pnlpanelbuttonfileopener.Size = New System.Drawing.Size(12, 20)
        Me.pnlpanelbuttonfileopener.TabIndex = 6
        Me.pnlpanelbuttonfileopener.Visible = False
        '
        'tbfileopenericon
        '
        Me.tbfileopenericon.BackColor = System.Drawing.Color.Transparent
        Me.tbfileopenericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbfileopenericon.Image = Global.ShiftOS.My.Resources.Resources.iconFileOpener
        Me.tbfileopenericon.Location = New System.Drawing.Point(4, 2)
        Me.tbfileopenericon.Name = "tbfileopenericon"
        Me.tbfileopenericon.Size = New System.Drawing.Size(16, 16)
        Me.tbfileopenericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbfileopenericon.TabIndex = 1
        Me.tbfileopenericon.TabStop = False
        '
        'tbfileopenertext
        '
        Me.tbfileopenertext.AutoSize = True
        Me.tbfileopenertext.BackColor = System.Drawing.Color.Transparent
        Me.tbfileopenertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbfileopenertext.ForeColor = System.Drawing.Color.White
        Me.tbfileopenertext.Location = New System.Drawing.Point(24, 2)
        Me.tbfileopenertext.Name = "tbfileopenertext"
        Me.tbfileopenertext.Size = New System.Drawing.Size(78, 16)
        Me.tbfileopenertext.TabIndex = 0
        Me.tbfileopenertext.Text = "File Opener"
        '
        'pnlpanelbuttoninfobox
        '
        Me.pnlpanelbuttoninfobox.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttoninfobox.Controls.Add(Me.tbinfoboxicon)
        Me.pnlpanelbuttoninfobox.Controls.Add(Me.tbinfoboxtext)
        Me.pnlpanelbuttoninfobox.Location = New System.Drawing.Point(87, 3)
        Me.pnlpanelbuttoninfobox.Name = "pnlpanelbuttoninfobox"
        Me.pnlpanelbuttoninfobox.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttoninfobox.TabIndex = 6
        Me.pnlpanelbuttoninfobox.Visible = False
        '
        'tbinfoboxicon
        '
        Me.tbinfoboxicon.BackColor = System.Drawing.Color.Transparent
        Me.tbinfoboxicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbinfoboxicon.Image = Global.ShiftOS.My.Resources.Resources.iconInfoBox
        Me.tbinfoboxicon.Location = New System.Drawing.Point(4, 2)
        Me.tbinfoboxicon.Name = "tbinfoboxicon"
        Me.tbinfoboxicon.Size = New System.Drawing.Size(16, 16)
        Me.tbinfoboxicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbinfoboxicon.TabIndex = 1
        Me.tbinfoboxicon.TabStop = False
        '
        'tbinfoboxtext
        '
        Me.tbinfoboxtext.AutoSize = True
        Me.tbinfoboxtext.BackColor = System.Drawing.Color.Transparent
        Me.tbinfoboxtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbinfoboxtext.ForeColor = System.Drawing.Color.White
        Me.tbinfoboxtext.Location = New System.Drawing.Point(24, 2)
        Me.tbinfoboxtext.Name = "tbinfoboxtext"
        Me.tbinfoboxtext.Size = New System.Drawing.Size(52, 16)
        Me.tbinfoboxtext.TabIndex = 0
        Me.tbinfoboxtext.Text = "InfoBox"
        '
        'pnlpanelbuttonknowledgeinput
        '
        Me.pnlpanelbuttonknowledgeinput.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonknowledgeinput.Controls.Add(Me.tbknowledgeinputicon)
        Me.pnlpanelbuttonknowledgeinput.Controls.Add(Me.tbknowledgeinputtext)
        Me.pnlpanelbuttonknowledgeinput.Location = New System.Drawing.Point(103, 3)
        Me.pnlpanelbuttonknowledgeinput.Name = "pnlpanelbuttonknowledgeinput"
        Me.pnlpanelbuttonknowledgeinput.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonknowledgeinput.TabIndex = 6
        Me.pnlpanelbuttonknowledgeinput.Visible = False
        '
        'tbknowledgeinputicon
        '
        Me.tbknowledgeinputicon.BackColor = System.Drawing.Color.Transparent
        Me.tbknowledgeinputicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbknowledgeinputicon.Image = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.tbknowledgeinputicon.Location = New System.Drawing.Point(4, 2)
        Me.tbknowledgeinputicon.Name = "tbknowledgeinputicon"
        Me.tbknowledgeinputicon.Size = New System.Drawing.Size(16, 16)
        Me.tbknowledgeinputicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbknowledgeinputicon.TabIndex = 1
        Me.tbknowledgeinputicon.TabStop = False
        '
        'tbknowledgeinputtext
        '
        Me.tbknowledgeinputtext.AutoSize = True
        Me.tbknowledgeinputtext.BackColor = System.Drawing.Color.Transparent
        Me.tbknowledgeinputtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbknowledgeinputtext.ForeColor = System.Drawing.Color.White
        Me.tbknowledgeinputtext.Location = New System.Drawing.Point(24, 2)
        Me.tbknowledgeinputtext.Name = "tbknowledgeinputtext"
        Me.tbknowledgeinputtext.Size = New System.Drawing.Size(106, 16)
        Me.tbknowledgeinputtext.TabIndex = 0
        Me.tbknowledgeinputtext.Text = "Knowledge Input"
        '
        'pnlpanelbuttoncolourpicker
        '
        Me.pnlpanelbuttoncolourpicker.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttoncolourpicker.Controls.Add(Me.tbcolourpickericon)
        Me.pnlpanelbuttoncolourpicker.Controls.Add(Me.tbcolourpickertext)
        Me.pnlpanelbuttoncolourpicker.Location = New System.Drawing.Point(119, 3)
        Me.pnlpanelbuttoncolourpicker.Name = "pnlpanelbuttoncolourpicker"
        Me.pnlpanelbuttoncolourpicker.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttoncolourpicker.TabIndex = 6
        Me.pnlpanelbuttoncolourpicker.Visible = False
        '
        'tbcolourpickericon
        '
        Me.tbcolourpickericon.BackColor = System.Drawing.Color.Transparent
        Me.tbcolourpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbcolourpickericon.Image = Global.ShiftOS.My.Resources.Resources.iconColourPicker
        Me.tbcolourpickericon.Location = New System.Drawing.Point(4, 2)
        Me.tbcolourpickericon.Name = "tbcolourpickericon"
        Me.tbcolourpickericon.Size = New System.Drawing.Size(16, 16)
        Me.tbcolourpickericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbcolourpickericon.TabIndex = 1
        Me.tbcolourpickericon.TabStop = False
        '
        'tbcolourpickertext
        '
        Me.tbcolourpickertext.AutoSize = True
        Me.tbcolourpickertext.BackColor = System.Drawing.Color.Transparent
        Me.tbcolourpickertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbcolourpickertext.ForeColor = System.Drawing.Color.White
        Me.tbcolourpickertext.Location = New System.Drawing.Point(24, 2)
        Me.tbcolourpickertext.Name = "tbcolourpickertext"
        Me.tbcolourpickertext.Size = New System.Drawing.Size(88, 16)
        Me.tbcolourpickertext.TabIndex = 0
        Me.tbcolourpickertext.Text = "Colour Picker"
        '
        'pnlpanelbuttonshiftorium
        '
        Me.pnlpanelbuttonshiftorium.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonshiftorium.Controls.Add(Me.tbshiftoriumicon)
        Me.pnlpanelbuttonshiftorium.Controls.Add(Me.tbshiftoriumtext)
        Me.pnlpanelbuttonshiftorium.Location = New System.Drawing.Point(135, 3)
        Me.pnlpanelbuttonshiftorium.Name = "pnlpanelbuttonshiftorium"
        Me.pnlpanelbuttonshiftorium.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonshiftorium.TabIndex = 7
        Me.pnlpanelbuttonshiftorium.Visible = False
        '
        'tbshiftoriumicon
        '
        Me.tbshiftoriumicon.BackColor = System.Drawing.Color.Transparent
        Me.tbshiftoriumicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbshiftoriumicon.Image = Global.ShiftOS.My.Resources.Resources.iconShiftorium
        Me.tbshiftoriumicon.Location = New System.Drawing.Point(4, 2)
        Me.tbshiftoriumicon.Name = "tbshiftoriumicon"
        Me.tbshiftoriumicon.Size = New System.Drawing.Size(16, 16)
        Me.tbshiftoriumicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbshiftoriumicon.TabIndex = 1
        Me.tbshiftoriumicon.TabStop = False
        '
        'tbshiftoriumtext
        '
        Me.tbshiftoriumtext.AutoSize = True
        Me.tbshiftoriumtext.BackColor = System.Drawing.Color.Transparent
        Me.tbshiftoriumtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbshiftoriumtext.ForeColor = System.Drawing.Color.White
        Me.tbshiftoriumtext.Location = New System.Drawing.Point(24, 2)
        Me.tbshiftoriumtext.Name = "tbshiftoriumtext"
        Me.tbshiftoriumtext.Size = New System.Drawing.Size(66, 16)
        Me.tbshiftoriumtext.TabIndex = 0
        Me.tbshiftoriumtext.Text = "Shiftorium"
        '
        'pnlpanelbuttonpong
        '
        Me.pnlpanelbuttonpong.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonpong.Controls.Add(Me.tbpongicon)
        Me.pnlpanelbuttonpong.Controls.Add(Me.tbpongtext)
        Me.pnlpanelbuttonpong.Location = New System.Drawing.Point(151, 3)
        Me.pnlpanelbuttonpong.Name = "pnlpanelbuttonpong"
        Me.pnlpanelbuttonpong.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonpong.TabIndex = 6
        Me.pnlpanelbuttonpong.Visible = False
        '
        'tbpongicon
        '
        Me.tbpongicon.BackColor = System.Drawing.Color.Transparent
        Me.tbpongicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbpongicon.Image = Global.ShiftOS.My.Resources.Resources.iconPong
        Me.tbpongicon.Location = New System.Drawing.Point(4, 2)
        Me.tbpongicon.Name = "tbpongicon"
        Me.tbpongicon.Size = New System.Drawing.Size(16, 16)
        Me.tbpongicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbpongicon.TabIndex = 1
        Me.tbpongicon.TabStop = False
        '
        'tbpongtext
        '
        Me.tbpongtext.AutoSize = True
        Me.tbpongtext.BackColor = System.Drawing.Color.Transparent
        Me.tbpongtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbpongtext.ForeColor = System.Drawing.Color.White
        Me.tbpongtext.Location = New System.Drawing.Point(24, 2)
        Me.tbpongtext.Name = "tbpongtext"
        Me.tbpongtext.Size = New System.Drawing.Size(40, 16)
        Me.tbpongtext.TabIndex = 0
        Me.tbpongtext.Text = "Pong"
        '
        'pnlpanelbuttonterminal
        '
        Me.pnlpanelbuttonterminal.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonterminal.Controls.Add(Me.tbterminalicon)
        Me.pnlpanelbuttonterminal.Controls.Add(Me.tbterminaltext)
        Me.pnlpanelbuttonterminal.Location = New System.Drawing.Point(167, 3)
        Me.pnlpanelbuttonterminal.Name = "pnlpanelbuttonterminal"
        Me.pnlpanelbuttonterminal.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonterminal.TabIndex = 8
        Me.pnlpanelbuttonterminal.Visible = False
        '
        'tbterminalicon
        '
        Me.tbterminalicon.BackColor = System.Drawing.Color.Transparent
        Me.tbterminalicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbterminalicon.Image = Global.ShiftOS.My.Resources.Resources.iconTerminal
        Me.tbterminalicon.Location = New System.Drawing.Point(4, 2)
        Me.tbterminalicon.Name = "tbterminalicon"
        Me.tbterminalicon.Size = New System.Drawing.Size(16, 16)
        Me.tbterminalicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbterminalicon.TabIndex = 1
        Me.tbterminalicon.TabStop = False
        '
        'tbterminaltext
        '
        Me.tbterminaltext.AutoSize = True
        Me.tbterminaltext.BackColor = System.Drawing.Color.Transparent
        Me.tbterminaltext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbterminaltext.ForeColor = System.Drawing.Color.White
        Me.tbterminaltext.Location = New System.Drawing.Point(24, 2)
        Me.tbterminaltext.Name = "tbterminaltext"
        Me.tbterminaltext.Size = New System.Drawing.Size(61, 16)
        Me.tbterminaltext.TabIndex = 0
        Me.tbterminaltext.Text = "Terminal"
        '
        'pnlpanelbuttontextpad
        '
        Me.pnlpanelbuttontextpad.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttontextpad.Controls.Add(Me.tbtextpadicon)
        Me.pnlpanelbuttontextpad.Controls.Add(Me.tbtextpadtext)
        Me.pnlpanelbuttontextpad.Location = New System.Drawing.Point(183, 3)
        Me.pnlpanelbuttontextpad.Name = "pnlpanelbuttontextpad"
        Me.pnlpanelbuttontextpad.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttontextpad.TabIndex = 4
        Me.pnlpanelbuttontextpad.Visible = False
        '
        'tbtextpadicon
        '
        Me.tbtextpadicon.BackColor = System.Drawing.Color.Transparent
        Me.tbtextpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbtextpadicon.Image = Global.ShiftOS.My.Resources.Resources.iconTextPad
        Me.tbtextpadicon.Location = New System.Drawing.Point(4, 2)
        Me.tbtextpadicon.Name = "tbtextpadicon"
        Me.tbtextpadicon.Size = New System.Drawing.Size(16, 16)
        Me.tbtextpadicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbtextpadicon.TabIndex = 1
        Me.tbtextpadicon.TabStop = False
        '
        'tbtextpadtext
        '
        Me.tbtextpadtext.AutoSize = True
        Me.tbtextpadtext.BackColor = System.Drawing.Color.Transparent
        Me.tbtextpadtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbtextpadtext.ForeColor = System.Drawing.Color.White
        Me.tbtextpadtext.Location = New System.Drawing.Point(24, 2)
        Me.tbtextpadtext.Name = "tbtextpadtext"
        Me.tbtextpadtext.Size = New System.Drawing.Size(58, 16)
        Me.tbtextpadtext.TabIndex = 0
        Me.tbtextpadtext.Text = "Textpad"
        '
        'pnlpanelbuttongraphicpicker
        '
        Me.pnlpanelbuttongraphicpicker.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttongraphicpicker.Controls.Add(Me.tbgraphicpickericon)
        Me.pnlpanelbuttongraphicpicker.Controls.Add(Me.tbgraphicpickertext)
        Me.pnlpanelbuttongraphicpicker.Location = New System.Drawing.Point(199, 3)
        Me.pnlpanelbuttongraphicpicker.Name = "pnlpanelbuttongraphicpicker"
        Me.pnlpanelbuttongraphicpicker.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttongraphicpicker.TabIndex = 6
        Me.pnlpanelbuttongraphicpicker.Visible = False
        '
        'tbgraphicpickericon
        '
        Me.tbgraphicpickericon.BackColor = System.Drawing.Color.Transparent
        Me.tbgraphicpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbgraphicpickericon.Image = Global.ShiftOS.My.Resources.Resources.iconGraphicPicker
        Me.tbgraphicpickericon.Location = New System.Drawing.Point(4, 2)
        Me.tbgraphicpickericon.Name = "tbgraphicpickericon"
        Me.tbgraphicpickericon.Size = New System.Drawing.Size(16, 16)
        Me.tbgraphicpickericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbgraphicpickericon.TabIndex = 1
        Me.tbgraphicpickericon.TabStop = False
        '
        'tbgraphicpickertext
        '
        Me.tbgraphicpickertext.AutoSize = True
        Me.tbgraphicpickertext.BackColor = System.Drawing.Color.Transparent
        Me.tbgraphicpickertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbgraphicpickertext.ForeColor = System.Drawing.Color.White
        Me.tbgraphicpickertext.Location = New System.Drawing.Point(24, 2)
        Me.tbgraphicpickertext.Name = "tbgraphicpickertext"
        Me.tbgraphicpickertext.Size = New System.Drawing.Size(96, 16)
        Me.tbgraphicpickertext.TabIndex = 0
        Me.tbgraphicpickertext.Text = "Graphic Picker"
        '
        'pnlpanelbuttonartpad
        '
        Me.pnlpanelbuttonartpad.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonartpad.Controls.Add(Me.tbartpadicon)
        Me.pnlpanelbuttonartpad.Controls.Add(Me.tbartpadtext)
        Me.pnlpanelbuttonartpad.Location = New System.Drawing.Point(215, 3)
        Me.pnlpanelbuttonartpad.Name = "pnlpanelbuttonartpad"
        Me.pnlpanelbuttonartpad.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonartpad.TabIndex = 9
        Me.pnlpanelbuttonartpad.Visible = False
        '
        'tbartpadicon
        '
        Me.tbartpadicon.BackColor = System.Drawing.Color.Transparent
        Me.tbartpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbartpadicon.Image = Global.ShiftOS.My.Resources.Resources.iconArtpad
        Me.tbartpadicon.Location = New System.Drawing.Point(4, 2)
        Me.tbartpadicon.Name = "tbartpadicon"
        Me.tbartpadicon.Size = New System.Drawing.Size(16, 16)
        Me.tbartpadicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbartpadicon.TabIndex = 1
        Me.tbartpadicon.TabStop = False
        '
        'tbartpadtext
        '
        Me.tbartpadtext.AutoSize = True
        Me.tbartpadtext.BackColor = System.Drawing.Color.Transparent
        Me.tbartpadtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbartpadtext.ForeColor = System.Drawing.Color.White
        Me.tbartpadtext.Location = New System.Drawing.Point(23, 2)
        Me.tbartpadtext.Name = "tbartpadtext"
        Me.tbartpadtext.Size = New System.Drawing.Size(49, 16)
        Me.tbartpadtext.TabIndex = 0
        Me.tbartpadtext.Text = "ArtPad"
        '
        'pnlpanelbuttoncalculator
        '
        Me.pnlpanelbuttoncalculator.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttoncalculator.Controls.Add(Me.tbcalculatoricon)
        Me.pnlpanelbuttoncalculator.Controls.Add(Me.tbcalculatortext)
        Me.pnlpanelbuttoncalculator.Location = New System.Drawing.Point(231, 3)
        Me.pnlpanelbuttoncalculator.Name = "pnlpanelbuttoncalculator"
        Me.pnlpanelbuttoncalculator.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttoncalculator.TabIndex = 10
        Me.pnlpanelbuttoncalculator.Visible = False
        '
        'tbcalculatoricon
        '
        Me.tbcalculatoricon.BackColor = System.Drawing.Color.Transparent
        Me.tbcalculatoricon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbcalculatoricon.Image = Global.ShiftOS.My.Resources.Resources.iconCalculator
        Me.tbcalculatoricon.Location = New System.Drawing.Point(4, 2)
        Me.tbcalculatoricon.Name = "tbcalculatoricon"
        Me.tbcalculatoricon.Size = New System.Drawing.Size(16, 16)
        Me.tbcalculatoricon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbcalculatoricon.TabIndex = 1
        Me.tbcalculatoricon.TabStop = False
        '
        'tbcalculatortext
        '
        Me.tbcalculatortext.AutoSize = True
        Me.tbcalculatortext.BackColor = System.Drawing.Color.Transparent
        Me.tbcalculatortext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbcalculatortext.ForeColor = System.Drawing.Color.White
        Me.tbcalculatortext.Location = New System.Drawing.Point(23, 2)
        Me.tbcalculatortext.Name = "tbcalculatortext"
        Me.tbcalculatortext.Size = New System.Drawing.Size(68, 16)
        Me.tbcalculatortext.TabIndex = 0
        Me.tbcalculatortext.Text = "Calculator"
        '
        'pnlpanelbuttonaudioplayer
        '
        Me.pnlpanelbuttonaudioplayer.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonaudioplayer.Controls.Add(Me.tbaudioplayericon)
        Me.pnlpanelbuttonaudioplayer.Controls.Add(Me.tbaudioplayertext)
        Me.pnlpanelbuttonaudioplayer.Location = New System.Drawing.Point(247, 3)
        Me.pnlpanelbuttonaudioplayer.Name = "pnlpanelbuttonaudioplayer"
        Me.pnlpanelbuttonaudioplayer.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonaudioplayer.TabIndex = 11
        Me.pnlpanelbuttonaudioplayer.Visible = False
        '
        'tbaudioplayericon
        '
        Me.tbaudioplayericon.BackColor = System.Drawing.Color.Transparent
        Me.tbaudioplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbaudioplayericon.Image = Global.ShiftOS.My.Resources.Resources.iconAudioPlayer
        Me.tbaudioplayericon.Location = New System.Drawing.Point(4, 2)
        Me.tbaudioplayericon.Name = "tbaudioplayericon"
        Me.tbaudioplayericon.Size = New System.Drawing.Size(16, 16)
        Me.tbaudioplayericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbaudioplayericon.TabIndex = 1
        Me.tbaudioplayericon.TabStop = False
        '
        'tbaudioplayertext
        '
        Me.tbaudioplayertext.AutoSize = True
        Me.tbaudioplayertext.BackColor = System.Drawing.Color.Transparent
        Me.tbaudioplayertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbaudioplayertext.ForeColor = System.Drawing.Color.White
        Me.tbaudioplayertext.Location = New System.Drawing.Point(23, 2)
        Me.tbaudioplayertext.Name = "tbaudioplayertext"
        Me.tbaudioplayertext.Size = New System.Drawing.Size(85, 16)
        Me.tbaudioplayertext.TabIndex = 0
        Me.tbaudioplayertext.Text = "Audio Player"
        '
        'pnlpanelbuttonvideoplayer
        '
        Me.pnlpanelbuttonvideoplayer.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonvideoplayer.Controls.Add(Me.tbvideoplayericon)
        Me.pnlpanelbuttonvideoplayer.Controls.Add(Me.tbvideoplayertext)
        Me.pnlpanelbuttonvideoplayer.Location = New System.Drawing.Point(263, 3)
        Me.pnlpanelbuttonvideoplayer.Name = "pnlpanelbuttonvideoplayer"
        Me.pnlpanelbuttonvideoplayer.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonvideoplayer.TabIndex = 13
        Me.pnlpanelbuttonvideoplayer.Visible = False
        '
        'tbvideoplayericon
        '
        Me.tbvideoplayericon.BackColor = System.Drawing.Color.Transparent
        Me.tbvideoplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbvideoplayericon.Image = Global.ShiftOS.My.Resources.Resources.iconVideoPlayer
        Me.tbvideoplayericon.Location = New System.Drawing.Point(4, 2)
        Me.tbvideoplayericon.Name = "tbvideoplayericon"
        Me.tbvideoplayericon.Size = New System.Drawing.Size(16, 16)
        Me.tbvideoplayericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbvideoplayericon.TabIndex = 1
        Me.tbvideoplayericon.TabStop = False
        '
        'tbvideoplayertext
        '
        Me.tbvideoplayertext.AutoSize = True
        Me.tbvideoplayertext.BackColor = System.Drawing.Color.Transparent
        Me.tbvideoplayertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbvideoplayertext.ForeColor = System.Drawing.Color.White
        Me.tbvideoplayertext.Location = New System.Drawing.Point(22, 2)
        Me.tbvideoplayertext.Name = "tbvideoplayertext"
        Me.tbvideoplayertext.Size = New System.Drawing.Size(86, 16)
        Me.tbvideoplayertext.TabIndex = 0
        Me.tbvideoplayertext.Text = "Video Player"
        '
        'pnlpanelbuttonwebbrowser
        '
        Me.pnlpanelbuttonwebbrowser.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonwebbrowser.Controls.Add(Me.tbwebbrowsericon)
        Me.pnlpanelbuttonwebbrowser.Controls.Add(Me.tbwebbrowsertext)
        Me.pnlpanelbuttonwebbrowser.Location = New System.Drawing.Point(279, 3)
        Me.pnlpanelbuttonwebbrowser.Name = "pnlpanelbuttonwebbrowser"
        Me.pnlpanelbuttonwebbrowser.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonwebbrowser.TabIndex = 12
        Me.pnlpanelbuttonwebbrowser.Visible = False
        '
        'tbwebbrowsericon
        '
        Me.tbwebbrowsericon.BackColor = System.Drawing.Color.Transparent
        Me.tbwebbrowsericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbwebbrowsericon.Image = Global.ShiftOS.My.Resources.Resources.iconWebBrowser
        Me.tbwebbrowsericon.Location = New System.Drawing.Point(4, 2)
        Me.tbwebbrowsericon.Name = "tbwebbrowsericon"
        Me.tbwebbrowsericon.Size = New System.Drawing.Size(16, 16)
        Me.tbwebbrowsericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbwebbrowsericon.TabIndex = 1
        Me.tbwebbrowsericon.TabStop = False
        '
        'tbwebbrowsertext
        '
        Me.tbwebbrowsertext.AutoSize = True
        Me.tbwebbrowsertext.BackColor = System.Drawing.Color.Transparent
        Me.tbwebbrowsertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbwebbrowsertext.ForeColor = System.Drawing.Color.White
        Me.tbwebbrowsertext.Location = New System.Drawing.Point(23, 2)
        Me.tbwebbrowsertext.Name = "tbwebbrowsertext"
        Me.tbwebbrowsertext.Size = New System.Drawing.Size(89, 16)
        Me.tbwebbrowsertext.TabIndex = 0
        Me.tbwebbrowsertext.Text = "Web Browser"
        '
        'pnlpanelbuttonnamechanger
        '
        Me.pnlpanelbuttonnamechanger.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonnamechanger.Controls.Add(Me.tbnamechangericon)
        Me.pnlpanelbuttonnamechanger.Controls.Add(Me.tbnamechangertext)
        Me.pnlpanelbuttonnamechanger.Location = New System.Drawing.Point(295, 3)
        Me.pnlpanelbuttonnamechanger.Name = "pnlpanelbuttonnamechanger"
        Me.pnlpanelbuttonnamechanger.Size = New System.Drawing.Size(36, 20)
        Me.pnlpanelbuttonnamechanger.TabIndex = 14
        Me.pnlpanelbuttonnamechanger.Visible = False
        '
        'tbnamechangericon
        '
        Me.tbnamechangericon.BackColor = System.Drawing.Color.Transparent
        Me.tbnamechangericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbnamechangericon.Image = Global.ShiftOS.My.Resources.Resources.iconNameChanger
        Me.tbnamechangericon.Location = New System.Drawing.Point(4, 2)
        Me.tbnamechangericon.Name = "tbnamechangericon"
        Me.tbnamechangericon.Size = New System.Drawing.Size(16, 16)
        Me.tbnamechangericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbnamechangericon.TabIndex = 1
        Me.tbnamechangericon.TabStop = False
        '
        'tbnamechangertext
        '
        Me.tbnamechangertext.AutoSize = True
        Me.tbnamechangertext.BackColor = System.Drawing.Color.Transparent
        Me.tbnamechangertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbnamechangertext.ForeColor = System.Drawing.Color.White
        Me.tbnamechangertext.Location = New System.Drawing.Point(22, 2)
        Me.tbnamechangertext.Name = "tbnamechangertext"
        Me.tbnamechangertext.Size = New System.Drawing.Size(99, 16)
        Me.tbnamechangertext.TabIndex = 0
        Me.tbnamechangertext.Text = "Name Changer"
        '
        'pnlpanelbuttoniconmanager
        '
        Me.pnlpanelbuttoniconmanager.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttoniconmanager.Controls.Add(Me.tbiconmanagericon)
        Me.pnlpanelbuttoniconmanager.Controls.Add(Me.tbiconmanagertext)
        Me.pnlpanelbuttoniconmanager.Location = New System.Drawing.Point(337, 3)
        Me.pnlpanelbuttoniconmanager.Name = "pnlpanelbuttoniconmanager"
        Me.pnlpanelbuttoniconmanager.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttoniconmanager.TabIndex = 15
        Me.pnlpanelbuttoniconmanager.Visible = False
        '
        'tbiconmanagericon
        '
        Me.tbiconmanagericon.BackColor = System.Drawing.Color.Transparent
        Me.tbiconmanagericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbiconmanagericon.Image = Global.ShiftOS.My.Resources.Resources.iconNameChanger
        Me.tbiconmanagericon.Location = New System.Drawing.Point(4, 2)
        Me.tbiconmanagericon.Name = "tbiconmanagericon"
        Me.tbiconmanagericon.Size = New System.Drawing.Size(16, 16)
        Me.tbiconmanagericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbiconmanagericon.TabIndex = 1
        Me.tbiconmanagericon.TabStop = False
        '
        'tbiconmanagertext
        '
        Me.tbiconmanagertext.AutoSize = True
        Me.tbiconmanagertext.BackColor = System.Drawing.Color.Transparent
        Me.tbiconmanagertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbiconmanagertext.ForeColor = System.Drawing.Color.White
        Me.tbiconmanagertext.Location = New System.Drawing.Point(22, 2)
        Me.tbiconmanagertext.Name = "tbiconmanagertext"
        Me.tbiconmanagertext.Size = New System.Drawing.Size(90, 16)
        Me.tbiconmanagertext.TabIndex = 0
        Me.tbiconmanagertext.Text = "Icon Manager"
        '
        'pnlpanelbuttonbitnotewallet
        '
        Me.pnlpanelbuttonbitnotewallet.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonbitnotewallet.Controls.Add(Me.tbbitnotewalleticon)
        Me.pnlpanelbuttonbitnotewallet.Controls.Add(Me.tbbitnotewallettext)
        Me.pnlpanelbuttonbitnotewallet.Location = New System.Drawing.Point(353, 3)
        Me.pnlpanelbuttonbitnotewallet.Name = "pnlpanelbuttonbitnotewallet"
        Me.pnlpanelbuttonbitnotewallet.Size = New System.Drawing.Size(10, 20)
        Me.pnlpanelbuttonbitnotewallet.TabIndex = 16
        Me.pnlpanelbuttonbitnotewallet.Visible = False
        '
        'tbbitnotewalleticon
        '
        Me.tbbitnotewalleticon.BackColor = System.Drawing.Color.Transparent
        Me.tbbitnotewalleticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbbitnotewalleticon.Image = Global.ShiftOS.My.Resources.Resources.iconBitnoteWallet
        Me.tbbitnotewalleticon.Location = New System.Drawing.Point(4, 2)
        Me.tbbitnotewalleticon.Name = "tbbitnotewalleticon"
        Me.tbbitnotewalleticon.Size = New System.Drawing.Size(16, 16)
        Me.tbbitnotewalleticon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbbitnotewalleticon.TabIndex = 1
        Me.tbbitnotewalleticon.TabStop = False
        '
        'tbbitnotewallettext
        '
        Me.tbbitnotewallettext.AutoSize = True
        Me.tbbitnotewallettext.BackColor = System.Drawing.Color.Transparent
        Me.tbbitnotewallettext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbbitnotewallettext.ForeColor = System.Drawing.Color.White
        Me.tbbitnotewallettext.Location = New System.Drawing.Point(22, 2)
        Me.tbbitnotewallettext.Name = "tbbitnotewallettext"
        Me.tbbitnotewallettext.Size = New System.Drawing.Size(90, 16)
        Me.tbbitnotewallettext.TabIndex = 0
        Me.tbbitnotewallettext.Text = "Bitnote Wallet"
        '
        'pnlpanelbuttonbitnotedigger
        '
        Me.pnlpanelbuttonbitnotedigger.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonbitnotedigger.Controls.Add(Me.tbbitnotediggericon)
        Me.pnlpanelbuttonbitnotedigger.Controls.Add(Me.tbbitnotediggertext)
        Me.pnlpanelbuttonbitnotedigger.Location = New System.Drawing.Point(369, 3)
        Me.pnlpanelbuttonbitnotedigger.Name = "pnlpanelbuttonbitnotedigger"
        Me.pnlpanelbuttonbitnotedigger.Size = New System.Drawing.Size(15, 20)
        Me.pnlpanelbuttonbitnotedigger.TabIndex = 17
        Me.pnlpanelbuttonbitnotedigger.Visible = False
        '
        'tbbitnotediggericon
        '
        Me.tbbitnotediggericon.BackColor = System.Drawing.Color.Transparent
        Me.tbbitnotediggericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbbitnotediggericon.Image = Global.ShiftOS.My.Resources.Resources.iconBitnoteDigger
        Me.tbbitnotediggericon.Location = New System.Drawing.Point(4, 2)
        Me.tbbitnotediggericon.Name = "tbbitnotediggericon"
        Me.tbbitnotediggericon.Size = New System.Drawing.Size(16, 16)
        Me.tbbitnotediggericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbbitnotediggericon.TabIndex = 1
        Me.tbbitnotediggericon.TabStop = False
        '
        'tbbitnotediggertext
        '
        Me.tbbitnotediggertext.AutoSize = True
        Me.tbbitnotediggertext.BackColor = System.Drawing.Color.Transparent
        Me.tbbitnotediggertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbbitnotediggertext.ForeColor = System.Drawing.Color.White
        Me.tbbitnotediggertext.Location = New System.Drawing.Point(22, 2)
        Me.tbbitnotediggertext.Name = "tbbitnotediggertext"
        Me.tbbitnotediggertext.Size = New System.Drawing.Size(93, 16)
        Me.tbbitnotediggertext.TabIndex = 0
        Me.tbbitnotediggertext.Text = "Bitnote Digger"
        '
        'pnlpanelbuttonskinshifter
        '
        Me.pnlpanelbuttonskinshifter.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonskinshifter.Controls.Add(Me.tbskinshiftericon)
        Me.pnlpanelbuttonskinshifter.Controls.Add(Me.tbskinshiftertext)
        Me.pnlpanelbuttonskinshifter.Location = New System.Drawing.Point(390, 3)
        Me.pnlpanelbuttonskinshifter.Name = "pnlpanelbuttonskinshifter"
        Me.pnlpanelbuttonskinshifter.Size = New System.Drawing.Size(19, 20)
        Me.pnlpanelbuttonskinshifter.TabIndex = 18
        Me.pnlpanelbuttonskinshifter.Visible = False
        '
        'tbskinshiftericon
        '
        Me.tbskinshiftericon.BackColor = System.Drawing.Color.Transparent
        Me.tbskinshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbskinshiftericon.Image = Global.ShiftOS.My.Resources.Resources.iconSkinShifter
        Me.tbskinshiftericon.Location = New System.Drawing.Point(4, 2)
        Me.tbskinshiftericon.Name = "tbskinshiftericon"
        Me.tbskinshiftericon.Size = New System.Drawing.Size(16, 16)
        Me.tbskinshiftericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbskinshiftericon.TabIndex = 1
        Me.tbskinshiftericon.TabStop = False
        '
        'tbskinshiftertext
        '
        Me.tbskinshiftertext.AutoSize = True
        Me.tbskinshiftertext.BackColor = System.Drawing.Color.Transparent
        Me.tbskinshiftertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbskinshiftertext.ForeColor = System.Drawing.Color.White
        Me.tbskinshiftertext.Location = New System.Drawing.Point(22, 2)
        Me.tbskinshiftertext.Name = "tbskinshiftertext"
        Me.tbskinshiftertext.Size = New System.Drawing.Size(74, 16)
        Me.tbskinshiftertext.TabIndex = 0
        Me.tbskinshiftertext.Text = "Skin Shifter"
        '
        'pnlpanelbuttondownloader
        '
        Me.pnlpanelbuttondownloader.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttondownloader.Controls.Add(Me.tbdownloadericon)
        Me.pnlpanelbuttondownloader.Controls.Add(Me.tbdownloadertext)
        Me.pnlpanelbuttondownloader.Location = New System.Drawing.Point(415, 3)
        Me.pnlpanelbuttondownloader.Name = "pnlpanelbuttondownloader"
        Me.pnlpanelbuttondownloader.Size = New System.Drawing.Size(23, 20)
        Me.pnlpanelbuttondownloader.TabIndex = 20
        Me.pnlpanelbuttondownloader.Visible = False
        '
        'tbdownloadericon
        '
        Me.tbdownloadericon.BackColor = System.Drawing.Color.Transparent
        Me.tbdownloadericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbdownloadericon.Image = Global.ShiftOS.My.Resources.Resources.iconDownloader
        Me.tbdownloadericon.Location = New System.Drawing.Point(4, 2)
        Me.tbdownloadericon.Name = "tbdownloadericon"
        Me.tbdownloadericon.Size = New System.Drawing.Size(16, 16)
        Me.tbdownloadericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbdownloadericon.TabIndex = 1
        Me.tbdownloadericon.TabStop = False
        '
        'tbdownloadertext
        '
        Me.tbdownloadertext.AutoSize = True
        Me.tbdownloadertext.BackColor = System.Drawing.Color.Transparent
        Me.tbdownloadertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbdownloadertext.ForeColor = System.Drawing.Color.White
        Me.tbdownloadertext.Location = New System.Drawing.Point(22, 2)
        Me.tbdownloadertext.Name = "tbdownloadertext"
        Me.tbdownloadertext.Size = New System.Drawing.Size(81, 16)
        Me.tbdownloadertext.TabIndex = 0
        Me.tbdownloadertext.Text = "Downloader"
        '
        'pnlpanelbuttonshiftnet
        '
        Me.pnlpanelbuttonshiftnet.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonshiftnet.Controls.Add(Me.tbshiftneticon)
        Me.pnlpanelbuttonshiftnet.Controls.Add(Me.tbshiftnettext)
        Me.pnlpanelbuttonshiftnet.Location = New System.Drawing.Point(444, 3)
        Me.pnlpanelbuttonshiftnet.Name = "pnlpanelbuttonshiftnet"
        Me.pnlpanelbuttonshiftnet.Size = New System.Drawing.Size(27, 20)
        Me.pnlpanelbuttonshiftnet.TabIndex = 19
        Me.pnlpanelbuttonshiftnet.Visible = False
        '
        'tbshiftneticon
        '
        Me.tbshiftneticon.BackColor = System.Drawing.Color.Transparent
        Me.tbshiftneticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbshiftneticon.Image = Global.ShiftOS.My.Resources.Resources.iconShiftnet
        Me.tbshiftneticon.Location = New System.Drawing.Point(4, 2)
        Me.tbshiftneticon.Name = "tbshiftneticon"
        Me.tbshiftneticon.Size = New System.Drawing.Size(16, 16)
        Me.tbshiftneticon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbshiftneticon.TabIndex = 1
        Me.tbshiftneticon.TabStop = False
        '
        'tbshiftnettext
        '
        Me.tbshiftnettext.AutoSize = True
        Me.tbshiftnettext.BackColor = System.Drawing.Color.Transparent
        Me.tbshiftnettext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbshiftnettext.ForeColor = System.Drawing.Color.White
        Me.tbshiftnettext.Location = New System.Drawing.Point(22, 2)
        Me.tbshiftnettext.Name = "tbshiftnettext"
        Me.tbshiftnettext.Size = New System.Drawing.Size(51, 16)
        Me.tbshiftnettext.TabIndex = 0
        Me.tbshiftnettext.Text = "Shiftnet"
        '
        'pnlpanelbuttondodge
        '
        Me.pnlpanelbuttondodge.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttondodge.Controls.Add(Me.tbdodgeicon)
        Me.pnlpanelbuttondodge.Controls.Add(Me.tbdodgetext)
        Me.pnlpanelbuttondodge.Location = New System.Drawing.Point(477, 3)
        Me.pnlpanelbuttondodge.Name = "pnlpanelbuttondodge"
        Me.pnlpanelbuttondodge.Size = New System.Drawing.Size(27, 20)
        Me.pnlpanelbuttondodge.TabIndex = 21
        Me.pnlpanelbuttondodge.Visible = False
        '
        'tbdodgeicon
        '
        Me.tbdodgeicon.BackColor = System.Drawing.Color.Transparent
        Me.tbdodgeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbdodgeicon.Image = Global.ShiftOS.My.Resources.Resources.iconDodge
        Me.tbdodgeicon.Location = New System.Drawing.Point(4, 2)
        Me.tbdodgeicon.Name = "tbdodgeicon"
        Me.tbdodgeicon.Size = New System.Drawing.Size(16, 16)
        Me.tbdodgeicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbdodgeicon.TabIndex = 1
        Me.tbdodgeicon.TabStop = False
        '
        'tbdodgetext
        '
        Me.tbdodgetext.AutoSize = True
        Me.tbdodgetext.BackColor = System.Drawing.Color.Transparent
        Me.tbdodgetext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbdodgetext.ForeColor = System.Drawing.Color.White
        Me.tbdodgetext.Location = New System.Drawing.Point(22, 2)
        Me.tbdodgetext.Name = "tbdodgetext"
        Me.tbdodgetext.Size = New System.Drawing.Size(50, 16)
        Me.tbdodgetext.TabIndex = 0
        Me.tbdodgetext.Text = "Dodge"
        '
        'pnlpanelbuttondownloadmanager
        '
        Me.pnlpanelbuttondownloadmanager.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttondownloadmanager.Controls.Add(Me.tbdownloadmanagericon)
        Me.pnlpanelbuttondownloadmanager.Controls.Add(Me.tbdownloadmanagertext)
        Me.pnlpanelbuttondownloadmanager.Location = New System.Drawing.Point(510, 3)
        Me.pnlpanelbuttondownloadmanager.Name = "pnlpanelbuttondownloadmanager"
        Me.pnlpanelbuttondownloadmanager.Size = New System.Drawing.Size(27, 20)
        Me.pnlpanelbuttondownloadmanager.TabIndex = 22
        Me.pnlpanelbuttondownloadmanager.Visible = False
        '
        'tbdownloadmanagericon
        '
        Me.tbdownloadmanagericon.BackColor = System.Drawing.Color.Transparent
        Me.tbdownloadmanagericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbdownloadmanagericon.Image = Global.ShiftOS.My.Resources.Resources.icondownloadmanager
        Me.tbdownloadmanagericon.Location = New System.Drawing.Point(4, 2)
        Me.tbdownloadmanagericon.Name = "tbdownloadmanagericon"
        Me.tbdownloadmanagericon.Size = New System.Drawing.Size(16, 16)
        Me.tbdownloadmanagericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbdownloadmanagericon.TabIndex = 1
        Me.tbdownloadmanagericon.TabStop = False
        '
        'tbdownloadmanagertext
        '
        Me.tbdownloadmanagertext.AutoSize = True
        Me.tbdownloadmanagertext.BackColor = System.Drawing.Color.Transparent
        Me.tbdownloadmanagertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbdownloadmanagertext.ForeColor = System.Drawing.Color.White
        Me.tbdownloadmanagertext.Location = New System.Drawing.Point(22, 2)
        Me.tbdownloadmanagertext.Name = "tbdownloadmanagertext"
        Me.tbdownloadmanagertext.Size = New System.Drawing.Size(126, 16)
        Me.tbdownloadmanagertext.TabIndex = 0
        Me.tbdownloadmanagertext.Text = "Download Manager"
        '
        'pnlcatalystpanelbutton
        '
        Me.pnlcatalystpanelbutton.BackColor = System.Drawing.Color.Black
        Me.pnlcatalystpanelbutton.Controls.Add(Me.tbcatalysticon)
        Me.pnlcatalystpanelbutton.Controls.Add(Me.lbcatalystname)
        Me.pnlcatalystpanelbutton.Location = New System.Drawing.Point(543, 3)
        Me.pnlcatalystpanelbutton.Name = "pnlcatalystpanelbutton"
        Me.pnlcatalystpanelbutton.Size = New System.Drawing.Size(27, 20)
        Me.pnlcatalystpanelbutton.TabIndex = 23
        Me.pnlcatalystpanelbutton.Visible = False
        '
        'tbcatalysticon
        '
        Me.tbcatalysticon.BackColor = System.Drawing.Color.Transparent
        Me.tbcatalysticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbcatalysticon.Image = Global.ShiftOS.My.Resources.Resources.icondownloadmanager
        Me.tbcatalysticon.Location = New System.Drawing.Point(4, 2)
        Me.tbcatalysticon.Name = "tbcatalysticon"
        Me.tbcatalysticon.Size = New System.Drawing.Size(16, 16)
        Me.tbcatalysticon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbcatalysticon.TabIndex = 1
        Me.tbcatalysticon.TabStop = False
        '
        'lbcatalystname
        '
        Me.lbcatalystname.AutoSize = True
        Me.lbcatalystname.BackColor = System.Drawing.Color.Transparent
        Me.lbcatalystname.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcatalystname.ForeColor = System.Drawing.Color.White
        Me.lbcatalystname.Location = New System.Drawing.Point(22, 2)
        Me.lbcatalystname.Name = "lbcatalystname"
        Me.lbcatalystname.Size = New System.Drawing.Size(56, 16)
        Me.lbcatalystname.TabIndex = 0
        Me.lbcatalystname.Text = "Catalyst"
        '
        'pnlpanelbuttoninstaller
        '
        Me.pnlpanelbuttoninstaller.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttoninstaller.Controls.Add(Me.tbinstallericon)
        Me.pnlpanelbuttoninstaller.Controls.Add(Me.tbinstallertext)
        Me.pnlpanelbuttoninstaller.Location = New System.Drawing.Point(576, 3)
        Me.pnlpanelbuttoninstaller.Name = "pnlpanelbuttoninstaller"
        Me.pnlpanelbuttoninstaller.Size = New System.Drawing.Size(32, 20)
        Me.pnlpanelbuttoninstaller.TabIndex = 23
        Me.pnlpanelbuttoninstaller.Visible = False
        '
        'tbinstallericon
        '
        Me.tbinstallericon.BackColor = System.Drawing.Color.Transparent
        Me.tbinstallericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbinstallericon.Image = Global.ShiftOS.My.Resources.Resources.icondownloadmanager
        Me.tbinstallericon.Location = New System.Drawing.Point(4, 2)
        Me.tbinstallericon.Name = "tbinstallericon"
        Me.tbinstallericon.Size = New System.Drawing.Size(16, 16)
        Me.tbinstallericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbinstallericon.TabIndex = 1
        Me.tbinstallericon.TabStop = False
        '
        'tbinstallertext
        '
        Me.tbinstallertext.AutoSize = True
        Me.tbinstallertext.BackColor = System.Drawing.Color.Transparent
        Me.tbinstallertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbinstallertext.ForeColor = System.Drawing.Color.White
        Me.tbinstallertext.Location = New System.Drawing.Point(22, 2)
        Me.tbinstallertext.Name = "tbinstallertext"
        Me.tbinstallertext.Size = New System.Drawing.Size(126, 16)
        Me.tbinstallertext.TabIndex = 0
        Me.tbinstallertext.Text = "Download Manager"
        '
        'pnl_panelbuttonsnakey
        '
        Me.pnl_panelbuttonsnakey.BackColor = System.Drawing.Color.Black
        Me.pnl_panelbuttonsnakey.Controls.Add(Me.tbsnakeyicon)
        Me.pnl_panelbuttonsnakey.Controls.Add(Me.tbsnakeytext)
        Me.pnl_panelbuttonsnakey.Location = New System.Drawing.Point(614, 3)
        Me.pnl_panelbuttonsnakey.Name = "pnl_panelbuttonsnakey"
        Me.pnl_panelbuttonsnakey.Size = New System.Drawing.Size(32, 20)
        Me.pnl_panelbuttonsnakey.TabIndex = 25
        Me.pnl_panelbuttonsnakey.Visible = False
        '
        'tbsnakeyicon
        '
        Me.tbsnakeyicon.BackColor = System.Drawing.Color.Transparent
        Me.tbsnakeyicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbsnakeyicon.Image = Global.ShiftOS.My.Resources.Resources.iconSnakey
        Me.tbsnakeyicon.Location = New System.Drawing.Point(4, 2)
        Me.tbsnakeyicon.Name = "tbsnakeyicon"
        Me.tbsnakeyicon.Size = New System.Drawing.Size(16, 16)
        Me.tbsnakeyicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbsnakeyicon.TabIndex = 1
        Me.tbsnakeyicon.TabStop = False
        '
        'tbsnakeytext
        '
        Me.tbsnakeytext.AutoSize = True
        Me.tbsnakeytext.BackColor = System.Drawing.Color.Transparent
        Me.tbsnakeytext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbsnakeytext.ForeColor = System.Drawing.Color.White
        Me.tbsnakeytext.Location = New System.Drawing.Point(22, 2)
        Me.tbsnakeytext.Name = "tbsnakeytext"
        Me.tbsnakeytext.Size = New System.Drawing.Size(126, 16)
        Me.tbsnakeytext.TabIndex = 0
        Me.tbsnakeytext.Text = "Download Manager"
        '
        'pnlpanelbuttonorcwrite
        '
        Me.pnlpanelbuttonorcwrite.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonorcwrite.Controls.Add(Me.tborcwriteicon)
        Me.pnlpanelbuttonorcwrite.Controls.Add(Me.tborcwritetext)
        Me.pnlpanelbuttonorcwrite.Location = New System.Drawing.Point(652, 3)
        Me.pnlpanelbuttonorcwrite.Name = "pnlpanelbuttonorcwrite"
        Me.pnlpanelbuttonorcwrite.Size = New System.Drawing.Size(32, 20)
        Me.pnlpanelbuttonorcwrite.TabIndex = 26
        Me.pnlpanelbuttonorcwrite.Visible = False
        '
        'tborcwriteicon
        '
        Me.tborcwriteicon.BackColor = System.Drawing.Color.Transparent
        Me.tborcwriteicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tborcwriteicon.Image = Global.ShiftOS.My.Resources.Resources.floodgateicn
        Me.tborcwriteicon.Location = New System.Drawing.Point(4, 2)
        Me.tborcwriteicon.Name = "tborcwriteicon"
        Me.tborcwriteicon.Size = New System.Drawing.Size(16, 16)
        Me.tborcwriteicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tborcwriteicon.TabIndex = 1
        Me.tborcwriteicon.TabStop = False
        '
        'tborcwritetext
        '
        Me.tborcwritetext.AutoSize = True
        Me.tborcwritetext.BackColor = System.Drawing.Color.Transparent
        Me.tborcwritetext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tborcwritetext.ForeColor = System.Drawing.Color.White
        Me.tborcwritetext.Location = New System.Drawing.Point(22, 2)
        Me.tborcwritetext.Name = "tborcwritetext"
        Me.tborcwritetext.Size = New System.Drawing.Size(126, 16)
        Me.tborcwritetext.TabIndex = 0
        Me.tborcwritetext.Text = "Download Manager"
        '
        'pnlpanelbuttonsnakey
        '
        Me.pnlpanelbuttonsnakey.AutoSize = True
        Me.pnlpanelbuttonsnakey.BackColor = System.Drawing.Color.Transparent
        Me.pnlpanelbuttonsnakey.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pnlpanelbuttonsnakey.ForeColor = System.Drawing.Color.White
        Me.pnlpanelbuttonsnakey.Location = New System.Drawing.Point(690, 0)
        Me.pnlpanelbuttonsnakey.Name = "pnlpanelbuttonsnakey"
        Me.pnlpanelbuttonsnakey.Size = New System.Drawing.Size(0, 16)
        Me.pnlpanelbuttonsnakey.TabIndex = 24
        '
        'pnlpanelbuttonfloodgate
        '
        Me.pnlpanelbuttonfloodgate.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonfloodgate.Controls.Add(Me.tbfloodgateicon)
        Me.pnlpanelbuttonfloodgate.Controls.Add(Me.tbfloodgatetext)
        Me.pnlpanelbuttonfloodgate.Location = New System.Drawing.Point(696, 3)
        Me.pnlpanelbuttonfloodgate.Name = "pnlpanelbuttonfloodgate"
        Me.pnlpanelbuttonfloodgate.Size = New System.Drawing.Size(32, 20)
        Me.pnlpanelbuttonfloodgate.TabIndex = 27
        Me.pnlpanelbuttonfloodgate.Visible = False
        '
        'tbfloodgateicon
        '
        Me.tbfloodgateicon.BackColor = System.Drawing.Color.Transparent
        Me.tbfloodgateicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbfloodgateicon.Image = Global.ShiftOS.My.Resources.Resources.iconSnakey
        Me.tbfloodgateicon.Location = New System.Drawing.Point(4, 2)
        Me.tbfloodgateicon.Name = "tbfloodgateicon"
        Me.tbfloodgateicon.Size = New System.Drawing.Size(16, 16)
        Me.tbfloodgateicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbfloodgateicon.TabIndex = 1
        Me.tbfloodgateicon.TabStop = False
        '
        'tbfloodgatetext
        '
        Me.tbfloodgatetext.AutoSize = True
        Me.tbfloodgatetext.BackColor = System.Drawing.Color.Transparent
        Me.tbfloodgatetext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbfloodgatetext.ForeColor = System.Drawing.Color.White
        Me.tbfloodgatetext.Location = New System.Drawing.Point(22, 2)
        Me.tbfloodgatetext.Name = "tbfloodgatetext"
        Me.tbfloodgatetext.Size = New System.Drawing.Size(126, 16)
        Me.tbfloodgatetext.TabIndex = 0
        Me.tbfloodgatetext.Text = "Download Manager"
        '
        'pnlpanelbuttonmaze
        '
        Me.pnlpanelbuttonmaze.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonmaze.Controls.Add(Me.tbmazeicon)
        Me.pnlpanelbuttonmaze.Controls.Add(Me.tbmazetext)
        Me.pnlpanelbuttonmaze.Location = New System.Drawing.Point(734, 3)
        Me.pnlpanelbuttonmaze.Name = "pnlpanelbuttonmaze"
        Me.pnlpanelbuttonmaze.Size = New System.Drawing.Size(32, 20)
        Me.pnlpanelbuttonmaze.TabIndex = 28
        Me.pnlpanelbuttonmaze.Visible = False
        '
        'tbmazeicon
        '
        Me.tbmazeicon.BackColor = System.Drawing.Color.Transparent
        Me.tbmazeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbmazeicon.Image = Global.ShiftOS.My.Resources.Resources.iconSnakey
        Me.tbmazeicon.Location = New System.Drawing.Point(4, 2)
        Me.tbmazeicon.Name = "tbmazeicon"
        Me.tbmazeicon.Size = New System.Drawing.Size(16, 16)
        Me.tbmazeicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbmazeicon.TabIndex = 1
        Me.tbmazeicon.TabStop = False
        '
        'tbmazetext
        '
        Me.tbmazetext.AutoSize = True
        Me.tbmazetext.BackColor = System.Drawing.Color.Transparent
        Me.tbmazetext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbmazetext.ForeColor = System.Drawing.Color.White
        Me.tbmazetext.Location = New System.Drawing.Point(22, 2)
        Me.tbmazetext.Name = "tbmazetext"
        Me.tbmazetext.Size = New System.Drawing.Size(126, 16)
        Me.tbmazetext.TabIndex = 0
        Me.tbmazetext.Text = "Download Manager"
        '
        'pnlpanelbuttonvirusscanner
        '
        Me.pnlpanelbuttonvirusscanner.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonvirusscanner.Controls.Add(Me.tbvirusscannericon)
        Me.pnlpanelbuttonvirusscanner.Controls.Add(Me.tbvirusscannertext)
        Me.pnlpanelbuttonvirusscanner.Location = New System.Drawing.Point(772, 3)
        Me.pnlpanelbuttonvirusscanner.Name = "pnlpanelbuttonvirusscanner"
        Me.pnlpanelbuttonvirusscanner.Size = New System.Drawing.Size(32, 20)
        Me.pnlpanelbuttonvirusscanner.TabIndex = 28
        Me.pnlpanelbuttonvirusscanner.Visible = False
        '
        'tbvirusscannericon
        '
        Me.tbvirusscannericon.BackColor = System.Drawing.Color.Transparent
        Me.tbvirusscannericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbvirusscannericon.Image = Global.ShiftOS.My.Resources.Resources.iconSnakey
        Me.tbvirusscannericon.Location = New System.Drawing.Point(4, 2)
        Me.tbvirusscannericon.Name = "tbvirusscannericon"
        Me.tbvirusscannericon.Size = New System.Drawing.Size(16, 16)
        Me.tbvirusscannericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbvirusscannericon.TabIndex = 1
        Me.tbvirusscannericon.TabStop = False
        '
        'tbvirusscannertext
        '
        Me.tbvirusscannertext.AutoSize = True
        Me.tbvirusscannertext.BackColor = System.Drawing.Color.Transparent
        Me.tbvirusscannertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbvirusscannertext.ForeColor = System.Drawing.Color.White
        Me.tbvirusscannertext.Location = New System.Drawing.Point(22, 2)
        Me.tbvirusscannertext.Name = "tbvirusscannertext"
        Me.tbvirusscannertext.Size = New System.Drawing.Size(126, 16)
        Me.tbvirusscannertext.TabIndex = 0
        Me.tbvirusscannertext.Text = "Download Manager"
        '
        'pnlpanelbuttonfilesaver
        '
        Me.pnlpanelbuttonfilesaver.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonfilesaver.Controls.Add(Me.tbfilesavericon)
        Me.pnlpanelbuttonfilesaver.Controls.Add(Me.tbfilesavertext)
        Me.pnlpanelbuttonfilesaver.Location = New System.Drawing.Point(810, 3)
        Me.pnlpanelbuttonfilesaver.Name = "pnlpanelbuttonfilesaver"
        Me.pnlpanelbuttonfilesaver.Size = New System.Drawing.Size(52, 20)
        Me.pnlpanelbuttonfilesaver.TabIndex = 29
        Me.pnlpanelbuttonfilesaver.Visible = False
        '
        'tbfilesavericon
        '
        Me.tbfilesavericon.BackColor = System.Drawing.Color.Transparent
        Me.tbfilesavericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbfilesavericon.Image = Global.ShiftOS.My.Resources.Resources.iconFileSaver
        Me.tbfilesavericon.Location = New System.Drawing.Point(4, 2)
        Me.tbfilesavericon.Name = "tbfilesavericon"
        Me.tbfilesavericon.Size = New System.Drawing.Size(16, 16)
        Me.tbfilesavericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbfilesavericon.TabIndex = 1
        Me.tbfilesavericon.TabStop = False
        '
        'tbfilesavertext
        '
        Me.tbfilesavertext.AutoSize = True
        Me.tbfilesavertext.BackColor = System.Drawing.Color.Transparent
        Me.tbfilesavertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbfilesavertext.ForeColor = System.Drawing.Color.White
        Me.tbfilesavertext.Location = New System.Drawing.Point(24, 2)
        Me.tbfilesavertext.Name = "tbfilesavertext"
        Me.tbfilesavertext.Size = New System.Drawing.Size(69, 16)
        Me.tbfilesavertext.TabIndex = 0
        Me.tbfilesavertext.Text = "File Saver"
        '
        'pnlpanelbuttonshifter
        '
        Me.pnlpanelbuttonshifter.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonshifter.Controls.Add(Me.tbshiftericon)
        Me.pnlpanelbuttonshifter.Controls.Add(Me.tbshiftertext)
        Me.pnlpanelbuttonshifter.Location = New System.Drawing.Point(868, 3)
        Me.pnlpanelbuttonshifter.Name = "pnlpanelbuttonshifter"
        Me.pnlpanelbuttonshifter.Size = New System.Drawing.Size(52, 20)
        Me.pnlpanelbuttonshifter.TabIndex = 30
        Me.pnlpanelbuttonshifter.Visible = False
        '
        'tbshiftericon
        '
        Me.tbshiftericon.BackColor = System.Drawing.Color.Transparent
        Me.tbshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbshiftericon.Image = Global.ShiftOS.My.Resources.Resources.iconShifter
        Me.tbshiftericon.Location = New System.Drawing.Point(4, 2)
        Me.tbshiftericon.Name = "tbshiftericon"
        Me.tbshiftericon.Size = New System.Drawing.Size(16, 16)
        Me.tbshiftericon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbshiftericon.TabIndex = 1
        Me.tbshiftericon.TabStop = False
        '
        'tbshiftertext
        '
        Me.tbshiftertext.AutoSize = True
        Me.tbshiftertext.BackColor = System.Drawing.Color.Transparent
        Me.tbshiftertext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbshiftertext.ForeColor = System.Drawing.Color.White
        Me.tbshiftertext.Location = New System.Drawing.Point(24, 2)
        Me.tbshiftertext.Name = "tbshiftertext"
        Me.tbshiftertext.Size = New System.Drawing.Size(45, 16)
        Me.tbshiftertext.TabIndex = 0
        Me.tbshiftertext.Text = "Shifter"
        '
        'applaunchermenuholder
        '
        Me.applaunchermenuholder.Controls.Add(Me.desktopappmenu)
        Me.applaunchermenuholder.Dock = System.Windows.Forms.DockStyle.Left
        Me.applaunchermenuholder.Location = New System.Drawing.Point(0, 0)
        Me.applaunchermenuholder.Name = "applaunchermenuholder"
        Me.applaunchermenuholder.Size = New System.Drawing.Size(130, 24)
        Me.applaunchermenuholder.TabIndex = 3
        '
        'desktopappmenu
        '
        Me.desktopappmenu.AutoSize = False
        Me.desktopappmenu.BackColor = System.Drawing.Color.Transparent
        Me.desktopappmenu.GripMargin = New System.Windows.Forms.Padding(0)
        Me.desktopappmenu.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.desktopappmenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplicationsToolStripMenuItem})
        Me.desktopappmenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.desktopappmenu.Location = New System.Drawing.Point(0, 0)
        Me.desktopappmenu.Name = "desktopappmenu"
        Me.desktopappmenu.Padding = New System.Windows.Forms.Padding(0)
        Me.desktopappmenu.Size = New System.Drawing.Size(130, 24)
        Me.desktopappmenu.TabIndex = 0
        Me.desktopappmenu.TabStop = True
        Me.desktopappmenu.Text = "MenuStrip1"
        '
        'ApplicationsToolStripMenuItem
        '
        Me.ApplicationsToolStripMenuItem.AutoSize = False
        Me.ApplicationsToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ApplicationsToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ApplicationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArtpadToolStripMenuItem, Me.AudioplayerToolStripMenuItem, Me.BitnoteDiggerToolStripMenuItem, Me.BitnoteWalletToolStripMenuItem, Me.CalculatorToolStripMenuItem, Me.CatalystToolStripMenuItem1, Me.ClockToolStripMenuItem, Me.DodgeToolStripMenuItem, Me.downloadmanagerToolStripMenuItem, Me.FileSkimmerToolStripMenuItem, Me.FloodGateToolStripMenuItem, Me.IconManagerToolStripMenuItem, Me.InstallerToolStripMenuItem, Me.KnowledgeInputToolStripMenuItem, Me.MazeToolStripMenuItem, Me.NameChangerToolStripMenuItem, Me.orcwriteToolStripMenuItem, Me.PongToolStripMenuItem, Me.ShifterToolStripMenuItem, Me.ShiftnetToolStripMenuItem, Me.ShiftoriumToolStripMenuItem, Me.SkinLoaderToolStripMenuItem, Me.SkinShifterToolStripMenuItem, Me.SnakeyToolStripMenuItem, Me.sysinfoToolStripMenuItem, Me.TerminalToolStripMenuItem, Me.TextPadToolStripMenuItem, Me.WebBrowserToolStripMenuItem, Me.VideoplayerToolStripMenuItem, Me.VirusScannerToolStripMenuItem, Me.unitySeperator, Me.UnityToolStripMenuItem, Me.ShutdownToolStripMenuItem})
        Me.ApplicationsToolStripMenuItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ApplicationsToolStripMenuItem.Name = "ApplicationsToolStripMenuItem"
        Me.ApplicationsToolStripMenuItem.Padding = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.ApplicationsToolStripMenuItem.ShowShortcutKeys = False
        Me.ApplicationsToolStripMenuItem.Size = New System.Drawing.Size(94, 24)
        Me.ApplicationsToolStripMenuItem.Text = "Applications"
        Me.ApplicationsToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        Me.ApplicationsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ArtpadToolStripMenuItem
        '
        Me.ArtpadToolStripMenuItem.Name = "ArtpadToolStripMenuItem"
        Me.ArtpadToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ArtpadToolStripMenuItem.Text = "ArtPad"
        '
        'AudioplayerToolStripMenuItem
        '
        Me.AudioplayerToolStripMenuItem.Name = "AudioplayerToolStripMenuItem"
        Me.AudioplayerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.AudioplayerToolStripMenuItem.Text = "Audio Player"
        '
        'BitnoteDiggerToolStripMenuItem
        '
        Me.BitnoteDiggerToolStripMenuItem.Name = "BitnoteDiggerToolStripMenuItem"
        Me.BitnoteDiggerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.BitnoteDiggerToolStripMenuItem.Text = "Bitnote Digger"
        '
        'BitnoteWalletToolStripMenuItem
        '
        Me.BitnoteWalletToolStripMenuItem.Name = "BitnoteWalletToolStripMenuItem"
        Me.BitnoteWalletToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.BitnoteWalletToolStripMenuItem.Text = "Bitnote Wallet"
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'ClockToolStripMenuItem
        '
        Me.ClockToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ClockToolStripMenuItem.Name = "ClockToolStripMenuItem"
        Me.ClockToolStripMenuItem.ShowShortcutKeys = False
        Me.ClockToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ClockToolStripMenuItem.Text = "Clock"
        '
        'DodgeToolStripMenuItem
        '
        Me.DodgeToolStripMenuItem.Name = "DodgeToolStripMenuItem"
        Me.DodgeToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.DodgeToolStripMenuItem.Text = "Dodge"
        '
        'downloadmanagerToolStripMenuItem
        '
        Me.downloadmanagerToolStripMenuItem.Name = "downloadmanagerToolStripMenuItem"
        Me.downloadmanagerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.downloadmanagerToolStripMenuItem.Text = "Download Manager"
        '
        'FileSkimmerToolStripMenuItem
        '
        Me.FileSkimmerToolStripMenuItem.Name = "FileSkimmerToolStripMenuItem"
        Me.FileSkimmerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.FileSkimmerToolStripMenuItem.Text = "File Skimmer"
        '
        'FloodGateToolStripMenuItem
        '
        Me.FloodGateToolStripMenuItem.Name = "FloodGateToolStripMenuItem"
        Me.FloodGateToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.FloodGateToolStripMenuItem.Text = "FloodGate Manager"
        '
        'IconManagerToolStripMenuItem
        '
        Me.IconManagerToolStripMenuItem.Name = "IconManagerToolStripMenuItem"
        Me.IconManagerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.IconManagerToolStripMenuItem.Text = "Icon Manager"
        '
        'InstallerToolStripMenuItem
        '
        Me.InstallerToolStripMenuItem.Name = "InstallerToolStripMenuItem"
        Me.InstallerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.InstallerToolStripMenuItem.Text = "Installer"
        '
        'KnowledgeInputToolStripMenuItem
        '
        Me.KnowledgeInputToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.KnowledgeInputToolStripMenuItem.Name = "KnowledgeInputToolStripMenuItem"
        Me.KnowledgeInputToolStripMenuItem.ShowShortcutKeys = False
        Me.KnowledgeInputToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.KnowledgeInputToolStripMenuItem.Text = "Knowledge Input"
        '
        'MazeToolStripMenuItem
        '
        Me.MazeToolStripMenuItem.Name = "MazeToolStripMenuItem"
        Me.MazeToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.MazeToolStripMenuItem.Text = "Labyrinth"
        '
        'NameChangerToolStripMenuItem
        '
        Me.NameChangerToolStripMenuItem.Name = "NameChangerToolStripMenuItem"
        Me.NameChangerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.NameChangerToolStripMenuItem.Text = "Name Changer"
        '
        'orcwriteToolStripMenuItem
        '
        Me.orcwriteToolStripMenuItem.Name = "orcwriteToolStripMenuItem"
        Me.orcwriteToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.orcwriteToolStripMenuItem.Text = "OrcWrite"
        '
        'PongToolStripMenuItem
        '
        Me.PongToolStripMenuItem.Name = "PongToolStripMenuItem"
        Me.PongToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.PongToolStripMenuItem.Text = "Pong"
        '
        'ShifterToolStripMenuItem
        '
        Me.ShifterToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShifterToolStripMenuItem.Name = "ShifterToolStripMenuItem"
        Me.ShifterToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ShifterToolStripMenuItem.Text = "Shifter"
        '
        'CatalystToolStripMenuItem1
        '
        Me.CatalystToolStripMenuItem1.Name = "CatalystToolStripMenuItem1"
        Me.CatalystToolStripMenuItem1.Size = New System.Drawing.Size(214, 22)
        Me.CatalystToolStripMenuItem1.Text = "Catalyst"
        '
        'ShiftnetToolStripMenuItem
        '
        Me.ShiftnetToolStripMenuItem.Name = "ShiftnetToolStripMenuItem"
        Me.ShiftnetToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ShiftnetToolStripMenuItem.Text = "Shiftnet"
        '
        'ShiftoriumToolStripMenuItem
        '
        Me.ShiftoriumToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShiftoriumToolStripMenuItem.Name = "ShiftoriumToolStripMenuItem"
        Me.ShiftoriumToolStripMenuItem.ShowShortcutKeys = False
        Me.ShiftoriumToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ShiftoriumToolStripMenuItem.Text = "Shiftorium"
        '
        'SkinLoaderToolStripMenuItem
        '
        Me.SkinLoaderToolStripMenuItem.Name = "SkinLoaderToolStripMenuItem"
        Me.SkinLoaderToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.SkinLoaderToolStripMenuItem.Text = "Skin Loader"
        '
        'SkinShifterToolStripMenuItem
        '
        Me.SkinShifterToolStripMenuItem.Name = "SkinShifterToolStripMenuItem"
        Me.SkinShifterToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.SkinShifterToolStripMenuItem.Text = "Skin Shifter"
        '
        'SnakeyToolStripMenuItem
        '
        Me.SnakeyToolStripMenuItem.Name = "SnakeyToolStripMenuItem"
        Me.SnakeyToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.SnakeyToolStripMenuItem.Text = "Snakey"
        '
        'sysinfoToolStripMenuItem
        '
        Me.sysinfoToolStripMenuItem.Name = "sysinfoToolStripMenuItem"
        Me.sysinfoToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.sysinfoToolStripMenuItem.Text = "System Information"
        '
        'TerminalToolStripMenuItem
        '
        Me.TerminalToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.TerminalToolStripMenuItem.Name = "TerminalToolStripMenuItem"
        Me.TerminalToolStripMenuItem.ShowShortcutKeys = False
        Me.TerminalToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.TerminalToolStripMenuItem.Text = "Terminal"
        '
        'TextPadToolStripMenuItem
        '
        Me.TextPadToolStripMenuItem.Name = "TextPadToolStripMenuItem"
        Me.TextPadToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.TextPadToolStripMenuItem.Text = "TextPad"
        '
        'WebBrowserToolStripMenuItem
        '
        Me.WebBrowserToolStripMenuItem.Name = "WebBrowserToolStripMenuItem"
        Me.WebBrowserToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.WebBrowserToolStripMenuItem.Text = "Web Browser"
        '
        'VideoplayerToolStripMenuItem
        '
        Me.VideoplayerToolStripMenuItem.Name = "VideoplayerToolStripMenuItem"
        Me.VideoplayerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.VideoplayerToolStripMenuItem.Text = "Video Player"
        '
        'VirusScannerToolStripMenuItem
        '
        Me.VirusScannerToolStripMenuItem.Name = "VirusScannerToolStripMenuItem"
        Me.VirusScannerToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.VirusScannerToolStripMenuItem.Text = "Virus Scanner"
        '
        'unitySeperator
        '
        Me.unitySeperator.BackColor = System.Drawing.Color.Transparent
        Me.unitySeperator.ForeColor = System.Drawing.Color.White
        Me.unitySeperator.Name = "unitySeperator"
        Me.unitySeperator.Size = New System.Drawing.Size(211, 6)
        '
        'UnityToolStripMenuItem
        '
        Me.UnityToolStripMenuItem.Name = "UnityToolStripMenuItem"
        Me.UnityToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.UnityToolStripMenuItem.Text = "Toggle Unity Mode"
        '
        'ShutdownToolStripMenuItem
        '
        Me.ShutdownToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.ShutdownToolStripMenuItem.Name = "ShutdownToolStripMenuItem"
        Me.ShutdownToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ShutdownToolStripMenuItem.Text = "Shut Down"
        '
        'timepanel
        '
        Me.timepanel.Controls.Add(Me.paneltimetext)
        Me.timepanel.Dock = System.Windows.Forms.DockStyle.Right
        Me.timepanel.Location = New System.Drawing.Point(1171, 0)
        Me.timepanel.Name = "timepanel"
        Me.timepanel.Size = New System.Drawing.Size(97, 24)
        Me.timepanel.TabIndex = 2
        '
        'paneltimetext
        '
        Me.paneltimetext.AutoSize = True
        Me.paneltimetext.BackColor = System.Drawing.Color.Transparent
        Me.paneltimetext.Font = New System.Drawing.Font("Trebuchet MS", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.paneltimetext.Location = New System.Drawing.Point(5, 0)
        Me.paneltimetext.Name = "paneltimetext"
        Me.paneltimetext.Size = New System.Drawing.Size(80, 24)
        Me.paneltimetext.TabIndex = 1
        Me.paneltimetext.Text = "5000023"
        Me.paneltimetext.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlpanelbuttonfloatybird
        '
        Me.pnlpanelbuttonfloatybird.BackColor = System.Drawing.Color.Black
        Me.pnlpanelbuttonfloatybird.Controls.Add(Me.tbfloatybirdicon)
        Me.pnlpanelbuttonfloatybird.Controls.Add(Me.tbfloatybirdtext)
        Me.pnlpanelbuttonfloatybird.Location = New System.Drawing.Point(5, 29)
        Me.pnlpanelbuttonfloatybird.Name = "pnlpanelbuttonfloatybird"
        Me.pnlpanelbuttonfloatybird.Size = New System.Drawing.Size(52, 20)
        Me.pnlpanelbuttonfloatybird.TabIndex = 31
        Me.pnlpanelbuttonfloatybird.Visible = False
        '
        'tbfloatybirdicon
        '
        Me.tbfloatybirdicon.BackColor = System.Drawing.Color.Transparent
        Me.tbfloatybirdicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tbfloatybirdicon.Image = Global.ShiftOS.My.Resources.Resources.iconShifter
        Me.tbfloatybirdicon.Location = New System.Drawing.Point(4, 2)
        Me.tbfloatybirdicon.Name = "tbfloatybirdicon"
        Me.tbfloatybirdicon.Size = New System.Drawing.Size(16, 16)
        Me.tbfloatybirdicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.tbfloatybirdicon.TabIndex = 1
        Me.tbfloatybirdicon.TabStop = False
        '
        'tbfloatybirdtext
        '
        Me.tbfloatybirdtext.AutoSize = True
        Me.tbfloatybirdtext.BackColor = System.Drawing.Color.Transparent
        Me.tbfloatybirdtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbfloatybirdtext.ForeColor = System.Drawing.Color.White
        Me.tbfloatybirdtext.Location = New System.Drawing.Point(24, 2)
        Me.tbfloatybirdtext.Name = "tbfloatybirdtext"
        Me.tbfloatybirdtext.Size = New System.Drawing.Size(45, 16)
        Me.tbfloatybirdtext.TabIndex = 0
        Me.tbfloatybirdtext.Text = "Shifter"
        '
        'floatybirdToolStripMenuItem
        '
        Me.floatybirdToolStripMenuItem.Name = "floatybirdToolStripMenuItem"
        Me.floatybirdToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.floatybirdToolStripMenuItem.Text = "Floaty Bird"
        '
        'clocktick
        '
        Me.clocktick.Enabled = True
        Me.clocktick.Interval = 1000
        '
        'autosave
        '
        Me.autosave.Enabled = True
        Me.autosave.Interval = 60000
        '
        'nocheat
        '
        '
        'desktopicons
        '
        Me.desktopicons.Alignment = System.Windows.Forms.ListViewAlignment.Left
        Me.desktopicons.BackColor = System.Drawing.Color.Black
        Me.desktopicons.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.desktopicons.ContextMenuStrip = Me.ContextMenuStrip1
        Me.desktopicons.Dock = System.Windows.Forms.DockStyle.Fill
        Me.desktopicons.ForeColor = System.Drawing.Color.White
        Me.desktopicons.Location = New System.Drawing.Point(0, 24)
        Me.desktopicons.Name = "desktopicons"
        Me.desktopicons.Scrollable = False
        Me.desktopicons.Size = New System.Drawing.Size(1268, 661)
        Me.desktopicons.TabIndex = 1
        Me.desktopicons.UseCompatibleStateImageBehavior = False
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.ToolStripMenuItem3, Me.TileViewToolStripMenuItem, Me.fileActionsSeparator, Me.AboutToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(170, 82)
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FolderToolStripMenuItem, Me.ToolStripMenuItem2, Me.ArtpadPictureToolStripMenuItem, Me.TextDocumentToolStripMenuItem, Me.OrcWriteDocumentToolStripMenuItem, Me.SystemInformationReportToolStripMenuItem, Me.NewSkin, Me.WebpageToolStripMenuItem, Me.ShortcutToolStripMenuItem})
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'FolderToolStripMenuItem
        '
        Me.FolderToolStripMenuItem.Name = "FolderToolStripMenuItem"
        Me.FolderToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.FolderToolStripMenuItem.Text = "Folder"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(213, 6)
        '
        'ArtpadPictureToolStripMenuItem
        '
        Me.ArtpadPictureToolStripMenuItem.Name = "ArtpadPictureToolStripMenuItem"
        Me.ArtpadPictureToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.ArtpadPictureToolStripMenuItem.Text = "Artpad Picture"
        '
        'TextDocumentToolStripMenuItem
        '
        Me.TextDocumentToolStripMenuItem.Name = "TextDocumentToolStripMenuItem"
        Me.TextDocumentToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.TextDocumentToolStripMenuItem.Text = "Text Document"
        '
        'OrcWriteDocumentToolStripMenuItem
        '
        Me.OrcWriteDocumentToolStripMenuItem.Name = "OrcWriteDocumentToolStripMenuItem"
        Me.OrcWriteDocumentToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.OrcWriteDocumentToolStripMenuItem.Text = "OrcWrite Document"
        '
        'SystemInformationReportToolStripMenuItem
        '
        Me.SystemInformationReportToolStripMenuItem.Name = "SystemInformationReportToolStripMenuItem"
        Me.SystemInformationReportToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.SystemInformationReportToolStripMenuItem.Text = "System Information Report"
        '
        'NewSkin
        '
        Me.NewSkin.Name = "NewSkin"
        Me.NewSkin.Size = New System.Drawing.Size(216, 22)
        Me.NewSkin.Text = "Skin"
        '
        'WebpageToolStripMenuItem
        '
        Me.WebpageToolStripMenuItem.Name = "WebpageToolStripMenuItem"
        Me.WebpageToolStripMenuItem.Size = New System.Drawing.Size(213, 6)
        '
        'ShortcutToolStripMenuItem
        '
        Me.ShortcutToolStripMenuItem.Name = "ShortcutToolStripMenuItem"
        Me.ShortcutToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.ShortcutToolStripMenuItem.Text = "Shortcut"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(166, 6)
        '
        'TileViewToolStripMenuItem
        '
        Me.TileViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RenameToolStripMenuItem, Me.DeleteToolStripMenuItem})
        Me.TileViewToolStripMenuItem.Name = "TileViewToolStripMenuItem"
        Me.TileViewToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.TileViewToolStripMenuItem.Text = "File Actions"
        '
        'RenameToolStripMenuItem
        '
        Me.RenameToolStripMenuItem.Name = "RenameToolStripMenuItem"
        Me.RenameToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.RenameToolStripMenuItem.Text = "Rename"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'fileActionsSeparator
        '
        Me.fileActionsSeparator.Name = "fileActionsSeparator"
        Me.fileActionsSeparator.Size = New System.Drawing.Size(166, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(169, 22)
        Me.AboutToolStripMenuItem.Text = "About Desktop++"
        '
        'pnladvapplauncher
        '
        Me.pnladvapplauncher.BackColor = System.Drawing.Color.Gray
        Me.pnladvapplauncher.Controls.Add(Me.pnladvmain)
        Me.pnladvapplauncher.Controls.Add(Me.pnladvplaces)
        Me.pnladvapplauncher.Controls.Add(Me.pnladvbottombar)
        Me.pnladvapplauncher.Controls.Add(Me.pnladvtopbar)
        Me.pnladvapplauncher.Location = New System.Drawing.Point(0, 24)
        Me.pnladvapplauncher.Name = "pnladvapplauncher"
        Me.pnladvapplauncher.Size = New System.Drawing.Size(320, 526)
        Me.pnladvapplauncher.TabIndex = 2
        Me.pnladvapplauncher.Visible = False
        '
        'pnladvmain
        '
        Me.pnladvmain.BackColor = System.Drawing.Color.Black
        Me.pnladvmain.Controls.Add(Me.tscadvmainframe)
        Me.pnladvmain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnladvmain.Location = New System.Drawing.Point(0, 55)
        Me.pnladvmain.Name = "pnladvmain"
        Me.pnladvmain.Size = New System.Drawing.Size(184, 427)
        Me.pnladvmain.TabIndex = 3
        '
        'tscadvmainframe
        '
        '
        'tscadvmainframe.BottomToolStripPanel
        '
        Me.tscadvmainframe.BottomToolStripPanel.Controls.Add(Me.ToolStrip1)
        '
        'tscadvmainframe.ContentPanel
        '
        Me.tscadvmainframe.ContentPanel.Controls.Add(Me.lvadvfiles)
        Me.tscadvmainframe.ContentPanel.Size = New System.Drawing.Size(184, 377)
        Me.tscadvmainframe.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tscadvmainframe.Location = New System.Drawing.Point(0, 0)
        Me.tscadvmainframe.Name = "tscadvmainframe"
        Me.tscadvmainframe.Size = New System.Drawing.Size(184, 427)
        Me.tscadvmainframe.TabIndex = 0
        Me.tscadvmainframe.Text = "ToolStripContainer1"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.allPrograms})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(184, 25)
        Me.ToolStrip1.Stretch = True
        Me.ToolStrip1.TabIndex = 0
        '
        'allPrograms
        '
        Me.allPrograms.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UtilitiesToolStripMenuItem, Me.SettingsToolStripMenuItem, Me.InternetToolStripMenuItem, Me.GamesToolStripMenuItem, Me.AccessoriesToolStripMenuItem})
        Me.allPrograms.Image = Global.ShiftOS.My.Resources.Resources.iconFileSkimmer
        Me.allPrograms.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.allPrograms.Name = "allPrograms"
        Me.allPrograms.Size = New System.Drawing.Size(104, 22)
        Me.allPrograms.Text = "All Programs"
        '
        'UtilitiesToolStripMenuItem
        '
        Me.UtilitiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TerminalToolStripMenuItem1, Me.FileSkimmerToolStripMenuItem1, Me.SystemInformationToolStripMenuItem})
        Me.UtilitiesToolStripMenuItem.Name = "UtilitiesToolStripMenuItem"
        Me.UtilitiesToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.UtilitiesToolStripMenuItem.Text = "Utilities"
        '
        'TerminalToolStripMenuItem1
        '
        Me.TerminalToolStripMenuItem1.Name = "TerminalToolStripMenuItem1"
        Me.TerminalToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.TerminalToolStripMenuItem1.Text = "Terminal"
        '
        'FileSkimmerToolStripMenuItem1
        '
        Me.FileSkimmerToolStripMenuItem1.Name = "FileSkimmerToolStripMenuItem1"
        Me.FileSkimmerToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.FileSkimmerToolStripMenuItem1.Text = "File Skimmer"
        '
        'SystemInformationToolStripMenuItem
        '
        Me.SystemInformationToolStripMenuItem.Name = "SystemInformationToolStripMenuItem"
        Me.SystemInformationToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.SystemInformationToolStripMenuItem.Text = "System Information"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShifterToolStripMenuItem1, Me.SkinLoaderToolStripMenuItem1, Me.SkinShifterToolStripMenuItem1, Me.IconManagerToolStripMenuItem1, Me.NameChangerToolStripMenuItem1})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'ShifterToolStripMenuItem1
        '
        Me.ShifterToolStripMenuItem1.Name = "ShifterToolStripMenuItem1"
        Me.ShifterToolStripMenuItem1.Size = New System.Drawing.Size(154, 22)
        Me.ShifterToolStripMenuItem1.Text = "Shifter"
        '
        'SkinLoaderToolStripMenuItem1
        '
        Me.SkinLoaderToolStripMenuItem1.Name = "SkinLoaderToolStripMenuItem1"
        Me.SkinLoaderToolStripMenuItem1.Size = New System.Drawing.Size(154, 22)
        Me.SkinLoaderToolStripMenuItem1.Text = "Skin Loader"
        '
        'SkinShifterToolStripMenuItem1
        '
        Me.SkinShifterToolStripMenuItem1.Name = "SkinShifterToolStripMenuItem1"
        Me.SkinShifterToolStripMenuItem1.Size = New System.Drawing.Size(154, 22)
        Me.SkinShifterToolStripMenuItem1.Text = "Skin Shifter"
        '
        'IconManagerToolStripMenuItem1
        '
        Me.IconManagerToolStripMenuItem1.Name = "IconManagerToolStripMenuItem1"
        Me.IconManagerToolStripMenuItem1.Size = New System.Drawing.Size(154, 22)
        Me.IconManagerToolStripMenuItem1.Text = "Icon Manager"
        '
        'NameChangerToolStripMenuItem1
        '
        Me.NameChangerToolStripMenuItem1.Name = "NameChangerToolStripMenuItem1"
        Me.NameChangerToolStripMenuItem1.Size = New System.Drawing.Size(154, 22)
        Me.NameChangerToolStripMenuItem1.Text = "Name Changer"
        '
        'InternetToolStripMenuItem
        '
        Me.InternetToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShiftnetToolStripMenuItem1, Me.ShiftoriumToolStripMenuItem1, Me.WebBrowserToolStripMenuItem1, Me.DownloadManagerToolStripMenuItem1, Me.InstallerToolStripMenuItem1, Me.BitnoteDiggerToolStripMenuItem1, Me.BitnoteWalletToolStripMenuItem1, Me.FloodGateManagerToolStripMenuItem, Me.VirusScannerToolStripMenuItem1, Me.CatalystToolStripMenuItem})
        Me.InternetToolStripMenuItem.Name = "InternetToolStripMenuItem"
        Me.InternetToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.InternetToolStripMenuItem.Text = "Internet"
        '
        'ShiftnetToolStripMenuItem1
        '
        Me.ShiftnetToolStripMenuItem1.Name = "ShiftnetToolStripMenuItem1"
        Me.ShiftnetToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.ShiftnetToolStripMenuItem1.Text = "Shiftnet"
        '
        'ShiftoriumToolStripMenuItem1
        '
        Me.ShiftoriumToolStripMenuItem1.Name = "ShiftoriumToolStripMenuItem1"
        Me.ShiftoriumToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.ShiftoriumToolStripMenuItem1.Text = "Shiftorium"
        '
        'WebBrowserToolStripMenuItem1
        '
        Me.WebBrowserToolStripMenuItem1.Name = "WebBrowserToolStripMenuItem1"
        Me.WebBrowserToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.WebBrowserToolStripMenuItem1.Text = "Web Browser"
        '
        'DownloadManagerToolStripMenuItem1
        '
        Me.DownloadManagerToolStripMenuItem1.Name = "DownloadManagerToolStripMenuItem1"
        Me.DownloadManagerToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.DownloadManagerToolStripMenuItem1.Text = "Download Manager"
        '
        'InstallerToolStripMenuItem1
        '
        Me.InstallerToolStripMenuItem1.Name = "InstallerToolStripMenuItem1"
        Me.InstallerToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.InstallerToolStripMenuItem1.Text = "Installer"
        '
        'BitnoteDiggerToolStripMenuItem1
        '
        Me.BitnoteDiggerToolStripMenuItem1.Name = "BitnoteDiggerToolStripMenuItem1"
        Me.BitnoteDiggerToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.BitnoteDiggerToolStripMenuItem1.Text = "Bitnote Digger"
        '
        'BitnoteWalletToolStripMenuItem1
        '
        Me.BitnoteWalletToolStripMenuItem1.Name = "BitnoteWalletToolStripMenuItem1"
        Me.BitnoteWalletToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.BitnoteWalletToolStripMenuItem1.Text = "Bitnote Wallet"
        '
        'FloodGateManagerToolStripMenuItem
        '
        Me.FloodGateManagerToolStripMenuItem.Name = "FloodGateManagerToolStripMenuItem"
        Me.FloodGateManagerToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.FloodGateManagerToolStripMenuItem.Text = "FloodGate Manager"
        '
        'VirusScannerToolStripMenuItem1
        '
        Me.VirusScannerToolStripMenuItem1.Name = "VirusScannerToolStripMenuItem1"
        Me.VirusScannerToolStripMenuItem1.Size = New System.Drawing.Size(178, 22)
        Me.VirusScannerToolStripMenuItem1.Text = "Virus Scanner"
        '
        'CatalystToolStripMenuItem
        '
        Me.CatalystToolStripMenuItem.Name = "CatalystToolStripMenuItem"
        Me.CatalystToolStripMenuItem.Size = New System.Drawing.Size(178, 22)
        Me.CatalystToolStripMenuItem.Text = "Catalyst"
        '
        'GamesToolStripMenuItem
        '
        Me.GamesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DodgeToolStripMenuItem1, Me.SnakeyToolStripMenuItem1, Me.PongToolStripMenuItem1, Me.KnowledgeInputToolStripMenuItem1, Me.LabyrinthToolStripMenuItem})
        Me.GamesToolStripMenuItem.Name = "GamesToolStripMenuItem"
        Me.GamesToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.GamesToolStripMenuItem.Text = "Games"
        '
        'DodgeToolStripMenuItem1
        '
        Me.DodgeToolStripMenuItem1.Name = "DodgeToolStripMenuItem1"
        Me.DodgeToolStripMenuItem1.Size = New System.Drawing.Size(164, 22)
        Me.DodgeToolStripMenuItem1.Text = "Dodge"
        '
        'SnakeyToolStripMenuItem1
        '
        Me.SnakeyToolStripMenuItem1.Name = "SnakeyToolStripMenuItem1"
        Me.SnakeyToolStripMenuItem1.Size = New System.Drawing.Size(164, 22)
        Me.SnakeyToolStripMenuItem1.Text = "Snakey"
        '
        'PongToolStripMenuItem1
        '
        Me.PongToolStripMenuItem1.Name = "PongToolStripMenuItem1"
        Me.PongToolStripMenuItem1.Size = New System.Drawing.Size(164, 22)
        Me.PongToolStripMenuItem1.Text = "Pong"
        '
        'KnowledgeInputToolStripMenuItem1
        '
        Me.KnowledgeInputToolStripMenuItem1.Name = "KnowledgeInputToolStripMenuItem1"
        Me.KnowledgeInputToolStripMenuItem1.Size = New System.Drawing.Size(164, 22)
        Me.KnowledgeInputToolStripMenuItem1.Text = "Knowledge Input"
        '
        'LabyrinthToolStripMenuItem
        '
        Me.LabyrinthToolStripMenuItem.Name = "LabyrinthToolStripMenuItem"
        Me.LabyrinthToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.LabyrinthToolStripMenuItem.Text = "Labyrinth"
        '
        'AccessoriesToolStripMenuItem
        '
        Me.AccessoriesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArtpadToolStripMenuItem1, Me.TextpadToolStripMenuItem1, Me.OrcWriteToolStripMenuItem1, Me.AudioPlayerToolStripMenuItem1, Me.VideoPlayerToolStripMenuItem1, Me.ClockToolStripMenuItem1, Me.CalculatorToolStripMenuItem1})
        Me.AccessoriesToolStripMenuItem.Name = "AccessoriesToolStripMenuItem"
        Me.AccessoriesToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.AccessoriesToolStripMenuItem.Text = "Accessories"
        '
        'ArtpadToolStripMenuItem1
        '
        Me.ArtpadToolStripMenuItem1.Name = "ArtpadToolStripMenuItem1"
        Me.ArtpadToolStripMenuItem1.Size = New System.Drawing.Size(141, 22)
        Me.ArtpadToolStripMenuItem1.Text = "Artpad"
        '
        'TextpadToolStripMenuItem1
        '
        Me.TextpadToolStripMenuItem1.Name = "TextpadToolStripMenuItem1"
        Me.TextpadToolStripMenuItem1.Size = New System.Drawing.Size(141, 22)
        Me.TextpadToolStripMenuItem1.Text = "Textpad"
        '
        'OrcWriteToolStripMenuItem1
        '
        Me.OrcWriteToolStripMenuItem1.Name = "OrcWriteToolStripMenuItem1"
        Me.OrcWriteToolStripMenuItem1.Size = New System.Drawing.Size(141, 22)
        Me.OrcWriteToolStripMenuItem1.Text = "OrcWrite"
        '
        'AudioPlayerToolStripMenuItem1
        '
        Me.AudioPlayerToolStripMenuItem1.Name = "AudioPlayerToolStripMenuItem1"
        Me.AudioPlayerToolStripMenuItem1.Size = New System.Drawing.Size(141, 22)
        Me.AudioPlayerToolStripMenuItem1.Text = "Audio Player"
        '
        'VideoPlayerToolStripMenuItem1
        '
        Me.VideoPlayerToolStripMenuItem1.Name = "VideoPlayerToolStripMenuItem1"
        Me.VideoPlayerToolStripMenuItem1.Size = New System.Drawing.Size(141, 22)
        Me.VideoPlayerToolStripMenuItem1.Text = "Video Player"
        '
        'ClockToolStripMenuItem1
        '
        Me.ClockToolStripMenuItem1.Name = "ClockToolStripMenuItem1"
        Me.ClockToolStripMenuItem1.Size = New System.Drawing.Size(141, 22)
        Me.ClockToolStripMenuItem1.Text = "Clock"
        '
        'CalculatorToolStripMenuItem1
        '
        Me.CalculatorToolStripMenuItem1.Name = "CalculatorToolStripMenuItem1"
        Me.CalculatorToolStripMenuItem1.Size = New System.Drawing.Size(141, 22)
        Me.CalculatorToolStripMenuItem1.Text = "Calculator"
        '
        'lvadvfiles
        '
        Me.lvadvfiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lvadvfiles.Location = New System.Drawing.Point(0, 0)
        Me.lvadvfiles.Name = "lvadvfiles"
        Me.lvadvfiles.Size = New System.Drawing.Size(184, 377)
        Me.lvadvfiles.TabIndex = 0
        Me.lvadvfiles.UseCompatibleStateImageBehavior = False
        '
        'pnladvplaces
        '
        Me.pnladvplaces.BackColor = System.Drawing.Color.White
        Me.pnladvplaces.Controls.Add(Me.lvadvplaces)
        Me.pnladvplaces.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnladvplaces.Location = New System.Drawing.Point(184, 55)
        Me.pnladvplaces.Name = "pnladvplaces"
        Me.pnladvplaces.Size = New System.Drawing.Size(136, 427)
        Me.pnladvplaces.TabIndex = 2
        '
        'lvadvplaces
        '
        Me.lvadvplaces.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lvadvplaces.Location = New System.Drawing.Point(0, 0)
        Me.lvadvplaces.Name = "lvadvplaces"
        Me.lvadvplaces.Size = New System.Drawing.Size(136, 427)
        Me.lvadvplaces.TabIndex = 0
        Me.lvadvplaces.UseCompatibleStateImageBehavior = False
        Me.lvadvplaces.View = System.Windows.Forms.View.SmallIcon
        '
        'pnladvbottombar
        '
        Me.pnladvbottombar.Controls.Add(Me.btnadvshutdown)
        Me.pnladvbottombar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnladvbottombar.Location = New System.Drawing.Point(0, 482)
        Me.pnladvbottombar.Name = "pnladvbottombar"
        Me.pnladvbottombar.Size = New System.Drawing.Size(320, 44)
        Me.pnladvbottombar.TabIndex = 1
        '
        'btnadvshutdown
        '
        Me.btnadvshutdown.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnadvshutdown.FlatAppearance.BorderSize = 0
        Me.btnadvshutdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnadvshutdown.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Italic)
        Me.btnadvshutdown.ForeColor = System.Drawing.Color.White
        Me.btnadvshutdown.Image = Global.ShiftOS.My.Resources.Resources.iconshutdown
        Me.btnadvshutdown.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnadvshutdown.Location = New System.Drawing.Point(0, 0)
        Me.btnadvshutdown.Name = "btnadvshutdown"
        Me.btnadvshutdown.Size = New System.Drawing.Size(320, 44)
        Me.btnadvshutdown.TabIndex = 0
        Me.btnadvshutdown.Text = "Shut Down ShiftOS"
        Me.btnadvshutdown.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnadvshutdown.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnadvshutdown.UseVisualStyleBackColor = True
        '
        'pnladvtopbar
        '
        Me.pnladvtopbar.Controls.Add(Me.lbuser)
        Me.pnladvtopbar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnladvtopbar.Location = New System.Drawing.Point(0, 0)
        Me.pnladvtopbar.Name = "pnladvtopbar"
        Me.pnladvtopbar.Size = New System.Drawing.Size(320, 55)
        Me.pnladvtopbar.TabIndex = 0
        '
        'lbuser
        '
        Me.lbuser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbuser.Font = New System.Drawing.Font("Trebuchet MS", 12.0!, System.Drawing.FontStyle.Italic)
        Me.lbuser.ForeColor = System.Drawing.Color.White
        Me.lbuser.Location = New System.Drawing.Point(0, 0)
        Me.lbuser.Name = "lbuser"
        Me.lbuser.Size = New System.Drawing.Size(320, 55)
        Me.lbuser.TabIndex = 0
        Me.lbuser.Text = "Username"
        Me.lbuser.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ShiftOSDesktop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(1268, 685)
        Me.Controls.Add(Me.pnladvapplauncher)
        Me.Controls.Add(Me.desktopicons)
        Me.Controls.Add(Me.desktoppanel)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.desktopappmenu
        Me.Name = "ShiftOSDesktop"
        Me.Text = "ShiftOSDesktop"
        Me.desktoppanel.ResumeLayout(False)
        Me.pnlpanelbuttonholder.ResumeLayout(False)
        Me.pnlpanelbuttonholder.PerformLayout()
        Me.pnlpanelbuttonclock.ResumeLayout(False)
        Me.pnlpanelbuttonclock.PerformLayout()
        CType(Me.tbclockicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonsysinfo.ResumeLayout(False)
        Me.pnlpanelbuttonsysinfo.PerformLayout()
        CType(Me.tbsysinfoicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonskinloader.ResumeLayout(False)
        Me.pnlpanelbuttonskinloader.PerformLayout()
        CType(Me.tbskinloadericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonfileskimmer.ResumeLayout(False)
        Me.pnlpanelbuttonfileskimmer.PerformLayout()
        CType(Me.tbfileskimmericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonfileopener.ResumeLayout(False)
        Me.pnlpanelbuttonfileopener.PerformLayout()
        CType(Me.tbfileopenericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttoninfobox.ResumeLayout(False)
        Me.pnlpanelbuttoninfobox.PerformLayout()
        CType(Me.tbinfoboxicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonknowledgeinput.ResumeLayout(False)
        Me.pnlpanelbuttonknowledgeinput.PerformLayout()
        CType(Me.tbknowledgeinputicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttoncolourpicker.ResumeLayout(False)
        Me.pnlpanelbuttoncolourpicker.PerformLayout()
        CType(Me.tbcolourpickericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonshiftorium.ResumeLayout(False)
        Me.pnlpanelbuttonshiftorium.PerformLayout()
        CType(Me.tbshiftoriumicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonpong.ResumeLayout(False)
        Me.pnlpanelbuttonpong.PerformLayout()
        CType(Me.tbpongicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonterminal.ResumeLayout(False)
        Me.pnlpanelbuttonterminal.PerformLayout()
        CType(Me.tbterminalicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttontextpad.ResumeLayout(False)
        Me.pnlpanelbuttontextpad.PerformLayout()
        CType(Me.tbtextpadicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttongraphicpicker.ResumeLayout(False)
        Me.pnlpanelbuttongraphicpicker.PerformLayout()
        CType(Me.tbgraphicpickericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonartpad.ResumeLayout(False)
        Me.pnlpanelbuttonartpad.PerformLayout()
        CType(Me.tbartpadicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttoncalculator.ResumeLayout(False)
        Me.pnlpanelbuttoncalculator.PerformLayout()
        CType(Me.tbcalculatoricon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonaudioplayer.ResumeLayout(False)
        Me.pnlpanelbuttonaudioplayer.PerformLayout()
        CType(Me.tbaudioplayericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonvideoplayer.ResumeLayout(False)
        Me.pnlpanelbuttonvideoplayer.PerformLayout()
        CType(Me.tbvideoplayericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonwebbrowser.ResumeLayout(False)
        Me.pnlpanelbuttonwebbrowser.PerformLayout()
        CType(Me.tbwebbrowsericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonnamechanger.ResumeLayout(False)
        Me.pnlpanelbuttonnamechanger.PerformLayout()
        CType(Me.tbnamechangericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttoniconmanager.ResumeLayout(False)
        Me.pnlpanelbuttoniconmanager.PerformLayout()
        CType(Me.tbiconmanagericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonbitnotewallet.ResumeLayout(False)
        Me.pnlpanelbuttonbitnotewallet.PerformLayout()
        CType(Me.tbbitnotewalleticon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonbitnotedigger.ResumeLayout(False)
        Me.pnlpanelbuttonbitnotedigger.PerformLayout()
        CType(Me.tbbitnotediggericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonskinshifter.ResumeLayout(False)
        Me.pnlpanelbuttonskinshifter.PerformLayout()
        CType(Me.tbskinshiftericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttondownloader.ResumeLayout(False)
        Me.pnlpanelbuttondownloader.PerformLayout()
        CType(Me.tbdownloadericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonshiftnet.ResumeLayout(False)
        Me.pnlpanelbuttonshiftnet.PerformLayout()
        CType(Me.tbshiftneticon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttondodge.ResumeLayout(False)
        Me.pnlpanelbuttondodge.PerformLayout()
        CType(Me.tbdodgeicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttondownloadmanager.ResumeLayout(False)
        Me.pnlpanelbuttondownloadmanager.PerformLayout()
        CType(Me.tbdownloadmanagericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlcatalystpanelbutton.ResumeLayout(False)
        Me.pnlcatalystpanelbutton.PerformLayout()
        CType(Me.tbcatalysticon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttoninstaller.ResumeLayout(False)
        Me.pnlpanelbuttoninstaller.PerformLayout()
        CType(Me.tbinstallericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_panelbuttonsnakey.ResumeLayout(False)
        Me.pnl_panelbuttonsnakey.PerformLayout()
        CType(Me.tbsnakeyicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonorcwrite.ResumeLayout(False)
        Me.pnlpanelbuttonorcwrite.PerformLayout()
        CType(Me.tborcwriteicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonfloodgate.ResumeLayout(False)
        Me.pnlpanelbuttonfloodgate.PerformLayout()
        CType(Me.tbfloodgateicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonmaze.ResumeLayout(False)
        Me.pnlpanelbuttonmaze.PerformLayout()
        CType(Me.tbmazeicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonvirusscanner.ResumeLayout(False)
        Me.pnlpanelbuttonvirusscanner.PerformLayout()
        CType(Me.tbvirusscannericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonfilesaver.ResumeLayout(False)
        Me.pnlpanelbuttonfilesaver.PerformLayout()
        CType(Me.tbfilesavericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlpanelbuttonshifter.ResumeLayout(False)
        Me.pnlpanelbuttonshifter.PerformLayout()
        CType(Me.tbshiftericon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.applaunchermenuholder.ResumeLayout(False)
        Me.desktopappmenu.ResumeLayout(False)
        Me.desktopappmenu.PerformLayout()
        Me.timepanel.ResumeLayout(False)
        Me.timepanel.PerformLayout()
        Me.pnlpanelbuttonfloatybird.ResumeLayout(False)
        Me.pnlpanelbuttonfloatybird.PerformLayout()
        CType(Me.tbfloatybirdicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.pnladvapplauncher.ResumeLayout(False)
        Me.pnladvmain.ResumeLayout(False)
        Me.tscadvmainframe.BottomToolStripPanel.ResumeLayout(False)
        Me.tscadvmainframe.BottomToolStripPanel.PerformLayout()
        Me.tscadvmainframe.ContentPanel.ResumeLayout(False)
        Me.tscadvmainframe.ResumeLayout(False)
        Me.tscadvmainframe.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.pnladvplaces.ResumeLayout(False)
        Me.pnladvbottombar.ResumeLayout(False)
        Me.pnladvtopbar.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents desktoppanel As System.Windows.Forms.Panel
    Friend WithEvents desktopappmenu As System.Windows.Forms.MenuStrip
    Friend WithEvents ApplicationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KnowledgeInputToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShiftoriumToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TerminalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents unitySeperator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ShutdownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents paneltimetext As System.Windows.Forms.Label
    Friend WithEvents clocktick As System.Windows.Forms.Timer
    Friend WithEvents timepanel As System.Windows.Forms.Panel
    Friend WithEvents ShifterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents applaunchermenuholder As System.Windows.Forms.Panel
    Friend WithEvents PongToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileSkimmerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextPadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents autosave As System.Windows.Forms.Timer
    Friend WithEvents SkinLoaderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttontextpad As System.Windows.Forms.Panel
    Friend WithEvents tbtextpadicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbtextpadtext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonclock As System.Windows.Forms.Panel
    Friend WithEvents tbclockicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbclocktext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttoncolourpicker As System.Windows.Forms.Panel
    Friend WithEvents tbcolourpickericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbcolourpickertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttongraphicpicker As System.Windows.Forms.Panel
    Friend WithEvents tbgraphicpickericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbgraphicpickertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonfileopener As System.Windows.Forms.Panel
    Friend WithEvents tbfileopenericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbfileopenertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonfileskimmer As System.Windows.Forms.Panel
    Friend WithEvents tbfileskimmericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbfileskimmertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonknowledgeinput As System.Windows.Forms.Panel
    Friend WithEvents tbknowledgeinputicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbknowledgeinputtext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttoninfobox As System.Windows.Forms.Panel
    Friend WithEvents tbinfoboxicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbinfoboxtext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonpong As System.Windows.Forms.Panel
    Friend WithEvents tbpongicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbpongtext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonshiftorium As System.Windows.Forms.Panel
    Friend WithEvents tbshiftoriumicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbshiftoriumtext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonskinloader As System.Windows.Forms.Panel
    Friend WithEvents tbskinloadericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbskinloadertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonterminal As System.Windows.Forms.Panel
    Friend WithEvents tbterminalicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbterminaltext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonholder As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents pnlpanelbuttonartpad As System.Windows.Forms.Panel
    Friend WithEvents tbartpadicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbartpadtext As System.Windows.Forms.Label
    Friend WithEvents ArtpadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttoncalculator As System.Windows.Forms.Panel
    Friend WithEvents tbcalculatoricon As System.Windows.Forms.PictureBox
    Friend WithEvents tbcalculatortext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonaudioplayer As System.Windows.Forms.Panel
    Friend WithEvents tbaudioplayericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbaudioplayertext As System.Windows.Forms.Label
    Friend WithEvents AudioplayerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonwebbrowser As System.Windows.Forms.Panel
    Friend WithEvents tbwebbrowsericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbwebbrowsertext As System.Windows.Forms.Label
    Friend WithEvents WebBrowserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonvideoplayer As System.Windows.Forms.Panel
    Friend WithEvents tbvideoplayericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbvideoplayertext As System.Windows.Forms.Label
    Friend WithEvents VideoplayerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonnamechanger As System.Windows.Forms.Panel
    Friend WithEvents tbnamechangericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbnamechangertext As System.Windows.Forms.Label
    Friend WithEvents NameChangerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttoniconmanager As System.Windows.Forms.Panel
    Friend WithEvents tbiconmanagericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbiconmanagertext As System.Windows.Forms.Label
    Friend WithEvents IconManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonbitnotewallet As System.Windows.Forms.Panel
    Friend WithEvents tbbitnotewalleticon As System.Windows.Forms.PictureBox
    Friend WithEvents tbbitnotewallettext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonbitnotedigger As System.Windows.Forms.Panel
    Friend WithEvents tbbitnotediggericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbbitnotediggertext As System.Windows.Forms.Label
    Friend WithEvents BitnoteWalletToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BitnoteDiggerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonskinshifter As System.Windows.Forms.Panel
    Friend WithEvents tbskinshiftericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbskinshiftertext As System.Windows.Forms.Label
    Friend WithEvents SkinShifterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonshiftnet As System.Windows.Forms.Panel
    Friend WithEvents tbshiftneticon As System.Windows.Forms.PictureBox
    Friend WithEvents tbshiftnettext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttondownloader As System.Windows.Forms.Panel
    Friend WithEvents tbdownloadericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbdownloadertext As System.Windows.Forms.Label
    Friend WithEvents ShiftnetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttondodge As System.Windows.Forms.Panel
    Friend WithEvents tbdodgeicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbdodgetext As System.Windows.Forms.Label
    Friend WithEvents DodgeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents sysinfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttondownloadmanager As System.Windows.Forms.Panel
    Friend WithEvents tbdownloadmanagericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbdownloadmanagertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttoninstaller As System.Windows.Forms.Panel
    Friend WithEvents tbinstallericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbinstallertext As System.Windows.Forms.Label
    Friend WithEvents InstallerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonsnakey As System.Windows.Forms.Label
    Friend WithEvents downloadmanagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnl_panelbuttonsnakey As System.Windows.Forms.Panel
    Friend WithEvents tbsnakeyicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbsnakeytext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonorcwrite As System.Windows.Forms.Panel
    Friend WithEvents tborcwriteicon As System.Windows.Forms.PictureBox
    Friend WithEvents tborcwritetext As System.Windows.Forms.Label
    Friend WithEvents orcwriteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonfloodgate As System.Windows.Forms.Panel
    Friend WithEvents tbfloodgateicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbfloodgatetext As System.Windows.Forms.Label
    Friend WithEvents FloodGateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonsysinfo As System.Windows.Forms.Panel
    Friend WithEvents tbsysinfoicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbsysinfotext As System.Windows.Forms.Label
    Friend WithEvents SnakeyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonmaze As System.Windows.Forms.Panel
    Friend WithEvents tbmazeicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbmazetext As System.Windows.Forms.Label
    Friend WithEvents MazeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlpanelbuttonvirusscanner As System.Windows.Forms.Panel
    Friend WithEvents tbvirusscannericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbvirusscannertext As System.Windows.Forms.Label
    Friend WithEvents VirusScannerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents nocheat As System.Windows.Forms.Timer
    Friend WithEvents pnlpanelbuttonfilesaver As System.Windows.Forms.Panel
    Friend WithEvents tbfilesavericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbfilesavertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonshifter As System.Windows.Forms.Panel
    Friend WithEvents tbshiftericon As System.Windows.Forms.PictureBox
    Friend WithEvents tbshiftertext As System.Windows.Forms.Label
    Friend WithEvents pnlpanelbuttonfloatybird As System.Windows.Forms.Panel
    Friend WithEvents tbfloatybirdicon As System.Windows.Forms.PictureBox
    Friend WithEvents tbfloatybirdtext As System.Windows.Forms.Label
    Friend WithEvents floatybirdToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tmrwindowedtest As System.Windows.Forms.Timer
    Friend WithEvents desktopicons As System.Windows.Forms.ListView
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents NewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ArtpadPictureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextDocumentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrcWriteDocumentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemInformationReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebpageToolStripMenuItem As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ShortcutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TileViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents fileActionsSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewSkin As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RenameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnladvapplauncher As System.Windows.Forms.Panel
    Friend WithEvents pnladvmain As System.Windows.Forms.Panel
    Friend WithEvents tscadvmainframe As System.Windows.Forms.ToolStripContainer
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents allPrograms As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents UtilitiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TerminalToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileSkimmerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShifterToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SkinLoaderToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SkinShifterToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IconManagerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NameChangerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InternetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShiftnetToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShiftoriumToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebBrowserToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DownloadManagerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InstallerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BitnoteDiggerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BitnoteWalletToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FloodGateManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VirusScannerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GamesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DodgeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SnakeyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PongToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KnowledgeInputToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LabyrinthToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccessoriesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ArtpadToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextpadToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrcWriteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AudioPlayerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VideoPlayerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClockToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnladvplaces As System.Windows.Forms.Panel
    Friend WithEvents pnladvbottombar As System.Windows.Forms.Panel
    Friend WithEvents pnladvtopbar As System.Windows.Forms.Panel
    Friend WithEvents btnadvshutdown As System.Windows.Forms.Button
    Friend WithEvents lvadvplaces As System.Windows.Forms.ListView
    Friend WithEvents lvadvfiles As System.Windows.Forms.ListView
    Friend WithEvents lbuser As System.Windows.Forms.Label
    Friend WithEvents pnlcatalystpanelbutton As System.Windows.Forms.Panel
    Friend WithEvents tbcatalysticon As System.Windows.Forms.PictureBox
    Friend WithEvents lbcatalystname As System.Windows.Forms.Label
    Friend WithEvents CatalystToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CatalystToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
End Class
