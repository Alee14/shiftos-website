﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Icon_Manager
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pullside = New System.Windows.Forms.Timer(Me.components)
        Me.pullbs = New System.Windows.Forms.Timer(Me.components)
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.pullbottom = New System.Windows.Forms.Timer(Me.components)
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnlknowledgeinputicons = New System.Windows.Forms.Panel()
        Me.txtknowledgeinputname = New System.Windows.Forms.Label()
        Me.pnltitlebarknowledgeinputicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonknowledgeinputicon = New System.Windows.Forms.Panel()
        Me.pnllauncherknowledgeinputicon = New System.Windows.Forms.Panel()
        Me.pnlshiftoriumicons = New System.Windows.Forms.Panel()
        Me.txtshiftoriumname = New System.Windows.Forms.Label()
        Me.pnltitlebarshiftoriumicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonshiftoriumicon = New System.Windows.Forms.Panel()
        Me.pnllaunchershiftoriumicon = New System.Windows.Forms.Panel()
        Me.pnlclockicons = New System.Windows.Forms.Panel()
        Me.txtclockname = New System.Windows.Forms.Label()
        Me.pnltitlebarclockicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonclockicon = New System.Windows.Forms.Panel()
        Me.pnllauncherclockicon = New System.Windows.Forms.Panel()
        Me.pnlshiftericons = New System.Windows.Forms.Panel()
        Me.txtshiftername = New System.Windows.Forms.Label()
        Me.pnltitlebarshiftericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonshiftericon = New System.Windows.Forms.Panel()
        Me.pnllaunchershiftericon = New System.Windows.Forms.Panel()
        Me.pnlcolourpickericons = New System.Windows.Forms.Panel()
        Me.txtcolourpickername = New System.Windows.Forms.Label()
        Me.pnltitlebarcolourpickericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttoncolourpickericon = New System.Windows.Forms.Panel()
        Me.pnllaunchercolourpickericon = New System.Windows.Forms.Panel()
        Me.pnlinfoboxicons = New System.Windows.Forms.Panel()
        Me.txtinfoboxname = New System.Windows.Forms.Label()
        Me.pnltitlebarinfoboxicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttoninfoboxicon = New System.Windows.Forms.Panel()
        Me.pnllauncherinfoboxicon = New System.Windows.Forms.Panel()
        Me.pnlpongicons = New System.Windows.Forms.Panel()
        Me.txtpongname = New System.Windows.Forms.Label()
        Me.pnltitlebarpongicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonpongicon = New System.Windows.Forms.Panel()
        Me.pnllauncherpongicon = New System.Windows.Forms.Panel()
        Me.pnlfileskimmericons = New System.Windows.Forms.Panel()
        Me.txtfileskimmername = New System.Windows.Forms.Label()
        Me.pnltitlebarfileskimmericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonfileskimmericon = New System.Windows.Forms.Panel()
        Me.pnllauncherfileskimmericon = New System.Windows.Forms.Panel()
        Me.pnltextpadicons = New System.Windows.Forms.Panel()
        Me.txttextpadname = New System.Windows.Forms.Label()
        Me.pnltitlebartextpadicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttontextpadicon = New System.Windows.Forms.Panel()
        Me.pnllaunchertextpadicon = New System.Windows.Forms.Panel()
        Me.pnlfileopenericons = New System.Windows.Forms.Panel()
        Me.txtfileopenername = New System.Windows.Forms.Label()
        Me.pnltitlebarfileopenericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonfileopenericon = New System.Windows.Forms.Panel()
        Me.pnllauncherfileopenericon = New System.Windows.Forms.Panel()
        Me.pnlfilesavericons = New System.Windows.Forms.Panel()
        Me.txtfilesavername = New System.Windows.Forms.Label()
        Me.pnltitlebarfilesavericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonfilesavericon = New System.Windows.Forms.Panel()
        Me.pnllauncherfilesavericon = New System.Windows.Forms.Panel()
        Me.pnlgraphicpickericons = New System.Windows.Forms.Panel()
        Me.txtgraphicpickername = New System.Windows.Forms.Label()
        Me.pnltitlebargraphicpickericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttongraphicpickericon = New System.Windows.Forms.Panel()
        Me.pnllaunchergraphicpickericon = New System.Windows.Forms.Panel()
        Me.pnlskinloadericons = New System.Windows.Forms.Panel()
        Me.txtskinloadername = New System.Windows.Forms.Label()
        Me.pnltitlebarskinloadericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonskinloadericon = New System.Windows.Forms.Panel()
        Me.pnllauncherskinloadericon = New System.Windows.Forms.Panel()
        Me.pnlartpadicons = New System.Windows.Forms.Panel()
        Me.txtartpadname = New System.Windows.Forms.Label()
        Me.pnltitlebarartpadicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonartpadicon = New System.Windows.Forms.Panel()
        Me.pnllauncherartpadicon = New System.Windows.Forms.Panel()
        Me.pnlcalculatoricons = New System.Windows.Forms.Panel()
        Me.txtcalculatorname = New System.Windows.Forms.Label()
        Me.pnltitlebarcalculatoricon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttoncalculatoricon = New System.Windows.Forms.Panel()
        Me.pnllaunchercalculatoricon = New System.Windows.Forms.Panel()
        Me.pnlaudioplayericons = New System.Windows.Forms.Panel()
        Me.txtaudioplayername = New System.Windows.Forms.Label()
        Me.pnltitlebaraudioplayericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonaudioplayericon = New System.Windows.Forms.Panel()
        Me.pnllauncheraudioplayericon = New System.Windows.Forms.Panel()
        Me.pnlwebbrowsericons = New System.Windows.Forms.Panel()
        Me.txtwebbrowsername = New System.Windows.Forms.Label()
        Me.pnltitlebarwebbrowsericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonwebbrowsericon = New System.Windows.Forms.Panel()
        Me.pnllauncherwebbrowsericon = New System.Windows.Forms.Panel()
        Me.pnlvideoplayericons = New System.Windows.Forms.Panel()
        Me.txtvideoplayername = New System.Windows.Forms.Label()
        Me.pnltitlebarvideoplayericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonvideoplayericon = New System.Windows.Forms.Panel()
        Me.pnllaunchervideoplayericon = New System.Windows.Forms.Panel()
        Me.pnlnamechangericons = New System.Windows.Forms.Panel()
        Me.txtnamechangername = New System.Windows.Forms.Label()
        Me.pnltitlebarnamechangericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonnamechangericon = New System.Windows.Forms.Panel()
        Me.pnllaunchernamechangericon = New System.Windows.Forms.Panel()
        Me.pnliconmanagericons = New System.Windows.Forms.Panel()
        Me.txticonmanagername = New System.Windows.Forms.Label()
        Me.pnltitlebariconmanagericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttoniconmanagericon = New System.Windows.Forms.Panel()
        Me.pnllaunchericonmanagericon = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.txtterminalname = New System.Windows.Forms.Label()
        Me.pnltitlebarterminalicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonterminalicon = New System.Windows.Forms.Panel()
        Me.pnllauncherterminalicon = New System.Windows.Forms.Panel()
        Me.pnlbitnotewallet = New System.Windows.Forms.Panel()
        Me.lblbitnotewallet = New System.Windows.Forms.Label()
        Me.pnltitlebarbitnotewalleticon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonbitnotewalleticon = New System.Windows.Forms.Panel()
        Me.pnllauncherbitnotewalleticon = New System.Windows.Forms.Panel()
        Me.pnlbitnotedigger = New System.Windows.Forms.Panel()
        Me.lblbitnotedigger = New System.Windows.Forms.Label()
        Me.pnltitlebarbitnotediggericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonbitnotediggericon = New System.Windows.Forms.Panel()
        Me.pnllauncherbitnotediggericon = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.txtlaunchericonsize = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtpanelbuttoniconsize = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txttitlebariconsize = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnApply = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.pnlskinshifter = New System.Windows.Forms.Panel()
        Me.lblskinshifter = New System.Windows.Forms.Label()
        Me.pnltitlebarskinshiftericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonskinshiftericon = New System.Windows.Forms.Panel()
        Me.pnllauncherskinshiftericon = New System.Windows.Forms.Panel()
        Me.pnlshiftnet = New System.Windows.Forms.Panel()
        Me.lblshiftnet = New System.Windows.Forms.Label()
        Me.pnltitlebarshiftneticon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonshiftneticon = New System.Windows.Forms.Panel()
        Me.pnllaunchershiftneticon = New System.Windows.Forms.Panel()
        Me.pnldodge = New System.Windows.Forms.Panel()
        Me.lbldodge = New System.Windows.Forms.Label()
        Me.pnltitlebardodgeicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttondodgeicon = New System.Windows.Forms.Panel()
        Me.pnllauncherdodgeicon = New System.Windows.Forms.Panel()
        Me.pnldownloadmanager = New System.Windows.Forms.Panel()
        Me.lbldownload = New System.Windows.Forms.Label()
        Me.pnltitlebardownloadicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttondownloadicon = New System.Windows.Forms.Panel()
        Me.pnllauncherdownloadicon = New System.Windows.Forms.Panel()
        Me.pnlinstaller = New System.Windows.Forms.Panel()
        Me.lblinstaller = New System.Windows.Forms.Label()
        Me.pnltitlebarinstallericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttoninstallericon = New System.Windows.Forms.Panel()
        Me.pnllauncherinstallericon = New System.Windows.Forms.Panel()
        Me.pnlsysinfo = New System.Windows.Forms.Panel()
        Me.lblsysinfo = New System.Windows.Forms.Label()
        Me.pnltitlebarsysinfoicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonsysinfoicon = New System.Windows.Forms.Panel()
        Me.pnllaunchersysinfoicon = New System.Windows.Forms.Panel()
        Me.pnlorcwrite = New System.Windows.Forms.Panel()
        Me.lblorcwrite = New System.Windows.Forms.Label()
        Me.pnltitlebarorcwriteicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonorcwriteicon = New System.Windows.Forms.Panel()
        Me.pnllauncherorcwriteicon = New System.Windows.Forms.Panel()
        Me.pnlfloodgate = New System.Windows.Forms.Panel()
        Me.lblfloodgate = New System.Windows.Forms.Label()
        Me.pnltitlebarfloodgateicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonfloodgateicon = New System.Windows.Forms.Panel()
        Me.pnllauncherfloodgateicon = New System.Windows.Forms.Panel()
        Me.pnlmaze = New System.Windows.Forms.Panel()
        Me.lblmaze = New System.Windows.Forms.Label()
        Me.pnltitlebarmazeicon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonmazeicon = New System.Windows.Forms.Panel()
        Me.pnllaunchermazeicon = New System.Windows.Forms.Panel()
        Me.pnlvirusscanner = New System.Windows.Forms.Panel()
        Me.lblvirusscanner = New System.Windows.Forms.Label()
        Me.pnltitlebarvirusscannericon = New System.Windows.Forms.Panel()
        Me.pnlpanelbuttonvirusscannericon = New System.Windows.Forms.Panel()
        Me.pnllaunchervirusscannericon = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.txtshutdownname = New System.Windows.Forms.Label()
        Me.pnllaunchershutdownicon = New System.Windows.Forms.Panel()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pgright.SuspendLayout()
        Me.pgcontents.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.pnlknowledgeinputicons.SuspendLayout()
        Me.pnlshiftoriumicons.SuspendLayout()
        Me.pnlclockicons.SuspendLayout()
        Me.pnlshiftericons.SuspendLayout()
        Me.pnlcolourpickericons.SuspendLayout()
        Me.pnlinfoboxicons.SuspendLayout()
        Me.pnlpongicons.SuspendLayout()
        Me.pnlfileskimmericons.SuspendLayout()
        Me.pnltextpadicons.SuspendLayout()
        Me.pnlfileopenericons.SuspendLayout()
        Me.pnlfilesavericons.SuspendLayout()
        Me.pnlgraphicpickericons.SuspendLayout()
        Me.pnlskinloadericons.SuspendLayout()
        Me.pnlartpadicons.SuspendLayout()
        Me.pnlcalculatoricons.SuspendLayout()
        Me.pnlaudioplayericons.SuspendLayout()
        Me.pnlwebbrowsericons.SuspendLayout()
        Me.pnlvideoplayericons.SuspendLayout()
        Me.pnlnamechangericons.SuspendLayout()
        Me.pnliconmanagericons.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.pnlbitnotewallet.SuspendLayout()
        Me.pnlbitnotedigger.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.pgleft.SuspendLayout()
        Me.titlebar.SuspendLayout()
        Me.pnlskinshifter.SuspendLayout()
        Me.pnlshiftnet.SuspendLayout()
        Me.pnldodge.SuspendLayout()
        Me.pnldownloadmanager.SuspendLayout()
        Me.pnlinstaller.SuspendLayout()
        Me.pnlsysinfo.SuspendLayout()
        Me.pnlorcwrite.SuspendLayout()
        Me.pnlfloodgate.SuspendLayout()
        Me.pnlmaze.SuspendLayout()
        Me.pnlvirusscanner.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.SuspendLayout()
        '
        'pullside
        '
        Me.pullside.Interval = 1
        '
        'pullbs
        '
        Me.pullbs.Interval = 1
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 702)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(1449, 2)
        Me.pgbottom.TabIndex = 23
        '
        'pullbottom
        '
        Me.pullbottom.Interval = 1
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(246, 5)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 24
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconTextPad
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(274, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 672)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(1451, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 674)
        Me.pgright.TabIndex = 22
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(302, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(110, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Icon Manager"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(1451, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 672)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgcontents
        '
        Me.pgcontents.BackColor = System.Drawing.Color.White
        Me.pgcontents.Controls.Add(Me.FlowLayoutPanel1)
        Me.pgcontents.Controls.Add(Me.Panel2)
        Me.pgcontents.Controls.Add(Me.Panel1)
        Me.pgcontents.Controls.Add(Me.Panel4)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(1449, 672)
        Me.pgcontents.TabIndex = 20
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlknowledgeinputicons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlshiftoriumicons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlclockicons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlshiftericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlcolourpickericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlinfoboxicons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlpongicons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlfileskimmericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnltextpadicons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlfileopenericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlfilesavericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlgraphicpickericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlskinloadericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlartpadicons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlcalculatoricons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlaudioplayericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlwebbrowsericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlvideoplayericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlnamechangericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnliconmanagericons)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel7)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlbitnotewallet)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlbitnotedigger)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlskinshifter)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlshiftnet)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnldodge)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnldownloadmanager)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlinstaller)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlsysinfo)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlorcwrite)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlfloodgate)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlmaze)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlvirusscanner)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel8)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 27)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(1449, 567)
        Me.FlowLayoutPanel1.TabIndex = 2
        '
        'pnlknowledgeinputicons
        '
        Me.pnlknowledgeinputicons.Controls.Add(Me.txtknowledgeinputname)
        Me.pnlknowledgeinputicons.Controls.Add(Me.pnltitlebarknowledgeinputicon)
        Me.pnlknowledgeinputicons.Controls.Add(Me.pnlpanelbuttonknowledgeinputicon)
        Me.pnlknowledgeinputicons.Controls.Add(Me.pnllauncherknowledgeinputicon)
        Me.pnlknowledgeinputicons.Location = New System.Drawing.Point(3, 3)
        Me.pnlknowledgeinputicons.Name = "pnlknowledgeinputicons"
        Me.pnlknowledgeinputicons.Size = New System.Drawing.Size(369, 64)
        Me.pnlknowledgeinputicons.TabIndex = 0
        '
        'txtknowledgeinputname
        '
        Me.txtknowledgeinputname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtknowledgeinputname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtknowledgeinputname.Location = New System.Drawing.Point(0, 0)
        Me.txtknowledgeinputname.Name = "txtknowledgeinputname"
        Me.txtknowledgeinputname.Size = New System.Drawing.Size(177, 64)
        Me.txtknowledgeinputname.TabIndex = 3
        Me.txtknowledgeinputname.Text = "Knowledge Input"
        Me.txtknowledgeinputname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarknowledgeinputicon
        '
        Me.pnltitlebarknowledgeinputicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarknowledgeinputicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarknowledgeinputicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarknowledgeinputicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarknowledgeinputicon.Name = "pnltitlebarknowledgeinputicon"
        Me.pnltitlebarknowledgeinputicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarknowledgeinputicon.TabIndex = 2
        '
        'pnlpanelbuttonknowledgeinputicon
        '
        Me.pnlpanelbuttonknowledgeinputicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonknowledgeinputicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonknowledgeinputicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonknowledgeinputicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonknowledgeinputicon.Name = "pnlpanelbuttonknowledgeinputicon"
        Me.pnlpanelbuttonknowledgeinputicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonknowledgeinputicon.TabIndex = 1
        '
        'pnllauncherknowledgeinputicon
        '
        Me.pnllauncherknowledgeinputicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherknowledgeinputicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherknowledgeinputicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherknowledgeinputicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherknowledgeinputicon.Name = "pnllauncherknowledgeinputicon"
        Me.pnllauncherknowledgeinputicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherknowledgeinputicon.TabIndex = 0
        '
        'pnlshiftoriumicons
        '
        Me.pnlshiftoriumicons.Controls.Add(Me.txtshiftoriumname)
        Me.pnlshiftoriumicons.Controls.Add(Me.pnltitlebarshiftoriumicon)
        Me.pnlshiftoriumicons.Controls.Add(Me.pnlpanelbuttonshiftoriumicon)
        Me.pnlshiftoriumicons.Controls.Add(Me.pnllaunchershiftoriumicon)
        Me.pnlshiftoriumicons.Location = New System.Drawing.Point(378, 3)
        Me.pnlshiftoriumicons.Name = "pnlshiftoriumicons"
        Me.pnlshiftoriumicons.Size = New System.Drawing.Size(369, 64)
        Me.pnlshiftoriumicons.TabIndex = 1
        '
        'txtshiftoriumname
        '
        Me.txtshiftoriumname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtshiftoriumname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtshiftoriumname.Location = New System.Drawing.Point(0, 0)
        Me.txtshiftoriumname.Name = "txtshiftoriumname"
        Me.txtshiftoriumname.Size = New System.Drawing.Size(177, 64)
        Me.txtshiftoriumname.TabIndex = 3
        Me.txtshiftoriumname.Text = "Shiftorium"
        Me.txtshiftoriumname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarshiftoriumicon
        '
        Me.pnltitlebarshiftoriumicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarshiftoriumicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarshiftoriumicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarshiftoriumicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarshiftoriumicon.Name = "pnltitlebarshiftoriumicon"
        Me.pnltitlebarshiftoriumicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarshiftoriumicon.TabIndex = 2
        '
        'pnlpanelbuttonshiftoriumicon
        '
        Me.pnlpanelbuttonshiftoriumicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonshiftoriumicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonshiftoriumicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonshiftoriumicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonshiftoriumicon.Name = "pnlpanelbuttonshiftoriumicon"
        Me.pnlpanelbuttonshiftoriumicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonshiftoriumicon.TabIndex = 1
        '
        'pnllaunchershiftoriumicon
        '
        Me.pnllaunchershiftoriumicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchershiftoriumicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchershiftoriumicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchershiftoriumicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchershiftoriumicon.Name = "pnllaunchershiftoriumicon"
        Me.pnllaunchershiftoriumicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchershiftoriumicon.TabIndex = 0
        '
        'pnlclockicons
        '
        Me.pnlclockicons.Controls.Add(Me.txtclockname)
        Me.pnlclockicons.Controls.Add(Me.pnltitlebarclockicon)
        Me.pnlclockicons.Controls.Add(Me.pnlpanelbuttonclockicon)
        Me.pnlclockicons.Controls.Add(Me.pnllauncherclockicon)
        Me.pnlclockicons.Location = New System.Drawing.Point(753, 3)
        Me.pnlclockicons.Name = "pnlclockicons"
        Me.pnlclockicons.Size = New System.Drawing.Size(369, 64)
        Me.pnlclockicons.TabIndex = 2
        '
        'txtclockname
        '
        Me.txtclockname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtclockname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtclockname.Location = New System.Drawing.Point(0, 0)
        Me.txtclockname.Name = "txtclockname"
        Me.txtclockname.Size = New System.Drawing.Size(177, 64)
        Me.txtclockname.TabIndex = 3
        Me.txtclockname.Text = "Clock"
        Me.txtclockname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarclockicon
        '
        Me.pnltitlebarclockicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarclockicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarclockicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarclockicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarclockicon.Name = "pnltitlebarclockicon"
        Me.pnltitlebarclockicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarclockicon.TabIndex = 2
        '
        'pnlpanelbuttonclockicon
        '
        Me.pnlpanelbuttonclockicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonclockicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonclockicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonclockicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonclockicon.Name = "pnlpanelbuttonclockicon"
        Me.pnlpanelbuttonclockicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonclockicon.TabIndex = 1
        '
        'pnllauncherclockicon
        '
        Me.pnllauncherclockicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherclockicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherclockicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherclockicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherclockicon.Name = "pnllauncherclockicon"
        Me.pnllauncherclockicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherclockicon.TabIndex = 0
        '
        'pnlshiftericons
        '
        Me.pnlshiftericons.Controls.Add(Me.txtshiftername)
        Me.pnlshiftericons.Controls.Add(Me.pnltitlebarshiftericon)
        Me.pnlshiftericons.Controls.Add(Me.pnlpanelbuttonshiftericon)
        Me.pnlshiftericons.Controls.Add(Me.pnllaunchershiftericon)
        Me.pnlshiftericons.Location = New System.Drawing.Point(3, 73)
        Me.pnlshiftericons.Name = "pnlshiftericons"
        Me.pnlshiftericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlshiftericons.TabIndex = 3
        '
        'txtshiftername
        '
        Me.txtshiftername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtshiftername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtshiftername.Location = New System.Drawing.Point(0, 0)
        Me.txtshiftername.Name = "txtshiftername"
        Me.txtshiftername.Size = New System.Drawing.Size(177, 64)
        Me.txtshiftername.TabIndex = 3
        Me.txtshiftername.Text = "Shifter"
        Me.txtshiftername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarshiftericon
        '
        Me.pnltitlebarshiftericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarshiftericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarshiftericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarshiftericon.Name = "pnltitlebarshiftericon"
        Me.pnltitlebarshiftericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarshiftericon.TabIndex = 2
        '
        'pnlpanelbuttonshiftericon
        '
        Me.pnlpanelbuttonshiftericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonshiftericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonshiftericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonshiftericon.Name = "pnlpanelbuttonshiftericon"
        Me.pnlpanelbuttonshiftericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonshiftericon.TabIndex = 1
        '
        'pnllaunchershiftericon
        '
        Me.pnllaunchershiftericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchershiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchershiftericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchershiftericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchershiftericon.Name = "pnllaunchershiftericon"
        Me.pnllaunchershiftericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchershiftericon.TabIndex = 0
        '
        'pnlcolourpickericons
        '
        Me.pnlcolourpickericons.Controls.Add(Me.txtcolourpickername)
        Me.pnlcolourpickericons.Controls.Add(Me.pnltitlebarcolourpickericon)
        Me.pnlcolourpickericons.Controls.Add(Me.pnlpanelbuttoncolourpickericon)
        Me.pnlcolourpickericons.Controls.Add(Me.pnllaunchercolourpickericon)
        Me.pnlcolourpickericons.Location = New System.Drawing.Point(378, 73)
        Me.pnlcolourpickericons.Name = "pnlcolourpickericons"
        Me.pnlcolourpickericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlcolourpickericons.TabIndex = 4
        '
        'txtcolourpickername
        '
        Me.txtcolourpickername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtcolourpickername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcolourpickername.Location = New System.Drawing.Point(0, 0)
        Me.txtcolourpickername.Name = "txtcolourpickername"
        Me.txtcolourpickername.Size = New System.Drawing.Size(177, 64)
        Me.txtcolourpickername.TabIndex = 3
        Me.txtcolourpickername.Text = "Colour Picker"
        Me.txtcolourpickername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarcolourpickericon
        '
        Me.pnltitlebarcolourpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarcolourpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarcolourpickericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarcolourpickericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarcolourpickericon.Name = "pnltitlebarcolourpickericon"
        Me.pnltitlebarcolourpickericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarcolourpickericon.TabIndex = 2
        '
        'pnlpanelbuttoncolourpickericon
        '
        Me.pnlpanelbuttoncolourpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttoncolourpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttoncolourpickericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttoncolourpickericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttoncolourpickericon.Name = "pnlpanelbuttoncolourpickericon"
        Me.pnlpanelbuttoncolourpickericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttoncolourpickericon.TabIndex = 1
        '
        'pnllaunchercolourpickericon
        '
        Me.pnllaunchercolourpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchercolourpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchercolourpickericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchercolourpickericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchercolourpickericon.Name = "pnllaunchercolourpickericon"
        Me.pnllaunchercolourpickericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchercolourpickericon.TabIndex = 0
        '
        'pnlinfoboxicons
        '
        Me.pnlinfoboxicons.Controls.Add(Me.txtinfoboxname)
        Me.pnlinfoboxicons.Controls.Add(Me.pnltitlebarinfoboxicon)
        Me.pnlinfoboxicons.Controls.Add(Me.pnlpanelbuttoninfoboxicon)
        Me.pnlinfoboxicons.Controls.Add(Me.pnllauncherinfoboxicon)
        Me.pnlinfoboxicons.Location = New System.Drawing.Point(753, 73)
        Me.pnlinfoboxicons.Name = "pnlinfoboxicons"
        Me.pnlinfoboxicons.Size = New System.Drawing.Size(369, 64)
        Me.pnlinfoboxicons.TabIndex = 5
        '
        'txtinfoboxname
        '
        Me.txtinfoboxname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtinfoboxname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtinfoboxname.Location = New System.Drawing.Point(0, 0)
        Me.txtinfoboxname.Name = "txtinfoboxname"
        Me.txtinfoboxname.Size = New System.Drawing.Size(177, 64)
        Me.txtinfoboxname.TabIndex = 3
        Me.txtinfoboxname.Text = "Infobox"
        Me.txtinfoboxname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarinfoboxicon
        '
        Me.pnltitlebarinfoboxicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarinfoboxicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarinfoboxicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarinfoboxicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarinfoboxicon.Name = "pnltitlebarinfoboxicon"
        Me.pnltitlebarinfoboxicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarinfoboxicon.TabIndex = 2
        '
        'pnlpanelbuttoninfoboxicon
        '
        Me.pnlpanelbuttoninfoboxicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttoninfoboxicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttoninfoboxicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttoninfoboxicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttoninfoboxicon.Name = "pnlpanelbuttoninfoboxicon"
        Me.pnlpanelbuttoninfoboxicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttoninfoboxicon.TabIndex = 1
        '
        'pnllauncherinfoboxicon
        '
        Me.pnllauncherinfoboxicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherinfoboxicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherinfoboxicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherinfoboxicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherinfoboxicon.Name = "pnllauncherinfoboxicon"
        Me.pnllauncherinfoboxicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherinfoboxicon.TabIndex = 0
        '
        'pnlpongicons
        '
        Me.pnlpongicons.Controls.Add(Me.txtpongname)
        Me.pnlpongicons.Controls.Add(Me.pnltitlebarpongicon)
        Me.pnlpongicons.Controls.Add(Me.pnlpanelbuttonpongicon)
        Me.pnlpongicons.Controls.Add(Me.pnllauncherpongicon)
        Me.pnlpongicons.Location = New System.Drawing.Point(3, 143)
        Me.pnlpongicons.Name = "pnlpongicons"
        Me.pnlpongicons.Size = New System.Drawing.Size(369, 64)
        Me.pnlpongicons.TabIndex = 6
        '
        'txtpongname
        '
        Me.txtpongname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtpongname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpongname.Location = New System.Drawing.Point(0, 0)
        Me.txtpongname.Name = "txtpongname"
        Me.txtpongname.Size = New System.Drawing.Size(177, 64)
        Me.txtpongname.TabIndex = 3
        Me.txtpongname.Text = "Pong"
        Me.txtpongname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarpongicon
        '
        Me.pnltitlebarpongicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarpongicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarpongicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarpongicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarpongicon.Name = "pnltitlebarpongicon"
        Me.pnltitlebarpongicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarpongicon.TabIndex = 2
        '
        'pnlpanelbuttonpongicon
        '
        Me.pnlpanelbuttonpongicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonpongicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonpongicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonpongicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonpongicon.Name = "pnlpanelbuttonpongicon"
        Me.pnlpanelbuttonpongicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonpongicon.TabIndex = 1
        '
        'pnllauncherpongicon
        '
        Me.pnllauncherpongicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherpongicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherpongicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherpongicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherpongicon.Name = "pnllauncherpongicon"
        Me.pnllauncherpongicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherpongicon.TabIndex = 0
        '
        'pnlfileskimmericons
        '
        Me.pnlfileskimmericons.Controls.Add(Me.txtfileskimmername)
        Me.pnlfileskimmericons.Controls.Add(Me.pnltitlebarfileskimmericon)
        Me.pnlfileskimmericons.Controls.Add(Me.pnlpanelbuttonfileskimmericon)
        Me.pnlfileskimmericons.Controls.Add(Me.pnllauncherfileskimmericon)
        Me.pnlfileskimmericons.Location = New System.Drawing.Point(378, 143)
        Me.pnlfileskimmericons.Name = "pnlfileskimmericons"
        Me.pnlfileskimmericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlfileskimmericons.TabIndex = 7
        '
        'txtfileskimmername
        '
        Me.txtfileskimmername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtfileskimmername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfileskimmername.Location = New System.Drawing.Point(0, 0)
        Me.txtfileskimmername.Name = "txtfileskimmername"
        Me.txtfileskimmername.Size = New System.Drawing.Size(177, 64)
        Me.txtfileskimmername.TabIndex = 3
        Me.txtfileskimmername.Text = "File Skimmer"
        Me.txtfileskimmername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarfileskimmericon
        '
        Me.pnltitlebarfileskimmericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarfileskimmericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarfileskimmericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarfileskimmericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarfileskimmericon.Name = "pnltitlebarfileskimmericon"
        Me.pnltitlebarfileskimmericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarfileskimmericon.TabIndex = 2
        '
        'pnlpanelbuttonfileskimmericon
        '
        Me.pnlpanelbuttonfileskimmericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonfileskimmericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonfileskimmericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonfileskimmericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonfileskimmericon.Name = "pnlpanelbuttonfileskimmericon"
        Me.pnlpanelbuttonfileskimmericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonfileskimmericon.TabIndex = 1
        '
        'pnllauncherfileskimmericon
        '
        Me.pnllauncherfileskimmericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherfileskimmericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherfileskimmericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherfileskimmericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherfileskimmericon.Name = "pnllauncherfileskimmericon"
        Me.pnllauncherfileskimmericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherfileskimmericon.TabIndex = 0
        '
        'pnltextpadicons
        '
        Me.pnltextpadicons.Controls.Add(Me.txttextpadname)
        Me.pnltextpadicons.Controls.Add(Me.pnltitlebartextpadicon)
        Me.pnltextpadicons.Controls.Add(Me.pnlpanelbuttontextpadicon)
        Me.pnltextpadicons.Controls.Add(Me.pnllaunchertextpadicon)
        Me.pnltextpadicons.Location = New System.Drawing.Point(753, 143)
        Me.pnltextpadicons.Name = "pnltextpadicons"
        Me.pnltextpadicons.Size = New System.Drawing.Size(369, 64)
        Me.pnltextpadicons.TabIndex = 8
        '
        'txttextpadname
        '
        Me.txttextpadname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txttextpadname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttextpadname.Location = New System.Drawing.Point(0, 0)
        Me.txttextpadname.Name = "txttextpadname"
        Me.txttextpadname.Size = New System.Drawing.Size(177, 64)
        Me.txttextpadname.TabIndex = 3
        Me.txttextpadname.Text = "TextPad"
        Me.txttextpadname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebartextpadicon
        '
        Me.pnltitlebartextpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebartextpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebartextpadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebartextpadicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebartextpadicon.Name = "pnltitlebartextpadicon"
        Me.pnltitlebartextpadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebartextpadicon.TabIndex = 2
        '
        'pnlpanelbuttontextpadicon
        '
        Me.pnlpanelbuttontextpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttontextpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttontextpadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttontextpadicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttontextpadicon.Name = "pnlpanelbuttontextpadicon"
        Me.pnlpanelbuttontextpadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttontextpadicon.TabIndex = 1
        '
        'pnllaunchertextpadicon
        '
        Me.pnllaunchertextpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchertextpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchertextpadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchertextpadicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchertextpadicon.Name = "pnllaunchertextpadicon"
        Me.pnllaunchertextpadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchertextpadicon.TabIndex = 0
        '
        'pnlfileopenericons
        '
        Me.pnlfileopenericons.Controls.Add(Me.txtfileopenername)
        Me.pnlfileopenericons.Controls.Add(Me.pnltitlebarfileopenericon)
        Me.pnlfileopenericons.Controls.Add(Me.pnlpanelbuttonfileopenericon)
        Me.pnlfileopenericons.Controls.Add(Me.pnllauncherfileopenericon)
        Me.pnlfileopenericons.Location = New System.Drawing.Point(3, 213)
        Me.pnlfileopenericons.Name = "pnlfileopenericons"
        Me.pnlfileopenericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlfileopenericons.TabIndex = 9
        '
        'txtfileopenername
        '
        Me.txtfileopenername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtfileopenername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfileopenername.Location = New System.Drawing.Point(0, 0)
        Me.txtfileopenername.Name = "txtfileopenername"
        Me.txtfileopenername.Size = New System.Drawing.Size(177, 64)
        Me.txtfileopenername.TabIndex = 3
        Me.txtfileopenername.Text = "File Opener"
        Me.txtfileopenername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarfileopenericon
        '
        Me.pnltitlebarfileopenericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarfileopenericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarfileopenericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarfileopenericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarfileopenericon.Name = "pnltitlebarfileopenericon"
        Me.pnltitlebarfileopenericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarfileopenericon.TabIndex = 2
        '
        'pnlpanelbuttonfileopenericon
        '
        Me.pnlpanelbuttonfileopenericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonfileopenericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonfileopenericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonfileopenericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonfileopenericon.Name = "pnlpanelbuttonfileopenericon"
        Me.pnlpanelbuttonfileopenericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonfileopenericon.TabIndex = 1
        '
        'pnllauncherfileopenericon
        '
        Me.pnllauncherfileopenericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherfileopenericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherfileopenericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherfileopenericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherfileopenericon.Name = "pnllauncherfileopenericon"
        Me.pnllauncherfileopenericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherfileopenericon.TabIndex = 0
        '
        'pnlfilesavericons
        '
        Me.pnlfilesavericons.Controls.Add(Me.txtfilesavername)
        Me.pnlfilesavericons.Controls.Add(Me.pnltitlebarfilesavericon)
        Me.pnlfilesavericons.Controls.Add(Me.pnlpanelbuttonfilesavericon)
        Me.pnlfilesavericons.Controls.Add(Me.pnllauncherfilesavericon)
        Me.pnlfilesavericons.Location = New System.Drawing.Point(378, 213)
        Me.pnlfilesavericons.Name = "pnlfilesavericons"
        Me.pnlfilesavericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlfilesavericons.TabIndex = 10
        '
        'txtfilesavername
        '
        Me.txtfilesavername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtfilesavername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfilesavername.Location = New System.Drawing.Point(0, 0)
        Me.txtfilesavername.Name = "txtfilesavername"
        Me.txtfilesavername.Size = New System.Drawing.Size(177, 64)
        Me.txtfilesavername.TabIndex = 3
        Me.txtfilesavername.Text = "File Saver"
        Me.txtfilesavername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarfilesavericon
        '
        Me.pnltitlebarfilesavericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarfilesavericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarfilesavericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarfilesavericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarfilesavericon.Name = "pnltitlebarfilesavericon"
        Me.pnltitlebarfilesavericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarfilesavericon.TabIndex = 2
        '
        'pnlpanelbuttonfilesavericon
        '
        Me.pnlpanelbuttonfilesavericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonfilesavericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonfilesavericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonfilesavericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonfilesavericon.Name = "pnlpanelbuttonfilesavericon"
        Me.pnlpanelbuttonfilesavericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonfilesavericon.TabIndex = 1
        '
        'pnllauncherfilesavericon
        '
        Me.pnllauncherfilesavericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherfilesavericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherfilesavericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherfilesavericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherfilesavericon.Name = "pnllauncherfilesavericon"
        Me.pnllauncherfilesavericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherfilesavericon.TabIndex = 0
        '
        'pnlgraphicpickericons
        '
        Me.pnlgraphicpickericons.Controls.Add(Me.txtgraphicpickername)
        Me.pnlgraphicpickericons.Controls.Add(Me.pnltitlebargraphicpickericon)
        Me.pnlgraphicpickericons.Controls.Add(Me.pnlpanelbuttongraphicpickericon)
        Me.pnlgraphicpickericons.Controls.Add(Me.pnllaunchergraphicpickericon)
        Me.pnlgraphicpickericons.Location = New System.Drawing.Point(753, 213)
        Me.pnlgraphicpickericons.Name = "pnlgraphicpickericons"
        Me.pnlgraphicpickericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlgraphicpickericons.TabIndex = 11
        '
        'txtgraphicpickername
        '
        Me.txtgraphicpickername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtgraphicpickername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgraphicpickername.Location = New System.Drawing.Point(0, 0)
        Me.txtgraphicpickername.Name = "txtgraphicpickername"
        Me.txtgraphicpickername.Size = New System.Drawing.Size(177, 64)
        Me.txtgraphicpickername.TabIndex = 3
        Me.txtgraphicpickername.Text = "Graphic Picker"
        Me.txtgraphicpickername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebargraphicpickericon
        '
        Me.pnltitlebargraphicpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebargraphicpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebargraphicpickericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebargraphicpickericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebargraphicpickericon.Name = "pnltitlebargraphicpickericon"
        Me.pnltitlebargraphicpickericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebargraphicpickericon.TabIndex = 2
        '
        'pnlpanelbuttongraphicpickericon
        '
        Me.pnlpanelbuttongraphicpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttongraphicpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttongraphicpickericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttongraphicpickericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttongraphicpickericon.Name = "pnlpanelbuttongraphicpickericon"
        Me.pnlpanelbuttongraphicpickericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttongraphicpickericon.TabIndex = 1
        '
        'pnllaunchergraphicpickericon
        '
        Me.pnllaunchergraphicpickericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchergraphicpickericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchergraphicpickericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchergraphicpickericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchergraphicpickericon.Name = "pnllaunchergraphicpickericon"
        Me.pnllaunchergraphicpickericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchergraphicpickericon.TabIndex = 0
        '
        'pnlskinloadericons
        '
        Me.pnlskinloadericons.Controls.Add(Me.txtskinloadername)
        Me.pnlskinloadericons.Controls.Add(Me.pnltitlebarskinloadericon)
        Me.pnlskinloadericons.Controls.Add(Me.pnlpanelbuttonskinloadericon)
        Me.pnlskinloadericons.Controls.Add(Me.pnllauncherskinloadericon)
        Me.pnlskinloadericons.Location = New System.Drawing.Point(3, 283)
        Me.pnlskinloadericons.Name = "pnlskinloadericons"
        Me.pnlskinloadericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlskinloadericons.TabIndex = 12
        '
        'txtskinloadername
        '
        Me.txtskinloadername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtskinloadername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtskinloadername.Location = New System.Drawing.Point(0, 0)
        Me.txtskinloadername.Name = "txtskinloadername"
        Me.txtskinloadername.Size = New System.Drawing.Size(177, 64)
        Me.txtskinloadername.TabIndex = 3
        Me.txtskinloadername.Text = "Skin Loader"
        Me.txtskinloadername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarskinloadericon
        '
        Me.pnltitlebarskinloadericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarskinloadericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarskinloadericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarskinloadericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarskinloadericon.Name = "pnltitlebarskinloadericon"
        Me.pnltitlebarskinloadericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarskinloadericon.TabIndex = 2
        '
        'pnlpanelbuttonskinloadericon
        '
        Me.pnlpanelbuttonskinloadericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonskinloadericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonskinloadericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonskinloadericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonskinloadericon.Name = "pnlpanelbuttonskinloadericon"
        Me.pnlpanelbuttonskinloadericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonskinloadericon.TabIndex = 1
        '
        'pnllauncherskinloadericon
        '
        Me.pnllauncherskinloadericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherskinloadericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherskinloadericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherskinloadericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherskinloadericon.Name = "pnllauncherskinloadericon"
        Me.pnllauncherskinloadericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherskinloadericon.TabIndex = 0
        '
        'pnlartpadicons
        '
        Me.pnlartpadicons.Controls.Add(Me.txtartpadname)
        Me.pnlartpadicons.Controls.Add(Me.pnltitlebarartpadicon)
        Me.pnlartpadicons.Controls.Add(Me.pnlpanelbuttonartpadicon)
        Me.pnlartpadicons.Controls.Add(Me.pnllauncherartpadicon)
        Me.pnlartpadicons.Location = New System.Drawing.Point(378, 283)
        Me.pnlartpadicons.Name = "pnlartpadicons"
        Me.pnlartpadicons.Size = New System.Drawing.Size(369, 64)
        Me.pnlartpadicons.TabIndex = 13
        '
        'txtartpadname
        '
        Me.txtartpadname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtartpadname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtartpadname.Location = New System.Drawing.Point(0, 0)
        Me.txtartpadname.Name = "txtartpadname"
        Me.txtartpadname.Size = New System.Drawing.Size(177, 64)
        Me.txtartpadname.TabIndex = 3
        Me.txtartpadname.Text = "Artpad"
        Me.txtartpadname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarartpadicon
        '
        Me.pnltitlebarartpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarartpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarartpadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarartpadicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarartpadicon.Name = "pnltitlebarartpadicon"
        Me.pnltitlebarartpadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarartpadicon.TabIndex = 2
        '
        'pnlpanelbuttonartpadicon
        '
        Me.pnlpanelbuttonartpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonartpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonartpadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonartpadicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonartpadicon.Name = "pnlpanelbuttonartpadicon"
        Me.pnlpanelbuttonartpadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonartpadicon.TabIndex = 1
        '
        'pnllauncherartpadicon
        '
        Me.pnllauncherartpadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherartpadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherartpadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherartpadicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherartpadicon.Name = "pnllauncherartpadicon"
        Me.pnllauncherartpadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherartpadicon.TabIndex = 0
        '
        'pnlcalculatoricons
        '
        Me.pnlcalculatoricons.Controls.Add(Me.txtcalculatorname)
        Me.pnlcalculatoricons.Controls.Add(Me.pnltitlebarcalculatoricon)
        Me.pnlcalculatoricons.Controls.Add(Me.pnlpanelbuttoncalculatoricon)
        Me.pnlcalculatoricons.Controls.Add(Me.pnllaunchercalculatoricon)
        Me.pnlcalculatoricons.Location = New System.Drawing.Point(753, 283)
        Me.pnlcalculatoricons.Name = "pnlcalculatoricons"
        Me.pnlcalculatoricons.Size = New System.Drawing.Size(369, 64)
        Me.pnlcalculatoricons.TabIndex = 14
        '
        'txtcalculatorname
        '
        Me.txtcalculatorname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtcalculatorname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcalculatorname.Location = New System.Drawing.Point(0, 0)
        Me.txtcalculatorname.Name = "txtcalculatorname"
        Me.txtcalculatorname.Size = New System.Drawing.Size(177, 64)
        Me.txtcalculatorname.TabIndex = 3
        Me.txtcalculatorname.Text = "Calculator"
        Me.txtcalculatorname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarcalculatoricon
        '
        Me.pnltitlebarcalculatoricon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarcalculatoricon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarcalculatoricon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarcalculatoricon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarcalculatoricon.Name = "pnltitlebarcalculatoricon"
        Me.pnltitlebarcalculatoricon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarcalculatoricon.TabIndex = 2
        '
        'pnlpanelbuttoncalculatoricon
        '
        Me.pnlpanelbuttoncalculatoricon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttoncalculatoricon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttoncalculatoricon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttoncalculatoricon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttoncalculatoricon.Name = "pnlpanelbuttoncalculatoricon"
        Me.pnlpanelbuttoncalculatoricon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttoncalculatoricon.TabIndex = 1
        '
        'pnllaunchercalculatoricon
        '
        Me.pnllaunchercalculatoricon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchercalculatoricon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchercalculatoricon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchercalculatoricon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchercalculatoricon.Name = "pnllaunchercalculatoricon"
        Me.pnllaunchercalculatoricon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchercalculatoricon.TabIndex = 0
        '
        'pnlaudioplayericons
        '
        Me.pnlaudioplayericons.Controls.Add(Me.txtaudioplayername)
        Me.pnlaudioplayericons.Controls.Add(Me.pnltitlebaraudioplayericon)
        Me.pnlaudioplayericons.Controls.Add(Me.pnlpanelbuttonaudioplayericon)
        Me.pnlaudioplayericons.Controls.Add(Me.pnllauncheraudioplayericon)
        Me.pnlaudioplayericons.Location = New System.Drawing.Point(3, 353)
        Me.pnlaudioplayericons.Name = "pnlaudioplayericons"
        Me.pnlaudioplayericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlaudioplayericons.TabIndex = 15
        '
        'txtaudioplayername
        '
        Me.txtaudioplayername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtaudioplayername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaudioplayername.Location = New System.Drawing.Point(0, 0)
        Me.txtaudioplayername.Name = "txtaudioplayername"
        Me.txtaudioplayername.Size = New System.Drawing.Size(177, 64)
        Me.txtaudioplayername.TabIndex = 3
        Me.txtaudioplayername.Text = "Audio Player"
        Me.txtaudioplayername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebaraudioplayericon
        '
        Me.pnltitlebaraudioplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebaraudioplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebaraudioplayericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebaraudioplayericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebaraudioplayericon.Name = "pnltitlebaraudioplayericon"
        Me.pnltitlebaraudioplayericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebaraudioplayericon.TabIndex = 2
        '
        'pnlpanelbuttonaudioplayericon
        '
        Me.pnlpanelbuttonaudioplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonaudioplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonaudioplayericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonaudioplayericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonaudioplayericon.Name = "pnlpanelbuttonaudioplayericon"
        Me.pnlpanelbuttonaudioplayericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonaudioplayericon.TabIndex = 1
        '
        'pnllauncheraudioplayericon
        '
        Me.pnllauncheraudioplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncheraudioplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncheraudioplayericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncheraudioplayericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncheraudioplayericon.Name = "pnllauncheraudioplayericon"
        Me.pnllauncheraudioplayericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncheraudioplayericon.TabIndex = 0
        '
        'pnlwebbrowsericons
        '
        Me.pnlwebbrowsericons.Controls.Add(Me.txtwebbrowsername)
        Me.pnlwebbrowsericons.Controls.Add(Me.pnltitlebarwebbrowsericon)
        Me.pnlwebbrowsericons.Controls.Add(Me.pnlpanelbuttonwebbrowsericon)
        Me.pnlwebbrowsericons.Controls.Add(Me.pnllauncherwebbrowsericon)
        Me.pnlwebbrowsericons.Location = New System.Drawing.Point(378, 353)
        Me.pnlwebbrowsericons.Name = "pnlwebbrowsericons"
        Me.pnlwebbrowsericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlwebbrowsericons.TabIndex = 16
        '
        'txtwebbrowsername
        '
        Me.txtwebbrowsername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtwebbrowsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtwebbrowsername.Location = New System.Drawing.Point(0, 0)
        Me.txtwebbrowsername.Name = "txtwebbrowsername"
        Me.txtwebbrowsername.Size = New System.Drawing.Size(177, 64)
        Me.txtwebbrowsername.TabIndex = 3
        Me.txtwebbrowsername.Text = "Web Browser"
        Me.txtwebbrowsername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarwebbrowsericon
        '
        Me.pnltitlebarwebbrowsericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarwebbrowsericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarwebbrowsericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarwebbrowsericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarwebbrowsericon.Name = "pnltitlebarwebbrowsericon"
        Me.pnltitlebarwebbrowsericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarwebbrowsericon.TabIndex = 2
        '
        'pnlpanelbuttonwebbrowsericon
        '
        Me.pnlpanelbuttonwebbrowsericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonwebbrowsericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonwebbrowsericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonwebbrowsericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonwebbrowsericon.Name = "pnlpanelbuttonwebbrowsericon"
        Me.pnlpanelbuttonwebbrowsericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonwebbrowsericon.TabIndex = 1
        '
        'pnllauncherwebbrowsericon
        '
        Me.pnllauncherwebbrowsericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherwebbrowsericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherwebbrowsericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherwebbrowsericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherwebbrowsericon.Name = "pnllauncherwebbrowsericon"
        Me.pnllauncherwebbrowsericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherwebbrowsericon.TabIndex = 0
        '
        'pnlvideoplayericons
        '
        Me.pnlvideoplayericons.Controls.Add(Me.txtvideoplayername)
        Me.pnlvideoplayericons.Controls.Add(Me.pnltitlebarvideoplayericon)
        Me.pnlvideoplayericons.Controls.Add(Me.pnlpanelbuttonvideoplayericon)
        Me.pnlvideoplayericons.Controls.Add(Me.pnllaunchervideoplayericon)
        Me.pnlvideoplayericons.Location = New System.Drawing.Point(753, 353)
        Me.pnlvideoplayericons.Name = "pnlvideoplayericons"
        Me.pnlvideoplayericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlvideoplayericons.TabIndex = 17
        '
        'txtvideoplayername
        '
        Me.txtvideoplayername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtvideoplayername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtvideoplayername.Location = New System.Drawing.Point(0, 0)
        Me.txtvideoplayername.Name = "txtvideoplayername"
        Me.txtvideoplayername.Size = New System.Drawing.Size(177, 64)
        Me.txtvideoplayername.TabIndex = 3
        Me.txtvideoplayername.Text = "Video Player"
        Me.txtvideoplayername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarvideoplayericon
        '
        Me.pnltitlebarvideoplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarvideoplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarvideoplayericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarvideoplayericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarvideoplayericon.Name = "pnltitlebarvideoplayericon"
        Me.pnltitlebarvideoplayericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarvideoplayericon.TabIndex = 2
        '
        'pnlpanelbuttonvideoplayericon
        '
        Me.pnlpanelbuttonvideoplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonvideoplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonvideoplayericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonvideoplayericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonvideoplayericon.Name = "pnlpanelbuttonvideoplayericon"
        Me.pnlpanelbuttonvideoplayericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonvideoplayericon.TabIndex = 1
        '
        'pnllaunchervideoplayericon
        '
        Me.pnllaunchervideoplayericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchervideoplayericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchervideoplayericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchervideoplayericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchervideoplayericon.Name = "pnllaunchervideoplayericon"
        Me.pnllaunchervideoplayericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchervideoplayericon.TabIndex = 0
        '
        'pnlnamechangericons
        '
        Me.pnlnamechangericons.Controls.Add(Me.txtnamechangername)
        Me.pnlnamechangericons.Controls.Add(Me.pnltitlebarnamechangericon)
        Me.pnlnamechangericons.Controls.Add(Me.pnlpanelbuttonnamechangericon)
        Me.pnlnamechangericons.Controls.Add(Me.pnllaunchernamechangericon)
        Me.pnlnamechangericons.Location = New System.Drawing.Point(3, 423)
        Me.pnlnamechangericons.Name = "pnlnamechangericons"
        Me.pnlnamechangericons.Size = New System.Drawing.Size(369, 64)
        Me.pnlnamechangericons.TabIndex = 18
        '
        'txtnamechangername
        '
        Me.txtnamechangername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtnamechangername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnamechangername.Location = New System.Drawing.Point(0, 0)
        Me.txtnamechangername.Name = "txtnamechangername"
        Me.txtnamechangername.Size = New System.Drawing.Size(177, 64)
        Me.txtnamechangername.TabIndex = 3
        Me.txtnamechangername.Text = "Name Changer"
        Me.txtnamechangername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarnamechangericon
        '
        Me.pnltitlebarnamechangericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarnamechangericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarnamechangericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarnamechangericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarnamechangericon.Name = "pnltitlebarnamechangericon"
        Me.pnltitlebarnamechangericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarnamechangericon.TabIndex = 2
        '
        'pnlpanelbuttonnamechangericon
        '
        Me.pnlpanelbuttonnamechangericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonnamechangericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonnamechangericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonnamechangericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonnamechangericon.Name = "pnlpanelbuttonnamechangericon"
        Me.pnlpanelbuttonnamechangericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonnamechangericon.TabIndex = 1
        '
        'pnllaunchernamechangericon
        '
        Me.pnllaunchernamechangericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchernamechangericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchernamechangericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchernamechangericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchernamechangericon.Name = "pnllaunchernamechangericon"
        Me.pnllaunchernamechangericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchernamechangericon.TabIndex = 0
        '
        'pnliconmanagericons
        '
        Me.pnliconmanagericons.Controls.Add(Me.txticonmanagername)
        Me.pnliconmanagericons.Controls.Add(Me.pnltitlebariconmanagericon)
        Me.pnliconmanagericons.Controls.Add(Me.pnlpanelbuttoniconmanagericon)
        Me.pnliconmanagericons.Controls.Add(Me.pnllaunchericonmanagericon)
        Me.pnliconmanagericons.Location = New System.Drawing.Point(378, 423)
        Me.pnliconmanagericons.Name = "pnliconmanagericons"
        Me.pnliconmanagericons.Size = New System.Drawing.Size(369, 64)
        Me.pnliconmanagericons.TabIndex = 19
        '
        'txticonmanagername
        '
        Me.txticonmanagername.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txticonmanagername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txticonmanagername.Location = New System.Drawing.Point(0, 0)
        Me.txticonmanagername.Name = "txticonmanagername"
        Me.txticonmanagername.Size = New System.Drawing.Size(177, 64)
        Me.txticonmanagername.TabIndex = 3
        Me.txticonmanagername.Text = "Icon Manager"
        Me.txticonmanagername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebariconmanagericon
        '
        Me.pnltitlebariconmanagericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebariconmanagericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebariconmanagericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebariconmanagericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebariconmanagericon.Name = "pnltitlebariconmanagericon"
        Me.pnltitlebariconmanagericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebariconmanagericon.TabIndex = 2
        '
        'pnlpanelbuttoniconmanagericon
        '
        Me.pnlpanelbuttoniconmanagericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttoniconmanagericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttoniconmanagericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttoniconmanagericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttoniconmanagericon.Name = "pnlpanelbuttoniconmanagericon"
        Me.pnlpanelbuttoniconmanagericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttoniconmanagericon.TabIndex = 1
        '
        'pnllaunchericonmanagericon
        '
        Me.pnllaunchericonmanagericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchericonmanagericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchericonmanagericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchericonmanagericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchericonmanagericon.Name = "pnllaunchericonmanagericon"
        Me.pnllaunchericonmanagericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchericonmanagericon.TabIndex = 0
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.txtterminalname)
        Me.Panel7.Controls.Add(Me.pnltitlebarterminalicon)
        Me.Panel7.Controls.Add(Me.pnlpanelbuttonterminalicon)
        Me.Panel7.Controls.Add(Me.pnllauncherterminalicon)
        Me.Panel7.Location = New System.Drawing.Point(753, 423)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(369, 64)
        Me.Panel7.TabIndex = 20
        '
        'txtterminalname
        '
        Me.txtterminalname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtterminalname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtterminalname.Location = New System.Drawing.Point(0, 0)
        Me.txtterminalname.Name = "txtterminalname"
        Me.txtterminalname.Size = New System.Drawing.Size(177, 64)
        Me.txtterminalname.TabIndex = 3
        Me.txtterminalname.Text = "Terminal"
        Me.txtterminalname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarterminalicon
        '
        Me.pnltitlebarterminalicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarterminalicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarterminalicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarterminalicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarterminalicon.Name = "pnltitlebarterminalicon"
        Me.pnltitlebarterminalicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarterminalicon.TabIndex = 2
        '
        'pnlpanelbuttonterminalicon
        '
        Me.pnlpanelbuttonterminalicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonterminalicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonterminalicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonterminalicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonterminalicon.Name = "pnlpanelbuttonterminalicon"
        Me.pnlpanelbuttonterminalicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonterminalicon.TabIndex = 1
        '
        'pnllauncherterminalicon
        '
        Me.pnllauncherterminalicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherterminalicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherterminalicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherterminalicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherterminalicon.Name = "pnllauncherterminalicon"
        Me.pnllauncherterminalicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherterminalicon.TabIndex = 0
        '
        'pnlbitnotewallet
        '
        Me.pnlbitnotewallet.Controls.Add(Me.lblbitnotewallet)
        Me.pnlbitnotewallet.Controls.Add(Me.pnltitlebarbitnotewalleticon)
        Me.pnlbitnotewallet.Controls.Add(Me.pnlpanelbuttonbitnotewalleticon)
        Me.pnlbitnotewallet.Controls.Add(Me.pnllauncherbitnotewalleticon)
        Me.pnlbitnotewallet.Location = New System.Drawing.Point(3, 493)
        Me.pnlbitnotewallet.Name = "pnlbitnotewallet"
        Me.pnlbitnotewallet.Size = New System.Drawing.Size(369, 64)
        Me.pnlbitnotewallet.TabIndex = 22
        '
        'lblbitnotewallet
        '
        Me.lblbitnotewallet.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblbitnotewallet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotewallet.Location = New System.Drawing.Point(0, 0)
        Me.lblbitnotewallet.Name = "lblbitnotewallet"
        Me.lblbitnotewallet.Size = New System.Drawing.Size(177, 64)
        Me.lblbitnotewallet.TabIndex = 3
        Me.lblbitnotewallet.Text = "Bitnote Wallet"
        Me.lblbitnotewallet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarbitnotewalleticon
        '
        Me.pnltitlebarbitnotewalleticon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarbitnotewalleticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarbitnotewalleticon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarbitnotewalleticon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarbitnotewalleticon.Name = "pnltitlebarbitnotewalleticon"
        Me.pnltitlebarbitnotewalleticon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarbitnotewalleticon.TabIndex = 2
        '
        'pnlpanelbuttonbitnotewalleticon
        '
        Me.pnlpanelbuttonbitnotewalleticon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonbitnotewalleticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonbitnotewalleticon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonbitnotewalleticon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonbitnotewalleticon.Name = "pnlpanelbuttonbitnotewalleticon"
        Me.pnlpanelbuttonbitnotewalleticon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonbitnotewalleticon.TabIndex = 1
        '
        'pnllauncherbitnotewalleticon
        '
        Me.pnllauncherbitnotewalleticon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherbitnotewalleticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherbitnotewalleticon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherbitnotewalleticon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherbitnotewalleticon.Name = "pnllauncherbitnotewalleticon"
        Me.pnllauncherbitnotewalleticon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherbitnotewalleticon.TabIndex = 0
        '
        'pnlbitnotedigger
        '
        Me.pnlbitnotedigger.Controls.Add(Me.lblbitnotedigger)
        Me.pnlbitnotedigger.Controls.Add(Me.pnltitlebarbitnotediggericon)
        Me.pnlbitnotedigger.Controls.Add(Me.pnlpanelbuttonbitnotediggericon)
        Me.pnlbitnotedigger.Controls.Add(Me.pnllauncherbitnotediggericon)
        Me.pnlbitnotedigger.Location = New System.Drawing.Point(378, 493)
        Me.pnlbitnotedigger.Name = "pnlbitnotedigger"
        Me.pnlbitnotedigger.Size = New System.Drawing.Size(369, 64)
        Me.pnlbitnotedigger.TabIndex = 23
        '
        'lblbitnotedigger
        '
        Me.lblbitnotedigger.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblbitnotedigger.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbitnotedigger.Location = New System.Drawing.Point(0, 0)
        Me.lblbitnotedigger.Name = "lblbitnotedigger"
        Me.lblbitnotedigger.Size = New System.Drawing.Size(177, 64)
        Me.lblbitnotedigger.TabIndex = 3
        Me.lblbitnotedigger.Text = "Bitnote Digger"
        Me.lblbitnotedigger.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarbitnotediggericon
        '
        Me.pnltitlebarbitnotediggericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarbitnotediggericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarbitnotediggericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarbitnotediggericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarbitnotediggericon.Name = "pnltitlebarbitnotediggericon"
        Me.pnltitlebarbitnotediggericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarbitnotediggericon.TabIndex = 2
        '
        'pnlpanelbuttonbitnotediggericon
        '
        Me.pnlpanelbuttonbitnotediggericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonbitnotediggericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonbitnotediggericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonbitnotediggericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonbitnotediggericon.Name = "pnlpanelbuttonbitnotediggericon"
        Me.pnlpanelbuttonbitnotediggericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonbitnotediggericon.TabIndex = 1
        '
        'pnllauncherbitnotediggericon
        '
        Me.pnllauncherbitnotediggericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherbitnotediggericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherbitnotediggericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherbitnotediggericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherbitnotediggericon.Name = "pnllauncherbitnotediggericon"
        Me.pnllauncherbitnotediggericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherbitnotediggericon.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Controls.Add(Me.txtlaunchericonsize)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.txtpanelbuttoniconsize)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.txttitlebariconsize)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 594)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1449, 37)
        Me.Panel2.TabIndex = 4
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Black
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1449, 1)
        Me.Panel3.TabIndex = 7
        '
        'txtlaunchericonsize
        '
        Me.txtlaunchericonsize.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtlaunchericonsize.BackColor = System.Drawing.Color.White
        Me.txtlaunchericonsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtlaunchericonsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlaunchericonsize.Location = New System.Drawing.Point(856, 8)
        Me.txtlaunchericonsize.Multiline = True
        Me.txtlaunchericonsize.Name = "txtlaunchericonsize"
        Me.txtlaunchericonsize.Size = New System.Drawing.Size(23, 20)
        Me.txtlaunchericonsize.TabIndex = 6
        Me.txtlaunchericonsize.Text = "34"
        Me.txtlaunchericonsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(787, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(66, 16)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Launcher:"
        '
        'txtpanelbuttoniconsize
        '
        Me.txtpanelbuttoniconsize.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtpanelbuttoniconsize.BackColor = System.Drawing.Color.White
        Me.txtpanelbuttoniconsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpanelbuttoniconsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpanelbuttoniconsize.Location = New System.Drawing.Point(751, 8)
        Me.txtpanelbuttoniconsize.Multiline = True
        Me.txtpanelbuttoniconsize.Name = "txtpanelbuttoniconsize"
        Me.txtpanelbuttoniconsize.Size = New System.Drawing.Size(23, 20)
        Me.txtpanelbuttoniconsize.TabIndex = 3
        Me.txtpanelbuttoniconsize.Text = "34"
        Me.txtpanelbuttoniconsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(663, 10)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Panel Button:"
        '
        'txttitlebariconsize
        '
        Me.txttitlebariconsize.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txttitlebariconsize.BackColor = System.Drawing.Color.White
        Me.txttitlebariconsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttitlebariconsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttitlebariconsize.Location = New System.Drawing.Point(624, 8)
        Me.txttitlebariconsize.Multiline = True
        Me.txttitlebariconsize.Name = "txttitlebariconsize"
        Me.txttitlebariconsize.Size = New System.Drawing.Size(23, 20)
        Me.txttitlebariconsize.TabIndex = 1
        Me.txttitlebariconsize.Text = "34"
        Me.txttitlebariconsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(564, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 16)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Titlebar:"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.btnReset)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Controls.Add(Me.btnApply)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 631)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1449, 41)
        Me.Panel1.TabIndex = 3
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Black
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1449, 1)
        Me.Panel5.TabIndex = 8
        '
        'btnReset
        '
        Me.btnReset.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnReset.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReset.Location = New System.Drawing.Point(528, 4)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(95, 34)
        Me.btnReset.TabIndex = 3
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(627, 4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(95, 34)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Load"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Location = New System.Drawing.Point(726, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(95, 34)
        Me.btnSave.TabIndex = 1
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnApply
        '
        Me.btnApply.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnApply.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnApply.Location = New System.Drawing.Point(825, 4)
        Me.btnApply.Name = "btnApply"
        Me.btnApply.Size = New System.Drawing.Size(95, 34)
        Me.btnApply.TabIndex = 0
        Me.btnApply.Text = "Apply"
        Me.btnApply.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel6)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1449, 27)
        Me.Panel4.TabIndex = 1
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Black
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel6.Location = New System.Drawing.Point(0, 26)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1449, 1)
        Me.Panel6.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1449, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Program Name | Titlebar Icon | Panel Button Icon | Launcher Icon"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 674)
        Me.pgleft.TabIndex = 21
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(1453, 30)
        Me.titlebar.TabIndex = 19
        '
        'pnlskinshifter
        '
        Me.pnlskinshifter.Controls.Add(Me.lblskinshifter)
        Me.pnlskinshifter.Controls.Add(Me.pnltitlebarskinshiftericon)
        Me.pnlskinshifter.Controls.Add(Me.pnlpanelbuttonskinshiftericon)
        Me.pnlskinshifter.Controls.Add(Me.pnllauncherskinshiftericon)
        Me.pnlskinshifter.Location = New System.Drawing.Point(753, 493)
        Me.pnlskinshifter.Name = "pnlskinshifter"
        Me.pnlskinshifter.Size = New System.Drawing.Size(369, 64)
        Me.pnlskinshifter.TabIndex = 24
        '
        'lblskinshifter
        '
        Me.lblskinshifter.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblskinshifter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblskinshifter.Location = New System.Drawing.Point(0, 0)
        Me.lblskinshifter.Name = "lblskinshifter"
        Me.lblskinshifter.Size = New System.Drawing.Size(177, 64)
        Me.lblskinshifter.TabIndex = 3
        Me.lblskinshifter.Text = "Skin Shifter"
        Me.lblskinshifter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarskinshiftericon
        '
        Me.pnltitlebarskinshiftericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarskinshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarskinshiftericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarskinshiftericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarskinshiftericon.Name = "pnltitlebarskinshiftericon"
        Me.pnltitlebarskinshiftericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarskinshiftericon.TabIndex = 2
        '
        'pnlpanelbuttonskinshiftericon
        '
        Me.pnlpanelbuttonskinshiftericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonskinshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonskinshiftericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonskinshiftericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonskinshiftericon.Name = "pnlpanelbuttonskinshiftericon"
        Me.pnlpanelbuttonskinshiftericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonskinshiftericon.TabIndex = 1
        '
        'pnllauncherskinshiftericon
        '
        Me.pnllauncherskinshiftericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherskinshiftericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherskinshiftericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherskinshiftericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherskinshiftericon.Name = "pnllauncherskinshiftericon"
        Me.pnllauncherskinshiftericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherskinshiftericon.TabIndex = 0
        '
        'pnlshiftnet
        '
        Me.pnlshiftnet.Controls.Add(Me.lblshiftnet)
        Me.pnlshiftnet.Controls.Add(Me.pnltitlebarshiftneticon)
        Me.pnlshiftnet.Controls.Add(Me.pnlpanelbuttonshiftneticon)
        Me.pnlshiftnet.Controls.Add(Me.pnllaunchershiftneticon)
        Me.pnlshiftnet.Location = New System.Drawing.Point(3, 563)
        Me.pnlshiftnet.Name = "pnlshiftnet"
        Me.pnlshiftnet.Size = New System.Drawing.Size(369, 64)
        Me.pnlshiftnet.TabIndex = 25
        '
        'lblshiftnet
        '
        Me.lblshiftnet.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblshiftnet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshiftnet.Location = New System.Drawing.Point(0, 0)
        Me.lblshiftnet.Name = "lblshiftnet"
        Me.lblshiftnet.Size = New System.Drawing.Size(177, 64)
        Me.lblshiftnet.TabIndex = 3
        Me.lblshiftnet.Text = "Shiftnet"
        Me.lblshiftnet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarshiftneticon
        '
        Me.pnltitlebarshiftneticon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarshiftneticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarshiftneticon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarshiftneticon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarshiftneticon.Name = "pnltitlebarshiftneticon"
        Me.pnltitlebarshiftneticon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarshiftneticon.TabIndex = 2
        '
        'pnlpanelbuttonshiftneticon
        '
        Me.pnlpanelbuttonshiftneticon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonshiftneticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonshiftneticon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonshiftneticon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonshiftneticon.Name = "pnlpanelbuttonshiftneticon"
        Me.pnlpanelbuttonshiftneticon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonshiftneticon.TabIndex = 1
        '
        'pnllaunchershiftneticon
        '
        Me.pnllaunchershiftneticon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchershiftneticon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchershiftneticon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchershiftneticon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchershiftneticon.Name = "pnllaunchershiftneticon"
        Me.pnllaunchershiftneticon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchershiftneticon.TabIndex = 0
        '
        'pnldodge
        '
        Me.pnldodge.Controls.Add(Me.lbldodge)
        Me.pnldodge.Controls.Add(Me.pnltitlebardodgeicon)
        Me.pnldodge.Controls.Add(Me.pnlpanelbuttondodgeicon)
        Me.pnldodge.Controls.Add(Me.pnllauncherdodgeicon)
        Me.pnldodge.Location = New System.Drawing.Point(378, 563)
        Me.pnldodge.Name = "pnldodge"
        Me.pnldodge.Size = New System.Drawing.Size(369, 64)
        Me.pnldodge.TabIndex = 26
        '
        'lbldodge
        '
        Me.lbldodge.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbldodge.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldodge.Location = New System.Drawing.Point(0, 0)
        Me.lbldodge.Name = "lbldodge"
        Me.lbldodge.Size = New System.Drawing.Size(177, 64)
        Me.lbldodge.TabIndex = 3
        Me.lbldodge.Text = "Dodge"
        Me.lbldodge.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebardodgeicon
        '
        Me.pnltitlebardodgeicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebardodgeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebardodgeicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebardodgeicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebardodgeicon.Name = "pnltitlebardodgeicon"
        Me.pnltitlebardodgeicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebardodgeicon.TabIndex = 2
        '
        'pnlpanelbuttondodgeicon
        '
        Me.pnlpanelbuttondodgeicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttondodgeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttondodgeicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttondodgeicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttondodgeicon.Name = "pnlpanelbuttondodgeicon"
        Me.pnlpanelbuttondodgeicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttondodgeicon.TabIndex = 1
        '
        'pnllauncherdodgeicon
        '
        Me.pnllauncherdodgeicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherdodgeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherdodgeicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherdodgeicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherdodgeicon.Name = "pnllauncherdodgeicon"
        Me.pnllauncherdodgeicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherdodgeicon.TabIndex = 0
        '
        'pnldownloadmanager
        '
        Me.pnldownloadmanager.Controls.Add(Me.lbldownload)
        Me.pnldownloadmanager.Controls.Add(Me.pnltitlebardownloadicon)
        Me.pnldownloadmanager.Controls.Add(Me.pnlpanelbuttondownloadicon)
        Me.pnldownloadmanager.Controls.Add(Me.pnllauncherdownloadicon)
        Me.pnldownloadmanager.Location = New System.Drawing.Point(753, 563)
        Me.pnldownloadmanager.Name = "pnldownloadmanager"
        Me.pnldownloadmanager.Size = New System.Drawing.Size(369, 64)
        Me.pnldownloadmanager.TabIndex = 27
        '
        'lbldownload
        '
        Me.lbldownload.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbldownload.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldownload.Location = New System.Drawing.Point(0, 0)
        Me.lbldownload.Name = "lbldownload"
        Me.lbldownload.Size = New System.Drawing.Size(177, 64)
        Me.lbldownload.TabIndex = 3
        Me.lbldownload.Text = "Download Manager"
        Me.lbldownload.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebardownloadicon
        '
        Me.pnltitlebardownloadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebardownloadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebardownloadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebardownloadicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebardownloadicon.Name = "pnltitlebardownloadicon"
        Me.pnltitlebardownloadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebardownloadicon.TabIndex = 2
        '
        'pnlpanelbuttondownloadicon
        '
        Me.pnlpanelbuttondownloadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttondownloadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttondownloadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttondownloadicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttondownloadicon.Name = "pnlpanelbuttondownloadicon"
        Me.pnlpanelbuttondownloadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttondownloadicon.TabIndex = 1
        '
        'pnllauncherdownloadicon
        '
        Me.pnllauncherdownloadicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherdownloadicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherdownloadicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherdownloadicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherdownloadicon.Name = "pnllauncherdownloadicon"
        Me.pnllauncherdownloadicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherdownloadicon.TabIndex = 0
        '
        'pnlinstaller
        '
        Me.pnlinstaller.Controls.Add(Me.lblinstaller)
        Me.pnlinstaller.Controls.Add(Me.pnltitlebarinstallericon)
        Me.pnlinstaller.Controls.Add(Me.pnlpanelbuttoninstallericon)
        Me.pnlinstaller.Controls.Add(Me.pnllauncherinstallericon)
        Me.pnlinstaller.Location = New System.Drawing.Point(3, 633)
        Me.pnlinstaller.Name = "pnlinstaller"
        Me.pnlinstaller.Size = New System.Drawing.Size(369, 64)
        Me.pnlinstaller.TabIndex = 28
        '
        'lblinstaller
        '
        Me.lblinstaller.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblinstaller.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblinstaller.Location = New System.Drawing.Point(0, 0)
        Me.lblinstaller.Name = "lblinstaller"
        Me.lblinstaller.Size = New System.Drawing.Size(177, 64)
        Me.lblinstaller.TabIndex = 3
        Me.lblinstaller.Text = "Installer"
        Me.lblinstaller.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarinstallericon
        '
        Me.pnltitlebarinstallericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarinstallericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarinstallericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarinstallericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarinstallericon.Name = "pnltitlebarinstallericon"
        Me.pnltitlebarinstallericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarinstallericon.TabIndex = 2
        '
        'pnlpanelbuttoninstallericon
        '
        Me.pnlpanelbuttoninstallericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttoninstallericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttoninstallericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttoninstallericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttoninstallericon.Name = "pnlpanelbuttoninstallericon"
        Me.pnlpanelbuttoninstallericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttoninstallericon.TabIndex = 1
        '
        'pnllauncherinstallericon
        '
        Me.pnllauncherinstallericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherinstallericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherinstallericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherinstallericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherinstallericon.Name = "pnllauncherinstallericon"
        Me.pnllauncherinstallericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherinstallericon.TabIndex = 0
        '
        'pnlsysinfo
        '
        Me.pnlsysinfo.Controls.Add(Me.lblsysinfo)
        Me.pnlsysinfo.Controls.Add(Me.pnltitlebarsysinfoicon)
        Me.pnlsysinfo.Controls.Add(Me.pnlpanelbuttonsysinfoicon)
        Me.pnlsysinfo.Controls.Add(Me.pnllaunchersysinfoicon)
        Me.pnlsysinfo.Location = New System.Drawing.Point(378, 633)
        Me.pnlsysinfo.Name = "pnlsysinfo"
        Me.pnlsysinfo.Size = New System.Drawing.Size(369, 64)
        Me.pnlsysinfo.TabIndex = 29
        '
        'lblsysinfo
        '
        Me.lblsysinfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblsysinfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsysinfo.Location = New System.Drawing.Point(0, 0)
        Me.lblsysinfo.Name = "lblsysinfo"
        Me.lblsysinfo.Size = New System.Drawing.Size(177, 64)
        Me.lblsysinfo.TabIndex = 3
        Me.lblsysinfo.Text = "System Infomation"
        Me.lblsysinfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarsysinfoicon
        '
        Me.pnltitlebarsysinfoicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarsysinfoicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarsysinfoicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarsysinfoicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarsysinfoicon.Name = "pnltitlebarsysinfoicon"
        Me.pnltitlebarsysinfoicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarsysinfoicon.TabIndex = 2
        '
        'pnlpanelbuttonsysinfoicon
        '
        Me.pnlpanelbuttonsysinfoicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonsysinfoicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonsysinfoicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonsysinfoicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonsysinfoicon.Name = "pnlpanelbuttonsysinfoicon"
        Me.pnlpanelbuttonsysinfoicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonsysinfoicon.TabIndex = 1
        '
        'pnllaunchersysinfoicon
        '
        Me.pnllaunchersysinfoicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchersysinfoicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchersysinfoicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchersysinfoicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchersysinfoicon.Name = "pnllaunchersysinfoicon"
        Me.pnllaunchersysinfoicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchersysinfoicon.TabIndex = 0
        '
        'pnlorcwrite
        '
        Me.pnlorcwrite.Controls.Add(Me.lblorcwrite)
        Me.pnlorcwrite.Controls.Add(Me.pnltitlebarorcwriteicon)
        Me.pnlorcwrite.Controls.Add(Me.pnlpanelbuttonorcwriteicon)
        Me.pnlorcwrite.Controls.Add(Me.pnllauncherorcwriteicon)
        Me.pnlorcwrite.Location = New System.Drawing.Point(753, 633)
        Me.pnlorcwrite.Name = "pnlorcwrite"
        Me.pnlorcwrite.Size = New System.Drawing.Size(369, 64)
        Me.pnlorcwrite.TabIndex = 30
        '
        'lblorcwrite
        '
        Me.lblorcwrite.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblorcwrite.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblorcwrite.Location = New System.Drawing.Point(0, 0)
        Me.lblorcwrite.Name = "lblorcwrite"
        Me.lblorcwrite.Size = New System.Drawing.Size(177, 64)
        Me.lblorcwrite.TabIndex = 3
        Me.lblorcwrite.Text = "OrcWrite"
        Me.lblorcwrite.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarorcwriteicon
        '
        Me.pnltitlebarorcwriteicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarorcwriteicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarorcwriteicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarorcwriteicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarorcwriteicon.Name = "pnltitlebarorcwriteicon"
        Me.pnltitlebarorcwriteicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarorcwriteicon.TabIndex = 2
        '
        'pnlpanelbuttonorcwriteicon
        '
        Me.pnlpanelbuttonorcwriteicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonorcwriteicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonorcwriteicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonorcwriteicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonorcwriteicon.Name = "pnlpanelbuttonorcwriteicon"
        Me.pnlpanelbuttonorcwriteicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonorcwriteicon.TabIndex = 1
        '
        'pnllauncherorcwriteicon
        '
        Me.pnllauncherorcwriteicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherorcwriteicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherorcwriteicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherorcwriteicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherorcwriteicon.Name = "pnllauncherorcwriteicon"
        Me.pnllauncherorcwriteicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherorcwriteicon.TabIndex = 0
        '
        'pnlfloodgate
        '
        Me.pnlfloodgate.Controls.Add(Me.lblfloodgate)
        Me.pnlfloodgate.Controls.Add(Me.pnltitlebarfloodgateicon)
        Me.pnlfloodgate.Controls.Add(Me.pnlpanelbuttonfloodgateicon)
        Me.pnlfloodgate.Controls.Add(Me.pnllauncherfloodgateicon)
        Me.pnlfloodgate.Location = New System.Drawing.Point(3, 703)
        Me.pnlfloodgate.Name = "pnlfloodgate"
        Me.pnlfloodgate.Size = New System.Drawing.Size(369, 64)
        Me.pnlfloodgate.TabIndex = 31
        '
        'lblfloodgate
        '
        Me.lblfloodgate.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblfloodgate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfloodgate.Location = New System.Drawing.Point(0, 0)
        Me.lblfloodgate.Name = "lblfloodgate"
        Me.lblfloodgate.Size = New System.Drawing.Size(177, 64)
        Me.lblfloodgate.TabIndex = 3
        Me.lblfloodgate.Text = "Floodgate Manager"
        Me.lblfloodgate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarfloodgateicon
        '
        Me.pnltitlebarfloodgateicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarfloodgateicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarfloodgateicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarfloodgateicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarfloodgateicon.Name = "pnltitlebarfloodgateicon"
        Me.pnltitlebarfloodgateicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarfloodgateicon.TabIndex = 2
        '
        'pnlpanelbuttonfloodgateicon
        '
        Me.pnlpanelbuttonfloodgateicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonfloodgateicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonfloodgateicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonfloodgateicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonfloodgateicon.Name = "pnlpanelbuttonfloodgateicon"
        Me.pnlpanelbuttonfloodgateicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonfloodgateicon.TabIndex = 1
        '
        'pnllauncherfloodgateicon
        '
        Me.pnllauncherfloodgateicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllauncherfloodgateicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllauncherfloodgateicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllauncherfloodgateicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllauncherfloodgateicon.Name = "pnllauncherfloodgateicon"
        Me.pnllauncherfloodgateicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllauncherfloodgateicon.TabIndex = 0
        '
        'pnlmaze
        '
        Me.pnlmaze.Controls.Add(Me.lblmaze)
        Me.pnlmaze.Controls.Add(Me.pnltitlebarmazeicon)
        Me.pnlmaze.Controls.Add(Me.pnlpanelbuttonmazeicon)
        Me.pnlmaze.Controls.Add(Me.pnllaunchermazeicon)
        Me.pnlmaze.Location = New System.Drawing.Point(378, 703)
        Me.pnlmaze.Name = "pnlmaze"
        Me.pnlmaze.Size = New System.Drawing.Size(369, 64)
        Me.pnlmaze.TabIndex = 32
        '
        'lblmaze
        '
        Me.lblmaze.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblmaze.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmaze.Location = New System.Drawing.Point(0, 0)
        Me.lblmaze.Name = "lblmaze"
        Me.lblmaze.Size = New System.Drawing.Size(177, 64)
        Me.lblmaze.TabIndex = 3
        Me.lblmaze.Text = "Labyrinth"
        Me.lblmaze.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarmazeicon
        '
        Me.pnltitlebarmazeicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarmazeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarmazeicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarmazeicon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarmazeicon.Name = "pnltitlebarmazeicon"
        Me.pnltitlebarmazeicon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarmazeicon.TabIndex = 2
        '
        'pnlpanelbuttonmazeicon
        '
        Me.pnlpanelbuttonmazeicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonmazeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonmazeicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonmazeicon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonmazeicon.Name = "pnlpanelbuttonmazeicon"
        Me.pnlpanelbuttonmazeicon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonmazeicon.TabIndex = 1
        '
        'pnllaunchermazeicon
        '
        Me.pnllaunchermazeicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchermazeicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchermazeicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchermazeicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchermazeicon.Name = "pnllaunchermazeicon"
        Me.pnllaunchermazeicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchermazeicon.TabIndex = 0
        '
        'pnlvirusscanner
        '
        Me.pnlvirusscanner.Controls.Add(Me.lblvirusscanner)
        Me.pnlvirusscanner.Controls.Add(Me.pnltitlebarvirusscannericon)
        Me.pnlvirusscanner.Controls.Add(Me.pnlpanelbuttonvirusscannericon)
        Me.pnlvirusscanner.Controls.Add(Me.pnllaunchervirusscannericon)
        Me.pnlvirusscanner.Location = New System.Drawing.Point(753, 703)
        Me.pnlvirusscanner.Name = "pnlvirusscanner"
        Me.pnlvirusscanner.Size = New System.Drawing.Size(369, 64)
        Me.pnlvirusscanner.TabIndex = 33
        '
        'lblvirusscanner
        '
        Me.lblvirusscanner.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblvirusscanner.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblvirusscanner.Location = New System.Drawing.Point(0, 0)
        Me.lblvirusscanner.Name = "lblvirusscanner"
        Me.lblvirusscanner.Size = New System.Drawing.Size(177, 64)
        Me.lblvirusscanner.TabIndex = 3
        Me.lblvirusscanner.Text = "Virus Scanner"
        Me.lblvirusscanner.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnltitlebarvirusscannericon
        '
        Me.pnltitlebarvirusscannericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnltitlebarvirusscannericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnltitlebarvirusscannericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnltitlebarvirusscannericon.Location = New System.Drawing.Point(177, 0)
        Me.pnltitlebarvirusscannericon.Name = "pnltitlebarvirusscannericon"
        Me.pnltitlebarvirusscannericon.Size = New System.Drawing.Size(64, 64)
        Me.pnltitlebarvirusscannericon.TabIndex = 2
        '
        'pnlpanelbuttonvirusscannericon
        '
        Me.pnlpanelbuttonvirusscannericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnlpanelbuttonvirusscannericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlpanelbuttonvirusscannericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlpanelbuttonvirusscannericon.Location = New System.Drawing.Point(241, 0)
        Me.pnlpanelbuttonvirusscannericon.Name = "pnlpanelbuttonvirusscannericon"
        Me.pnlpanelbuttonvirusscannericon.Size = New System.Drawing.Size(64, 64)
        Me.pnlpanelbuttonvirusscannericon.TabIndex = 1
        '
        'pnllaunchervirusscannericon
        '
        Me.pnllaunchervirusscannericon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchervirusscannericon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchervirusscannericon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchervirusscannericon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchervirusscannericon.Name = "pnllaunchervirusscannericon"
        Me.pnllaunchervirusscannericon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchervirusscannericon.TabIndex = 0
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.txtshutdownname)
        Me.Panel8.Controls.Add(Me.pnllaunchershutdownicon)
        Me.Panel8.Location = New System.Drawing.Point(3, 773)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(369, 64)
        Me.Panel8.TabIndex = 34
        '
        'txtshutdownname
        '
        Me.txtshutdownname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtshutdownname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtshutdownname.Location = New System.Drawing.Point(0, 0)
        Me.txtshutdownname.Name = "txtshutdownname"
        Me.txtshutdownname.Size = New System.Drawing.Size(305, 64)
        Me.txtshutdownname.TabIndex = 3
        Me.txtshutdownname.Text = "Shutdown"
        Me.txtshutdownname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnllaunchershutdownicon
        '
        Me.pnllaunchershutdownicon.BackgroundImage = Global.ShiftOS.My.Resources.Resources.iconKnowledgeInput
        Me.pnllaunchershutdownicon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnllaunchershutdownicon.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnllaunchershutdownicon.Location = New System.Drawing.Point(305, 0)
        Me.pnllaunchershutdownicon.Name = "pnllaunchershutdownicon"
        Me.pnllaunchershutdownicon.Size = New System.Drawing.Size(64, 64)
        Me.pnllaunchershutdownicon.TabIndex = 0
        '
        'Icon_Manager
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1453, 704)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Icon_Manager"
        Me.Text = "Icon_Manager"
        Me.TopMost = True
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pgright.ResumeLayout(False)
        Me.pgcontents.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.pnlknowledgeinputicons.ResumeLayout(False)
        Me.pnlshiftoriumicons.ResumeLayout(False)
        Me.pnlclockicons.ResumeLayout(False)
        Me.pnlshiftericons.ResumeLayout(False)
        Me.pnlcolourpickericons.ResumeLayout(False)
        Me.pnlinfoboxicons.ResumeLayout(False)
        Me.pnlpongicons.ResumeLayout(False)
        Me.pnlfileskimmericons.ResumeLayout(False)
        Me.pnltextpadicons.ResumeLayout(False)
        Me.pnlfileopenericons.ResumeLayout(False)
        Me.pnlfilesavericons.ResumeLayout(False)
        Me.pnlgraphicpickericons.ResumeLayout(False)
        Me.pnlskinloadericons.ResumeLayout(False)
        Me.pnlartpadicons.ResumeLayout(False)
        Me.pnlcalculatoricons.ResumeLayout(False)
        Me.pnlaudioplayericons.ResumeLayout(False)
        Me.pnlwebbrowsericons.ResumeLayout(False)
        Me.pnlvideoplayericons.ResumeLayout(False)
        Me.pnlnamechangericons.ResumeLayout(False)
        Me.pnliconmanagericons.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.pnlbitnotewallet.ResumeLayout(False)
        Me.pnlbitnotedigger.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.pgleft.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        Me.pnlskinshifter.ResumeLayout(False)
        Me.pnlshiftnet.ResumeLayout(False)
        Me.pnldodge.ResumeLayout(False)
        Me.pnldownloadmanager.ResumeLayout(False)
        Me.pnlinstaller.ResumeLayout(False)
        Me.pnlsysinfo.ResumeLayout(False)
        Me.pnlorcwrite.ResumeLayout(False)
        Me.pnlfloodgate.ResumeLayout(False)
        Me.pnlmaze.ResumeLayout(False)
        Me.pnlvirusscanner.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pullside As System.Windows.Forms.Timer
    Friend WithEvents pullbs As System.Windows.Forms.Timer
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents pullbottom As System.Windows.Forms.Timer
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnApply As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtlaunchericonsize As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtpanelbuttoniconsize As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txttitlebariconsize As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents pnlknowledgeinputicons As System.Windows.Forms.Panel
    Friend WithEvents txtknowledgeinputname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarknowledgeinputicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonknowledgeinputicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherknowledgeinputicon As System.Windows.Forms.Panel
    Friend WithEvents pnlshiftoriumicons As System.Windows.Forms.Panel
    Friend WithEvents txtshiftoriumname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarshiftoriumicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonshiftoriumicon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchershiftoriumicon As System.Windows.Forms.Panel
    Friend WithEvents pnlclockicons As System.Windows.Forms.Panel
    Friend WithEvents txtclockname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarclockicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonclockicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherclockicon As System.Windows.Forms.Panel
    Friend WithEvents pnlshiftericons As System.Windows.Forms.Panel
    Friend WithEvents txtshiftername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarshiftericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonshiftericon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchershiftericon As System.Windows.Forms.Panel
    Friend WithEvents pnlcolourpickericons As System.Windows.Forms.Panel
    Friend WithEvents txtcolourpickername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarcolourpickericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttoncolourpickericon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchercolourpickericon As System.Windows.Forms.Panel
    Friend WithEvents pnlinfoboxicons As System.Windows.Forms.Panel
    Friend WithEvents txtinfoboxname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarinfoboxicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttoninfoboxicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherinfoboxicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpongicons As System.Windows.Forms.Panel
    Friend WithEvents txtpongname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarpongicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonpongicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherpongicon As System.Windows.Forms.Panel
    Friend WithEvents pnlfileskimmericons As System.Windows.Forms.Panel
    Friend WithEvents txtfileskimmername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarfileskimmericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonfileskimmericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherfileskimmericon As System.Windows.Forms.Panel
    Friend WithEvents pnltextpadicons As System.Windows.Forms.Panel
    Friend WithEvents txttextpadname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebartextpadicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttontextpadicon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchertextpadicon As System.Windows.Forms.Panel
    Friend WithEvents pnlfileopenericons As System.Windows.Forms.Panel
    Friend WithEvents txtfileopenername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarfileopenericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonfileopenericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherfileopenericon As System.Windows.Forms.Panel
    Friend WithEvents pnlfilesavericons As System.Windows.Forms.Panel
    Friend WithEvents txtfilesavername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarfilesavericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonfilesavericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherfilesavericon As System.Windows.Forms.Panel
    Friend WithEvents pnlgraphicpickericons As System.Windows.Forms.Panel
    Friend WithEvents txtgraphicpickername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebargraphicpickericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttongraphicpickericon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchergraphicpickericon As System.Windows.Forms.Panel
    Friend WithEvents pnlskinloadericons As System.Windows.Forms.Panel
    Friend WithEvents txtskinloadername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarskinloadericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonskinloadericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherskinloadericon As System.Windows.Forms.Panel
    Friend WithEvents pnlartpadicons As System.Windows.Forms.Panel
    Friend WithEvents txtartpadname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarartpadicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonartpadicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherartpadicon As System.Windows.Forms.Panel
    Friend WithEvents pnlcalculatoricons As System.Windows.Forms.Panel
    Friend WithEvents txtcalculatorname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarcalculatoricon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttoncalculatoricon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchercalculatoricon As System.Windows.Forms.Panel
    Friend WithEvents pnlaudioplayericons As System.Windows.Forms.Panel
    Friend WithEvents txtaudioplayername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebaraudioplayericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonaudioplayericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncheraudioplayericon As System.Windows.Forms.Panel
    Friend WithEvents pnlwebbrowsericons As System.Windows.Forms.Panel
    Friend WithEvents txtwebbrowsername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarwebbrowsericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonwebbrowsericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherwebbrowsericon As System.Windows.Forms.Panel
    Friend WithEvents pnlvideoplayericons As System.Windows.Forms.Panel
    Friend WithEvents txtvideoplayername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarvideoplayericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonvideoplayericon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchervideoplayericon As System.Windows.Forms.Panel
    Friend WithEvents pnlnamechangericons As System.Windows.Forms.Panel
    Friend WithEvents txtnamechangername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarnamechangericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonnamechangericon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchernamechangericon As System.Windows.Forms.Panel
    Friend WithEvents pnliconmanagericons As System.Windows.Forms.Panel
    Friend WithEvents txticonmanagername As System.Windows.Forms.Label
    Friend WithEvents pnltitlebariconmanagericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttoniconmanagericon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchericonmanagericon As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents txtterminalname As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarterminalicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonterminalicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherterminalicon As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotewallet As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotewallet As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarbitnotewalleticon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonbitnotewalleticon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherbitnotewalleticon As System.Windows.Forms.Panel
    Friend WithEvents pnlbitnotedigger As System.Windows.Forms.Panel
    Friend WithEvents lblbitnotedigger As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarbitnotediggericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonbitnotediggericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherbitnotediggericon As System.Windows.Forms.Panel
    Friend WithEvents pnlskinshifter As System.Windows.Forms.Panel
    Friend WithEvents lblskinshifter As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarskinshiftericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonskinshiftericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherskinshiftericon As System.Windows.Forms.Panel
    Friend WithEvents pnlshiftnet As System.Windows.Forms.Panel
    Friend WithEvents lblshiftnet As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarshiftneticon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonshiftneticon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchershiftneticon As System.Windows.Forms.Panel
    Friend WithEvents pnldodge As System.Windows.Forms.Panel
    Friend WithEvents lbldodge As System.Windows.Forms.Label
    Friend WithEvents pnltitlebardodgeicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttondodgeicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherdodgeicon As System.Windows.Forms.Panel
    Friend WithEvents pnldownloadmanager As System.Windows.Forms.Panel
    Friend WithEvents lbldownload As System.Windows.Forms.Label
    Friend WithEvents pnltitlebardownloadicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttondownloadicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherdownloadicon As System.Windows.Forms.Panel
    Friend WithEvents pnlinstaller As System.Windows.Forms.Panel
    Friend WithEvents lblinstaller As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarinstallericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttoninstallericon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherinstallericon As System.Windows.Forms.Panel
    Friend WithEvents pnlsysinfo As System.Windows.Forms.Panel
    Friend WithEvents lblsysinfo As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarsysinfoicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonsysinfoicon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchersysinfoicon As System.Windows.Forms.Panel
    Friend WithEvents pnlorcwrite As System.Windows.Forms.Panel
    Friend WithEvents lblorcwrite As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarorcwriteicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonorcwriteicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherorcwriteicon As System.Windows.Forms.Panel
    Friend WithEvents pnlfloodgate As System.Windows.Forms.Panel
    Friend WithEvents lblfloodgate As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarfloodgateicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonfloodgateicon As System.Windows.Forms.Panel
    Friend WithEvents pnllauncherfloodgateicon As System.Windows.Forms.Panel
    Friend WithEvents pnlmaze As System.Windows.Forms.Panel
    Friend WithEvents lblmaze As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarmazeicon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonmazeicon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchermazeicon As System.Windows.Forms.Panel
    Friend WithEvents pnlvirusscanner As System.Windows.Forms.Panel
    Friend WithEvents lblvirusscanner As System.Windows.Forms.Label
    Friend WithEvents pnltitlebarvirusscannericon As System.Windows.Forms.Panel
    Friend WithEvents pnlpanelbuttonvirusscannericon As System.Windows.Forms.Panel
    Friend WithEvents pnllaunchervirusscannericon As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents txtshutdownname As System.Windows.Forms.Label
    Friend WithEvents pnllaunchershutdownicon As System.Windows.Forms.Panel
End Class
