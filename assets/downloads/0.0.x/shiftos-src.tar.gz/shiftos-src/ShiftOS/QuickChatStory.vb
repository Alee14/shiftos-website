﻿Public Class QuickChatStory

    Dim UndecidedName As String = "Hacker101"
    Public i = 0
    Public qcmain() As String = {UndecidedName & " joined", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 UndecidedName & " > Hi", _
                 "Marattiopsida", _
                 "Polypodiopsida"}

    Private Sub QuickChatStory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Hacker")
    End Sub
End Class