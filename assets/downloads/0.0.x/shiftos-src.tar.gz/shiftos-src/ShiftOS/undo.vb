﻿Public Class undo

    Public undoStack As New Stack(Of Image)
    Public redoStack As New Stack(Of Image)

End Class
