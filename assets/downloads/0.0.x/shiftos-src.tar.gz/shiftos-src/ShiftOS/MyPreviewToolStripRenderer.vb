﻿Imports ShiftOS.MyNamespace

Public Class MyPreviewToolStripRenderer
    Inherits ToolStripProfessionalRenderer
    Public Sub New()
        MyBase.New(New PreviewCustomColorTable())
    End Sub
End Class
