﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ArtPad
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ArtPad))
        Me.pgcontents = New System.Windows.Forms.Panel()
        Me.pnldrawingbackground = New System.Windows.Forms.Panel()
        Me.pnlpalletsize = New System.Windows.Forms.Panel()
        Me.txttopspace = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtsidespace = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.btnchangesizecancel = New System.Windows.Forms.Button()
        Me.btnsetsize = New System.Windows.Forms.Button()
        Me.txtcolorpalletheight = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.txtcolorpalletwidth = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.pnlinitialcanvassettings = New System.Windows.Forms.Panel()
        Me.btncancel = New System.Windows.Forms.Button()
        Me.btncreate = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lbltotalpixels = New System.Windows.Forms.Label()
        Me.txtnewcanvasheight = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtnewcanvaswidth = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.picdrawingdisplay = New System.Windows.Forms.PictureBox()
        Me.pnlbottompanel = New System.Windows.Forms.Panel()
        Me.pnlpallet = New System.Windows.Forms.Panel()
        Me.flowcolours = New System.Windows.Forms.FlowLayoutPanel()
        Me.colourpallet1 = New System.Windows.Forms.Panel()
        Me.colourpallet2 = New System.Windows.Forms.Panel()
        Me.colourpallet3 = New System.Windows.Forms.Panel()
        Me.colourpallet4 = New System.Windows.Forms.Panel()
        Me.colourpallet5 = New System.Windows.Forms.Panel()
        Me.colourpallet6 = New System.Windows.Forms.Panel()
        Me.colourpallet7 = New System.Windows.Forms.Panel()
        Me.colourpallet8 = New System.Windows.Forms.Panel()
        Me.colourpallet9 = New System.Windows.Forms.Panel()
        Me.colourpallet10 = New System.Windows.Forms.Panel()
        Me.colourpallet11 = New System.Windows.Forms.Panel()
        Me.colourpallet12 = New System.Windows.Forms.Panel()
        Me.colourpallet13 = New System.Windows.Forms.Panel()
        Me.colourpallet14 = New System.Windows.Forms.Panel()
        Me.colourpallet15 = New System.Windows.Forms.Panel()
        Me.colourpallet16 = New System.Windows.Forms.Panel()
        Me.colourpallet17 = New System.Windows.Forms.Panel()
        Me.colourpallet18 = New System.Windows.Forms.Panel()
        Me.colourpallet19 = New System.Windows.Forms.Panel()
        Me.colourpallet20 = New System.Windows.Forms.Panel()
        Me.colourpallet21 = New System.Windows.Forms.Panel()
        Me.colourpallet22 = New System.Windows.Forms.Panel()
        Me.colourpallet23 = New System.Windows.Forms.Panel()
        Me.colourpallet24 = New System.Windows.Forms.Panel()
        Me.colourpallet25 = New System.Windows.Forms.Panel()
        Me.colourpallet26 = New System.Windows.Forms.Panel()
        Me.colourpallet27 = New System.Windows.Forms.Panel()
        Me.colourpallet28 = New System.Windows.Forms.Panel()
        Me.colourpallet29 = New System.Windows.Forms.Panel()
        Me.colourpallet30 = New System.Windows.Forms.Panel()
        Me.colourpallet31 = New System.Windows.Forms.Panel()
        Me.colourpallet32 = New System.Windows.Forms.Panel()
        Me.colourpallet33 = New System.Windows.Forms.Panel()
        Me.colourpallet34 = New System.Windows.Forms.Panel()
        Me.colourpallet35 = New System.Windows.Forms.Panel()
        Me.colourpallet36 = New System.Windows.Forms.Panel()
        Me.colourpallet37 = New System.Windows.Forms.Panel()
        Me.colourpallet38 = New System.Windows.Forms.Panel()
        Me.colourpallet39 = New System.Windows.Forms.Panel()
        Me.colourpallet40 = New System.Windows.Forms.Panel()
        Me.colourpallet41 = New System.Windows.Forms.Panel()
        Me.colourpallet42 = New System.Windows.Forms.Panel()
        Me.colourpallet43 = New System.Windows.Forms.Panel()
        Me.colourpallet44 = New System.Windows.Forms.Panel()
        Me.colourpallet45 = New System.Windows.Forms.Panel()
        Me.colourpallet46 = New System.Windows.Forms.Panel()
        Me.colourpallet47 = New System.Windows.Forms.Panel()
        Me.colourpallet48 = New System.Windows.Forms.Panel()
        Me.colourpallet49 = New System.Windows.Forms.Panel()
        Me.colourpallet50 = New System.Windows.Forms.Panel()
        Me.colourpallet51 = New System.Windows.Forms.Panel()
        Me.colourpallet52 = New System.Windows.Forms.Panel()
        Me.colourpallet53 = New System.Windows.Forms.Panel()
        Me.colourpallet54 = New System.Windows.Forms.Panel()
        Me.colourpallet55 = New System.Windows.Forms.Panel()
        Me.colourpallet56 = New System.Windows.Forms.Panel()
        Me.colourpallet57 = New System.Windows.Forms.Panel()
        Me.colourpallet58 = New System.Windows.Forms.Panel()
        Me.colourpallet59 = New System.Windows.Forms.Panel()
        Me.colourpallet60 = New System.Windows.Forms.Panel()
        Me.colourpallet61 = New System.Windows.Forms.Panel()
        Me.colourpallet62 = New System.Windows.Forms.Panel()
        Me.colourpallet63 = New System.Windows.Forms.Panel()
        Me.colourpallet64 = New System.Windows.Forms.Panel()
        Me.colourpallet65 = New System.Windows.Forms.Panel()
        Me.colourpallet66 = New System.Windows.Forms.Panel()
        Me.colourpallet67 = New System.Windows.Forms.Panel()
        Me.colourpallet68 = New System.Windows.Forms.Panel()
        Me.colourpallet69 = New System.Windows.Forms.Panel()
        Me.colourpallet70 = New System.Windows.Forms.Panel()
        Me.colourpallet71 = New System.Windows.Forms.Panel()
        Me.colourpallet72 = New System.Windows.Forms.Panel()
        Me.colourpallet73 = New System.Windows.Forms.Panel()
        Me.colourpallet74 = New System.Windows.Forms.Panel()
        Me.colourpallet75 = New System.Windows.Forms.Panel()
        Me.colourpallet76 = New System.Windows.Forms.Panel()
        Me.colourpallet77 = New System.Windows.Forms.Panel()
        Me.colourpallet78 = New System.Windows.Forms.Panel()
        Me.colourpallet79 = New System.Windows.Forms.Panel()
        Me.colourpallet80 = New System.Windows.Forms.Panel()
        Me.colourpallet81 = New System.Windows.Forms.Panel()
        Me.colourpallet82 = New System.Windows.Forms.Panel()
        Me.colourpallet83 = New System.Windows.Forms.Panel()
        Me.colourpallet84 = New System.Windows.Forms.Panel()
        Me.colourpallet85 = New System.Windows.Forms.Panel()
        Me.colourpallet86 = New System.Windows.Forms.Panel()
        Me.colourpallet87 = New System.Windows.Forms.Panel()
        Me.colourpallet88 = New System.Windows.Forms.Panel()
        Me.colourpallet89 = New System.Windows.Forms.Panel()
        Me.colourpallet90 = New System.Windows.Forms.Panel()
        Me.colourpallet91 = New System.Windows.Forms.Panel()
        Me.colourpallet92 = New System.Windows.Forms.Panel()
        Me.colourpallet93 = New System.Windows.Forms.Panel()
        Me.colourpallet94 = New System.Windows.Forms.Panel()
        Me.colourpallet95 = New System.Windows.Forms.Panel()
        Me.colourpallet96 = New System.Windows.Forms.Panel()
        Me.colourpallet97 = New System.Windows.Forms.Panel()
        Me.colourpallet98 = New System.Windows.Forms.Panel()
        Me.colourpallet99 = New System.Windows.Forms.Panel()
        Me.colourpallet100 = New System.Windows.Forms.Panel()
        Me.colourpallet101 = New System.Windows.Forms.Panel()
        Me.colourpallet102 = New System.Windows.Forms.Panel()
        Me.colourpallet103 = New System.Windows.Forms.Panel()
        Me.colourpallet104 = New System.Windows.Forms.Panel()
        Me.colourpallet105 = New System.Windows.Forms.Panel()
        Me.colourpallet106 = New System.Windows.Forms.Panel()
        Me.colourpallet107 = New System.Windows.Forms.Panel()
        Me.colourpallet108 = New System.Windows.Forms.Panel()
        Me.colourpallet109 = New System.Windows.Forms.Panel()
        Me.colourpallet110 = New System.Windows.Forms.Panel()
        Me.colourpallet111 = New System.Windows.Forms.Panel()
        Me.colourpallet112 = New System.Windows.Forms.Panel()
        Me.colourpallet113 = New System.Windows.Forms.Panel()
        Me.colourpallet114 = New System.Windows.Forms.Panel()
        Me.colourpallet115 = New System.Windows.Forms.Panel()
        Me.colourpallet116 = New System.Windows.Forms.Panel()
        Me.colourpallet117 = New System.Windows.Forms.Panel()
        Me.colourpallet118 = New System.Windows.Forms.Panel()
        Me.colourpallet119 = New System.Windows.Forms.Panel()
        Me.colourpallet120 = New System.Windows.Forms.Panel()
        Me.colourpallet121 = New System.Windows.Forms.Panel()
        Me.colourpallet122 = New System.Windows.Forms.Panel()
        Me.colourpallet123 = New System.Windows.Forms.Panel()
        Me.colourpallet124 = New System.Windows.Forms.Panel()
        Me.colourpallet125 = New System.Windows.Forms.Panel()
        Me.colourpallet126 = New System.Windows.Forms.Panel()
        Me.colourpallet127 = New System.Windows.Forms.Panel()
        Me.colourpallet128 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.line6 = New System.Windows.Forms.Panel()
        Me.pnltoolproperties = New System.Windows.Forms.Panel()
        Me.pnltexttoolsettings = New System.Windows.Forms.Panel()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.combofontstyle = New System.Windows.Forms.ComboBox()
        Me.txtdrawstringtext = New System.Windows.Forms.TextBox()
        Me.combodrawtextfont = New System.Windows.Forms.ComboBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtdrawtextsize = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.pnlpixelsettersettings = New System.Windows.Forms.Panel()
        Me.btnpixelsettersetpixel = New System.Windows.Forms.Button()
        Me.txtpixelsetterycoordinate = New System.Windows.Forms.TextBox()
        Me.txtpixelsetterxcoordinate = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlpaintbrushtoolsettings = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.btnpaintsquareshape = New System.Windows.Forms.Button()
        Me.btnpaintcircleshape = New System.Windows.Forms.Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.txtpaintbrushsize = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.pnllinetoolsettings = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtlinewidth = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.pnlmagnifiersettings = New System.Windows.Forms.Panel()
        Me.btnzoomout = New System.Windows.Forms.Button()
        Me.btnzoomin = New System.Windows.Forms.Button()
        Me.lblzoomlevel = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.pnleracertoolsettings = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.btneracersquare = New System.Windows.Forms.Button()
        Me.btneracercircle = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txteracersize = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.pnlfloodfillsettings = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.pnlovaltoolsettings = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btnovalfillonoff = New System.Windows.Forms.Button()
        Me.pnlovalfillcolour = New System.Windows.Forms.Panel()
        Me.txtovalborderwidth = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.pnlsquaretoolsettings = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.btnsquarefillonoff = New System.Windows.Forms.Button()
        Me.pnlsquarefillcolour = New System.Windows.Forms.Panel()
        Me.txtsquareborderwidth = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.pnlpixelplacersettings = New System.Windows.Forms.Panel()
        Me.lblpixelplacerhelp = New System.Windows.Forms.Label()
        Me.btnpixelplacermovementmode = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pnlpencilsettings = New System.Windows.Forms.Panel()
        Me.btnpencilsize3 = New System.Windows.Forms.Button()
        Me.btnpencilsize2 = New System.Windows.Forms.Button()
        Me.btnpencilsize1 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.line5 = New System.Windows.Forms.Panel()
        Me.line3 = New System.Windows.Forms.Panel()
        Me.pnltools = New System.Windows.Forms.Panel()
        Me.pnltoolpositioner = New System.Windows.Forms.FlowLayoutPanel()
        Me.btnpixelsetter = New System.Windows.Forms.Button()
        Me.btnpixelplacer = New System.Windows.Forms.Button()
        Me.btnpencil = New System.Windows.Forms.Button()
        Me.btnfloodfill = New System.Windows.Forms.Button()
        Me.btnoval = New System.Windows.Forms.Button()
        Me.btnsquare = New System.Windows.Forms.Button()
        Me.btnlinetool = New System.Windows.Forms.Button()
        Me.btnpaintbrush = New System.Windows.Forms.Button()
        Me.btntexttool = New System.Windows.Forms.Button()
        Me.btneracer = New System.Windows.Forms.Button()
        Me.btnnew = New System.Windows.Forms.Button()
        Me.btnmagnify = New System.Windows.Forms.Button()
        Me.btnopen = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.btnundo = New System.Windows.Forms.Button()
        Me.btnredo = New System.Windows.Forms.Button()
        Me.line1 = New System.Windows.Forms.Panel()
        Me.pnltoolpreview = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.picpreview = New System.Windows.Forms.PictureBox()
        Me.lbltoolselected = New System.Windows.Forms.Label()
        Me.line4 = New System.Windows.Forms.Panel()
        Me.line2 = New System.Windows.Forms.Panel()
        Me.pgleft = New System.Windows.Forms.Panel()
        Me.pgbottomlcorner = New System.Windows.Forms.Panel()
        Me.pgright = New System.Windows.Forms.Panel()
        Me.pgbottomrcorner = New System.Windows.Forms.Panel()
        Me.titlebar = New System.Windows.Forms.Panel()
        Me.minimizebutton = New System.Windows.Forms.Panel()
        Me.pnlicon = New System.Windows.Forms.PictureBox()
        Me.rollupbutton = New System.Windows.Forms.Panel()
        Me.closebutton = New System.Windows.Forms.Panel()
        Me.lbtitletext = New System.Windows.Forms.Label()
        Me.pgtoplcorner = New System.Windows.Forms.Panel()
        Me.pgtoprcorner = New System.Windows.Forms.Panel()
        Me.pgbottom = New System.Windows.Forms.Panel()
        Me.tmrcodepointcooldown = New System.Windows.Forms.Timer(Me.components)
        Me.tmrshowearnedcodepoints = New System.Windows.Forms.Timer(Me.components)
        Me.pullbs = New System.Windows.Forms.Timer(Me.components)
        Me.pullbottom = New System.Windows.Forms.Timer(Me.components)
        Me.pullside = New System.Windows.Forms.Timer(Me.components)
        Me.pgcontents.SuspendLayout()
        Me.pnldrawingbackground.SuspendLayout()
        Me.pnlpalletsize.SuspendLayout()
        Me.pnlinitialcanvassettings.SuspendLayout()
        CType(Me.picdrawingdisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlbottompanel.SuspendLayout()
        Me.pnlpallet.SuspendLayout()
        Me.flowcolours.SuspendLayout()
        Me.pnltoolproperties.SuspendLayout()
        Me.pnltexttoolsettings.SuspendLayout()
        Me.pnlpixelsettersettings.SuspendLayout()
        Me.pnlpaintbrushtoolsettings.SuspendLayout()
        Me.pnllinetoolsettings.SuspendLayout()
        Me.pnlmagnifiersettings.SuspendLayout()
        Me.pnleracertoolsettings.SuspendLayout()
        Me.pnlfloodfillsettings.SuspendLayout()
        Me.pnlovaltoolsettings.SuspendLayout()
        Me.pnlsquaretoolsettings.SuspendLayout()
        Me.pnlpixelplacersettings.SuspendLayout()
        Me.pnlpencilsettings.SuspendLayout()
        Me.pnltools.SuspendLayout()
        Me.pnltoolpositioner.SuspendLayout()
        Me.pnltoolpreview.SuspendLayout()
        CType(Me.picpreview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pgleft.SuspendLayout()
        Me.pgright.SuspendLayout()
        Me.titlebar.SuspendLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pgcontents
        '
        Me.pgcontents.BackColor = System.Drawing.Color.White
        Me.pgcontents.Controls.Add(Me.pnldrawingbackground)
        Me.pgcontents.Controls.Add(Me.pnlbottompanel)
        Me.pgcontents.Controls.Add(Me.pnltools)
        Me.pgcontents.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pgcontents.Location = New System.Drawing.Point(2, 30)
        Me.pgcontents.Name = "pgcontents"
        Me.pgcontents.Size = New System.Drawing.Size(798, 566)
        Me.pgcontents.TabIndex = 20
        '
        'pnldrawingbackground
        '
        Me.pnldrawingbackground.AutoScroll = True
        Me.pnldrawingbackground.BackColor = System.Drawing.Color.Gray
        Me.pnldrawingbackground.Controls.Add(Me.pnlpalletsize)
        Me.pnldrawingbackground.Controls.Add(Me.pnlinitialcanvassettings)
        Me.pnldrawingbackground.Controls.Add(Me.picdrawingdisplay)
        Me.pnldrawingbackground.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnldrawingbackground.Location = New System.Drawing.Point(120, 0)
        Me.pnldrawingbackground.Name = "pnldrawingbackground"
        Me.pnldrawingbackground.Size = New System.Drawing.Size(678, 466)
        Me.pnldrawingbackground.TabIndex = 2
        '
        'pnlpalletsize
        '
        Me.pnlpalletsize.BackColor = System.Drawing.Color.White
        Me.pnlpalletsize.Controls.Add(Me.txttopspace)
        Me.pnlpalletsize.Controls.Add(Me.Label40)
        Me.pnlpalletsize.Controls.Add(Me.txtsidespace)
        Me.pnlpalletsize.Controls.Add(Me.Label41)
        Me.pnlpalletsize.Controls.Add(Me.btnchangesizecancel)
        Me.pnlpalletsize.Controls.Add(Me.btnsetsize)
        Me.pnlpalletsize.Controls.Add(Me.txtcolorpalletheight)
        Me.pnlpalletsize.Controls.Add(Me.Label42)
        Me.pnlpalletsize.Controls.Add(Me.txtcolorpalletwidth)
        Me.pnlpalletsize.Controls.Add(Me.Label43)
        Me.pnlpalletsize.Location = New System.Drawing.Point(207, 178)
        Me.pnlpalletsize.Name = "pnlpalletsize"
        Me.pnlpalletsize.Size = New System.Drawing.Size(259, 100)
        Me.pnlpalletsize.TabIndex = 2
        Me.pnlpalletsize.Visible = False
        '
        'txttopspace
        '
        Me.txttopspace.BackColor = System.Drawing.Color.White
        Me.txttopspace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttopspace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttopspace.Location = New System.Drawing.Point(198, 38)
        Me.txttopspace.Name = "txttopspace"
        Me.txttopspace.Size = New System.Drawing.Size(54, 22)
        Me.txttopspace.TabIndex = 11
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(115, 40)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(79, 16)
        Me.Label40.TabIndex = 10
        Me.Label40.Text = "Top Space:"
        '
        'txtsidespace
        '
        Me.txtsidespace.BackColor = System.Drawing.Color.White
        Me.txtsidespace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsidespace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsidespace.Location = New System.Drawing.Point(198, 10)
        Me.txtsidespace.Name = "txtsidespace"
        Me.txtsidespace.Size = New System.Drawing.Size(54, 22)
        Me.txtsidespace.TabIndex = 9
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(115, 12)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(82, 16)
        Me.Label41.TabIndex = 8
        Me.Label41.Text = "Side Space:"
        '
        'btnchangesizecancel
        '
        Me.btnchangesizecancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnchangesizecancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnchangesizecancel.Location = New System.Drawing.Point(7, 66)
        Me.btnchangesizecancel.Name = "btnchangesizecancel"
        Me.btnchangesizecancel.Size = New System.Drawing.Size(121, 28)
        Me.btnchangesizecancel.TabIndex = 7
        Me.btnchangesizecancel.Text = "Close"
        Me.btnchangesizecancel.UseVisualStyleBackColor = True
        '
        'btnsetsize
        '
        Me.btnsetsize.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsetsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsetsize.Location = New System.Drawing.Point(133, 66)
        Me.btnsetsize.Name = "btnsetsize"
        Me.btnsetsize.Size = New System.Drawing.Size(119, 28)
        Me.btnsetsize.TabIndex = 6
        Me.btnsetsize.Text = "Set Size"
        Me.btnsetsize.UseVisualStyleBackColor = True
        '
        'txtcolorpalletheight
        '
        Me.txtcolorpalletheight.BackColor = System.Drawing.Color.White
        Me.txtcolorpalletheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcolorpalletheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcolorpalletheight.Location = New System.Drawing.Point(59, 37)
        Me.txtcolorpalletheight.Name = "txtcolorpalletheight"
        Me.txtcolorpalletheight.Size = New System.Drawing.Size(54, 22)
        Me.txtcolorpalletheight.TabIndex = 3
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(8, 40)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(50, 16)
        Me.Label42.TabIndex = 2
        Me.Label42.Text = "Height:"
        '
        'txtcolorpalletwidth
        '
        Me.txtcolorpalletwidth.BackColor = System.Drawing.Color.White
        Me.txtcolorpalletwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcolorpalletwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcolorpalletwidth.Location = New System.Drawing.Point(59, 9)
        Me.txtcolorpalletwidth.Name = "txtcolorpalletwidth"
        Me.txtcolorpalletwidth.Size = New System.Drawing.Size(54, 22)
        Me.txtcolorpalletwidth.TabIndex = 1
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(8, 12)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(45, 16)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Width:"
        '
        'pnlinitialcanvassettings
        '
        Me.pnlinitialcanvassettings.BackColor = System.Drawing.Color.White
        Me.pnlinitialcanvassettings.Controls.Add(Me.btncancel)
        Me.pnlinitialcanvassettings.Controls.Add(Me.btncreate)
        Me.pnlinitialcanvassettings.Controls.Add(Me.Label11)
        Me.pnlinitialcanvassettings.Controls.Add(Me.lbltotalpixels)
        Me.pnlinitialcanvassettings.Controls.Add(Me.txtnewcanvasheight)
        Me.pnlinitialcanvassettings.Controls.Add(Me.Label10)
        Me.pnlinitialcanvassettings.Controls.Add(Me.txtnewcanvaswidth)
        Me.pnlinitialcanvassettings.Controls.Add(Me.Label9)
        Me.pnlinitialcanvassettings.Location = New System.Drawing.Point(223, 178)
        Me.pnlinitialcanvassettings.Name = "pnlinitialcanvassettings"
        Me.pnlinitialcanvassettings.Size = New System.Drawing.Size(223, 100)
        Me.pnlinitialcanvassettings.TabIndex = 1
        '
        'btncancel
        '
        Me.btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(7, 66)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(102, 28)
        Me.btncancel.TabIndex = 7
        Me.btncancel.Text = "Cancel"
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'btncreate
        '
        Me.btncreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncreate.Location = New System.Drawing.Point(114, 66)
        Me.btncreate.Name = "btncreate"
        Me.btncreate.Size = New System.Drawing.Size(102, 28)
        Me.btncreate.TabIndex = 6
        Me.btncreate.Text = "Create"
        Me.btncreate.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(124, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(88, 20)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Total Pixels"
        '
        'lbltotalpixels
        '
        Me.lbltotalpixels.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltotalpixels.Location = New System.Drawing.Point(114, 30)
        Me.lbltotalpixels.Name = "lbltotalpixels"
        Me.lbltotalpixels.Size = New System.Drawing.Size(106, 29)
        Me.lbltotalpixels.TabIndex = 4
        Me.lbltotalpixels.Text = "0"
        Me.lbltotalpixels.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtnewcanvasheight
        '
        Me.txtnewcanvasheight.BackColor = System.Drawing.Color.White
        Me.txtnewcanvasheight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnewcanvasheight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnewcanvasheight.Location = New System.Drawing.Point(59, 37)
        Me.txtnewcanvasheight.MaxLength = 4
        Me.txtnewcanvasheight.Name = "txtnewcanvasheight"
        Me.txtnewcanvasheight.Size = New System.Drawing.Size(54, 22)
        Me.txtnewcanvasheight.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(8, 40)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 16)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Height:"
        '
        'txtnewcanvaswidth
        '
        Me.txtnewcanvaswidth.BackColor = System.Drawing.Color.White
        Me.txtnewcanvaswidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnewcanvaswidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnewcanvaswidth.Location = New System.Drawing.Point(59, 9)
        Me.txtnewcanvaswidth.MaxLength = 4
        Me.txtnewcanvaswidth.Name = "txtnewcanvaswidth"
        Me.txtnewcanvaswidth.Size = New System.Drawing.Size(54, 22)
        Me.txtnewcanvaswidth.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(8, 12)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 16)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Width:"
        '
        'picdrawingdisplay
        '
        Me.picdrawingdisplay.BackColor = System.Drawing.Color.White
        Me.picdrawingdisplay.Location = New System.Drawing.Point(180, 108)
        Me.picdrawingdisplay.Name = "picdrawingdisplay"
        Me.picdrawingdisplay.Size = New System.Drawing.Size(100, 50)
        Me.picdrawingdisplay.TabIndex = 0
        Me.picdrawingdisplay.TabStop = False
        Me.picdrawingdisplay.Visible = False
        '
        'pnlbottompanel
        '
        Me.pnlbottompanel.Controls.Add(Me.pnlpallet)
        Me.pnlbottompanel.Controls.Add(Me.pnltoolproperties)
        Me.pnlbottompanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlbottompanel.Location = New System.Drawing.Point(120, 466)
        Me.pnlbottompanel.Name = "pnlbottompanel"
        Me.pnlbottompanel.Size = New System.Drawing.Size(678, 100)
        Me.pnlbottompanel.TabIndex = 1
        '
        'pnlpallet
        '
        Me.pnlpallet.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlpallet.Controls.Add(Me.flowcolours)
        Me.pnlpallet.Controls.Add(Me.Label4)
        Me.pnlpallet.Controls.Add(Me.line6)
        Me.pnlpallet.Location = New System.Drawing.Point(457, 0)
        Me.pnlpallet.Name = "pnlpallet"
        Me.pnlpallet.Size = New System.Drawing.Size(221, 100)
        Me.pnlpallet.TabIndex = 0
        '
        'flowcolours
        '
        Me.flowcolours.Controls.Add(Me.colourpallet1)
        Me.flowcolours.Controls.Add(Me.colourpallet2)
        Me.flowcolours.Controls.Add(Me.colourpallet3)
        Me.flowcolours.Controls.Add(Me.colourpallet4)
        Me.flowcolours.Controls.Add(Me.colourpallet5)
        Me.flowcolours.Controls.Add(Me.colourpallet6)
        Me.flowcolours.Controls.Add(Me.colourpallet7)
        Me.flowcolours.Controls.Add(Me.colourpallet8)
        Me.flowcolours.Controls.Add(Me.colourpallet9)
        Me.flowcolours.Controls.Add(Me.colourpallet10)
        Me.flowcolours.Controls.Add(Me.colourpallet11)
        Me.flowcolours.Controls.Add(Me.colourpallet12)
        Me.flowcolours.Controls.Add(Me.colourpallet13)
        Me.flowcolours.Controls.Add(Me.colourpallet14)
        Me.flowcolours.Controls.Add(Me.colourpallet15)
        Me.flowcolours.Controls.Add(Me.colourpallet16)
        Me.flowcolours.Controls.Add(Me.colourpallet17)
        Me.flowcolours.Controls.Add(Me.colourpallet18)
        Me.flowcolours.Controls.Add(Me.colourpallet19)
        Me.flowcolours.Controls.Add(Me.colourpallet20)
        Me.flowcolours.Controls.Add(Me.colourpallet21)
        Me.flowcolours.Controls.Add(Me.colourpallet22)
        Me.flowcolours.Controls.Add(Me.colourpallet23)
        Me.flowcolours.Controls.Add(Me.colourpallet24)
        Me.flowcolours.Controls.Add(Me.colourpallet25)
        Me.flowcolours.Controls.Add(Me.colourpallet26)
        Me.flowcolours.Controls.Add(Me.colourpallet27)
        Me.flowcolours.Controls.Add(Me.colourpallet28)
        Me.flowcolours.Controls.Add(Me.colourpallet29)
        Me.flowcolours.Controls.Add(Me.colourpallet30)
        Me.flowcolours.Controls.Add(Me.colourpallet31)
        Me.flowcolours.Controls.Add(Me.colourpallet32)
        Me.flowcolours.Controls.Add(Me.colourpallet33)
        Me.flowcolours.Controls.Add(Me.colourpallet34)
        Me.flowcolours.Controls.Add(Me.colourpallet35)
        Me.flowcolours.Controls.Add(Me.colourpallet36)
        Me.flowcolours.Controls.Add(Me.colourpallet37)
        Me.flowcolours.Controls.Add(Me.colourpallet38)
        Me.flowcolours.Controls.Add(Me.colourpallet39)
        Me.flowcolours.Controls.Add(Me.colourpallet40)
        Me.flowcolours.Controls.Add(Me.colourpallet41)
        Me.flowcolours.Controls.Add(Me.colourpallet42)
        Me.flowcolours.Controls.Add(Me.colourpallet43)
        Me.flowcolours.Controls.Add(Me.colourpallet44)
        Me.flowcolours.Controls.Add(Me.colourpallet45)
        Me.flowcolours.Controls.Add(Me.colourpallet46)
        Me.flowcolours.Controls.Add(Me.colourpallet47)
        Me.flowcolours.Controls.Add(Me.colourpallet48)
        Me.flowcolours.Controls.Add(Me.colourpallet49)
        Me.flowcolours.Controls.Add(Me.colourpallet50)
        Me.flowcolours.Controls.Add(Me.colourpallet51)
        Me.flowcolours.Controls.Add(Me.colourpallet52)
        Me.flowcolours.Controls.Add(Me.colourpallet53)
        Me.flowcolours.Controls.Add(Me.colourpallet54)
        Me.flowcolours.Controls.Add(Me.colourpallet55)
        Me.flowcolours.Controls.Add(Me.colourpallet56)
        Me.flowcolours.Controls.Add(Me.colourpallet57)
        Me.flowcolours.Controls.Add(Me.colourpallet58)
        Me.flowcolours.Controls.Add(Me.colourpallet59)
        Me.flowcolours.Controls.Add(Me.colourpallet60)
        Me.flowcolours.Controls.Add(Me.colourpallet61)
        Me.flowcolours.Controls.Add(Me.colourpallet62)
        Me.flowcolours.Controls.Add(Me.colourpallet63)
        Me.flowcolours.Controls.Add(Me.colourpallet64)
        Me.flowcolours.Controls.Add(Me.colourpallet65)
        Me.flowcolours.Controls.Add(Me.colourpallet66)
        Me.flowcolours.Controls.Add(Me.colourpallet67)
        Me.flowcolours.Controls.Add(Me.colourpallet68)
        Me.flowcolours.Controls.Add(Me.colourpallet69)
        Me.flowcolours.Controls.Add(Me.colourpallet70)
        Me.flowcolours.Controls.Add(Me.colourpallet71)
        Me.flowcolours.Controls.Add(Me.colourpallet72)
        Me.flowcolours.Controls.Add(Me.colourpallet73)
        Me.flowcolours.Controls.Add(Me.colourpallet74)
        Me.flowcolours.Controls.Add(Me.colourpallet75)
        Me.flowcolours.Controls.Add(Me.colourpallet76)
        Me.flowcolours.Controls.Add(Me.colourpallet77)
        Me.flowcolours.Controls.Add(Me.colourpallet78)
        Me.flowcolours.Controls.Add(Me.colourpallet79)
        Me.flowcolours.Controls.Add(Me.colourpallet80)
        Me.flowcolours.Controls.Add(Me.colourpallet81)
        Me.flowcolours.Controls.Add(Me.colourpallet82)
        Me.flowcolours.Controls.Add(Me.colourpallet83)
        Me.flowcolours.Controls.Add(Me.colourpallet84)
        Me.flowcolours.Controls.Add(Me.colourpallet85)
        Me.flowcolours.Controls.Add(Me.colourpallet86)
        Me.flowcolours.Controls.Add(Me.colourpallet87)
        Me.flowcolours.Controls.Add(Me.colourpallet88)
        Me.flowcolours.Controls.Add(Me.colourpallet89)
        Me.flowcolours.Controls.Add(Me.colourpallet90)
        Me.flowcolours.Controls.Add(Me.colourpallet91)
        Me.flowcolours.Controls.Add(Me.colourpallet92)
        Me.flowcolours.Controls.Add(Me.colourpallet93)
        Me.flowcolours.Controls.Add(Me.colourpallet94)
        Me.flowcolours.Controls.Add(Me.colourpallet95)
        Me.flowcolours.Controls.Add(Me.colourpallet96)
        Me.flowcolours.Controls.Add(Me.colourpallet97)
        Me.flowcolours.Controls.Add(Me.colourpallet98)
        Me.flowcolours.Controls.Add(Me.colourpallet99)
        Me.flowcolours.Controls.Add(Me.colourpallet100)
        Me.flowcolours.Controls.Add(Me.colourpallet101)
        Me.flowcolours.Controls.Add(Me.colourpallet102)
        Me.flowcolours.Controls.Add(Me.colourpallet103)
        Me.flowcolours.Controls.Add(Me.colourpallet104)
        Me.flowcolours.Controls.Add(Me.colourpallet105)
        Me.flowcolours.Controls.Add(Me.colourpallet106)
        Me.flowcolours.Controls.Add(Me.colourpallet107)
        Me.flowcolours.Controls.Add(Me.colourpallet108)
        Me.flowcolours.Controls.Add(Me.colourpallet109)
        Me.flowcolours.Controls.Add(Me.colourpallet110)
        Me.flowcolours.Controls.Add(Me.colourpallet111)
        Me.flowcolours.Controls.Add(Me.colourpallet112)
        Me.flowcolours.Controls.Add(Me.colourpallet113)
        Me.flowcolours.Controls.Add(Me.colourpallet114)
        Me.flowcolours.Controls.Add(Me.colourpallet115)
        Me.flowcolours.Controls.Add(Me.colourpallet116)
        Me.flowcolours.Controls.Add(Me.colourpallet117)
        Me.flowcolours.Controls.Add(Me.colourpallet118)
        Me.flowcolours.Controls.Add(Me.colourpallet119)
        Me.flowcolours.Controls.Add(Me.colourpallet120)
        Me.flowcolours.Controls.Add(Me.colourpallet121)
        Me.flowcolours.Controls.Add(Me.colourpallet122)
        Me.flowcolours.Controls.Add(Me.colourpallet123)
        Me.flowcolours.Controls.Add(Me.colourpallet124)
        Me.flowcolours.Controls.Add(Me.colourpallet125)
        Me.flowcolours.Controls.Add(Me.colourpallet126)
        Me.flowcolours.Controls.Add(Me.colourpallet127)
        Me.flowcolours.Controls.Add(Me.colourpallet128)
        Me.flowcolours.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.flowcolours.Location = New System.Drawing.Point(0, 27)
        Me.flowcolours.Name = "flowcolours"
        Me.flowcolours.Padding = New System.Windows.Forms.Padding(1, 1, 0, 0)
        Me.flowcolours.Size = New System.Drawing.Size(221, 73)
        Me.flowcolours.TabIndex = 12
        '
        'colourpallet1
        '
        Me.colourpallet1.BackColor = System.Drawing.Color.Black
        Me.colourpallet1.Location = New System.Drawing.Point(2, 1)
        Me.colourpallet1.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet1.Name = "colourpallet1"
        Me.colourpallet1.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet1.TabIndex = 5
        Me.colourpallet1.Visible = False
        '
        'colourpallet2
        '
        Me.colourpallet2.BackColor = System.Drawing.Color.Black
        Me.colourpallet2.Location = New System.Drawing.Point(15, 1)
        Me.colourpallet2.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet2.Name = "colourpallet2"
        Me.colourpallet2.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet2.TabIndex = 9
        Me.colourpallet2.Visible = False
        '
        'colourpallet3
        '
        Me.colourpallet3.BackColor = System.Drawing.Color.Black
        Me.colourpallet3.Location = New System.Drawing.Point(28, 1)
        Me.colourpallet3.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet3.Name = "colourpallet3"
        Me.colourpallet3.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet3.TabIndex = 13
        Me.colourpallet3.Visible = False
        '
        'colourpallet4
        '
        Me.colourpallet4.BackColor = System.Drawing.Color.Black
        Me.colourpallet4.Location = New System.Drawing.Point(41, 1)
        Me.colourpallet4.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet4.Name = "colourpallet4"
        Me.colourpallet4.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet4.TabIndex = 9
        Me.colourpallet4.Visible = False
        '
        'colourpallet5
        '
        Me.colourpallet5.BackColor = System.Drawing.Color.Black
        Me.colourpallet5.Location = New System.Drawing.Point(54, 1)
        Me.colourpallet5.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet5.Name = "colourpallet5"
        Me.colourpallet5.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet5.TabIndex = 18
        Me.colourpallet5.Visible = False
        '
        'colourpallet6
        '
        Me.colourpallet6.BackColor = System.Drawing.Color.Black
        Me.colourpallet6.Location = New System.Drawing.Point(67, 1)
        Me.colourpallet6.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet6.Name = "colourpallet6"
        Me.colourpallet6.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet6.TabIndex = 17
        Me.colourpallet6.Visible = False
        '
        'colourpallet7
        '
        Me.colourpallet7.BackColor = System.Drawing.Color.Black
        Me.colourpallet7.Location = New System.Drawing.Point(80, 1)
        Me.colourpallet7.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet7.Name = "colourpallet7"
        Me.colourpallet7.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet7.TabIndex = 14
        Me.colourpallet7.Visible = False
        '
        'colourpallet8
        '
        Me.colourpallet8.BackColor = System.Drawing.Color.Black
        Me.colourpallet8.Location = New System.Drawing.Point(93, 1)
        Me.colourpallet8.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet8.Name = "colourpallet8"
        Me.colourpallet8.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet8.TabIndex = 13
        Me.colourpallet8.Visible = False
        '
        'colourpallet9
        '
        Me.colourpallet9.BackColor = System.Drawing.Color.Black
        Me.colourpallet9.Location = New System.Drawing.Point(106, 1)
        Me.colourpallet9.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet9.Name = "colourpallet9"
        Me.colourpallet9.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet9.TabIndex = 15
        Me.colourpallet9.Visible = False
        '
        'colourpallet10
        '
        Me.colourpallet10.BackColor = System.Drawing.Color.Black
        Me.colourpallet10.Location = New System.Drawing.Point(119, 1)
        Me.colourpallet10.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet10.Name = "colourpallet10"
        Me.colourpallet10.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet10.TabIndex = 11
        Me.colourpallet10.Visible = False
        '
        'colourpallet11
        '
        Me.colourpallet11.BackColor = System.Drawing.Color.Black
        Me.colourpallet11.Location = New System.Drawing.Point(132, 1)
        Me.colourpallet11.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet11.Name = "colourpallet11"
        Me.colourpallet11.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet11.TabIndex = 12
        Me.colourpallet11.Visible = False
        '
        'colourpallet12
        '
        Me.colourpallet12.BackColor = System.Drawing.Color.Black
        Me.colourpallet12.Location = New System.Drawing.Point(145, 1)
        Me.colourpallet12.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet12.Name = "colourpallet12"
        Me.colourpallet12.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet12.TabIndex = 16
        Me.colourpallet12.Visible = False
        '
        'colourpallet13
        '
        Me.colourpallet13.BackColor = System.Drawing.Color.Black
        Me.colourpallet13.Location = New System.Drawing.Point(158, 1)
        Me.colourpallet13.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet13.Name = "colourpallet13"
        Me.colourpallet13.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet13.TabIndex = 10
        Me.colourpallet13.Visible = False
        '
        'colourpallet14
        '
        Me.colourpallet14.BackColor = System.Drawing.Color.Black
        Me.colourpallet14.Location = New System.Drawing.Point(171, 1)
        Me.colourpallet14.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet14.Name = "colourpallet14"
        Me.colourpallet14.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet14.TabIndex = 20
        Me.colourpallet14.Visible = False
        '
        'colourpallet15
        '
        Me.colourpallet15.BackColor = System.Drawing.Color.Black
        Me.colourpallet15.Location = New System.Drawing.Point(184, 1)
        Me.colourpallet15.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet15.Name = "colourpallet15"
        Me.colourpallet15.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet15.TabIndex = 14
        Me.colourpallet15.Visible = False
        '
        'colourpallet16
        '
        Me.colourpallet16.BackColor = System.Drawing.Color.Black
        Me.colourpallet16.Location = New System.Drawing.Point(197, 1)
        Me.colourpallet16.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet16.Name = "colourpallet16"
        Me.colourpallet16.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet16.TabIndex = 16
        Me.colourpallet16.Visible = False
        '
        'colourpallet17
        '
        Me.colourpallet17.BackColor = System.Drawing.Color.Black
        Me.colourpallet17.Location = New System.Drawing.Point(2, 10)
        Me.colourpallet17.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet17.Name = "colourpallet17"
        Me.colourpallet17.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet17.TabIndex = 11
        Me.colourpallet17.Visible = False
        '
        'colourpallet18
        '
        Me.colourpallet18.BackColor = System.Drawing.Color.Black
        Me.colourpallet18.Location = New System.Drawing.Point(15, 10)
        Me.colourpallet18.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet18.Name = "colourpallet18"
        Me.colourpallet18.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet18.TabIndex = 8
        Me.colourpallet18.Visible = False
        '
        'colourpallet19
        '
        Me.colourpallet19.BackColor = System.Drawing.Color.Black
        Me.colourpallet19.Location = New System.Drawing.Point(28, 10)
        Me.colourpallet19.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet19.Name = "colourpallet19"
        Me.colourpallet19.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet19.TabIndex = 24
        Me.colourpallet19.Visible = False
        '
        'colourpallet20
        '
        Me.colourpallet20.BackColor = System.Drawing.Color.Black
        Me.colourpallet20.Location = New System.Drawing.Point(41, 10)
        Me.colourpallet20.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet20.Name = "colourpallet20"
        Me.colourpallet20.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet20.TabIndex = 12
        Me.colourpallet20.Visible = False
        '
        'colourpallet21
        '
        Me.colourpallet21.BackColor = System.Drawing.Color.Black
        Me.colourpallet21.Location = New System.Drawing.Point(54, 10)
        Me.colourpallet21.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet21.Name = "colourpallet21"
        Me.colourpallet21.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet21.TabIndex = 20
        Me.colourpallet21.Visible = False
        '
        'colourpallet22
        '
        Me.colourpallet22.BackColor = System.Drawing.Color.Black
        Me.colourpallet22.Location = New System.Drawing.Point(67, 10)
        Me.colourpallet22.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet22.Name = "colourpallet22"
        Me.colourpallet22.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet22.TabIndex = 8
        Me.colourpallet22.Visible = False
        '
        'colourpallet23
        '
        Me.colourpallet23.BackColor = System.Drawing.Color.Black
        Me.colourpallet23.Location = New System.Drawing.Point(80, 10)
        Me.colourpallet23.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet23.Name = "colourpallet23"
        Me.colourpallet23.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet23.TabIndex = 19
        Me.colourpallet23.Visible = False
        '
        'colourpallet24
        '
        Me.colourpallet24.BackColor = System.Drawing.Color.Black
        Me.colourpallet24.Location = New System.Drawing.Point(93, 10)
        Me.colourpallet24.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet24.Name = "colourpallet24"
        Me.colourpallet24.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet24.TabIndex = 10
        Me.colourpallet24.Visible = False
        '
        'colourpallet25
        '
        Me.colourpallet25.BackColor = System.Drawing.Color.Black
        Me.colourpallet25.Location = New System.Drawing.Point(106, 10)
        Me.colourpallet25.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet25.Name = "colourpallet25"
        Me.colourpallet25.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet25.TabIndex = 15
        Me.colourpallet25.Visible = False
        '
        'colourpallet26
        '
        Me.colourpallet26.BackColor = System.Drawing.Color.Black
        Me.colourpallet26.Location = New System.Drawing.Point(119, 10)
        Me.colourpallet26.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet26.Name = "colourpallet26"
        Me.colourpallet26.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet26.TabIndex = 23
        Me.colourpallet26.Visible = False
        '
        'colourpallet27
        '
        Me.colourpallet27.BackColor = System.Drawing.Color.Black
        Me.colourpallet27.Location = New System.Drawing.Point(132, 10)
        Me.colourpallet27.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet27.Name = "colourpallet27"
        Me.colourpallet27.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet27.TabIndex = 6
        Me.colourpallet27.Visible = False
        '
        'colourpallet28
        '
        Me.colourpallet28.BackColor = System.Drawing.Color.Black
        Me.colourpallet28.Location = New System.Drawing.Point(145, 10)
        Me.colourpallet28.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet28.Name = "colourpallet28"
        Me.colourpallet28.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet28.TabIndex = 19
        Me.colourpallet28.Visible = False
        '
        'colourpallet29
        '
        Me.colourpallet29.BackColor = System.Drawing.Color.Black
        Me.colourpallet29.Location = New System.Drawing.Point(158, 10)
        Me.colourpallet29.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet29.Name = "colourpallet29"
        Me.colourpallet29.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet29.TabIndex = 22
        Me.colourpallet29.Visible = False
        '
        'colourpallet30
        '
        Me.colourpallet30.BackColor = System.Drawing.Color.Black
        Me.colourpallet30.Location = New System.Drawing.Point(171, 10)
        Me.colourpallet30.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet30.Name = "colourpallet30"
        Me.colourpallet30.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet30.TabIndex = 18
        Me.colourpallet30.Visible = False
        '
        'colourpallet31
        '
        Me.colourpallet31.BackColor = System.Drawing.Color.Black
        Me.colourpallet31.Location = New System.Drawing.Point(184, 10)
        Me.colourpallet31.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet31.Name = "colourpallet31"
        Me.colourpallet31.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet31.TabIndex = 21
        Me.colourpallet31.Visible = False
        '
        'colourpallet32
        '
        Me.colourpallet32.BackColor = System.Drawing.Color.Black
        Me.colourpallet32.Location = New System.Drawing.Point(197, 10)
        Me.colourpallet32.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet32.Name = "colourpallet32"
        Me.colourpallet32.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet32.TabIndex = 17
        Me.colourpallet32.Visible = False
        '
        'colourpallet33
        '
        Me.colourpallet33.BackColor = System.Drawing.Color.Black
        Me.colourpallet33.Location = New System.Drawing.Point(2, 19)
        Me.colourpallet33.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet33.Name = "colourpallet33"
        Me.colourpallet33.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet33.TabIndex = 50
        Me.colourpallet33.Visible = False
        '
        'colourpallet34
        '
        Me.colourpallet34.BackColor = System.Drawing.Color.Black
        Me.colourpallet34.Location = New System.Drawing.Point(15, 19)
        Me.colourpallet34.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet34.Name = "colourpallet34"
        Me.colourpallet34.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet34.TabIndex = 46
        Me.colourpallet34.Visible = False
        '
        'colourpallet35
        '
        Me.colourpallet35.BackColor = System.Drawing.Color.Black
        Me.colourpallet35.Location = New System.Drawing.Point(28, 19)
        Me.colourpallet35.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet35.Name = "colourpallet35"
        Me.colourpallet35.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet35.TabIndex = 53
        Me.colourpallet35.Visible = False
        '
        'colourpallet36
        '
        Me.colourpallet36.BackColor = System.Drawing.Color.Black
        Me.colourpallet36.Location = New System.Drawing.Point(41, 19)
        Me.colourpallet36.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet36.Name = "colourpallet36"
        Me.colourpallet36.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet36.TabIndex = 48
        Me.colourpallet36.Visible = False
        '
        'colourpallet37
        '
        Me.colourpallet37.BackColor = System.Drawing.Color.Black
        Me.colourpallet37.Location = New System.Drawing.Point(54, 19)
        Me.colourpallet37.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet37.Name = "colourpallet37"
        Me.colourpallet37.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet37.TabIndex = 54
        Me.colourpallet37.Visible = False
        '
        'colourpallet38
        '
        Me.colourpallet38.BackColor = System.Drawing.Color.Black
        Me.colourpallet38.Location = New System.Drawing.Point(67, 19)
        Me.colourpallet38.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet38.Name = "colourpallet38"
        Me.colourpallet38.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet38.TabIndex = 26
        Me.colourpallet38.Visible = False
        '
        'colourpallet39
        '
        Me.colourpallet39.BackColor = System.Drawing.Color.Black
        Me.colourpallet39.Location = New System.Drawing.Point(80, 19)
        Me.colourpallet39.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet39.Name = "colourpallet39"
        Me.colourpallet39.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet39.TabIndex = 55
        Me.colourpallet39.Visible = False
        '
        'colourpallet40
        '
        Me.colourpallet40.BackColor = System.Drawing.Color.Black
        Me.colourpallet40.Location = New System.Drawing.Point(93, 19)
        Me.colourpallet40.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet40.Name = "colourpallet40"
        Me.colourpallet40.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet40.TabIndex = 41
        Me.colourpallet40.Visible = False
        '
        'colourpallet41
        '
        Me.colourpallet41.BackColor = System.Drawing.Color.Black
        Me.colourpallet41.Location = New System.Drawing.Point(106, 19)
        Me.colourpallet41.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet41.Name = "colourpallet41"
        Me.colourpallet41.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet41.TabIndex = 31
        Me.colourpallet41.Visible = False
        '
        'colourpallet42
        '
        Me.colourpallet42.BackColor = System.Drawing.Color.Black
        Me.colourpallet42.Location = New System.Drawing.Point(119, 19)
        Me.colourpallet42.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet42.Name = "colourpallet42"
        Me.colourpallet42.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet42.TabIndex = 49
        Me.colourpallet42.Visible = False
        '
        'colourpallet43
        '
        Me.colourpallet43.BackColor = System.Drawing.Color.Black
        Me.colourpallet43.Location = New System.Drawing.Point(132, 19)
        Me.colourpallet43.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet43.Name = "colourpallet43"
        Me.colourpallet43.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet43.TabIndex = 27
        Me.colourpallet43.Visible = False
        '
        'colourpallet44
        '
        Me.colourpallet44.BackColor = System.Drawing.Color.Black
        Me.colourpallet44.Location = New System.Drawing.Point(145, 19)
        Me.colourpallet44.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet44.Name = "colourpallet44"
        Me.colourpallet44.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet44.TabIndex = 51
        Me.colourpallet44.Visible = False
        '
        'colourpallet45
        '
        Me.colourpallet45.BackColor = System.Drawing.Color.Black
        Me.colourpallet45.Location = New System.Drawing.Point(158, 19)
        Me.colourpallet45.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet45.Name = "colourpallet45"
        Me.colourpallet45.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet45.TabIndex = 36
        Me.colourpallet45.Visible = False
        '
        'colourpallet46
        '
        Me.colourpallet46.BackColor = System.Drawing.Color.Black
        Me.colourpallet46.Location = New System.Drawing.Point(171, 19)
        Me.colourpallet46.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet46.Name = "colourpallet46"
        Me.colourpallet46.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet46.TabIndex = 56
        Me.colourpallet46.Visible = False
        '
        'colourpallet47
        '
        Me.colourpallet47.BackColor = System.Drawing.Color.Black
        Me.colourpallet47.Location = New System.Drawing.Point(184, 19)
        Me.colourpallet47.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet47.Name = "colourpallet47"
        Me.colourpallet47.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet47.TabIndex = 28
        Me.colourpallet47.Visible = False
        '
        'colourpallet48
        '
        Me.colourpallet48.BackColor = System.Drawing.Color.Black
        Me.colourpallet48.Location = New System.Drawing.Point(197, 19)
        Me.colourpallet48.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet48.Name = "colourpallet48"
        Me.colourpallet48.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet48.TabIndex = 33
        Me.colourpallet48.Visible = False
        '
        'colourpallet49
        '
        Me.colourpallet49.BackColor = System.Drawing.Color.Black
        Me.colourpallet49.Location = New System.Drawing.Point(2, 28)
        Me.colourpallet49.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet49.Name = "colourpallet49"
        Me.colourpallet49.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet49.TabIndex = 43
        Me.colourpallet49.Visible = False
        '
        'colourpallet50
        '
        Me.colourpallet50.BackColor = System.Drawing.Color.Black
        Me.colourpallet50.Location = New System.Drawing.Point(15, 28)
        Me.colourpallet50.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet50.Name = "colourpallet50"
        Me.colourpallet50.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet50.TabIndex = 40
        Me.colourpallet50.Visible = False
        '
        'colourpallet51
        '
        Me.colourpallet51.BackColor = System.Drawing.Color.Black
        Me.colourpallet51.Location = New System.Drawing.Point(28, 28)
        Me.colourpallet51.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet51.Name = "colourpallet51"
        Me.colourpallet51.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet51.TabIndex = 52
        Me.colourpallet51.Visible = False
        '
        'colourpallet52
        '
        Me.colourpallet52.BackColor = System.Drawing.Color.Black
        Me.colourpallet52.Location = New System.Drawing.Point(41, 28)
        Me.colourpallet52.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet52.Name = "colourpallet52"
        Me.colourpallet52.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet52.TabIndex = 32
        Me.colourpallet52.Visible = False
        '
        'colourpallet53
        '
        Me.colourpallet53.BackColor = System.Drawing.Color.Black
        Me.colourpallet53.Location = New System.Drawing.Point(54, 28)
        Me.colourpallet53.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet53.Name = "colourpallet53"
        Me.colourpallet53.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet53.TabIndex = 44
        Me.colourpallet53.Visible = False
        '
        'colourpallet54
        '
        Me.colourpallet54.BackColor = System.Drawing.Color.Black
        Me.colourpallet54.Location = New System.Drawing.Point(67, 28)
        Me.colourpallet54.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet54.Name = "colourpallet54"
        Me.colourpallet54.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet54.TabIndex = 35
        Me.colourpallet54.Visible = False
        '
        'colourpallet55
        '
        Me.colourpallet55.BackColor = System.Drawing.Color.Black
        Me.colourpallet55.Location = New System.Drawing.Point(80, 28)
        Me.colourpallet55.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet55.Name = "colourpallet55"
        Me.colourpallet55.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet55.TabIndex = 34
        Me.colourpallet55.Visible = False
        '
        'colourpallet56
        '
        Me.colourpallet56.BackColor = System.Drawing.Color.Black
        Me.colourpallet56.Location = New System.Drawing.Point(93, 28)
        Me.colourpallet56.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet56.Name = "colourpallet56"
        Me.colourpallet56.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet56.TabIndex = 42
        Me.colourpallet56.Visible = False
        '
        'colourpallet57
        '
        Me.colourpallet57.BackColor = System.Drawing.Color.Black
        Me.colourpallet57.Location = New System.Drawing.Point(106, 28)
        Me.colourpallet57.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet57.Name = "colourpallet57"
        Me.colourpallet57.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet57.TabIndex = 38
        Me.colourpallet57.Visible = False
        '
        'colourpallet58
        '
        Me.colourpallet58.BackColor = System.Drawing.Color.Black
        Me.colourpallet58.Location = New System.Drawing.Point(119, 28)
        Me.colourpallet58.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet58.Name = "colourpallet58"
        Me.colourpallet58.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet58.TabIndex = 39
        Me.colourpallet58.Visible = False
        '
        'colourpallet59
        '
        Me.colourpallet59.BackColor = System.Drawing.Color.Black
        Me.colourpallet59.Location = New System.Drawing.Point(132, 28)
        Me.colourpallet59.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet59.Name = "colourpallet59"
        Me.colourpallet59.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet59.TabIndex = 45
        Me.colourpallet59.Visible = False
        '
        'colourpallet60
        '
        Me.colourpallet60.BackColor = System.Drawing.Color.Black
        Me.colourpallet60.Location = New System.Drawing.Point(145, 28)
        Me.colourpallet60.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet60.Name = "colourpallet60"
        Me.colourpallet60.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet60.TabIndex = 47
        Me.colourpallet60.Visible = False
        '
        'colourpallet61
        '
        Me.colourpallet61.BackColor = System.Drawing.Color.Black
        Me.colourpallet61.Location = New System.Drawing.Point(158, 28)
        Me.colourpallet61.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet61.Name = "colourpallet61"
        Me.colourpallet61.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet61.TabIndex = 30
        Me.colourpallet61.Visible = False
        '
        'colourpallet62
        '
        Me.colourpallet62.BackColor = System.Drawing.Color.Black
        Me.colourpallet62.Location = New System.Drawing.Point(171, 28)
        Me.colourpallet62.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet62.Name = "colourpallet62"
        Me.colourpallet62.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet62.TabIndex = 37
        Me.colourpallet62.Visible = False
        '
        'colourpallet63
        '
        Me.colourpallet63.BackColor = System.Drawing.Color.Black
        Me.colourpallet63.Location = New System.Drawing.Point(184, 28)
        Me.colourpallet63.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet63.Name = "colourpallet63"
        Me.colourpallet63.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet63.TabIndex = 29
        Me.colourpallet63.Visible = False
        '
        'colourpallet64
        '
        Me.colourpallet64.BackColor = System.Drawing.Color.Black
        Me.colourpallet64.Location = New System.Drawing.Point(197, 28)
        Me.colourpallet64.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet64.Name = "colourpallet64"
        Me.colourpallet64.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet64.TabIndex = 25
        Me.colourpallet64.Visible = False
        '
        'colourpallet65
        '
        Me.colourpallet65.BackColor = System.Drawing.Color.Black
        Me.colourpallet65.Location = New System.Drawing.Point(2, 37)
        Me.colourpallet65.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet65.Name = "colourpallet65"
        Me.colourpallet65.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet65.TabIndex = 57
        Me.colourpallet65.Visible = False
        '
        'colourpallet66
        '
        Me.colourpallet66.BackColor = System.Drawing.Color.Black
        Me.colourpallet66.Location = New System.Drawing.Point(15, 37)
        Me.colourpallet66.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet66.Name = "colourpallet66"
        Me.colourpallet66.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet66.TabIndex = 61
        Me.colourpallet66.Visible = False
        '
        'colourpallet67
        '
        Me.colourpallet67.BackColor = System.Drawing.Color.Black
        Me.colourpallet67.Location = New System.Drawing.Point(28, 37)
        Me.colourpallet67.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet67.Name = "colourpallet67"
        Me.colourpallet67.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet67.TabIndex = 69
        Me.colourpallet67.Visible = False
        '
        'colourpallet68
        '
        Me.colourpallet68.BackColor = System.Drawing.Color.Black
        Me.colourpallet68.Location = New System.Drawing.Point(41, 37)
        Me.colourpallet68.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet68.Name = "colourpallet68"
        Me.colourpallet68.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet68.TabIndex = 62
        Me.colourpallet68.Visible = False
        '
        'colourpallet69
        '
        Me.colourpallet69.BackColor = System.Drawing.Color.Black
        Me.colourpallet69.Location = New System.Drawing.Point(54, 37)
        Me.colourpallet69.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet69.Name = "colourpallet69"
        Me.colourpallet69.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet69.TabIndex = 79
        Me.colourpallet69.Visible = False
        '
        'colourpallet70
        '
        Me.colourpallet70.BackColor = System.Drawing.Color.Black
        Me.colourpallet70.Location = New System.Drawing.Point(67, 37)
        Me.colourpallet70.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet70.Name = "colourpallet70"
        Me.colourpallet70.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet70.TabIndex = 77
        Me.colourpallet70.Visible = False
        '
        'colourpallet71
        '
        Me.colourpallet71.BackColor = System.Drawing.Color.Black
        Me.colourpallet71.Location = New System.Drawing.Point(80, 37)
        Me.colourpallet71.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet71.Name = "colourpallet71"
        Me.colourpallet71.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet71.TabIndex = 71
        Me.colourpallet71.Visible = False
        '
        'colourpallet72
        '
        Me.colourpallet72.BackColor = System.Drawing.Color.Black
        Me.colourpallet72.Location = New System.Drawing.Point(93, 37)
        Me.colourpallet72.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet72.Name = "colourpallet72"
        Me.colourpallet72.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet72.TabIndex = 70
        Me.colourpallet72.Visible = False
        '
        'colourpallet73
        '
        Me.colourpallet73.BackColor = System.Drawing.Color.Black
        Me.colourpallet73.Location = New System.Drawing.Point(106, 37)
        Me.colourpallet73.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet73.Name = "colourpallet73"
        Me.colourpallet73.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet73.TabIndex = 74
        Me.colourpallet73.Visible = False
        '
        'colourpallet74
        '
        Me.colourpallet74.BackColor = System.Drawing.Color.Black
        Me.colourpallet74.Location = New System.Drawing.Point(119, 37)
        Me.colourpallet74.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet74.Name = "colourpallet74"
        Me.colourpallet74.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet74.TabIndex = 66
        Me.colourpallet74.Visible = False
        '
        'colourpallet75
        '
        Me.colourpallet75.BackColor = System.Drawing.Color.Black
        Me.colourpallet75.Location = New System.Drawing.Point(132, 37)
        Me.colourpallet75.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet75.Name = "colourpallet75"
        Me.colourpallet75.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet75.TabIndex = 67
        Me.colourpallet75.Visible = False
        '
        'colourpallet76
        '
        Me.colourpallet76.BackColor = System.Drawing.Color.Black
        Me.colourpallet76.Location = New System.Drawing.Point(145, 37)
        Me.colourpallet76.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet76.Name = "colourpallet76"
        Me.colourpallet76.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet76.TabIndex = 76
        Me.colourpallet76.Visible = False
        '
        'colourpallet77
        '
        Me.colourpallet77.BackColor = System.Drawing.Color.Black
        Me.colourpallet77.Location = New System.Drawing.Point(158, 37)
        Me.colourpallet77.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet77.Name = "colourpallet77"
        Me.colourpallet77.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet77.TabIndex = 64
        Me.colourpallet77.Visible = False
        '
        'colourpallet78
        '
        Me.colourpallet78.BackColor = System.Drawing.Color.Black
        Me.colourpallet78.Location = New System.Drawing.Point(171, 37)
        Me.colourpallet78.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet78.Name = "colourpallet78"
        Me.colourpallet78.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet78.TabIndex = 84
        Me.colourpallet78.Visible = False
        '
        'colourpallet79
        '
        Me.colourpallet79.BackColor = System.Drawing.Color.Black
        Me.colourpallet79.Location = New System.Drawing.Point(184, 37)
        Me.colourpallet79.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet79.Name = "colourpallet79"
        Me.colourpallet79.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet79.TabIndex = 72
        Me.colourpallet79.Visible = False
        '
        'colourpallet80
        '
        Me.colourpallet80.BackColor = System.Drawing.Color.Black
        Me.colourpallet80.Location = New System.Drawing.Point(197, 37)
        Me.colourpallet80.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet80.Name = "colourpallet80"
        Me.colourpallet80.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet80.TabIndex = 75
        Me.colourpallet80.Visible = False
        '
        'colourpallet81
        '
        Me.colourpallet81.BackColor = System.Drawing.Color.Black
        Me.colourpallet81.Location = New System.Drawing.Point(2, 46)
        Me.colourpallet81.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet81.Name = "colourpallet81"
        Me.colourpallet81.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet81.TabIndex = 65
        Me.colourpallet81.Visible = False
        '
        'colourpallet82
        '
        Me.colourpallet82.BackColor = System.Drawing.Color.Black
        Me.colourpallet82.Location = New System.Drawing.Point(15, 46)
        Me.colourpallet82.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet82.Name = "colourpallet82"
        Me.colourpallet82.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet82.TabIndex = 60
        Me.colourpallet82.Visible = False
        '
        'colourpallet83
        '
        Me.colourpallet83.BackColor = System.Drawing.Color.Black
        Me.colourpallet83.Location = New System.Drawing.Point(28, 46)
        Me.colourpallet83.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet83.Name = "colourpallet83"
        Me.colourpallet83.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet83.TabIndex = 88
        Me.colourpallet83.Visible = False
        '
        'colourpallet84
        '
        Me.colourpallet84.BackColor = System.Drawing.Color.Black
        Me.colourpallet84.Location = New System.Drawing.Point(41, 46)
        Me.colourpallet84.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet84.Name = "colourpallet84"
        Me.colourpallet84.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet84.TabIndex = 68
        Me.colourpallet84.Visible = False
        '
        'colourpallet85
        '
        Me.colourpallet85.BackColor = System.Drawing.Color.Black
        Me.colourpallet85.Location = New System.Drawing.Point(54, 46)
        Me.colourpallet85.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet85.Name = "colourpallet85"
        Me.colourpallet85.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet85.TabIndex = 83
        Me.colourpallet85.Visible = False
        '
        'colourpallet86
        '
        Me.colourpallet86.BackColor = System.Drawing.Color.Black
        Me.colourpallet86.Location = New System.Drawing.Point(67, 46)
        Me.colourpallet86.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet86.Name = "colourpallet86"
        Me.colourpallet86.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet86.TabIndex = 59
        Me.colourpallet86.Visible = False
        '
        'colourpallet87
        '
        Me.colourpallet87.BackColor = System.Drawing.Color.Black
        Me.colourpallet87.Location = New System.Drawing.Point(80, 46)
        Me.colourpallet87.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet87.Name = "colourpallet87"
        Me.colourpallet87.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet87.TabIndex = 81
        Me.colourpallet87.Visible = False
        '
        'colourpallet88
        '
        Me.colourpallet88.BackColor = System.Drawing.Color.Black
        Me.colourpallet88.Location = New System.Drawing.Point(93, 46)
        Me.colourpallet88.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet88.Name = "colourpallet88"
        Me.colourpallet88.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet88.TabIndex = 63
        Me.colourpallet88.Visible = False
        '
        'colourpallet89
        '
        Me.colourpallet89.BackColor = System.Drawing.Color.Black
        Me.colourpallet89.Location = New System.Drawing.Point(106, 46)
        Me.colourpallet89.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet89.Name = "colourpallet89"
        Me.colourpallet89.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet89.TabIndex = 73
        Me.colourpallet89.Visible = False
        '
        'colourpallet90
        '
        Me.colourpallet90.BackColor = System.Drawing.Color.Black
        Me.colourpallet90.Location = New System.Drawing.Point(119, 46)
        Me.colourpallet90.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet90.Name = "colourpallet90"
        Me.colourpallet90.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet90.TabIndex = 87
        Me.colourpallet90.Visible = False
        '
        'colourpallet91
        '
        Me.colourpallet91.BackColor = System.Drawing.Color.Black
        Me.colourpallet91.Location = New System.Drawing.Point(132, 46)
        Me.colourpallet91.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet91.Name = "colourpallet91"
        Me.colourpallet91.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet91.TabIndex = 58
        Me.colourpallet91.Visible = False
        '
        'colourpallet92
        '
        Me.colourpallet92.BackColor = System.Drawing.Color.Black
        Me.colourpallet92.Location = New System.Drawing.Point(145, 46)
        Me.colourpallet92.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet92.Name = "colourpallet92"
        Me.colourpallet92.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet92.TabIndex = 82
        Me.colourpallet92.Visible = False
        '
        'colourpallet93
        '
        Me.colourpallet93.BackColor = System.Drawing.Color.Black
        Me.colourpallet93.Location = New System.Drawing.Point(158, 46)
        Me.colourpallet93.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet93.Name = "colourpallet93"
        Me.colourpallet93.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet93.TabIndex = 86
        Me.colourpallet93.Visible = False
        '
        'colourpallet94
        '
        Me.colourpallet94.BackColor = System.Drawing.Color.Black
        Me.colourpallet94.Location = New System.Drawing.Point(171, 46)
        Me.colourpallet94.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet94.Name = "colourpallet94"
        Me.colourpallet94.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet94.TabIndex = 80
        Me.colourpallet94.Visible = False
        '
        'colourpallet95
        '
        Me.colourpallet95.BackColor = System.Drawing.Color.Black
        Me.colourpallet95.Location = New System.Drawing.Point(184, 46)
        Me.colourpallet95.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet95.Name = "colourpallet95"
        Me.colourpallet95.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet95.TabIndex = 85
        Me.colourpallet95.Visible = False
        '
        'colourpallet96
        '
        Me.colourpallet96.BackColor = System.Drawing.Color.Black
        Me.colourpallet96.Location = New System.Drawing.Point(197, 46)
        Me.colourpallet96.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet96.Name = "colourpallet96"
        Me.colourpallet96.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet96.TabIndex = 78
        Me.colourpallet96.Visible = False
        '
        'colourpallet97
        '
        Me.colourpallet97.BackColor = System.Drawing.Color.Black
        Me.colourpallet97.Location = New System.Drawing.Point(2, 55)
        Me.colourpallet97.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet97.Name = "colourpallet97"
        Me.colourpallet97.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet97.TabIndex = 89
        Me.colourpallet97.Visible = False
        '
        'colourpallet98
        '
        Me.colourpallet98.BackColor = System.Drawing.Color.Black
        Me.colourpallet98.Location = New System.Drawing.Point(15, 55)
        Me.colourpallet98.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet98.Name = "colourpallet98"
        Me.colourpallet98.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet98.TabIndex = 93
        Me.colourpallet98.Visible = False
        '
        'colourpallet99
        '
        Me.colourpallet99.BackColor = System.Drawing.Color.Black
        Me.colourpallet99.Location = New System.Drawing.Point(28, 55)
        Me.colourpallet99.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet99.Name = "colourpallet99"
        Me.colourpallet99.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet99.TabIndex = 101
        Me.colourpallet99.Visible = False
        '
        'colourpallet100
        '
        Me.colourpallet100.BackColor = System.Drawing.Color.Black
        Me.colourpallet100.Location = New System.Drawing.Point(41, 55)
        Me.colourpallet100.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet100.Name = "colourpallet100"
        Me.colourpallet100.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet100.TabIndex = 94
        Me.colourpallet100.Visible = False
        '
        'colourpallet101
        '
        Me.colourpallet101.BackColor = System.Drawing.Color.Black
        Me.colourpallet101.Location = New System.Drawing.Point(54, 55)
        Me.colourpallet101.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet101.Name = "colourpallet101"
        Me.colourpallet101.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet101.TabIndex = 111
        Me.colourpallet101.Visible = False
        '
        'colourpallet102
        '
        Me.colourpallet102.BackColor = System.Drawing.Color.Black
        Me.colourpallet102.Location = New System.Drawing.Point(67, 55)
        Me.colourpallet102.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet102.Name = "colourpallet102"
        Me.colourpallet102.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet102.TabIndex = 110
        Me.colourpallet102.Visible = False
        '
        'colourpallet103
        '
        Me.colourpallet103.BackColor = System.Drawing.Color.Black
        Me.colourpallet103.Location = New System.Drawing.Point(80, 55)
        Me.colourpallet103.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet103.Name = "colourpallet103"
        Me.colourpallet103.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet103.TabIndex = 117
        Me.colourpallet103.Visible = False
        '
        'colourpallet104
        '
        Me.colourpallet104.BackColor = System.Drawing.Color.Black
        Me.colourpallet104.Location = New System.Drawing.Point(93, 55)
        Me.colourpallet104.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet104.Name = "colourpallet104"
        Me.colourpallet104.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet104.TabIndex = 112
        Me.colourpallet104.Visible = False
        '
        'colourpallet105
        '
        Me.colourpallet105.BackColor = System.Drawing.Color.Black
        Me.colourpallet105.Location = New System.Drawing.Point(106, 55)
        Me.colourpallet105.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet105.Name = "colourpallet105"
        Me.colourpallet105.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet105.TabIndex = 109
        Me.colourpallet105.Visible = False
        '
        'colourpallet106
        '
        Me.colourpallet106.BackColor = System.Drawing.Color.Black
        Me.colourpallet106.Location = New System.Drawing.Point(119, 55)
        Me.colourpallet106.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet106.Name = "colourpallet106"
        Me.colourpallet106.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet106.TabIndex = 103
        Me.colourpallet106.Visible = False
        '
        'colourpallet107
        '
        Me.colourpallet107.BackColor = System.Drawing.Color.Black
        Me.colourpallet107.Location = New System.Drawing.Point(132, 55)
        Me.colourpallet107.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet107.Name = "colourpallet107"
        Me.colourpallet107.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet107.TabIndex = 102
        Me.colourpallet107.Visible = False
        '
        'colourpallet108
        '
        Me.colourpallet108.BackColor = System.Drawing.Color.Black
        Me.colourpallet108.Location = New System.Drawing.Point(145, 55)
        Me.colourpallet108.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet108.Name = "colourpallet108"
        Me.colourpallet108.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet108.TabIndex = 106
        Me.colourpallet108.Visible = False
        '
        'colourpallet109
        '
        Me.colourpallet109.BackColor = System.Drawing.Color.Black
        Me.colourpallet109.Location = New System.Drawing.Point(158, 55)
        Me.colourpallet109.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet109.Name = "colourpallet109"
        Me.colourpallet109.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet109.TabIndex = 98
        Me.colourpallet109.Visible = False
        '
        'colourpallet110
        '
        Me.colourpallet110.BackColor = System.Drawing.Color.Black
        Me.colourpallet110.Location = New System.Drawing.Point(171, 55)
        Me.colourpallet110.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet110.Name = "colourpallet110"
        Me.colourpallet110.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet110.TabIndex = 99
        Me.colourpallet110.Visible = False
        '
        'colourpallet111
        '
        Me.colourpallet111.BackColor = System.Drawing.Color.Black
        Me.colourpallet111.Location = New System.Drawing.Point(184, 55)
        Me.colourpallet111.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet111.Name = "colourpallet111"
        Me.colourpallet111.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet111.TabIndex = 108
        Me.colourpallet111.Visible = False
        '
        'colourpallet112
        '
        Me.colourpallet112.BackColor = System.Drawing.Color.Black
        Me.colourpallet112.Location = New System.Drawing.Point(197, 55)
        Me.colourpallet112.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet112.Name = "colourpallet112"
        Me.colourpallet112.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet112.TabIndex = 96
        Me.colourpallet112.Visible = False
        '
        'colourpallet113
        '
        Me.colourpallet113.BackColor = System.Drawing.Color.Black
        Me.colourpallet113.Location = New System.Drawing.Point(2, 64)
        Me.colourpallet113.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet113.Name = "colourpallet113"
        Me.colourpallet113.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet113.TabIndex = 116
        Me.colourpallet113.Visible = False
        '
        'colourpallet114
        '
        Me.colourpallet114.BackColor = System.Drawing.Color.Black
        Me.colourpallet114.Location = New System.Drawing.Point(15, 64)
        Me.colourpallet114.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet114.Name = "colourpallet114"
        Me.colourpallet114.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet114.TabIndex = 104
        Me.colourpallet114.Visible = False
        '
        'colourpallet115
        '
        Me.colourpallet115.BackColor = System.Drawing.Color.Black
        Me.colourpallet115.Location = New System.Drawing.Point(28, 64)
        Me.colourpallet115.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet115.Name = "colourpallet115"
        Me.colourpallet115.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet115.TabIndex = 107
        Me.colourpallet115.Visible = False
        '
        'colourpallet116
        '
        Me.colourpallet116.BackColor = System.Drawing.Color.Black
        Me.colourpallet116.Location = New System.Drawing.Point(41, 64)
        Me.colourpallet116.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet116.Name = "colourpallet116"
        Me.colourpallet116.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet116.TabIndex = 97
        Me.colourpallet116.Visible = False
        '
        'colourpallet117
        '
        Me.colourpallet117.BackColor = System.Drawing.Color.Black
        Me.colourpallet117.Location = New System.Drawing.Point(54, 64)
        Me.colourpallet117.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet117.Name = "colourpallet117"
        Me.colourpallet117.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet117.TabIndex = 92
        Me.colourpallet117.Visible = False
        '
        'colourpallet118
        '
        Me.colourpallet118.BackColor = System.Drawing.Color.Black
        Me.colourpallet118.Location = New System.Drawing.Point(67, 64)
        Me.colourpallet118.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet118.Name = "colourpallet118"
        Me.colourpallet118.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet118.TabIndex = 120
        Me.colourpallet118.Visible = False
        '
        'colourpallet119
        '
        Me.colourpallet119.BackColor = System.Drawing.Color.Black
        Me.colourpallet119.Location = New System.Drawing.Point(80, 64)
        Me.colourpallet119.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet119.Name = "colourpallet119"
        Me.colourpallet119.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet119.TabIndex = 100
        Me.colourpallet119.Visible = False
        '
        'colourpallet120
        '
        Me.colourpallet120.BackColor = System.Drawing.Color.Black
        Me.colourpallet120.Location = New System.Drawing.Point(93, 64)
        Me.colourpallet120.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet120.Name = "colourpallet120"
        Me.colourpallet120.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet120.TabIndex = 115
        Me.colourpallet120.Visible = False
        '
        'colourpallet121
        '
        Me.colourpallet121.BackColor = System.Drawing.Color.Black
        Me.colourpallet121.Location = New System.Drawing.Point(106, 64)
        Me.colourpallet121.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet121.Name = "colourpallet121"
        Me.colourpallet121.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet121.TabIndex = 91
        Me.colourpallet121.Visible = False
        '
        'colourpallet122
        '
        Me.colourpallet122.BackColor = System.Drawing.Color.Black
        Me.colourpallet122.Location = New System.Drawing.Point(119, 64)
        Me.colourpallet122.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet122.Name = "colourpallet122"
        Me.colourpallet122.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet122.TabIndex = 113
        Me.colourpallet122.Visible = False
        '
        'colourpallet123
        '
        Me.colourpallet123.BackColor = System.Drawing.Color.Black
        Me.colourpallet123.Location = New System.Drawing.Point(132, 64)
        Me.colourpallet123.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet123.Name = "colourpallet123"
        Me.colourpallet123.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet123.TabIndex = 95
        Me.colourpallet123.Visible = False
        '
        'colourpallet124
        '
        Me.colourpallet124.BackColor = System.Drawing.Color.Black
        Me.colourpallet124.Location = New System.Drawing.Point(145, 64)
        Me.colourpallet124.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet124.Name = "colourpallet124"
        Me.colourpallet124.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet124.TabIndex = 105
        Me.colourpallet124.Visible = False
        '
        'colourpallet125
        '
        Me.colourpallet125.BackColor = System.Drawing.Color.Black
        Me.colourpallet125.Location = New System.Drawing.Point(158, 64)
        Me.colourpallet125.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet125.Name = "colourpallet125"
        Me.colourpallet125.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet125.TabIndex = 119
        Me.colourpallet125.Visible = False
        '
        'colourpallet126
        '
        Me.colourpallet126.BackColor = System.Drawing.Color.Black
        Me.colourpallet126.Location = New System.Drawing.Point(171, 64)
        Me.colourpallet126.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet126.Name = "colourpallet126"
        Me.colourpallet126.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet126.TabIndex = 90
        Me.colourpallet126.Visible = False
        '
        'colourpallet127
        '
        Me.colourpallet127.BackColor = System.Drawing.Color.Black
        Me.colourpallet127.Location = New System.Drawing.Point(184, 64)
        Me.colourpallet127.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet127.Name = "colourpallet127"
        Me.colourpallet127.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet127.TabIndex = 114
        Me.colourpallet127.Visible = False
        '
        'colourpallet128
        '
        Me.colourpallet128.BackColor = System.Drawing.Color.Black
        Me.colourpallet128.Location = New System.Drawing.Point(197, 64)
        Me.colourpallet128.Margin = New System.Windows.Forms.Padding(1, 0, 0, 1)
        Me.colourpallet128.Name = "colourpallet128"
        Me.colourpallet128.Size = New System.Drawing.Size(12, 8)
        Me.colourpallet128.TabIndex = 118
        Me.colourpallet128.Visible = False
        '
        'Label4
        '
        Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(11, 2)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(200, 23)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Colours"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'line6
        '
        Me.line6.BackColor = System.Drawing.Color.Black
        Me.line6.Dock = System.Windows.Forms.DockStyle.Top
        Me.line6.Location = New System.Drawing.Point(0, 0)
        Me.line6.Name = "line6"
        Me.line6.Size = New System.Drawing.Size(221, 1)
        Me.line6.TabIndex = 4
        '
        'pnltoolproperties
        '
        Me.pnltoolproperties.Controls.Add(Me.pnltexttoolsettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlpixelsettersettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlpaintbrushtoolsettings)
        Me.pnltoolproperties.Controls.Add(Me.pnllinetoolsettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlmagnifiersettings)
        Me.pnltoolproperties.Controls.Add(Me.pnleracertoolsettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlfloodfillsettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlovaltoolsettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlsquaretoolsettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlpixelplacersettings)
        Me.pnltoolproperties.Controls.Add(Me.pnlpencilsettings)
        Me.pnltoolproperties.Controls.Add(Me.Label6)
        Me.pnltoolproperties.Controls.Add(Me.Label5)
        Me.pnltoolproperties.Controls.Add(Me.line5)
        Me.pnltoolproperties.Controls.Add(Me.line3)
        Me.pnltoolproperties.Location = New System.Drawing.Point(0, 0)
        Me.pnltoolproperties.Name = "pnltoolproperties"
        Me.pnltoolproperties.Size = New System.Drawing.Size(457, 100)
        Me.pnltoolproperties.TabIndex = 1
        '
        'pnltexttoolsettings
        '
        Me.pnltexttoolsettings.Controls.Add(Me.Label35)
        Me.pnltexttoolsettings.Controls.Add(Me.combofontstyle)
        Me.pnltexttoolsettings.Controls.Add(Me.txtdrawstringtext)
        Me.pnltexttoolsettings.Controls.Add(Me.combodrawtextfont)
        Me.pnltexttoolsettings.Controls.Add(Me.Label25)
        Me.pnltexttoolsettings.Controls.Add(Me.txtdrawtextsize)
        Me.pnltexttoolsettings.Controls.Add(Me.Label32)
        Me.pnltexttoolsettings.Controls.Add(Me.Label33)
        Me.pnltexttoolsettings.Controls.Add(Me.Label34)
        Me.pnltexttoolsettings.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnltexttoolsettings.Location = New System.Drawing.Point(0, 1)
        Me.pnltexttoolsettings.Name = "pnltexttoolsettings"
        Me.pnltexttoolsettings.Size = New System.Drawing.Size(456, 99)
        Me.pnltexttoolsettings.TabIndex = 17
        Me.pnltexttoolsettings.Visible = False
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(117, 33)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(55, 24)
        Me.Label35.TabIndex = 19
        Me.Label35.Text = "Style:"
        '
        'combofontstyle
        '
        Me.combofontstyle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.combofontstyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combofontstyle.FormattingEnabled = True
        Me.combofontstyle.Items.AddRange(New Object() {"Bold", "Italic", "Regular", "Strikeout", "Underline"})
        Me.combofontstyle.Location = New System.Drawing.Point(178, 34)
        Me.combofontstyle.Name = "combofontstyle"
        Me.combofontstyle.Size = New System.Drawing.Size(78, 24)
        Me.combofontstyle.TabIndex = 18
        '
        'txtdrawstringtext
        '
        Me.txtdrawstringtext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdrawstringtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdrawstringtext.Location = New System.Drawing.Point(265, 52)
        Me.txtdrawstringtext.Multiline = True
        Me.txtdrawstringtext.Name = "txtdrawstringtext"
        Me.txtdrawstringtext.Size = New System.Drawing.Size(185, 41)
        Me.txtdrawstringtext.TabIndex = 17
        Me.txtdrawstringtext.Text = "Enter Words Here"
        '
        'combodrawtextfont
        '
        Me.combodrawtextfont.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.combodrawtextfont.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combodrawtextfont.FormattingEnabled = True
        Me.combodrawtextfont.Location = New System.Drawing.Point(64, 68)
        Me.combodrawtextfont.Name = "combodrawtextfont"
        Me.combodrawtextfont.Size = New System.Drawing.Size(192, 24)
        Me.combodrawtextfont.TabIndex = 16
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(262, 26)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(189, 23)
        Me.Label25.TabIndex = 15
        Me.Label25.Text = "Click and drag on the canvas!"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtdrawtextsize
        '
        Me.txtdrawtextsize.BackColor = System.Drawing.Color.White
        Me.txtdrawtextsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdrawtextsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdrawtextsize.ForeColor = System.Drawing.Color.Black
        Me.txtdrawtextsize.Location = New System.Drawing.Point(61, 33)
        Me.txtdrawtextsize.Name = "txtdrawtextsize"
        Me.txtdrawtextsize.Size = New System.Drawing.Size(43, 26)
        Me.txtdrawtextsize.TabIndex = 12
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(4, 66)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(53, 24)
        Me.Label32.TabIndex = 11
        Me.Label32.Text = "Font:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(4, 33)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(51, 24)
        Me.Label33.TabIndex = 10
        Me.Label33.Text = "Size:"
        '
        'Label34
        '
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(6, 3)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(444, 23)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Text Tool Settings"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlpixelsettersettings
        '
        Me.pnlpixelsettersettings.Controls.Add(Me.btnpixelsettersetpixel)
        Me.pnlpixelsettersettings.Controls.Add(Me.txtpixelsetterycoordinate)
        Me.pnlpixelsettersettings.Controls.Add(Me.txtpixelsetterxcoordinate)
        Me.pnlpixelsettersettings.Controls.Add(Me.Label3)
        Me.pnlpixelsettersettings.Controls.Add(Me.Label2)
        Me.pnlpixelsettersettings.Controls.Add(Me.Label1)
        Me.pnlpixelsettersettings.Location = New System.Drawing.Point(342, 35)
        Me.pnlpixelsettersettings.Name = "pnlpixelsettersettings"
        Me.pnlpixelsettersettings.Size = New System.Drawing.Size(37, 23)
        Me.pnlpixelsettersettings.TabIndex = 5
        Me.pnlpixelsettersettings.Visible = False
        '
        'btnpixelsettersetpixel
        '
        Me.btnpixelsettersetpixel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpixelsettersetpixel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpixelsettersetpixel.Location = New System.Drawing.Point(215, 34)
        Me.btnpixelsettersetpixel.Name = "btnpixelsettersetpixel"
        Me.btnpixelsettersetpixel.Size = New System.Drawing.Size(228, 56)
        Me.btnpixelsettersetpixel.TabIndex = 10
        Me.btnpixelsettersetpixel.Text = "Set Pixel"
        Me.btnpixelsettersetpixel.UseVisualStyleBackColor = True
        '
        'txtpixelsetterycoordinate
        '
        Me.txtpixelsetterycoordinate.BackColor = System.Drawing.Color.White
        Me.txtpixelsetterycoordinate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpixelsetterycoordinate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpixelsetterycoordinate.ForeColor = System.Drawing.Color.Black
        Me.txtpixelsetterycoordinate.Location = New System.Drawing.Point(136, 64)
        Me.txtpixelsetterycoordinate.Name = "txtpixelsetterycoordinate"
        Me.txtpixelsetterycoordinate.Size = New System.Drawing.Size(73, 26)
        Me.txtpixelsetterycoordinate.TabIndex = 9
        '
        'txtpixelsetterxcoordinate
        '
        Me.txtpixelsetterxcoordinate.BackColor = System.Drawing.Color.White
        Me.txtpixelsetterxcoordinate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpixelsetterxcoordinate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpixelsetterxcoordinate.ForeColor = System.Drawing.Color.Black
        Me.txtpixelsetterxcoordinate.Location = New System.Drawing.Point(136, 34)
        Me.txtpixelsetterxcoordinate.Name = "txtpixelsetterxcoordinate"
        Me.txtpixelsetterxcoordinate.Size = New System.Drawing.Size(73, 26)
        Me.txtpixelsetterxcoordinate.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 63)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(124, 24)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Y Coordinate:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(7, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(126, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "X Coordinate:"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(444, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pixel Setter Settings"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlpaintbrushtoolsettings
        '
        Me.pnlpaintbrushtoolsettings.Controls.Add(Me.Label36)
        Me.pnlpaintbrushtoolsettings.Controls.Add(Me.btnpaintsquareshape)
        Me.pnlpaintbrushtoolsettings.Controls.Add(Me.btnpaintcircleshape)
        Me.pnlpaintbrushtoolsettings.Controls.Add(Me.Label37)
        Me.pnlpaintbrushtoolsettings.Controls.Add(Me.txtpaintbrushsize)
        Me.pnlpaintbrushtoolsettings.Controls.Add(Me.Label38)
        Me.pnlpaintbrushtoolsettings.Controls.Add(Me.Label39)
        Me.pnlpaintbrushtoolsettings.Location = New System.Drawing.Point(261, 13)
        Me.pnlpaintbrushtoolsettings.Name = "pnlpaintbrushtoolsettings"
        Me.pnlpaintbrushtoolsettings.Size = New System.Drawing.Size(51, 27)
        Me.pnlpaintbrushtoolsettings.TabIndex = 21
        Me.pnlpaintbrushtoolsettings.Visible = False
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(32, 69)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(65, 24)
        Me.Label36.TabIndex = 19
        Me.Label36.Text = "Shape"
        '
        'btnpaintsquareshape
        '
        Me.btnpaintsquareshape.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadsquarerubber
        Me.btnpaintsquareshape.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnpaintsquareshape.FlatAppearance.BorderSize = 0
        Me.btnpaintsquareshape.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpaintsquareshape.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpaintsquareshape.Location = New System.Drawing.Point(69, 27)
        Me.btnpaintsquareshape.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnpaintsquareshape.Name = "btnpaintsquareshape"
        Me.btnpaintsquareshape.Size = New System.Drawing.Size(48, 40)
        Me.btnpaintsquareshape.TabIndex = 17
        Me.btnpaintsquareshape.Text = " "
        Me.btnpaintsquareshape.UseVisualStyleBackColor = True
        '
        'btnpaintcircleshape
        '
        Me.btnpaintcircleshape.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadcirclerubberselected
        Me.btnpaintcircleshape.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnpaintcircleshape.FlatAppearance.BorderSize = 0
        Me.btnpaintcircleshape.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpaintcircleshape.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpaintcircleshape.Location = New System.Drawing.Point(16, 27)
        Me.btnpaintcircleshape.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnpaintcircleshape.Name = "btnpaintcircleshape"
        Me.btnpaintcircleshape.Size = New System.Drawing.Size(48, 40)
        Me.btnpaintcircleshape.TabIndex = 16
        Me.btnpaintcircleshape.Text = " "
        Me.btnpaintcircleshape.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(137, 29)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(314, 38)
        Me.Label37.TabIndex = 15
        Me.Label37.Text = "Choose a shape and size for your paint brush then paint on the canvas by drawing " & _
    "with the mouse."
        '
        'txtpaintbrushsize
        '
        Me.txtpaintbrushsize.BackColor = System.Drawing.Color.White
        Me.txtpaintbrushsize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpaintbrushsize.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpaintbrushsize.ForeColor = System.Drawing.Color.Black
        Me.txtpaintbrushsize.Location = New System.Drawing.Point(194, 68)
        Me.txtpaintbrushsize.Name = "txtpaintbrushsize"
        Me.txtpaintbrushsize.Size = New System.Drawing.Size(73, 26)
        Me.txtpaintbrushsize.TabIndex = 12
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(137, 69)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(51, 24)
        Me.Label38.TabIndex = 10
        Me.Label38.Text = "Size:"
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(6, 3)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(444, 23)
        Me.Label39.TabIndex = 0
        Me.Label39.Text = "Paint Brush Tool Settings"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnllinetoolsettings
        '
        Me.pnllinetoolsettings.Controls.Add(Me.Label29)
        Me.pnllinetoolsettings.Controls.Add(Me.txtlinewidth)
        Me.pnllinetoolsettings.Controls.Add(Me.Label30)
        Me.pnllinetoolsettings.Controls.Add(Me.Label31)
        Me.pnllinetoolsettings.Location = New System.Drawing.Point(168, 32)
        Me.pnllinetoolsettings.Name = "pnllinetoolsettings"
        Me.pnllinetoolsettings.Size = New System.Drawing.Size(60, 28)
        Me.pnllinetoolsettings.TabIndex = 20
        Me.pnllinetoolsettings.Visible = False
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(196, 29)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(257, 38)
        Me.Label29.TabIndex = 15
        Me.Label29.Text = "Enter a line width then use the mouse to draw a straight line on the canvas." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtlinewidth
        '
        Me.txtlinewidth.BackColor = System.Drawing.Color.White
        Me.txtlinewidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtlinewidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlinewidth.ForeColor = System.Drawing.Color.Black
        Me.txtlinewidth.Location = New System.Drawing.Point(114, 33)
        Me.txtlinewidth.Name = "txtlinewidth"
        Me.txtlinewidth.Size = New System.Drawing.Size(73, 26)
        Me.txtlinewidth.TabIndex = 12
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(8, 34)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(104, 24)
        Me.Label30.TabIndex = 10
        Me.Label30.Text = "Line Width:"
        '
        'Label31
        '
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(6, 3)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(444, 23)
        Me.Label31.TabIndex = 0
        Me.Label31.Text = "Line Tool Settings"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlmagnifiersettings
        '
        Me.pnlmagnifiersettings.Controls.Add(Me.btnzoomout)
        Me.pnlmagnifiersettings.Controls.Add(Me.btnzoomin)
        Me.pnlmagnifiersettings.Controls.Add(Me.lblzoomlevel)
        Me.pnlmagnifiersettings.Controls.Add(Me.Label7)
        Me.pnlmagnifiersettings.Location = New System.Drawing.Point(78, 50)
        Me.pnlmagnifiersettings.Name = "pnlmagnifiersettings"
        Me.pnlmagnifiersettings.Size = New System.Drawing.Size(67, 44)
        Me.pnlmagnifiersettings.TabIndex = 6
        Me.pnlmagnifiersettings.Visible = False
        '
        'btnzoomout
        '
        Me.btnzoomout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnzoomout.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnzoomout.Location = New System.Drawing.Point(16, 33)
        Me.btnzoomout.Name = "btnzoomout"
        Me.btnzoomout.Size = New System.Drawing.Size(129, 56)
        Me.btnzoomout.TabIndex = 11
        Me.btnzoomout.Text = "-"
        Me.btnzoomout.UseVisualStyleBackColor = True
        '
        'btnzoomin
        '
        Me.btnzoomin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnzoomin.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnzoomin.Location = New System.Drawing.Point(313, 33)
        Me.btnzoomin.Name = "btnzoomin"
        Me.btnzoomin.Size = New System.Drawing.Size(129, 56)
        Me.btnzoomin.TabIndex = 10
        Me.btnzoomin.Text = "+"
        Me.btnzoomin.UseVisualStyleBackColor = True
        '
        'lblzoomlevel
        '
        Me.lblzoomlevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblzoomlevel.Location = New System.Drawing.Point(151, 33)
        Me.lblzoomlevel.Name = "lblzoomlevel"
        Me.lblzoomlevel.Size = New System.Drawing.Size(156, 56)
        Me.lblzoomlevel.TabIndex = 1
        Me.lblzoomlevel.Text = "1X"
        Me.lblzoomlevel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 3)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(444, 23)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Magnifier Settings"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnleracertoolsettings
        '
        Me.pnleracertoolsettings.Controls.Add(Me.Label28)
        Me.pnleracertoolsettings.Controls.Add(Me.btneracersquare)
        Me.pnleracertoolsettings.Controls.Add(Me.btneracercircle)
        Me.pnleracertoolsettings.Controls.Add(Me.Label24)
        Me.pnleracertoolsettings.Controls.Add(Me.txteracersize)
        Me.pnleracertoolsettings.Controls.Add(Me.Label26)
        Me.pnleracertoolsettings.Controls.Add(Me.Label27)
        Me.pnleracertoolsettings.Location = New System.Drawing.Point(308, 69)
        Me.pnleracertoolsettings.Name = "pnleracertoolsettings"
        Me.pnleracertoolsettings.Size = New System.Drawing.Size(50, 21)
        Me.pnleracertoolsettings.TabIndex = 16
        Me.pnleracertoolsettings.Visible = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(40, 71)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(65, 24)
        Me.Label28.TabIndex = 19
        Me.Label28.Text = "Shape"
        '
        'btneracersquare
        '
        Me.btneracersquare.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadsquarerubberselected
        Me.btneracersquare.FlatAppearance.BorderSize = 0
        Me.btneracersquare.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btneracersquare.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btneracersquare.Location = New System.Drawing.Point(75, 21)
        Me.btneracersquare.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btneracersquare.Name = "btneracersquare"
        Me.btneracersquare.Size = New System.Drawing.Size(60, 50)
        Me.btneracersquare.TabIndex = 17
        Me.btneracersquare.Text = " "
        Me.btneracersquare.UseVisualStyleBackColor = True
        '
        'btneracercircle
        '
        Me.btneracercircle.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadcirclerubber
        Me.btneracercircle.FlatAppearance.BorderSize = 0
        Me.btneracercircle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btneracercircle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btneracercircle.Location = New System.Drawing.Point(9, 21)
        Me.btneracercircle.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btneracercircle.Name = "btneracercircle"
        Me.btneracercircle.Size = New System.Drawing.Size(60, 50)
        Me.btneracercircle.TabIndex = 16
        Me.btneracercircle.Text = " "
        Me.btneracercircle.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(141, 29)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(314, 38)
        Me.Label24.TabIndex = 15
        Me.Label24.Text = "Choose a shape and size for your eracer then rub out unwanted parts of your drawi" & _
    "ng with the mouse."
        '
        'txteracersize
        '
        Me.txteracersize.BackColor = System.Drawing.Color.White
        Me.txteracersize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txteracersize.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txteracersize.ForeColor = System.Drawing.Color.Black
        Me.txteracersize.Location = New System.Drawing.Point(198, 70)
        Me.txteracersize.Name = "txteracersize"
        Me.txteracersize.Size = New System.Drawing.Size(73, 26)
        Me.txteracersize.TabIndex = 12
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(141, 71)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(51, 24)
        Me.Label26.TabIndex = 10
        Me.Label26.Text = "Size:"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(6, 3)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(444, 23)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Eracer Tool Settings"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlfloodfillsettings
        '
        Me.pnlfloodfillsettings.Controls.Add(Me.Label12)
        Me.pnlfloodfillsettings.Controls.Add(Me.Label15)
        Me.pnlfloodfillsettings.Location = New System.Drawing.Point(162, 65)
        Me.pnlfloodfillsettings.Name = "pnlfloodfillsettings"
        Me.pnlfloodfillsettings.Size = New System.Drawing.Size(71, 31)
        Me.pnlfloodfillsettings.TabIndex = 13
        Me.pnlfloodfillsettings.Visible = False
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(3, 28)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(450, 51)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = resources.GetString("Label12.Text")
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(6, 3)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(444, 23)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Flood Fill Settings"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlovaltoolsettings
        '
        Me.pnlovaltoolsettings.Controls.Add(Me.Label20)
        Me.pnlovaltoolsettings.Controls.Add(Me.btnovalfillonoff)
        Me.pnlovaltoolsettings.Controls.Add(Me.pnlovalfillcolour)
        Me.pnlovaltoolsettings.Controls.Add(Me.txtovalborderwidth)
        Me.pnlovaltoolsettings.Controls.Add(Me.Label21)
        Me.pnlovaltoolsettings.Controls.Add(Me.Label22)
        Me.pnlovaltoolsettings.Controls.Add(Me.Label23)
        Me.pnlovaltoolsettings.Location = New System.Drawing.Point(152, 5)
        Me.pnlovaltoolsettings.Name = "pnlovaltoolsettings"
        Me.pnlovaltoolsettings.Size = New System.Drawing.Size(80, 22)
        Me.pnlovaltoolsettings.TabIndex = 15
        Me.pnlovaltoolsettings.Visible = False
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(211, 29)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(244, 65)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "Set a border width and turn fill on or off then draw the square on the canvas wit" & _
    "h the mouse. Click the fill colour box to set it to your currently selected colo" & _
    "ur."
        '
        'btnovalfillonoff
        '
        Me.btnovalfillonoff.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnovalfillonoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnovalfillonoff.Location = New System.Drawing.Point(150, 64)
        Me.btnovalfillonoff.Name = "btnovalfillonoff"
        Me.btnovalfillonoff.Size = New System.Drawing.Size(56, 28)
        Me.btnovalfillonoff.TabIndex = 14
        Me.btnovalfillonoff.Text = "Fill OFF"
        Me.btnovalfillonoff.UseVisualStyleBackColor = True
        '
        'pnlovalfillcolour
        '
        Me.pnlovalfillcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlovalfillcolour.Location = New System.Drawing.Point(109, 64)
        Me.pnlovalfillcolour.Name = "pnlovalfillcolour"
        Me.pnlovalfillcolour.Size = New System.Drawing.Size(34, 28)
        Me.pnlovalfillcolour.TabIndex = 13
        '
        'txtovalborderwidth
        '
        Me.txtovalborderwidth.BackColor = System.Drawing.Color.White
        Me.txtovalborderwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtovalborderwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtovalborderwidth.ForeColor = System.Drawing.Color.Black
        Me.txtovalborderwidth.Location = New System.Drawing.Point(133, 33)
        Me.txtovalborderwidth.Name = "txtovalborderwidth"
        Me.txtovalborderwidth.Size = New System.Drawing.Size(73, 26)
        Me.txtovalborderwidth.TabIndex = 12
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(4, 66)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(100, 24)
        Me.Label21.TabIndex = 11
        Me.Label21.Text = "Fill Colour:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(4, 33)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(125, 24)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "Border Width:"
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(6, 3)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(444, 23)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Oval Tool Settings"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlsquaretoolsettings
        '
        Me.pnlsquaretoolsettings.Controls.Add(Me.Label19)
        Me.pnlsquaretoolsettings.Controls.Add(Me.btnsquarefillonoff)
        Me.pnlsquaretoolsettings.Controls.Add(Me.pnlsquarefillcolour)
        Me.pnlsquaretoolsettings.Controls.Add(Me.txtsquareborderwidth)
        Me.pnlsquaretoolsettings.Controls.Add(Me.Label16)
        Me.pnlsquaretoolsettings.Controls.Add(Me.Label18)
        Me.pnlsquaretoolsettings.Controls.Add(Me.Label17)
        Me.pnlsquaretoolsettings.Location = New System.Drawing.Point(16, 39)
        Me.pnlsquaretoolsettings.Name = "pnlsquaretoolsettings"
        Me.pnlsquaretoolsettings.Size = New System.Drawing.Size(42, 31)
        Me.pnlsquaretoolsettings.TabIndex = 14
        Me.pnlsquaretoolsettings.Visible = False
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(211, 29)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(244, 65)
        Me.Label19.TabIndex = 15
        Me.Label19.Text = "Set a border width and turn fill on or off then draw the square on the canvas wit" & _
    "h the mouse. Click the fill colour box to set it to your currently selected colo" & _
    "ur."
        '
        'btnsquarefillonoff
        '
        Me.btnsquarefillonoff.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnsquarefillonoff.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsquarefillonoff.Location = New System.Drawing.Point(150, 64)
        Me.btnsquarefillonoff.Name = "btnsquarefillonoff"
        Me.btnsquarefillonoff.Size = New System.Drawing.Size(56, 28)
        Me.btnsquarefillonoff.TabIndex = 14
        Me.btnsquarefillonoff.Text = "Fill OFF"
        Me.btnsquarefillonoff.UseVisualStyleBackColor = True
        '
        'pnlsquarefillcolour
        '
        Me.pnlsquarefillcolour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlsquarefillcolour.Location = New System.Drawing.Point(109, 64)
        Me.pnlsquarefillcolour.Name = "pnlsquarefillcolour"
        Me.pnlsquarefillcolour.Size = New System.Drawing.Size(34, 28)
        Me.pnlsquarefillcolour.TabIndex = 13
        '
        'txtsquareborderwidth
        '
        Me.txtsquareborderwidth.BackColor = System.Drawing.Color.White
        Me.txtsquareborderwidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsquareborderwidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsquareborderwidth.ForeColor = System.Drawing.Color.Black
        Me.txtsquareborderwidth.Location = New System.Drawing.Point(133, 33)
        Me.txtsquareborderwidth.Name = "txtsquareborderwidth"
        Me.txtsquareborderwidth.Size = New System.Drawing.Size(73, 26)
        Me.txtsquareborderwidth.TabIndex = 12
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(4, 66)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(100, 24)
        Me.Label16.TabIndex = 11
        Me.Label16.Text = "Fill Colour:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(4, 33)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(125, 24)
        Me.Label18.TabIndex = 10
        Me.Label18.Text = "Border Width:"
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(6, 3)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(444, 23)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Rectangle Tool Settings"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlpixelplacersettings
        '
        Me.pnlpixelplacersettings.Controls.Add(Me.lblpixelplacerhelp)
        Me.pnlpixelplacersettings.Controls.Add(Me.btnpixelplacermovementmode)
        Me.pnlpixelplacersettings.Controls.Add(Me.Label8)
        Me.pnlpixelplacersettings.Location = New System.Drawing.Point(44, 4)
        Me.pnlpixelplacersettings.Name = "pnlpixelplacersettings"
        Me.pnlpixelplacersettings.Size = New System.Drawing.Size(37, 37)
        Me.pnlpixelplacersettings.TabIndex = 7
        Me.pnlpixelplacersettings.Visible = False
        '
        'lblpixelplacerhelp
        '
        Me.lblpixelplacerhelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpixelplacerhelp.Location = New System.Drawing.Point(3, 26)
        Me.lblpixelplacerhelp.Name = "lblpixelplacerhelp"
        Me.lblpixelplacerhelp.Size = New System.Drawing.Size(307, 67)
        Me.lblpixelplacerhelp.TabIndex = 11
        Me.lblpixelplacerhelp.Text = "This tool does not contain any alterable settings. Simply click on the canvas and" & _
    " a pixel will be placed in the spot you click."
        Me.lblpixelplacerhelp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnpixelplacermovementmode
        '
        Me.btnpixelplacermovementmode.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpixelplacermovementmode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpixelplacermovementmode.Location = New System.Drawing.Point(312, 26)
        Me.btnpixelplacermovementmode.Name = "btnpixelplacermovementmode"
        Me.btnpixelplacermovementmode.Size = New System.Drawing.Size(138, 67)
        Me.btnpixelplacermovementmode.TabIndex = 10
        Me.btnpixelplacermovementmode.Text = "Activate Movement Mode"
        Me.btnpixelplacermovementmode.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(6, 3)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(444, 23)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Pixel Placer Settings"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlpencilsettings
        '
        Me.pnlpencilsettings.Controls.Add(Me.btnpencilsize3)
        Me.pnlpencilsettings.Controls.Add(Me.btnpencilsize2)
        Me.pnlpencilsettings.Controls.Add(Me.btnpencilsize1)
        Me.pnlpencilsettings.Controls.Add(Me.Label14)
        Me.pnlpencilsettings.Location = New System.Drawing.Point(422, 13)
        Me.pnlpencilsettings.Name = "pnlpencilsettings"
        Me.pnlpencilsettings.Size = New System.Drawing.Size(28, 22)
        Me.pnlpencilsettings.TabIndex = 12
        Me.pnlpencilsettings.Visible = False
        '
        'btnpencilsize3
        '
        Me.btnpencilsize3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpencilsize3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpencilsize3.Location = New System.Drawing.Point(298, 30)
        Me.btnpencilsize3.Name = "btnpencilsize3"
        Me.btnpencilsize3.Size = New System.Drawing.Size(127, 54)
        Me.btnpencilsize3.TabIndex = 12
        Me.btnpencilsize3.Text = "Thickest"
        Me.btnpencilsize3.UseVisualStyleBackColor = True
        '
        'btnpencilsize2
        '
        Me.btnpencilsize2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpencilsize2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpencilsize2.Location = New System.Drawing.Point(165, 30)
        Me.btnpencilsize2.Name = "btnpencilsize2"
        Me.btnpencilsize2.Size = New System.Drawing.Size(127, 54)
        Me.btnpencilsize2.TabIndex = 11
        Me.btnpencilsize2.Text = "Thicker"
        Me.btnpencilsize2.UseVisualStyleBackColor = True
        '
        'btnpencilsize1
        '
        Me.btnpencilsize1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpencilsize1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpencilsize1.Location = New System.Drawing.Point(30, 30)
        Me.btnpencilsize1.Name = "btnpencilsize1"
        Me.btnpencilsize1.Size = New System.Drawing.Size(127, 54)
        Me.btnpencilsize1.TabIndex = 10
        Me.btnpencilsize1.Text = "Thin"
        Me.btnpencilsize1.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(6, 3)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(444, 23)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Pencil Settings"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(437, 49)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = resources.GetString("Label6.Text")
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(110, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(269, 24)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "No Tool Currently Selected!"
        '
        'line5
        '
        Me.line5.BackColor = System.Drawing.Color.Black
        Me.line5.Dock = System.Windows.Forms.DockStyle.Top
        Me.line5.Location = New System.Drawing.Point(0, 0)
        Me.line5.Name = "line5"
        Me.line5.Size = New System.Drawing.Size(456, 1)
        Me.line5.TabIndex = 4
        '
        'line3
        '
        Me.line3.BackColor = System.Drawing.Color.Black
        Me.line3.Dock = System.Windows.Forms.DockStyle.Right
        Me.line3.Location = New System.Drawing.Point(456, 0)
        Me.line3.Name = "line3"
        Me.line3.Size = New System.Drawing.Size(1, 100)
        Me.line3.TabIndex = 2
        '
        'pnltools
        '
        Me.pnltools.BackColor = System.Drawing.Color.White
        Me.pnltools.Controls.Add(Me.pnltoolpositioner)
        Me.pnltools.Controls.Add(Me.line1)
        Me.pnltools.Controls.Add(Me.pnltoolpreview)
        Me.pnltools.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnltools.Location = New System.Drawing.Point(0, 0)
        Me.pnltools.Name = "pnltools"
        Me.pnltools.Size = New System.Drawing.Size(120, 566)
        Me.pnltools.TabIndex = 0
        '
        'pnltoolpositioner
        '
        Me.pnltoolpositioner.Controls.Add(Me.btnpixelsetter)
        Me.pnltoolpositioner.Controls.Add(Me.btnpixelplacer)
        Me.pnltoolpositioner.Controls.Add(Me.btnpencil)
        Me.pnltoolpositioner.Controls.Add(Me.btnfloodfill)
        Me.pnltoolpositioner.Controls.Add(Me.btnoval)
        Me.pnltoolpositioner.Controls.Add(Me.btnsquare)
        Me.pnltoolpositioner.Controls.Add(Me.btnlinetool)
        Me.pnltoolpositioner.Controls.Add(Me.btnpaintbrush)
        Me.pnltoolpositioner.Controls.Add(Me.btntexttool)
        Me.pnltoolpositioner.Controls.Add(Me.btneracer)
        Me.pnltoolpositioner.Controls.Add(Me.btnnew)
        Me.pnltoolpositioner.Controls.Add(Me.btnmagnify)
        Me.pnltoolpositioner.Controls.Add(Me.btnopen)
        Me.pnltoolpositioner.Controls.Add(Me.btnsave)
        Me.pnltoolpositioner.Controls.Add(Me.btnundo)
        Me.pnltoolpositioner.Controls.Add(Me.btnredo)
        Me.pnltoolpositioner.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnltoolpositioner.Location = New System.Drawing.Point(0, 0)
        Me.pnltoolpositioner.Name = "pnltoolpositioner"
        Me.pnltoolpositioner.Size = New System.Drawing.Size(119, 466)
        Me.pnltoolpositioner.TabIndex = 2
        '
        'btnpixelsetter
        '
        Me.btnpixelsetter.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadpixelsetter
        Me.btnpixelsetter.FlatAppearance.BorderSize = 0
        Me.btnpixelsetter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpixelsetter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpixelsetter.Location = New System.Drawing.Point(6, 6)
        Me.btnpixelsetter.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnpixelsetter.Name = "btnpixelsetter"
        Me.btnpixelsetter.Size = New System.Drawing.Size(50, 50)
        Me.btnpixelsetter.TabIndex = 2
        Me.btnpixelsetter.UseVisualStyleBackColor = True
        '
        'btnpixelplacer
        '
        Me.btnpixelplacer.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadpixelplacer
        Me.btnpixelplacer.FlatAppearance.BorderSize = 0
        Me.btnpixelplacer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpixelplacer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpixelplacer.Location = New System.Drawing.Point(62, 6)
        Me.btnpixelplacer.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnpixelplacer.Name = "btnpixelplacer"
        Me.btnpixelplacer.Size = New System.Drawing.Size(50, 50)
        Me.btnpixelplacer.TabIndex = 4
        Me.btnpixelplacer.UseVisualStyleBackColor = True
        '
        'btnpencil
        '
        Me.btnpencil.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadpencil
        Me.btnpencil.FlatAppearance.BorderSize = 0
        Me.btnpencil.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpencil.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpencil.Location = New System.Drawing.Point(6, 62)
        Me.btnpencil.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnpencil.Name = "btnpencil"
        Me.btnpencil.Size = New System.Drawing.Size(50, 50)
        Me.btnpencil.TabIndex = 7
        Me.btnpencil.Text = " "
        Me.btnpencil.UseVisualStyleBackColor = True
        '
        'btnfloodfill
        '
        Me.btnfloodfill.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadfloodfill
        Me.btnfloodfill.FlatAppearance.BorderSize = 0
        Me.btnfloodfill.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnfloodfill.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfloodfill.Location = New System.Drawing.Point(62, 62)
        Me.btnfloodfill.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnfloodfill.Name = "btnfloodfill"
        Me.btnfloodfill.Size = New System.Drawing.Size(50, 50)
        Me.btnfloodfill.TabIndex = 11
        Me.btnfloodfill.UseVisualStyleBackColor = True
        '
        'btnoval
        '
        Me.btnoval.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadOval
        Me.btnoval.FlatAppearance.BorderSize = 0
        Me.btnoval.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnoval.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnoval.Location = New System.Drawing.Point(6, 118)
        Me.btnoval.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnoval.Name = "btnoval"
        Me.btnoval.Size = New System.Drawing.Size(50, 50)
        Me.btnoval.TabIndex = 13
        Me.btnoval.Text = " "
        Me.btnoval.UseVisualStyleBackColor = True
        '
        'btnsquare
        '
        Me.btnsquare.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadRectangle
        Me.btnsquare.FlatAppearance.BorderSize = 0
        Me.btnsquare.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsquare.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsquare.Location = New System.Drawing.Point(62, 118)
        Me.btnsquare.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnsquare.Name = "btnsquare"
        Me.btnsquare.Size = New System.Drawing.Size(50, 50)
        Me.btnsquare.TabIndex = 12
        Me.btnsquare.Text = " "
        Me.btnsquare.UseVisualStyleBackColor = True
        '
        'btnlinetool
        '
        Me.btnlinetool.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadlinetool
        Me.btnlinetool.FlatAppearance.BorderSize = 0
        Me.btnlinetool.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlinetool.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlinetool.Location = New System.Drawing.Point(6, 174)
        Me.btnlinetool.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnlinetool.Name = "btnlinetool"
        Me.btnlinetool.Size = New System.Drawing.Size(50, 50)
        Me.btnlinetool.TabIndex = 15
        Me.btnlinetool.Text = " "
        Me.btnlinetool.UseVisualStyleBackColor = True
        '
        'btnpaintbrush
        '
        Me.btnpaintbrush.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadpaintbrush
        Me.btnpaintbrush.FlatAppearance.BorderSize = 0
        Me.btnpaintbrush.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpaintbrush.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpaintbrush.Location = New System.Drawing.Point(62, 174)
        Me.btnpaintbrush.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnpaintbrush.Name = "btnpaintbrush"
        Me.btnpaintbrush.Size = New System.Drawing.Size(50, 50)
        Me.btnpaintbrush.TabIndex = 17
        Me.btnpaintbrush.Text = " "
        Me.btnpaintbrush.UseVisualStyleBackColor = True
        '
        'btntexttool
        '
        Me.btntexttool.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadtexttool
        Me.btntexttool.FlatAppearance.BorderSize = 0
        Me.btntexttool.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntexttool.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntexttool.Location = New System.Drawing.Point(6, 230)
        Me.btntexttool.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btntexttool.Name = "btntexttool"
        Me.btntexttool.Size = New System.Drawing.Size(50, 50)
        Me.btntexttool.TabIndex = 16
        Me.btntexttool.Text = " "
        Me.btntexttool.UseVisualStyleBackColor = True
        '
        'btneracer
        '
        Me.btneracer.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPaderacer
        Me.btneracer.FlatAppearance.BorderSize = 0
        Me.btneracer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btneracer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btneracer.Location = New System.Drawing.Point(62, 230)
        Me.btneracer.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btneracer.Name = "btneracer"
        Me.btneracer.Size = New System.Drawing.Size(50, 50)
        Me.btneracer.TabIndex = 14
        Me.btneracer.Text = " "
        Me.btneracer.UseVisualStyleBackColor = True
        '
        'btnnew
        '
        Me.btnnew.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadnew
        Me.btnnew.FlatAppearance.BorderSize = 0
        Me.btnnew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnnew.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnew.Location = New System.Drawing.Point(6, 286)
        Me.btnnew.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnnew.Name = "btnnew"
        Me.btnnew.Size = New System.Drawing.Size(50, 50)
        Me.btnnew.TabIndex = 6
        Me.btnnew.Text = " "
        Me.btnnew.UseVisualStyleBackColor = True
        '
        'btnmagnify
        '
        Me.btnmagnify.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadmagnify
        Me.btnmagnify.FlatAppearance.BorderSize = 0
        Me.btnmagnify.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmagnify.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmagnify.Location = New System.Drawing.Point(62, 286)
        Me.btnmagnify.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnmagnify.Name = "btnmagnify"
        Me.btnmagnify.Size = New System.Drawing.Size(50, 50)
        Me.btnmagnify.TabIndex = 3
        Me.btnmagnify.Text = " "
        Me.btnmagnify.UseVisualStyleBackColor = True
        '
        'btnopen
        '
        Me.btnopen.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadopen
        Me.btnopen.FlatAppearance.BorderSize = 0
        Me.btnopen.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnopen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnopen.Location = New System.Drawing.Point(6, 342)
        Me.btnopen.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnopen.Name = "btnopen"
        Me.btnopen.Size = New System.Drawing.Size(50, 50)
        Me.btnopen.TabIndex = 10
        Me.btnopen.Text = " "
        Me.btnopen.UseVisualStyleBackColor = True
        '
        'btnsave
        '
        Me.btnsave.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadsave
        Me.btnsave.FlatAppearance.BorderSize = 0
        Me.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(62, 342)
        Me.btnsave.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(50, 50)
        Me.btnsave.TabIndex = 5
        Me.btnsave.Text = " "
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'btnundo
        '
        Me.btnundo.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadundo
        Me.btnundo.FlatAppearance.BorderSize = 0
        Me.btnundo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnundo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnundo.Location = New System.Drawing.Point(6, 398)
        Me.btnundo.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnundo.Name = "btnundo"
        Me.btnundo.Size = New System.Drawing.Size(50, 50)
        Me.btnundo.TabIndex = 8
        Me.btnundo.Text = " "
        Me.btnundo.UseVisualStyleBackColor = True
        '
        'btnredo
        '
        Me.btnredo.BackgroundImage = Global.ShiftOS.My.Resources.Resources.ArtPadredo
        Me.btnredo.FlatAppearance.BorderSize = 0
        Me.btnredo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnredo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnredo.Location = New System.Drawing.Point(62, 398)
        Me.btnredo.Margin = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.btnredo.Name = "btnredo"
        Me.btnredo.Size = New System.Drawing.Size(50, 50)
        Me.btnredo.TabIndex = 9
        Me.btnredo.Text = " "
        Me.btnredo.UseVisualStyleBackColor = True
        '
        'line1
        '
        Me.line1.BackColor = System.Drawing.Color.Black
        Me.line1.Dock = System.Windows.Forms.DockStyle.Right
        Me.line1.Location = New System.Drawing.Point(119, 0)
        Me.line1.Name = "line1"
        Me.line1.Size = New System.Drawing.Size(1, 466)
        Me.line1.TabIndex = 1
        '
        'pnltoolpreview
        '
        Me.pnltoolpreview.Controls.Add(Me.Label13)
        Me.pnltoolpreview.Controls.Add(Me.picpreview)
        Me.pnltoolpreview.Controls.Add(Me.lbltoolselected)
        Me.pnltoolpreview.Controls.Add(Me.line4)
        Me.pnltoolpreview.Controls.Add(Me.line2)
        Me.pnltoolpreview.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnltoolpreview.Location = New System.Drawing.Point(0, 466)
        Me.pnltoolpreview.Name = "pnltoolpreview"
        Me.pnltoolpreview.Size = New System.Drawing.Size(120, 100)
        Me.pnltoolpreview.TabIndex = 0
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(3, 79)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(113, 21)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Preview"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picpreview
        '
        Me.picpreview.Location = New System.Drawing.Point(24, 27)
        Me.picpreview.Name = "picpreview"
        Me.picpreview.Size = New System.Drawing.Size(70, 50)
        Me.picpreview.TabIndex = 5
        Me.picpreview.TabStop = False
        '
        'lbltoolselected
        '
        Me.lbltoolselected.BackColor = System.Drawing.Color.Transparent
        Me.lbltoolselected.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltoolselected.Location = New System.Drawing.Point(3, 3)
        Me.lbltoolselected.Name = "lbltoolselected"
        Me.lbltoolselected.Size = New System.Drawing.Size(113, 21)
        Me.lbltoolselected.TabIndex = 4
        Me.lbltoolselected.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'line4
        '
        Me.line4.BackColor = System.Drawing.Color.Black
        Me.line4.Dock = System.Windows.Forms.DockStyle.Top
        Me.line4.Location = New System.Drawing.Point(0, 0)
        Me.line4.Name = "line4"
        Me.line4.Size = New System.Drawing.Size(119, 1)
        Me.line4.TabIndex = 3
        '
        'line2
        '
        Me.line2.BackColor = System.Drawing.Color.Black
        Me.line2.Dock = System.Windows.Forms.DockStyle.Right
        Me.line2.Location = New System.Drawing.Point(119, 0)
        Me.line2.Name = "line2"
        Me.line2.Size = New System.Drawing.Size(1, 100)
        Me.line2.TabIndex = 2
        '
        'pgleft
        '
        Me.pgleft.BackColor = System.Drawing.Color.Gray
        Me.pgleft.Controls.Add(Me.pgbottomlcorner)
        Me.pgleft.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgleft.Location = New System.Drawing.Point(0, 30)
        Me.pgleft.Name = "pgleft"
        Me.pgleft.Size = New System.Drawing.Size(2, 568)
        Me.pgleft.TabIndex = 21
        '
        'pgbottomlcorner
        '
        Me.pgbottomlcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomlcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomlcorner.Location = New System.Drawing.Point(0, 566)
        Me.pgbottomlcorner.Name = "pgbottomlcorner"
        Me.pgbottomlcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomlcorner.TabIndex = 14
        '
        'pgright
        '
        Me.pgright.BackColor = System.Drawing.Color.Gray
        Me.pgright.Controls.Add(Me.pgbottomrcorner)
        Me.pgright.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgright.Location = New System.Drawing.Point(800, 30)
        Me.pgright.Name = "pgright"
        Me.pgright.Size = New System.Drawing.Size(2, 568)
        Me.pgright.TabIndex = 22
        '
        'pgbottomrcorner
        '
        Me.pgbottomrcorner.BackColor = System.Drawing.Color.Red
        Me.pgbottomrcorner.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottomrcorner.Location = New System.Drawing.Point(0, 566)
        Me.pgbottomrcorner.Name = "pgbottomrcorner"
        Me.pgbottomrcorner.Size = New System.Drawing.Size(2, 2)
        Me.pgbottomrcorner.TabIndex = 15
        '
        'titlebar
        '
        Me.titlebar.BackColor = System.Drawing.Color.Gray
        Me.titlebar.Controls.Add(Me.minimizebutton)
        Me.titlebar.Controls.Add(Me.pnlicon)
        Me.titlebar.Controls.Add(Me.rollupbutton)
        Me.titlebar.Controls.Add(Me.closebutton)
        Me.titlebar.Controls.Add(Me.lbtitletext)
        Me.titlebar.Controls.Add(Me.pgtoplcorner)
        Me.titlebar.Controls.Add(Me.pgtoprcorner)
        Me.titlebar.Dock = System.Windows.Forms.DockStyle.Top
        Me.titlebar.ForeColor = System.Drawing.Color.White
        Me.titlebar.Location = New System.Drawing.Point(0, 0)
        Me.titlebar.Name = "titlebar"
        Me.titlebar.Size = New System.Drawing.Size(802, 30)
        Me.titlebar.TabIndex = 19
        '
        'minimizebutton
        '
        Me.minimizebutton.BackColor = System.Drawing.Color.Black
        Me.minimizebutton.Location = New System.Drawing.Point(246, 5)
        Me.minimizebutton.Name = "minimizebutton"
        Me.minimizebutton.Size = New System.Drawing.Size(22, 22)
        Me.minimizebutton.TabIndex = 24
        '
        'pnlicon
        '
        Me.pnlicon.BackColor = System.Drawing.Color.Transparent
        Me.pnlicon.Image = Global.ShiftOS.My.Resources.Resources.iconArtpad
        Me.pnlicon.Location = New System.Drawing.Point(8, 8)
        Me.pnlicon.Name = "pnlicon"
        Me.pnlicon.Size = New System.Drawing.Size(16, 16)
        Me.pnlicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pnlicon.TabIndex = 24
        Me.pnlicon.TabStop = False
        Me.pnlicon.Visible = False
        '
        'rollupbutton
        '
        Me.rollupbutton.BackColor = System.Drawing.Color.Black
        Me.rollupbutton.Location = New System.Drawing.Point(274, 3)
        Me.rollupbutton.Name = "rollupbutton"
        Me.rollupbutton.Size = New System.Drawing.Size(22, 22)
        Me.rollupbutton.TabIndex = 22
        '
        'closebutton
        '
        Me.closebutton.BackColor = System.Drawing.Color.Black
        Me.closebutton.Location = New System.Drawing.Point(302, 3)
        Me.closebutton.Name = "closebutton"
        Me.closebutton.Size = New System.Drawing.Size(22, 22)
        Me.closebutton.TabIndex = 20
        '
        'lbtitletext
        '
        Me.lbtitletext.AutoSize = True
        Me.lbtitletext.BackColor = System.Drawing.Color.Transparent
        Me.lbtitletext.Font = New System.Drawing.Font("Felix Titling", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbtitletext.Location = New System.Drawing.Point(26, 7)
        Me.lbtitletext.Name = "lbtitletext"
        Me.lbtitletext.Size = New System.Drawing.Size(76, 18)
        Me.lbtitletext.TabIndex = 19
        Me.lbtitletext.Text = "Artpad"
        '
        'pgtoplcorner
        '
        Me.pgtoplcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoplcorner.Dock = System.Windows.Forms.DockStyle.Left
        Me.pgtoplcorner.Location = New System.Drawing.Point(0, 0)
        Me.pgtoplcorner.Name = "pgtoplcorner"
        Me.pgtoplcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoplcorner.TabIndex = 17
        '
        'pgtoprcorner
        '
        Me.pgtoprcorner.BackColor = System.Drawing.Color.Red
        Me.pgtoprcorner.Dock = System.Windows.Forms.DockStyle.Right
        Me.pgtoprcorner.Location = New System.Drawing.Point(800, 0)
        Me.pgtoprcorner.Name = "pgtoprcorner"
        Me.pgtoprcorner.Size = New System.Drawing.Size(2, 30)
        Me.pgtoprcorner.TabIndex = 16
        '
        'pgbottom
        '
        Me.pgbottom.BackColor = System.Drawing.Color.Gray
        Me.pgbottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pgbottom.Location = New System.Drawing.Point(2, 596)
        Me.pgbottom.Name = "pgbottom"
        Me.pgbottom.Size = New System.Drawing.Size(798, 2)
        Me.pgbottom.TabIndex = 23
        '
        'tmrcodepointcooldown
        '
        Me.tmrcodepointcooldown.Interval = 10000
        '
        'tmrshowearnedcodepoints
        '
        Me.tmrshowearnedcodepoints.Interval = 3000
        '
        'pullbs
        '
        Me.pullbs.Interval = 1
        '
        'pullbottom
        '
        Me.pullbottom.Interval = 1
        '
        'pullside
        '
        Me.pullside.Interval = 1
        '
        'ArtPad
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(802, 598)
        Me.Controls.Add(Me.pgcontents)
        Me.Controls.Add(Me.pgbottom)
        Me.Controls.Add(Me.pgleft)
        Me.Controls.Add(Me.pgright)
        Me.Controls.Add(Me.titlebar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MinimumSize = New System.Drawing.Size(502, 398)
        Me.Name = "ArtPad"
        Me.Text = "ArtPad"
        Me.TopMost = True
        Me.pgcontents.ResumeLayout(False)
        Me.pnldrawingbackground.ResumeLayout(False)
        Me.pnlpalletsize.ResumeLayout(False)
        Me.pnlpalletsize.PerformLayout()
        Me.pnlinitialcanvassettings.ResumeLayout(False)
        Me.pnlinitialcanvassettings.PerformLayout()
        CType(Me.picdrawingdisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlbottompanel.ResumeLayout(False)
        Me.pnlpallet.ResumeLayout(False)
        Me.flowcolours.ResumeLayout(False)
        Me.pnltoolproperties.ResumeLayout(False)
        Me.pnltoolproperties.PerformLayout()
        Me.pnltexttoolsettings.ResumeLayout(False)
        Me.pnltexttoolsettings.PerformLayout()
        Me.pnlpixelsettersettings.ResumeLayout(False)
        Me.pnlpixelsettersettings.PerformLayout()
        Me.pnlpaintbrushtoolsettings.ResumeLayout(False)
        Me.pnlpaintbrushtoolsettings.PerformLayout()
        Me.pnllinetoolsettings.ResumeLayout(False)
        Me.pnllinetoolsettings.PerformLayout()
        Me.pnlmagnifiersettings.ResumeLayout(False)
        Me.pnleracertoolsettings.ResumeLayout(False)
        Me.pnleracertoolsettings.PerformLayout()
        Me.pnlfloodfillsettings.ResumeLayout(False)
        Me.pnlovaltoolsettings.ResumeLayout(False)
        Me.pnlovaltoolsettings.PerformLayout()
        Me.pnlsquaretoolsettings.ResumeLayout(False)
        Me.pnlsquaretoolsettings.PerformLayout()
        Me.pnlpixelplacersettings.ResumeLayout(False)
        Me.pnlpencilsettings.ResumeLayout(False)
        Me.pnltools.ResumeLayout(False)
        Me.pnltoolpositioner.ResumeLayout(False)
        Me.pnltoolpreview.ResumeLayout(False)
        CType(Me.picpreview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pgleft.ResumeLayout(False)
        Me.pgright.ResumeLayout(False)
        Me.titlebar.ResumeLayout(False)
        Me.titlebar.PerformLayout()
        CType(Me.pnlicon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pgcontents As System.Windows.Forms.Panel
    Friend WithEvents pgleft As System.Windows.Forms.Panel
    Friend WithEvents pgbottomlcorner As System.Windows.Forms.Panel
    Friend WithEvents pgright As System.Windows.Forms.Panel
    Friend WithEvents pgbottomrcorner As System.Windows.Forms.Panel
    Friend WithEvents titlebar As System.Windows.Forms.Panel
    Friend WithEvents minimizebutton As System.Windows.Forms.Panel
    Friend WithEvents pnlicon As System.Windows.Forms.PictureBox
    Friend WithEvents rollupbutton As System.Windows.Forms.Panel
    Friend WithEvents closebutton As System.Windows.Forms.Panel
    Friend WithEvents lbtitletext As System.Windows.Forms.Label
    Friend WithEvents pgtoplcorner As System.Windows.Forms.Panel
    Friend WithEvents pgtoprcorner As System.Windows.Forms.Panel
    Friend WithEvents pgbottom As System.Windows.Forms.Panel
    Friend WithEvents pnlbottompanel As System.Windows.Forms.Panel
    Friend WithEvents pnltoolproperties As System.Windows.Forms.Panel
    Friend WithEvents pnlpallet As System.Windows.Forms.Panel
    Friend WithEvents line3 As System.Windows.Forms.Panel
    Friend WithEvents line5 As System.Windows.Forms.Panel
    Friend WithEvents line6 As System.Windows.Forms.Panel
    Friend WithEvents pnldrawingbackground As System.Windows.Forms.Panel
    Friend WithEvents picdrawingdisplay As System.Windows.Forms.PictureBox
    Friend WithEvents btnpixelsetter As System.Windows.Forms.Button
    Friend WithEvents pnlpixelsettersettings As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnpixelsettersetpixel As System.Windows.Forms.Button
    Friend WithEvents txtpixelsetterycoordinate As System.Windows.Forms.TextBox
    Friend WithEvents txtpixelsetterxcoordinate As System.Windows.Forms.TextBox
    Friend WithEvents btnmagnify As System.Windows.Forms.Button
    Friend WithEvents colourpallet32 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet31 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet30 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet29 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet28 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet26 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet25 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet23 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet21 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet19 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet8 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet6 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet16 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet14 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet7 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet5 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet10 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet9 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet11 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet12 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet13 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet15 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet4 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet3 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet17 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet18 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet20 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet22 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet24 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet2 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet27 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents colourpallet1 As System.Windows.Forms.Panel
    Friend WithEvents pnlmagnifiersettings As System.Windows.Forms.Panel
    Friend WithEvents btnzoomin As System.Windows.Forms.Button
    Friend WithEvents lblzoomlevel As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnzoomout As System.Windows.Forms.Button
    Friend WithEvents btnpixelplacer As System.Windows.Forms.Button
    Friend WithEvents pnlpixelplacersettings As System.Windows.Forms.Panel
    Friend WithEvents btnpixelplacermovementmode As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblpixelplacerhelp As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnnew As System.Windows.Forms.Button
    Friend WithEvents flowcolours As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents btnpencil As System.Windows.Forms.Button
    Friend WithEvents pnlpencilsettings As System.Windows.Forms.Panel
    Friend WithEvents btnpencilsize3 As System.Windows.Forms.Button
    Friend WithEvents btnpencilsize2 As System.Windows.Forms.Button
    Friend WithEvents btnpencilsize1 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnfloodfill As System.Windows.Forms.Button
    Friend WithEvents pnlfloodfillsettings As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents btnsquare As System.Windows.Forms.Button
    Friend WithEvents pnlsquaretoolsettings As System.Windows.Forms.Panel
    Friend WithEvents txtsquareborderwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents btnsquarefillonoff As System.Windows.Forms.Button
    Friend WithEvents pnlsquarefillcolour As System.Windows.Forms.Panel
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents btnoval As System.Windows.Forms.Button
    Friend WithEvents pnlovaltoolsettings As System.Windows.Forms.Panel
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents btnovalfillonoff As System.Windows.Forms.Button
    Friend WithEvents pnlovalfillcolour As System.Windows.Forms.Panel
    Friend WithEvents txtovalborderwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents pnltools As System.Windows.Forms.Panel
    Friend WithEvents pnltoolpositioner As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents line1 As System.Windows.Forms.Panel
    Friend WithEvents pnltoolpreview As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents picpreview As System.Windows.Forms.PictureBox
    Friend WithEvents lbltoolselected As System.Windows.Forms.Label
    Friend WithEvents line4 As System.Windows.Forms.Panel
    Friend WithEvents line2 As System.Windows.Forms.Panel
    Friend WithEvents btnopen As System.Windows.Forms.Button
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents btnundo As System.Windows.Forms.Button
    Friend WithEvents btnredo As System.Windows.Forms.Button
    Friend WithEvents btneracer As System.Windows.Forms.Button
    Friend WithEvents btnlinetool As System.Windows.Forms.Button
    Friend WithEvents pnllinetoolsettings As System.Windows.Forms.Panel
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtlinewidth As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents pnleracertoolsettings As System.Windows.Forms.Panel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents btneracersquare As System.Windows.Forms.Button
    Friend WithEvents btneracercircle As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txteracersize As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents btntexttool As System.Windows.Forms.Button
    Friend WithEvents btnpaintbrush As System.Windows.Forms.Button
    Friend WithEvents pnltexttoolsettings As System.Windows.Forms.Panel
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtdrawtextsize As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents combodrawtextfont As System.Windows.Forms.ComboBox
    Friend WithEvents txtdrawstringtext As System.Windows.Forms.TextBox
    Friend WithEvents combofontstyle As System.Windows.Forms.ComboBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents pnlpaintbrushtoolsettings As System.Windows.Forms.Panel
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents btnpaintsquareshape As System.Windows.Forms.Button
    Friend WithEvents btnpaintcircleshape As System.Windows.Forms.Button
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txtpaintbrushsize As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents tmrcodepointcooldown As System.Windows.Forms.Timer
    Friend WithEvents tmrshowearnedcodepoints As System.Windows.Forms.Timer
    Friend WithEvents pnlpalletsize As System.Windows.Forms.Panel
    Friend WithEvents btnchangesizecancel As System.Windows.Forms.Button
    Friend WithEvents btnsetsize As System.Windows.Forms.Button
    Friend WithEvents txtcolorpalletheight As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txtcolorpalletwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents pnlinitialcanvassettings As System.Windows.Forms.Panel
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btncreate As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lbltotalpixels As System.Windows.Forms.Label
    Friend WithEvents txtnewcanvasheight As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtnewcanvaswidth As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents colourpallet33 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet34 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet35 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet36 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet37 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet38 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet39 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet40 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet41 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet42 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet43 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet44 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet45 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet46 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet47 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet48 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet49 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet50 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet51 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet52 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet53 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet54 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet55 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet56 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet57 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet58 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet59 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet60 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet61 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet62 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet63 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet64 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet65 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet66 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet67 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet68 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet69 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet70 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet71 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet72 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet73 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet74 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet75 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet76 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet77 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet78 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet79 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet80 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet81 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet82 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet83 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet84 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet85 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet86 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet87 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet88 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet89 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet90 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet91 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet92 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet93 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet94 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet95 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet96 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet97 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet98 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet99 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet100 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet101 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet102 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet103 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet104 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet105 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet106 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet107 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet108 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet109 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet110 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet111 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet112 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet113 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet114 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet115 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet116 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet117 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet118 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet119 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet120 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet121 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet122 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet123 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet124 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet125 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet126 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet127 As System.Windows.Forms.Panel
    Friend WithEvents colourpallet128 As System.Windows.Forms.Panel
    Friend WithEvents txttopspace As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtsidespace As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents pullbs As System.Windows.Forms.Timer
    Friend WithEvents pullbottom As System.Windows.Forms.Timer
    Friend WithEvents pullside As System.Windows.Forms.Timer
End Class
