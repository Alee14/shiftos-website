# Development save file

This is a save file with everything unlocked. The `ShiftOS` directory is C:\ShiftOS\
