This repo is an archive repo of the original ShiftOS codebase.

Although the game was open-source and released under the Apache 2 license, I use this code for other things like testing my code before actually using it in something better. So, I wouldn't trust this source code. Plus, the game's deprecated.
